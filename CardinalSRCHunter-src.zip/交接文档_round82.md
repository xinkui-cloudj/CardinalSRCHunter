# 交接文档 · round82（用户实机反馈 4 项修复）

> 日期：2026-10-19　工作区：`/storage/emulated/0/Audiobooks/src/bt-src-hunter`
> 上一轮：`交接文档_round81.md`（观测性 / 目标不落盘 / AI 黑框）
> 本轮定性：**round81 交付后用户实机测试，报 4 项问题；本轮不是新功能，是修缺陷 + 一个设计纠偏。**

---

## 1. 用户原话（4 项反馈，按原意转写）

1. **黑框不应放在下面**，应该**竖着放在输出框右边**才好看；标题 `AI 输出 / 分析（黑框）` 里的「（黑框）」要删掉。
2. **AI 输出框根本不会输出任何内容**是什么鬼？去修复。
3. （截图划线处）**不会像之前那样列能力清单**，我怎么知道有没有用工具？
4. 输出比之前**简略**，且**全是 0 命中**，感觉功能已经受损出问题了。

用户随后拍板：**A 方案**（AI 关闭时黑框也要有内容）+ **④ 一起修**。

---

## 2. 四项真因（全部已实证，不是猜测）

| # | 现象 | 真因 | 性质 |
|---|---|---|---|
| ① | 黑框在下、标题带「（黑框）」 | `ui/gui.py` 用 `ai_frame.pack(fill="both", expand=False)` 排在主框下方；标题字符串硬编码含「（黑框）」 | 纯 UI |
| ② | AI 框永远空白 | `takeover.enabled=false` 时 `agent_loop.py` 只打一行「接管未启用…跳过」，**不产生任何 `bt.agent` 日志**；黑框按 logger 名分流，自然无内容。空白本身「如实」，但**无法区分「没启用」与「框坏了」** | **设计缺陷** |
| ③ | 不列能力清单 | `core/engine.py` 的 `list_capabilities()` 调用**写在 `if takeover_conf().get("enabled"):` 分支内部**，AI 一关整段不执行 → 清单永不出现 | **真 bug** |
| ④ | 输出简略 / 全 0 命中 | `lab/verify_round73b.py` 自带 8126 端口自测扫描，`dicts.SENSITIVE_PATHS=['/none1']` 等**改完不复原**，且自测日志**写进生产 `logs/bt-*.log`** → 用户在自己日志里看到「字典 1 条 / 阶段 1-7 全 0」，误以为扫描功能坏了 | **回归脚本污染** |

### ④ 的两层细节（关键，别再踩）
- `'/none1'` 是**字符串**，而 `dicts.SENSITIVE_PATHS` 元素是 `(path, name, level)` 三元组。传字符串会导致
  `probe_sensitive_paths` 解包时报 `too many values to unpack (expected 3)`（`'/none1'` 有 6 个字符），
  于是每个路径都异常，**命中必然为 0**。
- `regall.sh` 是 `for f in …; python3 -u "$f"`，**每个脚本独立子进程**，`dicts` 不可能跨进程污染。
  所以「全 0」不是回归毒害主流程，而是**该脚本自己的日志串进了生产日志文件**——这点曾误判过一次，记录在此。

---

## 3. 修复落点（本轮改了哪些文件、改了什么）

### ① + ② `ui/gui.py`
- 标题字符串去掉「（黑框）」→ `text="AI 输出 / 分析"`。
- 布局由「上下 pack」改为**左右 grid 分栏**：
  ```python
  _logwrap = ttk.Frame(root)
  _logwrap.pack(fill="both", expand=True, padx=8, pady=(8, 0))
  _logwrap.columnconfigure(0, weight=72, uniform="logcols")
  _logwrap.columnconfigure(1, weight=28, uniform="logcols")
  _logwrap.rowconfigure(0, weight=1)
  main_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
  ai_frame.grid(row=0, column=1, sticky="nsew")
  ```
- `_make_logbox(parent, height, bg=None, fg=None, wrap=None)` 新增 `wrap` 参数；
  AI 框传 `wrap="word"`（右侧窄列必须按词换行，否则横向溢出）。
- 新增 `_ai_hint_if_off(txt)`：状态串以 `○` 开头（未连接/未启用）时返回一行指引；
  `_write_ai_head()` 把它拼成第 2 行。**黑框从此永不空白。**

### ③ `core/engine.py`
- 把能力清单盘点到 `if` 分支外**无条件执行**：
  ```python
  _tk_on = bool(_agent_loop.takeover_conf(self).get("enabled"))
  try:
      _cl = _cap.list_capabilities(self)
      log.info("能力清单：SKILL %d 个已启用｜MCP 服务 %d 个｜MCP 工具 %d 个%s", ...)
      for _sk in _cl["skills"]:
          if isinstance(_sk, dict):
              log.info("  能力清单·SKILL：%s（%s）", _sk.get("name", "?"), _sk.get("kind", "-"))
          else:
              log.info("  能力清单·SKILL：%s", _sk)
      if not _tk_on:
          log.info("能力清单·AI 未启用：以上清单本轮不会被模型调用（要 AI 参与请在 Web 控制台开启 AI 接管）；确定性探测不受影响。")
  except Exception as _ce:
      log.debug("能力清单读取跳过：%s", _ce)
  if _tk_on:
      self._load_mcp_tools()
  ```
- **`_load_mcp_tools()` 仍留在 `if _tk_on:` 内**（加载工具才需要 AI 参与，不能无条件跑）。

### ④ `lab/verify_round73b.py`
- `dicts` 篡改前**快照**，脚本尾部 `for _k, _v in _DICT_SNAPSHOT.items(): setattr(dicts, _k, _v)` 复原。
- `SENSITIVE_PATHS = [('/none1', 'B6 占位项', 'info')]` —— **合法三元组**，不再触发 unpack 异常。
- 新增 `_VLOG = tempfile.mkdtemp(prefix='v73b_log_')` + `logger.init(log_dir=_VLOG)`，
  自测日志**彻底脱离生产 `logs/`**。

### 版本戳
- `ui/web.py`：`_APP_VER = "r82"`（原 r81）。
- `build/make_sfx_exe.py`：`BUILD_ID = "r82-" + time.strftime(...)`（原 `"r81-"`）。
- 新增 `lab/verify_round82.py`，并已登记进 `lab/regall.sh`（紧随 `verify_round81.py`）。

---

## 4. 验证结果

| 验证 | 结果 |
|---|---|
| `python3 -m py_compile ui/gui.py core/engine.py lab/verify_round73b.py` | 全通过 |
| `lab/verify_round82.py`（A gui 16 / B engine 5 / C 73b 5 / D 编译 3） | **PASS=29 FAIL=0** |
| `lab/verify_round73b.py` 单跑 | **PASS=20 FAIL=0**，且**生产日志 md5 与行数零变化**（实测 `PROD_LOG_UNTOUCHED`，3591 行不变） |
| `lab/verify_round81.py` | **PASS=49 FAIL=0**（A12 断言原写死 `fg=None):`，因 `_make_logbox` 新增 `wrap` 参数而失配，已改为前缀匹配 `fg=None`，语义未变） |
| `lab/verify_round80.py` / `verify_round78.py` | 84/0、66/0 |
| ③ 运行时实证 | AI 强制关闭下实跑扫描，日志出现 4 行：总清单 + 2 条 SKILL 明细（`字典工程师增强（words）`、`验证工程师增强（trigger）`）+「AI 未启用」说明 |
| 全量回归 `bash lab/regall.sh` | `PASS=3611 FAIL=4`（重打包前，4 条全属 80/81 版本戳预期失效）→ 修完后 `FAIL=0` |
| 版本戳连锁 r81→r82 | `ui/web.py::_APP_VER="r82"`、`build/make_sfx_exe.py::BUILD_ID="r82-"`、`lab/check_exe_r81.py`→`check_exe_r82.py`（r82: 命中 13 次、r81: 0 次）、`lab/regall.sh` 全量 sed（EX82_DIR / verify82）、`lab/verify_*.py` 历史脚本批量替换 |
| 版本戳断言语义化 | `verify_round80.py` F1/F2、`verify_round81.py` E1/E2/E13 断言标签 `= r81` → `= current`（值仍锁 `"r82"`）；`CEX.count("r82:") >= 5` 基线改 `>= 1`（真实命中 13） |
| 三项回归实测 | `verify_round80.py` 84/0、`verify_round81.py` 49/0、`verify_round82.py` 29/0 |
| 重打包 | exe `CardinalSRCHunter.exe` 21701629 B md5 `38bb2ab24bb9235579dec5059fb23d3d`；zip `CardinalSRCHunter-src.zip` 919710 B / 178 项 md5 `69c113bb79d377f7a30f1bf80eb17aa7`；`MD5SUMS.txt` 已刷新三行 |

---

## 5. 本轮教训（写进铁律）

19. **回归脚本不许改全局单例且不复原**。`dicts` 之类模块级单例被改成单元素，同进程后续逻辑全废；要么 `try/finally` 复原，要么干脆别改（复用真实字典 + 只断言计数）。
20. **读日志判断实机行为，必须排除回归自测噪音**。用户报「全 0 命中」时，先确认那段日志是 `who` 写的——本次真凶就是自测脚本，不是扫描器。
21. **「能力清单」这类只读盘点必须与功能开关解耦**。写进 `if enabled:` 里，开关一关用户就以为功能坏了。只读盘点无条件做，需要外部资源的加载（`_load_mcp_tools`）才留在开关内。
22. **自测脚本自带扫描 → 必须独立 log_dir**。改 `dicts` 只解决「命中数不对」，不解决「日志串台」；两件事要一起修。
23. **旧回归断言写死函数签名会随参数增加而假红**。断言应匹配语义前缀（`fg=None`），不匹配完整签名（`fg=None):`）。

---

## 6. 接手 checklist
- [ ] 读 `进度.md` round82 段落 + 本文档 + `项目总结报告.md` §22。
- [ ] `python3 lab/verify_round82.py` 应 `PASS=29 FAIL=0`；`lab/verify_round81.py` 应 `PASS=49 FAIL=0`。
- [ ] 单跑 `lab/verify_round73b.py` 后对比 `logs/bt-*.log` 行数——**必须零变化**（这是 ④ 的活体验证）。
- [ ] `bash lab/regall.sh`，末行须 `REGALL TOTAL PASS=… FAIL=0 SCRIPTS_FAILED=0`。
- [ ] 若刚改过源码，**先重打包再跑 EXE 复核组**，否则 `check_exe_r81.py` 必红。
---
## 7. 实机事故追加：双击 EXE 后黑框一闪即退（hotfix r82b）
### 7.1 现象
用户实机双击 r82 EXE：进度条跑满 → 黑框闪一下 → 无任何窗口、无弹窗、进程消失。
### 7.2 真因（代码级）
`ui/gui.py` 第 901 行：
```python
ai_frame = ttk.LabelFrame(root, text="AI 输出 / 分析", padding=2)
ai_frame.grid(row=0, column=1, sticky="nsew")
```
AI 框的父容器写成了 **`root`**，却用 `.grid()` 布局；而 `root` 下 `top` / `bar` / `opts` /
`opts2` / `ai_conn_frame` / `_logwrap` / `ask_bar` **全部是 `pack()`**。
Tk 铁律：**同一父容器只能由一种几何管理器管理子控件**，混用即在 `mainloop()`
之前抛 `TclError: cannot use geometry manager grid inside . which already has
slaves managed by pack`。因为 `run.bat` 用 `pythonw.exe` 启动（无控制台），
异常信息无处输出，用户侧只剩「黑框闪一下」。
### 7.3 修复
`root` → `_logwrap`（AI 框与主输出框同属 grid 分栏容器）：
```python
ai_frame = ttk.LabelFrame(_logwrap, text="AI 输出 / 分析", padding=2)
```
### 7.4 防回归
- 新增 `lab/check_geometry.py`：静态扫描 `ui/gui.py`，按「变量→父容器」建表，
  统计每个父容器上的 pack/grid 使用，**任一父容器两种混用即 FAIL**；
  并专项断言 `ai_frame` 父容器为 `_logwrap`、`_logwrap` 自身用 pack 挂 root、
  旧 `ai_frame = ttk.LabelFrame(root` 字面量不得残留。
- `lab/verify_round82.py` 增加 **E 组 5 条**（E1 混用检查 / E2 ai_frame 父容器 /
  E3 _logwrap 用 pack / E4 无 root 版残留 / E5 check_geometry 已入库），
  现为 **PASS=34 FAIL=0**。
### 7.5 新铁律
24. **改 Tk 布局必须查父容器归属**。grid 化一个控件前，先确认它的 master 是不是
    已经全 pack 的容器；分栏要先把子控件挂进新的 grid 容器，而不是继续挂 root。
25. **回归脚本无法覆盖「Tk 运行期 TclError」**。`py_compile` 只验语法，
    几何管理器冲突是运行期错误，必须靠静态结构检查（`lab/check_geometry.py`）兜住。
26. **pythonw 下的启动失败必然静默**。凡 GUI 启动路径改动，交付前必须同时看
    `main.py::_gui_crash_log` 落点（`logs/gui_crash.log`）是否仍有效。
