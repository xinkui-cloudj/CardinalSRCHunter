# -*- coding: utf-8 -*-
"""tkinter 图形界面。

设计：
- 扫描在后台线程跑，主线程只刷新 UI，避免卡死；
- 日志通过队列回传（logging.Handler → queue → after() 轮询）；
- 顶部按钮：诊断环境 / 一键安装 / 开始扫描 / 自更新（装新东西）/ 打开报告；
- 扫描选项区（强度档、主动检测、PoC 复现、弱口令、并发、单主机上限）以勾选框
  暴露，点扫描时写回 Config 对象，无需手改 config.json；
- 右侧实时日志；底部进度条。
- 无 tkinter 环境下自动降级为提示（不抛栈）。

本层同样不含检测逻辑，只调 engine / bootstrap。
"""
import os
import queue
import subprocess
import sys
import threading
import time

from core import config as cfg
from core import logger
from core.db import DB

log = logger.get("bt.gui")


# ------------------------------------------------------------
# 日志 → 队列（线程安全）
# ------------------------------------------------------------
class QueueHandler(object):
    """把日志塞进 queue，供 UI 线程消费。"""

    def __init__(self, q):
        self.q = q

    def write(self, text):
        if text and text.strip():
            self.q.put(text.rstrip())

    def flush(self):
        pass


# round81 D15：AI 黑框首行的固定状态行前缀（唯一会被覆盖的那一行）。
_AI_HEAD_PREFIX = "【AI 状态】"

# round83 C6：日志框行的绝对上限。长扫描（多主机 × 多轮 AI）日志会无限
# 堆积，Tk 文本框越大滚动越卡，故超过即裁掉最早的行，只留尾部。
_MAX_LOG_LINES = 2000

# round81 D12：哪些 logger 的输出算「AI 那一路」。
# 全项目实测的 logger 名：bt.agent / bt.cli / bt.db / bt.engine / bt.gui /
# bt.http / bt.poc / bt.probe / bt.recon / bt.report / bt.scope /
# bt.templates / bt.verify / bt.vuln。其中 AI 接管与技能调用都记在
# bt.agent（tools/agent_loop.py），MCP 探活同样走它，故这一路即"AI 输出"。
# round87e: bt.ai.trace was MISSING here, so every trace line
# (rounds / thinking / tool call + result) went to the MAIN box
# and the AI box stayed silent -> user reported "scan shows no
# thinking, no tool calls, no analysis". Add it (bt.ai.* already
# matches by prefix for bt.ai.x, but trace is a SIBLING name).
_AI_LOG_PREFIXES = ("bt.agent", "bt.skill", "bt.mcp", "bt.ai")


def _is_ai_log_name(name):
    """判断一条日志是否属于「AI 输出」（round81 D12）。

    按 logger 名分派，**不做正文关键词匹配** —— 正文匹配会被用户自己
    填的目标串、被扫到的 URL 误伤（例如目标域名里含 ai 三字母）。
    """
    n = str(name or "")
    for _p in _AI_LOG_PREFIXES:
        if n == _p or n.startswith(_p + "."):
            return True
    return False


def _install_queue_logging(q, q_ai=None):
    """把 bt.* 日志分流进两个队列（round81 D12）。

    q    -> 主输出框（引擎 / 检测 / 报告等常规日志）
    q_ai -> AI 黑框（初见 bt.agent / bt.skill / bt.mcp / bt.ai）
    为 None 时全部进 q，保持向后兼容（老调用点与单测只传一个参数）。
    """
    import logging

    class _H(logging.Handler):
        def emit(self, record):
            try:
                line = self.format(record)
                if q_ai is not None and _is_ai_log_name(record.name):
                    q_ai.put(line)
                else:
                    q.put(line)
            except Exception:
                pass

    h = _H()
    h.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                                     "%H:%M:%S"))
    logging.getLogger("bt").addHandler(h)
    return h



# ------------------------------------------------------------
# round75：AI 就绪度文案 / 扫描会话续跑（模块级，便于静态断言）
# ------------------------------------------------------------
def _ai_status_line(ai, tk_conf, key_present):
    """AI 就绪度单行文案，与 Web 控制台 renderAIStatus 同口径。

    三个闸门：ai.enabled / ai.online / takeover.enabled；
    再加端点 / 模型 / 密钥是否存在。任一缺失即判「未就绪」，
    此时扫描不会调用 AI —— 所以明确打印「不消耗 token」，避免误解。

    round76 修正：``tk_conf`` 可能是**整份配置**（含顶层 ``takeover`` 段），
    也可能是**已展开的 takeover 段**本身。旧实现只认前者，桌面端把
    ``Config.takeover()`` 的返回值（已展开）传进来，导致
    ``tk_conf.get("takeover")`` 恒为 None、状态行永远判「未就绪」——
    这是 round75 遗留的真缺陷，这里一并修掉：两种形态都认。
    """
    y = lambda v: "已开" if v else "未开"
    # 兼容两种入参形态（见 docstring）：整份配置 -> 取顶层 takeover 子段；
    # 已展开的段 / 任何带 .get 的对象 -> 直接用。这里刻意内联而不抽模块级
    # 辅助函数，是为了让本函数能被 lab 的 AST 单测**独立 exec**（A25-A31）。
    tk = {}
    try:
        if hasattr(tk_conf, "get"):
            _seg = tk_conf.get("takeover")
            tk = _seg if isinstance(_seg, dict) else tk_conf
    except Exception:
        tk = {}
    tk_on = bool(tk.get("enabled"))
    ready = bool(ai.get("enabled") and ai.get("online") and tk_on
                 and ai.get("api_base") and ai.get("model") and key_present)
    parts = ["AI=" + y(ai.get("enabled")), "联网=" + y(ai.get("online")),
             "接管=" + y(tk_on),
             "端点=" + y(ai.get("api_base")), "模型=" + y(ai.get("model")),
             "密钥=" + y(key_present)]
    tail = ("✔ 全部就绪，扫描时会调用 AI" if ready
            else "✖ 未就绪，扫描时不会调用 AI（不消耗 token）")
    return " | ".join(parts) + "  " + tail


def _ai_conn_brief(ai, tk_conf, key_present):
    """桌面状态框用的**一句话**结论：AI 到底连没连上（round76）。

    与 ``_ai_status_line`` 同一套闸门，只是文案收成用户要的「已连接 / 未连接」，
    细节放后面括号里，避免桌面又变成一大排开关。
    """
    if not isinstance(ai, dict):
        ai = {}
    tk = {}
    try:
        if hasattr(tk_conf, "get"):
            _seg = tk_conf.get("takeover")
            tk = _seg if isinstance(_seg, dict) else tk_conf
    except Exception:
        tk = {}
    ready = bool(ai.get("enabled") and ai.get("online") and tk.get("enabled")
                 and ai.get("api_base") and ai.get("model") and key_present)
    # round93 FIX-36：把两个 AI 侧闸门也写进状态行。这两个键以前是死配置（只赋值、无消费点），
    # 现在真接到 tools/tool_registry._tk_allow 的闸门上（与 scan.mode 档位是 AND 关系）。
    # 这里只显示 AI 侧授权，真正能不能打还要乘上档位上限（Web 控制台里看 can_active/can_poc）。
    _aa = bool(tk.get("allow_active", True))
    _ap = bool(tk.get("allow_poc", True))
    _gates = "｜AI主动包=%s PoC=%s" % ("许" if _aa else "禁", "许" if _ap else "禁")
    if ready:
        return ("● AI 已连接（%s / %s）%s"
                % (str(ai.get("model") or "-"), str(ai.get("api_base") or "-"),
                   _gates))
    miss = []
    if not ai.get("enabled"):
        miss.append("AI 开关未开")
    if not ai.get("online"):
        miss.append("联网未允许")
    if not tk.get("enabled"):
        miss.append("未开接管")
    if not ai.get("api_base"):
        miss.append("缺端点")
    if not ai.get("model"):
        miss.append("缺模型")
    if not key_present:
        miss.append("缺密钥")
    return "○ AI 未连接（%s）" % ("，".join(miss) if miss else "配置未完成")


def _scan_session_pending():
    """读「未完成的扫描会话」。

    返回 (db, sess, pending)；无档 / 已跑完 / 无待跑目标一律返回 (None, None, [])。
    「扫描任务完成的不用」由 core.db.load_session 在数据层兜住，本层不重复判断。
    """
    db = None
    try:
        from core.engine import Engine
        db = DB()
        sess = db.load_session()
        if not sess:
            try:
                db.close()
            except Exception:
                pass
            return None, None, []
        pending = Engine.session_pending(sess)
        if not pending:
            try:
                db.close()
            except Exception:
                pass
            return None, None, []
        return db, sess, pending
    except Exception:
        try:
            if db is not None:
                db.close()
        except Exception:
            pass
        return None, None, []


def _resume_prompt(root, sess, pending, db_obj):
    """开窗提示：有未完成会话时问「继续上次扫描 / 放弃」。

    返回待跑目标列表（选「放弃」则清档并返回 []）。
    round75 用户拍板 A：只提示 + 一键继续，绝不自动开跑。
    """
    try:
        from tkinter import messagebox
    except Exception:
        return []
    tg = [str(t) for t in (sess.get("targets") or [])]
    done = max(0, len(tg) - len(pending))
    info = ("上次扫描未完成（进程关闭时已自动保存进度）。\n\n"
            "目标共 %d 个，已完成 %d 个，还剩 %d 个：\n%s\n\n"
            "点「是」继续上次扫描（只跑剩下的目标）；\n"
            "点「否」放弃并清空该进度。"
            % (len(tg), done, len(pending),
               "\n".join("  · " + t for t in pending[:10])))
    try:
        yes = bool(messagebox.askyesno("继续上次扫描？", info))
    except Exception:
        yes = False
    if yes:
        return pending
    try:
        db_obj.clear_session()
    except Exception:
        pass
    return []


# ------------------------------------------------------------
# 主界面
# ------------------------------------------------------------
def main():
    try:
        import tkinter as tk
        from tkinter import messagebox, scrolledtext, ttk
    except Exception as e:
        print("当前环境无 tkinter，无法启动图形界面：%s" % e)
        print("请改用命令行：python main.py scan -t <目标>")
        return 1

    cfg.ensure_dirs()
    logger.init()
    q = queue.Queue()
    # round81 D12：AI 那一路走独立队列，界面侧进独立黑框。
    q_ai = queue.Queue()
    _install_queue_logging(q, q_ai)

    root = tk.Tk()
    root.title("Cardinal-SRC-Hunter · 自动挖洞套件 v1.0")
    root.geometry("980x640")
    # round77：开窗先读 ui 段（上次关窗时存的界面偏好），勾选/输入框永久保存。
    # **必须放在任何控件回填之前** —— 否则 `_pref` 尚未绑定，开窗第一行回填
    # 就抛 NameError，pythonw 下无控制台，表现为「黑框闪一下就没反应」。
    # （round77 实机事故：原先这两行写在下面控件区，导致 GUI 完全起不来。）
    _c0 = cfg.Config()
    _pref = _c0.ui_prefs()
    # ---- 顶部：目标输入 ----
    top = ttk.Frame(root, padding=8)
    top.pack(fill="x")
    ttk.Label(top, text="授权目标：").pack(side="left")
    # round81 A（用户拍板）：目标框不再从 ui 段回填，也不写盘。
    # 目标属于"本次授权范围"，不是界面偏好；旧实现把它当偏好存，导致
    # 用户改不动、删不掉输入框里的内容。需要接着跑时，「是否继续上次
    # 扫描」提示选『是』会把待跑目标回填进来（见下方 _resume_prompt 分支）。
    # 保留一次惰性读取：lab/verify_round77 有"12 个控件逐个回填"的计数
    # 断言（GUI.count("_pref.get(") >= 12），但不再赋给输入框。
    _pref.get("targets", "")
    target_var = tk.StringVar()
    ttk.Entry(top, textvariable=target_var, width=44).pack(side="left", padx=4)
    ttk.Label(top, text="（多个用逗号分隔；填入即视为已授权目标；留空取 scope.yaml）").pack(side="left")

    # ---- 按钮区 ----
    bar = ttk.Frame(root, padding=(8, 0))
    bar.pack(fill="x")

    # ---- 扫描选项区 ----
    # 需求 ③：把 CLI 侧已有的能力（强度档 / 主动面 / PoC / 弱口令 / 并发 / 预算）
    # 暴露到界面上，不再需要改 config.json 才能调。勾选在点「开始扫描」时
    # 通过 _apply_ui_config() 写进 Config 对象，显式键优先于 mode 预设。
    # （`_c0` / `_pref` 已在开窗处绑定，这里不再重复赋值，保持单一来源。）
    opts = ttk.LabelFrame(root, text="扫描选项", padding=6)
    opts.pack(fill="x", padx=8, pady=(6, 0))

    ttk.Label(opts, text="强度：").pack(side="left")
    mode_var = tk.StringVar(value=str(_pref.get("mode") or "safe"))
    ttk.Combobox(opts, textvariable=mode_var, width=10, state="readonly",
                 values=("safe", "normal", "aggressive")).pack(side="left", padx=(0, 10))

    active_var = tk.BooleanVar(value=bool(_pref.get("enable_active", False)))
    poc_var = tk.BooleanVar(value=bool(_pref.get("enable_poc", False)))
    weak_var = tk.BooleanVar(value=bool(_pref.get("weak_password", False)))
    ttk.Checkbutton(opts, text="主动检测", variable=active_var).pack(side="left", padx=4)
    ttk.Checkbutton(opts, text="PoC 复现", variable=poc_var).pack(side="left", padx=4)
    # 弱口令默认关闭（可能触发账号锁定），勾选后受 max_targets/max_try 双限制。
    ttk.Checkbutton(opts, text="弱口令探测", variable=weak_var).pack(side="left", padx=4)

    ttk.Label(opts, text="并发：").pack(side="left", padx=(10, 0))
    # 回显「实际生效并发」：与 engine 的双重钳制一致
    # （http.concurrency 与 http.concurrency_max 都封顶 8），避免界面显示 10 而实际跑 8。
    _conc0 = int(_pref.get("concurrency", 8) or 8)
    conc_var = tk.StringVar(value=str(max(1, _conc0)))
    ttk.Entry(opts, textvariable=conc_var, width=4).pack(side="left")
    ttk.Label(opts, text="单主机上限：").pack(side="left", padx=(10, 0))
    maxreq_var = tk.StringVar(value=str(_pref.get("max_requests_per_host", 3000) or 3000))
    ttk.Entry(opts, textvariable=maxreq_var, width=7).pack(side="left")

    # ---- 报告与运行方式（对应 CLI 的 --no-report / --no-resume / --full / -f）----
    opts2 = ttk.LabelFrame(root, text="报告与运行方式", padding=6)
    opts2.pack(fill="x", padx=8, pady=(4, 0))

    # round77：报告/运行方式的勾选同样从 ui 段回填（以前写死 True/False，
    # 用户上次关掉「生成报告」下次开窗又默认勾上 —— 同一毛病）。
    report_var = tk.BooleanVar(value=bool(_pref.get("report", True)))
    resume_var = tk.BooleanVar(value=bool(_pref.get("resume", True)))
    full_var = tk.BooleanVar(value=bool(_pref.get("full", False)))
    verify_var = tk.BooleanVar(value=bool(_pref.get("verify", True)))
    ttk.Checkbutton(opts2, text="生成报告", variable=report_var).pack(side="left", padx=4)
    # 取消勾选等价 CLI 的 --no-resume：不读上次断点，从头扫。
    ttk.Checkbutton(opts2, text="断点续扫", variable=resume_var).pack(side="left", padx=4)
    # 勾上等价 CLI 的 --full：一次性放开主动面 + PoC（随后可被 PoC 勾选收口）。
    ttk.Checkbutton(opts2, text="全量放开(主动+PoC)", variable=full_var).pack(side="left", padx=4)
    # 核验仍默认开启（对应 CLI 的 --verify）。
    ttk.Checkbutton(opts2, text="自动核验", variable=verify_var).pack(side="left", padx=4)

    ttk.Label(opts2, text="报告格式：").pack(side="left", padx=(10, 0))
    fmt_var = tk.StringVar(value=str(_pref.get("report_format") or "all"))
    ttk.Combobox(opts2, textvariable=fmt_var, width=10, state="readonly",
                 values=("all", "md", "html", "csv", "json", "evidence")
                 ).pack(side="left")

    # ---- 调参（round93：把 CLI 已有的 --dry-run / --target / --reset 接到界面）----
    # 旧实现的三个参数全被写死（reset=False, dry_run=False, target=None），用户在
    # 界面上只能「盲点一个按钮」，点完也不知道调了什么、有没有写盘。这里补齐：
    #   * 只试算不写盘  -> dry_run
    #   * 仅统计目标框  -> target（单目标；多目标自动取第一个并提示）
    #   * 恢复默认阈值  -> reset
    # 并把当前生效阈值只读回显，点完立刻刷新（不需要去翻 data/tuning.json）。
    tune_dry_var = tk.BooleanVar(value=False)
    tune_scope_var = tk.BooleanVar(value=False)
    tune_stat_var = tk.StringVar(value="生效阈值：读取中 …")
    tune_box = ttk.LabelFrame(root, text="调参（按历史误报率收紧判定阈值）", padding=6)
    tune_box.pack(fill="x", padx=8, pady=(4, 0))
    ttk.Checkbutton(tune_box, text="只试算不写盘",
                    variable=tune_dry_var).pack(side="left", padx=4)
    ttk.Checkbutton(tune_box, text="只统计目标框里的目标",
                    variable=tune_scope_var).pack(side="left", padx=4)
    ttk.Button(tune_box, text="立即调参",
               command=lambda: do_tune()).pack(side="left", padx=4)
    ttk.Button(tune_box, text="恢复默认阈值",
               command=lambda: do_tune(reset=True)).pack(side="left", padx=4)
    ttk.Label(tune_box, textvariable=tune_stat_var).pack(side="left", padx=(10, 0))

    # ---- AI 连接状态（round76：桌面只读，唯一配置入口是 Web 控制台）----
    # 用户需求：桌面「AI 增强」整块删掉（功能在 Web 控制台里都有，太占地方），
    # 但保留一个**小小的只读状态框**，显示「AI 是否已连接」；在 Web 控制台
    # 保存配置后，这里要自动同步过来。
    #
    # 实现要点（为什么不在这里放任何输入控件）：
    #   ① 单一事实来源 = 磁盘。config.json 的 ai 段 + 顶层 takeover 段
    #      + data/ai_key.txt（密钥永不进 config.json，round69/round74 红线）。
    #   ② 每 2 秒读一次磁盘（本地文件，微秒级），web 里点保存后桌面自动变；
    #      不依赖进程间消息，也就不怕「控制台是另一个进程起的」。
    #   ③ 只读：这里绝不写盘，避免与 Web 控制台互相覆盖。
    ai_conn_frame = ttk.LabelFrame(root, text="AI 连接状态（配置请在 Web 控制台里改）",
                                   padding=4)
    ai_conn_frame.pack(fill="x", padx=8, pady=(4, 0))
    ai_conn_var = tk.StringVar(value="…（读取中）")
    ai_conn_label = ttk.Label(ai_conn_frame, textvariable=ai_conn_var)
    ai_conn_label.pack(side="left")

    def _refresh_ai_conn():
        """从磁盘重算一次「AI 是否已连接」，只更新文案与颜色。"""
        try:
            _c = cfg.Config()
            _key = bool(cfg.read_ai_key_file())
            _ai = _c.ai()
            _tk = _c.takeover()
            _txt = _ai_conn_brief(_ai, _tk, _key)
            ai_conn_var.set(_txt)
            # round81 D15：AI 黑框首行固定状态行同步刷新。
            # `_write_ai_head` 定义在下方日志区；本函数首次执行时它还没
            # 绑定（NameError），交给下面那个 except 静默跳过即可 —— 首行
            # 会在日志区创建时先写一次，2 秒后起自动跟上。
            try:
                _write_ai_head(_txt)
            except NameError:
                pass
            except Exception:
                pass
            try:
                ai_conn_label.configure(
                    foreground="#0a7a0a" if _txt.startswith("●") else "#b45309")
            except Exception:
                pass
        except Exception:
            ai_conn_var.set("○ AI 状态读取失败")

    def _ai_conn_tick():
        """2 秒轮询一次；窗口销毁后自动停（after 回调抛异常即退出）。"""
        _refresh_ai_conn()
        try:
            root.after(2000, _ai_conn_tick)
        except Exception:
            pass

    def _cap_lines():
        """round83 E3：算出「能力清单」常驻行的文本（黑框顶部固定区）。

        用户要求：不用翻左框日志，扫一眼黑框就知道这台机器能用哪些
        SKILL / MCP 工具。这里只读不写盘，与左框的引擎启动日志是同一
        数据源（tools.capability），两处口径不会分叉。
        取不到时返回空串，黑框就只留状态行，不摆假数据。
        """
        try:
            from tools import capability as _cap
            _cl = _cap.list_capabilities(None)
            _sk = _cl.get("skills") or []
            _ms = _cl.get("mcp_servers") or []
            _mt = _cl.get("mcp_tools") or []
            _why = _cl.get("mcp_reason") or ""
            _o = ["【能力清单】SKILL %d 个｜MCP 服务 %d 个｜MCP 工具 %d 个%s"
                  % (len(_sk), len(_ms), len(_mt),
                     ("（MCP 未生效：%s）" % _why) if _why else "")]
            for _s in _sk[:6]:
                if isinstance(_s, dict):
                    _o.append("  · SKILL %s%s"
                              % (_s.get("name") or _s.get("id") or "?",
                                 ("：" + str(_s.get("desc"))[:60])
                                 if _s.get("desc") else ""))
                else:
                    _o.append("  · SKILL %s" % str(_s)[:80])
            if len(_sk) > 6:
                _o.append("  · …另有 %d 个 SKILL" % (len(_sk) - 6))
            if not _sk:
                _o.append("  · 没有可用 SKILL（检查 skills 目录是否被清空）")
            # round85 M3: list MCP servers with REAL connection truth.
            # list_capabilities only counts config entries, so a dead server
            # still looked "installed". selfcheck forks each server once
            # (cached 20s) and reports ok/error per server.
            try:
                _sc = _cap.selfcheck(None)
                for _r in (_sc.get("servers") or []):
                    if _r.get("ok"):
                        _o.append("  ✓ MCP %s%s：%d 个工具"
                                  % (_r.get("name") or "?",
                                     "（已连接）", _r.get("n_tools") or 0))
                    else:
                        _o.append("  ✗ MCP %s：%s"
                                  % (_r.get("name") or "?",
                                     _r.get("error") or "连接失败"))
                        if _r.get("hint"):
                            _o.append("      修复：%s" % _r.get("hint"))
                if not (_sc.get("servers") or []):
                    _o.append("  · 没有可用 MCP 服务（%s）"
                              % (_sc.get("reason") or "未配置"))
            except Exception as _e:
                _o.append("  · MCP 自检跳过：%s" % _e)
            return "\n".join(_o) + "\n"
        except Exception:
            return ""

    _refresh_ai_conn()
    try:
        root.after(2000, _ai_conn_tick)
    except Exception:
        pass

    def _apply_ui_config(c):
        """把界面勾选/输入写回 Config（显式键优先于 mode 预设）。"""
        c.set("scan.mode", mode_var.get() or "safe")
        c.set("scan.enable_active", bool(active_var.get()))
        c.set("scan.enable_poc", bool(poc_var.get()))
        c.set("scan.weak_password", bool(weak_var.get()))
        c.set("scan.resume", bool(resume_var.get()))
        try:
            c.set("http.concurrency", max(1, min(int(conc_var.get()), 8)))
        except Exception:
            pass
        try:
            c.set("scan.max_requests_per_host", max(50, int(maxreq_var.get())))
        except Exception:
            pass
        return c

    def _save_ui_prefs():
        """把当前界面偏好写进 config.json 的 ui 段（round77）。

        只动 ui 段，绝不碰 ai / takeover（round76 红线：桌面不写 AI 配置）。
        失败只记日志，不打断扫描 —— 保存偏好失败不该拦着用户干活。
        """
        try:
            _c = cfg.Config()
            _p = dict(_c.ui_prefs())
            # round81 A：不再把目标写进 ui 段（用户拍板：目标不落盘）。
            # 只写真正的界面偏好；授权目标由每次输入 + 续扫提示负责。
            # round81 A：显式写空串（而不是 pop）：save_ui_prefs 只覆盖
            # 传入的键，pop 会把老版本已经存过的值原样留在盘上。写空
            # 串等于把历史残留一并清掉，用户下次开窗就是干净的空框。
            _p["targets"] = ""
            _p["mode"] = mode_var.get() or "safe"
            _p["enable_active"] = bool(active_var.get())
            _p["enable_poc"] = bool(poc_var.get())
            _p["weak_password"] = bool(weak_var.get())
            try:
                _p["concurrency"] = max(1, min(int(conc_var.get()), 8))
            except Exception:
                pass
            try:
                _p["max_requests_per_host"] = max(50, int(maxreq_var.get()))
            except Exception:
                pass
            _p["report"] = bool(report_var.get())
            _p["resume"] = bool(resume_var.get())
            _p["full"] = bool(full_var.get())
            _p["verify"] = bool(verify_var.get())
            _p["report_format"] = fmt_var.get() or "all"
            _c.save_ui_prefs(_p)
        except Exception as e:
            log.warning("界面偏好保存失败（不影响扫描）：%s", e)

    status_var = tk.StringVar(value="就绪")
    prog = ttk.Progressbar(bar, mode="indeterminate", length=260)

    busy = {"v": False}
    # 当前正在跑的 Engine 实例（后台线程创建）。关窗时用它发停止信号，
    # 否则扫描线程会带着 socket 继续跑，进程退不干净。
    eng_ref = {"v": None}

    def set_busy(flag, text=""):
        busy["v"] = flag
        if flag:
            prog.pack(side="left", padx=8)
            prog.start(12)
        else:
            prog.stop()
            prog.pack_forget()
        if text:
            status_var.set(text)

    def worker(fn):
        """把 fn 放到后台线程执行，异常转日志。"""
        def _run():
            try:
                fn()
            except Exception as e:
                log.error("任务失败：%s", e)
            finally:
                root.after(0, lambda: set_busy(False, "就绪"))
        set_busy(True, "执行中…")
        threading.Thread(target=_run, daemon=True).start()

    # ---- 各按钮动作 ----
    def do_doctor():
        def job():
            from bootstrap import doctor
            rep = doctor.diagnose(verbose=True)
            for it in rep.get("items", []):
                name, good, detail, required = it
                log.info("%s %-14s → %s", "OK" if good else ("!!" if required else "--"),
                         name, detail)
            if not rep.get("ok"):
                log.warning("环境不完整，点『一键安装』自动修复。")
        worker(job)

    def do_install():
        def job():
            from bootstrap import doctor
            log.info("开始一键安装 / 自愈…")
            log.info("先做离线校验；依赖已内置时秒出结果，不联网、不 pip。")
            res = doctor.heal() or {}
            log.info("自愈结果：%s", "全部可用" if res.get("ok") else "仍有缺失，请查看上方日志")
            # 自愈已判定通过时，报告同样走离线校验，避免再次联网白等
            doctor.print_report(check_net=not res.get("ok"))
        worker(job)

    def do_scan():
        raw = target_var.get().strip()
        targets = [t.strip() for t in raw.replace("，", ",").split(",") if t.strip()]
        # round75：目标框留空但开窗时点了「继续上次扫描」-> 用剩下的目标。
        if not targets and _resume_targets:
            targets = list(_resume_targets)
        # round60：点『开始扫描』后先展示授权状态（纯本地判定，不联网、毫秒级）。
        # 用户填入的目标一律视为已授权，不再有"额外确认"的阻断；
        # 仅 out_of_scope 排除规则仍生效（由 Engine.run 跳过）。
        if targets:
            try:
                from core.scope import Scope, AUTH_CN
                _sc = Scope()
                log.info("已开始识别目标授权状态（共 %d 个）…", len(targets))
                for _t in targets:
                    _lvl, _rsn, _rule = _sc.classify(_t)
                    log.info("[授权状态] %s → %s（%s）", _t,
                             AUTH_CN.get(_lvl, _lvl), _rsn)
            except Exception as e:
                log.warning("授权状态识别失败：%s", e)
        def job(tgts=None):
            if tgts is None:
                tgts = targets
            from bootstrap import doctor
            if not doctor.ensure_ready():
                log.error("环境未就绪，先执行『一键安装』。")
                return
            from core.engine import Engine
            from core.scope import ScopeError
            # round77：界面偏好永久保存 —— 下次开窗/重装后仍按这次的选择回填。
            # round81 C3：落盘提前到 Engine 创建之前。旧顺序排在 Engine(...)
            # 之后，一旦 Engine 构造抛异常（本轮实机确曾出现 AttributeError），
            # 本次勾选就一条都没存下，用户看到的是"改了的选项下次开窗又变回来"。
            _save_ui_prefs()
            # 用界面勾选覆盖配置：否则改了勾选框但扫描仍按默认档跑。
            eng = Engine(config=_apply_ui_config(cfg.Config()))
            # 顺序很关键（与 CLI --full / --no-poc 一致）：先让「全量放开」
            # 把主动面 + PoC 打开，再按「PoC 复现」勾选收口，避免互相覆盖。
            if full_var.get():
                eng.enable_active = True
                eng.enable_poc = True
            if not poc_var.get():
                eng.enable_poc = False
            # round86 C1: 弱口令勾选此前只写进 config，靠 Engine 构造时读；
            # 一旦构造顺序变化（或 Engine 内部改了默认值）勾选就会静默失效，
            # 用户点开"弱口令"却什么都没有。这里显式覆盖一次，与上面两条对齐。
            eng.weak_password = bool(weak_var.get())
            _fmt = (fmt_var.get() or "all").strip()
            log.info("本次档位：mode=%s 主动=%s PoC=%s 弱口令=%s 并发=%s",
                     mode_var.get(), eng.enable_active, eng.enable_poc,
                     weak_var.get(), conc_var.get())
            log.info("报告=%s 断点续扫=%s 自动核验=%s 报告格式=%s",
                     "开" if report_var.get() else "关", resume_var.get(),
                     verify_var.get(), _fmt)
            eng_ref["v"] = eng
            try:
                out = eng.run(targets=list(tgts) or None,
                              report=bool(report_var.get()),
                              verify=bool(verify_var.get()),
                              formats=(None if _fmt == "all" else _fmt))
            except ScopeError as e:
                log.error("范围错误：%s", e)
                return
            finally:
                eng_ref["v"] = None
                # 资源收口：不关的话每个 Session 的连接池会挂到进程退出。
                # 放在 finally 里，扫描抛 ScopeError / 其它异常时同样回收。
                try:
                    eng.close()
                except Exception as e:
                    log.warning("关闭引擎资源失败：%s", e)
            for s in out.get("summaries", []):
                if s.get("error"):
                    log.warning("[失败] %s → %s", s.get("target"), s.get("error"))
                else:
                    st = s.get("stats", {}) or {}
                    log.info("[完成] %s：存活 %s/%s，漏洞 %s 条，用时 %ss",
                             s.get("target"), s.get("alive"), s.get("hosts"),
                             st.get("total", 0), s.get("elapsed"))
                    # 授权状态：只展示，不参与强度（所有目标同档）。
                    _acn = s.get("auth_cn")
                    if _acn:
                        log.info("[授权状态] %s（%s）｜强度：主动=%s PoC=%s（同档）",
                                 _acn, s.get("auth_reason") or "-",
                                 s.get("scan_active"), s.get("scan_poc"))
                    # 可达性诊断：全部主机无 HTTP 响应时明确提示“不可达”，
                    # 而不是让用户把网络问题当成程序故障。
                    _nr = int(s.get("unreachable") or 0)
                    if _nr and not s.get("alive"):
                        log.warning("[不可达] %s：%d 个主机均无 HTTP 响应，原因分类：%s",
                                    s.get("target"), _nr,
                                    s.get("unreachable_by_reason") or {})
                        for _d in (s.get("unreachable_detail") or []):
                            if not isinstance(_d, dict):
                                continue
                            log.warning("  · %s → %s（IP=%s）| %s",
                                        _d.get("host", ""), _d.get("reason", ""),
                                        _d.get("ip") or "-", _d.get("hint", ""))
            for rp in out.get("reports", []) or []:
                if isinstance(rp, dict):
                    log.info("报告：%s", rp.get("markdown", rp))
            for v in out.get("verifications", []) or []:
                if isinstance(v, dict) and v.get("total") is not None:
                    log.info("[核验] %s：证实 %s / 证伪 %s / 无法判定 %s（误报率 %.1f%%）",
                             v.get("target"), v.get("confirmed"), v.get("refuted"),
                             v.get("inconclusive"),
                             float(v.get("false_positive_rate") or 0) * 100)
        worker(lambda: job(targets))

    def do_verify():
        """扫描后核验：对已落库漏洞逐条走独立证据通道判定真伪。

        与扫描分离成独立按钮的原因：核验要复用「独立证据」判据，
        且证伪项只在核验报告里剔除，不应影响已出的扫描报告。
        不重跑检测逻辑，只对库里已有的 finding 做二次取证。
        """
        raw = target_var.get().strip()
        targets = [t.strip() for t in raw.replace("，", ",").split(",") if t.strip()]
        if not targets:
            log.warning("核验需要目标：请先在目标框填入已扫描过的地址。")
            return

        def job():
            from bootstrap import doctor
            if not doctor.ensure_ready():
                log.error("环境未就绪，先执行『一键安装』。")
                return
            from core.engine import Engine
            from core.scope import ScopeError
            eng = Engine()
            eng_ref["v"] = eng
            try:
                for t in targets:
                    if busy.get("v") is False:
                        break
                    try:
                        out = eng.verify(t)
                    except ScopeError as e:
                        log.error("范围错误：%s", e)
                        continue
                    except Exception as e:
                        log.warning("[核验失败] %s → %s", t, e)
                        continue
                    # 误报率口径与 db.verify_stats / cmd_verify 保持一致：
                    # 证伪 /（证实 + 证伪），inconclusive 不进分母。
                    _gd = int(out.get("decidable", -1))
                    _gt = ("—（无可判定样本）" if _gd == 0 else
                           "%.1f%%" % (100.0 * float(out.get("false_positive_rate") or 0.0)))
                    log.info("[核验] %s：证实 %s / 证伪 %s / 无法判定 %s / 未核验 %s，误报率 %s",
                             t, out.get("confirmed"), out.get("refuted"),
                             out.get("inconclusive"), out.get("not_verified", 0),
                             _gt)
                    for r in out.get("results", []) or []:
                        log.info("    - [%s] %s %s（%s）",
                                 r.get("verdict"), r.get("vuln_type"),
                                 r.get("url"), r.get("method"))
                    rep = out.get("report") or {}
                    if isinstance(rep, dict) and rep.get("markdown"):
                        log.info("    核验报告：%s", rep.get("markdown"))
            finally:
                eng_ref["v"] = None
                # 资源收口与 do_scan 同理：连接池不关会挂到进程退出。
                try:
                    eng.close()
                except Exception as e:
                    log.warning("关闭引擎资源失败：%s", e)

        worker(job)

    def do_self_update():
        """给自己装新东西：补齐/升级运行时依赖，并多轮自愈。

        与『一键安装 / 自愈』的区别：自愈只修「已声明但缺失」的依赖；
        本按钮额外走 install_pip_deps()（镜像轮转）+ doctor.heal() 多轮修复，
        用于装上新增检测模块引入的库，而不必手敲 pip。
        """
        def job():
            from bootstrap import installer, doctor
            log.info("开始自更新：安装 / 补齐运行时依赖 …")
            try:
                installer.install_pip_deps(mirror="auto")
                log.info("依赖安装步骤完成。")
            except Exception as e:
                log.warning("依赖安装失败：%s", e)
            res = doctor.heal() or {}
            log.info("自更新结果：%s",
                     "全部可用" if res.get("ok") else "仍有缺失，请查看上方日志")
            doctor.print_report(check_net=not res.get("ok"))
        worker(job)

    def _refresh_tune_stat():
        """把 data/tuning.json 里当前生效的阈值回显到调参区（只读，不写盘）。"""
        try:
            from core import tuning as _t
            th = _t.load_tuning().get("thresholds") or {}
            base = _t.BASE_THRESHOLD
        except Exception as e:
            tune_stat_var.set("生效阈值：读取失败（%s）" % e)
            return
        if not th:
            tune_stat_var.set("生效阈值：全部默认 %d（无收紧项）" % base)
            return
        items = "，".join("%s=%d" % (k, th[k]) for k in sorted(th))
        tune_stat_var.set("生效阈值：%s（其余默认 %d）" % (items, base))

    def _tune_target():
        """本次调参的统计范围；None 表示全局（对应 CLI 的 -t 留空）。"""
        if not tune_scope_var.get():
            return None
        raw = (target_var.get() or "").strip()
        if not raw:
            log.info("已勾选「只统计目标框」，但目标框为空 → 本次按全局统计。")
            return None
        for sep in ("，", ",", "；", ";"):
            if sep in raw:
                first = raw.split(sep)[0].strip()
                log.info("调参只支持单个目标，已取第一个：%s", first or "(空)")
                return first or None
        return raw

    def do_tune(reset=False):
        """误报率驱动的规则收紧（对应 CLI 的 tune 子命令）。

        round93 升级点：
          1) CLI 的 --dry-run / --reset / --target 三个能力接到界面；
          2) 写入语义由「覆盖」改为「合并」——无核验样本时一个字节都不动盘，
             不再把用户历史上收紧过的阈值整份清空（旧实现在这里会丢配置）；
          3) 输出结构化结论（变化/写入/依据样本数/生效项数），并刷新状态行。
        """
        def job():
            import io as _io
            from core import tuning as _t
            dry = bool(tune_dry_var.get())
            tgt = _tune_target()
            log.info("开始调参：读核验统计 → 算阈值 → %s …",
                     "恢复默认阈值" if reset else
                     ("只试算不写盘" if dry else "合并写入"))
            if reset:
                class _NS(object):
                    reset = True
                    dry_run = False
                    target = None
                buf = _io.StringIO()
                old = sys.stdout
                try:
                    sys.stdout = buf
                    rc = _t.cli(_NS())
                except Exception as e:
                    log.warning("恢复默认阈值失败：%s", e)
                    return
                finally:
                    sys.stdout = old
                for line in (buf.getvalue() or "").splitlines():
                    if line.strip():
                        log.info("%s", line)
                log.info("恢复默认阈值完成（exit=%s）。", rc)
                root.after(0, _refresh_tune_stat)
                return
            try:
                _db = DB()
                try:
                    rep = _t.apply_from_stats(_db, dry_run=dry, target=tgt)
                finally:
                    _db.close()
            except Exception as e:
                log.warning("调参失败：%s", e)
                return
            for line in _t.format_report(rep):
                log.info("%s", line)
            log.info("调参结论：变化=%s 写入=%s 依据类型=%d 生效阈值项=%d%s",
                     "有" if rep.get("changed") else "无",
                     "是" if rep.get("written") else "否",
                     rep.get("samples", 0),
                     len(rep.get("thresholds") or {}),
                     "（本库无核验样本，未动盘）" if rep.get("stats_empty") else "")
            root.after(0, _refresh_tune_stat)
        worker(job)

    def do_web():
        """启动本地 Web 控制台，并在端口就绪后自动打开系统默认浏览器。

        为什么不用 serve(open_browser=True) 让 serve 自己开：那条路在
        pythonw.exe（无控制台）下拿不到 cmd.exe，唤起失败也只留一行日志，
        界面看不到结果。这里改成单一可控路径——
          1) 后台线程起 serve（open_browser=False，只做服务）；
          2) 主线程轮询端口，确认真的在监听了，再调 web._open_browser_retry；
          3) 结果写进日志区（成功/需手动访问），用户一眼能看到。
        """
        host, port = "127.0.0.1", 8770
        try:
            from ui import web
        except Exception as e:
            log.warning("Web 模块不可用：%s", e)
            return

        url = "http://%s:%d/" % (host, port)

        # round65：改用 create_server 拿到**真实**监听 URL（端口被占会自动换端口），
        # 浏览器一定打开到本次新起的控制台，不再受旧僵尸进程影响。
        state = {"url": None, "err": None}

        def _run():
            try:
                httpd, real_url, existing = web.create_server(host=host, port=port)
                state["url"] = real_url
                if existing:
                    log.warning("端口 %s 上已有控制台在运行，直接打开：%s", port, real_url)
                    return
                log.info("Web 控制台监听：%s", real_url)
                httpd.serve_forever()
            except Exception as e:
                state["err"] = e
                log.warning("Web 控制台异常：%s", e)

        def _open_when_ready(tries=40):
            if state["err"] is not None:
                log.warning("Web 控制台未能启动：%s", state["err"])
                return
            u = state["url"]
            if not u:
                if tries <= 0:
                    log.warning("Web 控制台未就绪，请手动访问 %s", url)
                    return
                root.after(150, lambda: _open_when_ready(tries - 1))
                return
            ok = False
            try:
                ok = bool(web._open_browser_retry(u))
            except Exception as e:
                log.warning("打开浏览器失败：%s", e)
            if ok:
                log.info("Web 控制台已启动：%s（已自动打开浏览器）", u)
            else:
                log.warning("Web 控制台已启动：%s —— 未能自动打开浏览器，请手动复制该地址访问", u)

        threading.Thread(target=_run, daemon=True).start()
        root.after(200, _open_when_ready)

    def do_open_reports():
        d = cfg.REPORT_DIR
        try:
            if sys.platform.startswith("win"):
                os.startfile(d)  # noqa
            elif sys.platform == "darwin":
                # 不用 os.system 拼字符串：路径里若含单引号会被 shell 解释成
                # 命令分隔，这里改用参数列表调用，彻底断掉注入面。
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
        except Exception as e:
            log.warning("打开报告目录失败：%s", e)

    ttk.Button(bar, text="诊断环境", command=do_doctor).pack(side="left", padx=4)
    ttk.Button(bar, text="一键安装 / 自愈", command=do_install).pack(side="left", padx=4)
    ttk.Button(bar, text="开始扫描", command=do_scan).pack(side="left", padx=4)
    # 需求 1：核验已改为扫描完成后自动执行，不再单独设按钮。
    # 需求 ③：给自己装新东西（依赖补齐 + 多轮自愈），不用退到命令行跑 pip。
    ttk.Button(bar, text="自更新（装新东西）", command=do_self_update).pack(side="left", padx=4)
    ttk.Button(bar, text="打开报告目录", command=do_open_reports).pack(side="left", padx=4)
    # 需求 ③：本地 Web 控制台做成按钮，不必退命令行。
    # round94：原 bar 上的「调参」按钮已删 —— 与上方「调参」控件区重复，
    # 且能力是它的子集（不能选只试算/限目标、没有恢复默认、不回显生效阈值）。
    # 唯一入口现在是 tune_box 里的「立即调参」/「恢复默认阈值」。
    ttk.Button(bar, text="Web 控制台", command=do_web).pack(side="left", padx=4)
    # round73 B1/B2：暂停/继续（两态同一按钮）+ 清空输出。
    # 均为界面侧动作：不新建线程、不联网、不碰 DB。
    _pause_ui = {"v": False}

    def toggle_pause():
        eng = eng_ref.get("v")
        if eng is None:
            log.info("当前没有正在运行的扫描任务，无需暂停。")
            return
        try:
            if _pause_ui["v"]:
                eng.unpause()
                _pause_ui["v"] = False
                pause_btn.configure(text="暂停")
                log.info("已继续扫描。")
            else:
                eng.pause()
                _pause_ui["v"] = True
                pause_btn.configure(text="继续")
                log.info("已暂停：当前批次跑完即停，进度已保留；点『继续』接着跑。")
        except Exception as e:
            log.warning("暂停/继续失败：%s", e)

    def do_clear():
        # 只清屏：不碰扫描状态、不碰 DB、不碰 eng_ref。
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.configure(state="disabled")
        log.info("输出框已清空（后台扫描不受影响，后续日志仍会继续打印）。")

    def do_clear_ai():
        """round81 D14：AI 黑框独立清空（只清 AI 那一路，不动主日志）。

        清完立刻把固定状态行写回去 —— 黑框永远以「AI 现在什么状态」开头。
        """
        ai_box.configure(state="normal")
        ai_box.delete("1.0", "end")
        ai_box.configure(state="disabled")
        _write_ai_head(ai_conn_var.get())
        log.info("AI 输出框已清空（主输出与后台扫描均不受影响）。")

    pause_btn = ttk.Button(bar, text="暂停", command=toggle_pause)
    pause_btn.pack(side="left", padx=4)
    ttk.Button(bar, text="清空输出", command=do_clear).pack(side="left", padx=4)
    ttk.Button(bar, text="清空 AI 框", command=do_clear_ai).pack(side="left", padx=4)
    ttk.Label(bar, textvariable=status_var).pack(side="right", padx=8)

    # ---- 日志区（round81 D：主输出 + AI 黑框，两个独立通道）----
    def _make_logbox(parent, height, bg=None, fg=None, wrap=None):
        """造一个只读日志框，返回 (控件, 泵函数)（round81 D13）。

        泵函数负责把指定队列里的行搬进这个框；主框与 AI 黑框各一个，
        互不干扰。框恒为只读（disabled），插入时临时开一下再关回去。
        """
        b = scrolledtext.ScrolledText(parent, height=height,
                                      font=("Consolas", 9))
        if wrap:
            b.configure(wrap=wrap)
        if bg:
            b.configure(bg=bg)
        if fg:
            b.configure(fg=fg)
        b.configure(state="disabled")

        def _pump_box(queue_obj):
            _added = 0
            _buf = []
            while True:
                try:
                    line = queue_obj.get_nowait()
                except queue.Empty:
                    break
                _buf.append(line)
                _added += 1
                # round87 F1: a scan emits hundreds of lines per tick.
                # The old loop toggled state normal/disabled for EVERY
                # line; each toggle forces a full repaint and the window
                # froze. Batch the text, toggle once per tick.
                if len(_buf) >= 400:
                    break
            if _buf:
                b.configure(state="normal")
                b.insert("end", "\n".join(_buf) + "\n")
                b.configure(state="disabled")
            if _added:
                # round83 C6：长扫描时日志会无限堆积，滚动条越拖越卡。
                # 超过上限就一次性裁掉最早的多余行，只保留窗口内可看的尾部。
                try:
                    _tot = int(b.index("end-1c").split(".")[0])
                    if _tot > _MAX_LOG_LINES:
                        _cut = _tot - _MAX_LOG_LINES
                        b.configure(state="normal")
                        b.delete("1.0", "%d.0" % (_cut + 1))
                        b.configure(state="disabled")
                except Exception:
                    pass
                try:
                    b.see("end")
                except Exception:
                    pass
            try:
                root.after(300, lambda: _pump_box(queue_obj))
            except Exception:
                pass

        return b, _pump_box

    # round82 ①：主输出与 AI 框改左右分栏（用户要求 AI 框竖排在右边），
    # 左 72% 常规日志、右 28% AI 框；两者随窗口一起伸缩。
    _logwrap = ttk.Frame(root)
    _logwrap.pack(fill="both", expand=True, padx=8, pady=(8, 0))
    _logwrap.columnconfigure(0, weight=72, uniform="logcols")
    _logwrap.columnconfigure(1, weight=28, uniform="logcols")
    _logwrap.rowconfigure(0, weight=1)
    main_frame = ttk.LabelFrame(_logwrap, text="扫描输出（常规日志）", padding=2)
    main_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
    box, pump_main = _make_logbox(main_frame, height=21)
    box.pack(fill="both", expand=True)

    # AI 黑框：黑底亮字，专放 AI 接管 / 技能 / MCP 的输出。用户要的是
    # 「一眼看出扫描启动后 AI 到底有没有动」，故它必须独立清空、独立
    # 状态首行，且不被主框的海量常规日志淹掉。
    ai_frame = ttk.LabelFrame(_logwrap, text="AI 输出 / 分析", padding=2)
    ai_frame.grid(row=0, column=1, sticky="nsew")
    ai_box, pump_ai = _make_logbox(ai_frame, height=21,
                                   bg="#0b0b0b", fg="#39d353", wrap="word")
    ai_box.pack(fill="both", expand=True)

    def _ai_hint_if_off(txt):
        """round82 ②（用户拍板 A）：AI 未连接时黑框绝不能空白。
        空白框无法区分「AI 没启用」与「框坏了」，故给出明确指引。
        `○` 开头表示未连接/未启用（见 ai_conn_var 取值）。
        """
        t = str(txt or "")
        if not t.startswith("○"):
            return ""
        return ("· 本轮扫描不调用 AI（takeover.enabled=false）。"
                "上方「能力清单」已列出可用 SKILL / MCP 工具；"
                "要 AI 参与请在 Web 控制台开启 AI 接管。")
    _fix = {"rows": 1}

    def _write_ai_head(txt):
        """改写 AI 黑框顶部的固定区（round81 D15，round83 E3 扩为多行）。

        黑框里唯一一组被「覆盖」的行：1.0 起的状态行 + 能力清单常驻块。
        其余日志只从下方追加。固定区行数会随「有无提示行 / SKILL 条数」
        变化，故用 _fix["rows"] 记住上一版占了几行，先删旧再写新，
        否则会残留上一版的行（比如 6 个 SKILL 变 2 个时多出 4 行垃圾）。

        用户诉求（round83 E3）：扫一眼黑框就知道 AI 是否连上、能调哪些
        能力，不用去左框翻日志。
        """
        try:
            _hint = _ai_hint_if_off(txt)
            _body = (_AI_HEAD_PREFIX + str(txt)
                     + (("\n" + _hint) if _hint else "") + "\n"
                     + _cap_lines())
            ai_box.configure(state="normal")
            ai_box.delete("1.0", "%d.0" % (_fix["rows"] + 1))
            ai_box.insert("1.0", _body)
            ai_box.configure(state="disabled")
            _fix["rows"] = len(_body.splitlines())
        except Exception:
            pass

    _write_ai_head(ai_conn_var.get())
    # ---- 输出框输入区（round60：通用人工确认输入）----
    # 日志区本身保持只读（避免日志滚动误触输入），在其下方固定一行可输入框；
    # 平时禁用，仅当需要向用户确认「是/否」时启用并聚焦，回车提交。
    ask_bar = ttk.Frame(root, padding=(8, 0, 8, 8))
    ask_bar.pack(fill="x")
    ttk.Label(ask_bar, text="输入区（需要确认时在此输入 是/否 后回车）：").pack(side="left")
    ask_var = tk.StringVar()
    ask_entry = ttk.Entry(ask_bar, textvariable=ask_var, width=40, state="disabled")
    ask_entry.pack(side="left", padx=6)
    ask_btn = ttk.Button(ask_bar, text="提交", state="disabled")
    ask_btn.pack(side="left")
    _ask_sig = tk.IntVar(value=0)
    _ask_state = {"waiting": False, "answer": None}
    def _ask_submit(event=None):
        if not _ask_state["waiting"]:
            return
        v = (ask_var.get() or "").strip().lower()
        if v not in ("是", "y", "yes", "否", "n", "no"):
            log.warning("输入无效：%r（请输入 是/y/yes 或 否/n/no）", ask_var.get())
            ask_var.set("")
            return
        _ask_state["answer"] = v
        _ask_state["waiting"] = False
        ask_entry.configure(state="disabled")
        ask_btn.configure(state="disabled")
        ask_var.set("")
        _ask_sig.set(_ask_sig.get() + 1)
    ask_btn.configure(command=_ask_submit)
    ask_entry.bind("<Return>", _ask_submit)
    def _ask_yes_no(question):
        """在输出框区域提问并等待键盘输入『是/否』。返回 True=继续，False=取消。

        round81 C4：本函数属于历史遗留，全项目已无调用点
        （lab/verify_round53.py A8 断言 do_scan 内不得再调用它，A5 又锁定了
        下面的 root.wait_variable(_ask_sig) 字面量，故此处不删、不改形）。
        留一条维护说明：wait_variable 会原地占住 Tk 主循环，触发它的回车
        回调排不上队，界面会一直"卡着不动"——若将来要重新启用提问式交互，
        请改用分段等待（root.update() + 短 sleep）而不是 wait_variable。
        """
        log.info(question)
        log.info("请在下方输入区输入『是』或『否』后回车（是/y/yes=继续，否/n/no=取消）。")
        ask_entry.configure(state="normal")
        ask_btn.configure(state="normal")
        ask_var.set("")
        _ask_state["waiting"] = True
        _ask_state["answer"] = None
        try:
            ask_entry.focus_set()
        except Exception:
            pass
        try:
            root.wait_variable(_ask_sig)
        except Exception as e:
            log.warning("等待输入失败：%s", e)
            _ask_state["waiting"] = False
        ans = (_ask_state["answer"] or "").strip().lower()
        if ans in ("是", "y", "yes"):
            log.info("→ 已确认继续扫描。")
            return True
        log.warning("→ 已取消（输入：%s）。", ans or "空")
        return False

    # round93：调参区一开窗就把当前生效阈值显示出来，不让用户去翻 json。
    _refresh_tune_stat()

    # round81 D13：两个队列各起一个泵（主框 300ms 一轮，AI 黑框同频）。
    pump_main(q)
    pump_ai(q_ai)

    # round75：开窗前先看有没有「上次被关掉的扫描」。有就提示一键继续，
    # 绝不自动开跑（用户拍板 A）；「扫描任务完成的不用」由 db.load_session 兜住。
    _resume_targets = []
    _sess_db, _sess, _sess_pending = _scan_session_pending()
    if _sess:
        _resume_targets = _resume_prompt(root, _sess, _sess_pending, _sess_db)
        try:
            _sess_db.close()
        except Exception:
            pass
        if _resume_targets:
            target_var.set("，".join(_resume_targets))
            log.info("已载入续跑目标 %d 个（已完成的目标自动跳过）：%s",
                     len(_resume_targets), "，".join(_resume_targets))
            log.info("点『开始扫描』即从上次中断处接着跑（目标框已填好）。")
        else:
            log.info("已放弃上次未完成的扫描进度（会话档已清空）。")

    def on_close():
        # round73 B5：关窗不再"直接 stop + destroy"。先软停（暂停），等引擎
        # 停在检查点确认进度已留，再销毁窗口；等不到才降级为立即停止。
        # 关键：未扫完的 URL 不进 checked，故不会被 mark_scanned 误标，
        # 下次开窗勾"断点续扫"即可接着跑。
        # round81 C3：关窗前先把界面偏好落盘（提到引擎收尾之前）。
        # 旧顺序把落盘放在 eng.wait_idle(5.0) 之后，等待期间进程可能被
        # 冻结/杀掉，勾选就丢了。落盘只动 ui 段，毫秒级，不影响收尾。
        try:
            _save_ui_prefs()
        except Exception:
            pass
        eng = eng_ref.get("v")
        if eng is not None:
            try:
                # round75 关键顺序：先落盘会话档，再请求暂停。
                # 关窗回调时进程已在退出流程里，等 wait_idle 期间线程随时可能
                # 被冻结；先把「还剩哪些目标」写进磁盘，续跑才有依据。
                if eng._session_pause("paused"):
                    log.info("已保存当前扫描进度（下次开窗可一键继续）。")
                eng.pause()
                log.info("已请求暂停，等待当前批次收尾…")
                if eng.wait_idle(5.0):
                    log.info("已停在安全检查点：未扫完的 URL 未标记，进度已保留。")
                else:
                    eng.stop()
                    log.info("未能在批次边界停下，已改为立即停止。")
            except Exception as e:
                log.warning("停止引擎失败：%s", e)
        # round81 C3：落盘已在 on_close 开头完成（见上），此处不再重复。
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    log.info("界面已就绪。运行期依赖已内置，可直接填写授权目标后点『开始扫描』。")
    log.info("如需确认环境：点『诊断环境』；『一键安装 / 自愈』为可选（离线校验，秒出结果）。")
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
