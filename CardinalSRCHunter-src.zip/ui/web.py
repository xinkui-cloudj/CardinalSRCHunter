# -*- coding: utf-8 -*-
"""Web UI（零依赖 stdlib 实现）。

为什么不用 Flask
----------------
目标环境 pip 被 PEP668 锁死（externally-managed-environment），装不上
Flask；而本项目从第一行就坚持"自包含、双击即用"。因此这里用标准库
`http.server.ThreadingHTTPServer` 手写一个单文件控制台。

职责边界（与红线一致）
----------------------
- **只读 + 触发**：读 SQLite 结果库、读 reports/、触发一次扫描/核验。
- **不做检测决策**：任何漏洞判定都在 core/ modules/ 里完成，本文件不
  参与，也不 import 扫描热路径里的任何东西。
- **不联网取数**：除了本机回环监听，不做任何外部请求。

安全
----
- 默认只绑 127.0.0.1（`--host` 可改，但改了就是用户自己负责）。
- 扫描接口只接受显式传入的目标，且复用 cli 的 scope 校验路径。
- 所有路径参数都过 `_safe_join`，禁止 `..` 穿越读任意文件。

启动：`python3 main.py web` 或 `python3 -m ui.web`
"""
import json
import os
import sys
import threading
import time
import traceback
import shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# round70: 控制台版本标记（/api/ver 用；也是端口探活的握手标识）
_APP_VER = "r89"

from core import config as cfg

# B 方案（round71）：启动横幅上的 AI 增强可用性提示判定。
# 复用一个极轻的伪 engine（list_capabilities 只读 engine.config 的 MCP 配置），
# 避免在 serve() 入口实例化完整 Engine（会连带建 DB 连接 + HTTP 客户端）。
def _ai_banner_notes():
    """返回需要追加到启动横幅的提示行列表；无提示时返回空列表。"""
    notes = []
    try:
        from tools import capability
        eng = type("_LiteEngine", (), {"config": cfg.Config()})()
        txt = capability.scan_note(eng)
        if txt:
            notes = txt.splitlines()
    except Exception:
        pass
    return notes

# 扫描任务单例状态（同一时刻只允许一个扫描在跑，避免并发写库冲突）
_SCAN = {"running": False, "target": "", "started": 0.0, "done": 0,
         "log": [], "error": "", "summary": "",
         "eng": None, "paused": False}
_SCAN_LOCK = threading.Lock()


# ----------------------------------------------------------------------
# 数据读取（全部走 core.db，出口已 hydrate）
# ----------------------------------------------------------------------
def _db():
    from core.db import DB
    return DB()


def _delete_action(payload):
    """批量删除：findings / verifications / assets 走数据库，reports 走磁盘目录。"""
    payload = payload if isinstance(payload, dict) else {}
    kind = str(payload.get("kind") or "").strip()
    raw = payload.get("ids")
    if isinstance(raw, list):
        ids = raw
    elif raw in (None, ""):
        ids = []
    else:
        ids = [raw]
    db = _db()
    try:
        if kind == "findings":
            n = db.delete_findings(ids)
        elif kind == "verifications":
            n = db.delete_verifications(ids)
        elif kind == "assets":
            n = db.delete_assets(ids)
        elif kind == "reports":
            n = 0
            for name in ids:
                try:
                    p = _safe_join(cfg.REPORT_DIR, str(name))
                except ValueError:
                    continue
                if os.path.isdir(p):
                    shutil.rmtree(p, ignore_errors=True)
                    n += 1
        elif kind == "skills":
            n = 0
            for name in ids:
                r = _skill_cli(["uninstall", str(name)])
                if isinstance(r, dict) and r.get("ok"):
                    n += 1
        elif kind == "mcp":
            c = _read_cfg_json()
            tk = c.setdefault("takeover", {})
            m = tk.setdefault("mcp", {})
            sv = m.setdefault("servers", [])
            drop = set(str(x) for x in ids)
            before = len(sv)
            m["servers"] = [x for x in sv if (x.get("name") or "") not in drop]
            _write_cfg_json(c)
            n = before - len(m["servers"])
        else:
            return {"ok": False, "error": "unknown kind: %s" % kind}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return {"ok": True, "deleted": n}


def api_stats(target=None):
    db = _db()
    try:
        out = {"findings": db.stats(target)}
        out["assets"] = len(db.all_assets())
        out["verifications"] = len(db.verifications(target, limit=500))
        try:
            out["verify_stats"] = db.verify_stats(target)
        except Exception:
            out["verify_stats"] = {}
        prog = db.get_progress("last_scan", None)
        out["last_scan"] = prog or {}
        return out
    finally:
        db.close()


def api_findings(target=None, severity=None, limit=500):
    db = _db()
    try:
        rows = db.all_findings(target=target, min_severity=severity)
        return rows[:int(limit)]
    finally:
        db.close()


def api_verifications(target=None, limit=200):
    db = _db()
    try:
        return db.verifications(target, limit=int(limit))
    finally:
        db.close()


def api_assets(limit=500):
    db = _db()
    try:
        return db.all_assets()[:int(limit)]
    finally:
        db.close()


def api_reports():
    """列出 reports/ 下的报告目录，按时间倒序。"""
    root = cfg.REPORT_DIR
    if not os.path.isdir(root):
        return []
    out = []
    for name in os.listdir(root):
        p = os.path.join(root, name)
        if not os.path.isdir(p):
            continue
        files = []
        try:
            for fn in sorted(os.listdir(p)):
                fp = os.path.join(p, fn)
                if os.path.isfile(fp):
                    files.append({"name": fn, "size": os.path.getsize(fp)})
        except Exception:
            pass
        out.append({"name": name, "mtime": os.path.getmtime(p), "files": files})
    out.sort(key=lambda r: r["mtime"], reverse=True)
    return out


def _safe_join(root, *parts):
    """在 root 下拼路径，拒绝逃逸（..、绝对路径）。"""
    root_abs = os.path.abspath(root)
    p = os.path.abspath(os.path.join(root_abs, *parts))
    if p != root_abs and not p.startswith(root_abs + os.sep):
        raise ValueError("路径越界")
    return p


def read_report(report_name, file_name=None):
    """读单个报告文件内容；file_name 为空时返回该目录的文件清单。

    返回 None 表示"不存在或越界"，调用方统一按 404 处理——
    越界不抛异常，避免把内部路径结构通过 traceback 回显出去。
    """
    try:
        d = _safe_join(cfg.REPORT_DIR, report_name)
    except ValueError:
        return None
    if not os.path.isdir(d):
        return None
    if not file_name:
        return {"name": report_name,
                "files": [f for f in sorted(os.listdir(d))
                          if os.path.isfile(os.path.join(d, f))]}
    try:
        fp = _safe_join(d, file_name)
    except ValueError:
        return None
    if not os.path.isfile(fp):
        return None
    with open(fp, "r", encoding="utf-8", errors="replace") as f:
        return {"name": file_name, "content": f.read()}


def _strip_secrets(d):
    """递归剥离不该落盘的敏感字段（round69）。

    设计契约（见 tools/ai_client.py）：端点/模型读 config.json 的 ai 段，
    密钥只从环境变量读。因此 api_key 一律不进磁盘、不进接口返回体。
    """
    if isinstance(d, dict):
        return {k: _strip_secrets(v) for k, v in d.items() if k != "api_key"}
    if isinstance(d, list):
        return [_strip_secrets(x) for x in d]
    return d

def api_config():
    c = cfg.Config()
    d = _strip_secrets(c.data)
    # round74：附一份**运行态就绪快照**给前端，让用户一眼看到「AI 到底会不会跑」。
    # 这是修复「填完保存了却零 token 消耗」的关键——原先界面只显示"已保存"，
    # 三个闸门（takeover.enabled / ai.enabled / ai.online）与密钥状态完全不可见。
    try:
        a = c.ai()
        tk = c.takeover()
        try:
            _scan_active, _scan_poc = c.scan_profile()
        except Exception:
            _scan_active, _scan_poc = (False, False)
        ready = bool(a.get("enabled") and a.get("online")
                     and a.get("api_base") and a.get("model")
                     and key_value_present())
        d["__ai_status"] = {
            "ai_enabled": bool(a.get("enabled")),
            "ai_online": bool(a.get("online")),
            "takeover": bool(tk.get("enabled")),
            "takeover_mode": str(tk.get("mode") or "advisory"),
            # round93 FIX-36：AI 侧闸门 + 扫描档位实际值，让前端能一眼看出
            # 「配置说能打」和「引擎实际能不能打」是否一致。
            "allow_active": bool(tk.get("allow_active")),
            "allow_poc": bool(tk.get("allow_poc")),
            "scan_active": _scan_active,
            "scan_poc": _scan_poc,
            "can_active": bool(tk.get("allow_active") and _scan_active),
            "can_poc": bool(tk.get("allow_poc") and _scan_poc),
            "base_set": bool(a.get("api_base")),
            "model_set": bool(a.get("model")),
            "key_set": key_value_present(),
            "key_path": cfg.ai_key_path(),
            # round76：明文回显（用户拍板「完全回显」）。仅供本机回环控制台
            # 把已存密钥填回输入框，绝不进 config.json、绝不进发布包。
            "key_preview": (ai_key_status() or {}).get("key") or "",
            "ready": ready,
        }
    except Exception as e:
        d["__ai_status"] = {"error": str(e), "ready": False}
    return d


def ai_key_present():
    """密钥是否已就绪（**零 import 实现**，专供热路径状态展示用）。

    round74 说明：本函数刻意不 import tools.ai_client —— round47 D1 是一条
    红线段言「core/ modules/ ui/ 的 .py 里不得出现增强层模块的 import」
    （**含函数体内的延迟 import**；round45 B1 更进一步：连字面提及都不行）。
    取密钥文件本身只有两行，内联一份即可，换来热路径 import 图与文本扫描
    结果逐字不变（否则 round45 B1 / round47 D1 会因本文件的说明文字而翻红）。
    """
    try:
        if (os.environ.get("BTSRHUNTER_AI_KEY") or "").strip():
            return True
    except Exception:
        pass
    try:
        return bool(cfg.read_ai_key_file())
    except Exception:
        return False
def key_value_present():
    """密钥是否已就绪（环境变量或密钥文件任一有值）。不返回密钥本身。"""
    return ai_key_present()


def ai_key_status():
    """密钥状态（round76：按用户要求**明文回显**）。

    历史沿革：round74 这里只回 present/source/path，绝不回明文。round76 用户
    明确要求「密钥完全回显」——因为落盘的目的就是「下次不用重填」，而输入框
    若永远空白，用户根本不知道自己存的是什么。因此新增 ``key`` 字段回明文。

    安全边界（未变）：
      · 明文只出现在**本机 127.0.0.1 的本地控制台**回包里，服务只监听回环
        地址（create_server 默认 host=127.0.0.1），不对外网暴露；
      · 明文**绝不进 config.json**（round69 scrub_secrets 红线仍在）；
      · 明文字段名用 ``key``，与 ``_strip_secrets`` 剥的 ``api_key`` 不同名，
        因此不会被误剥，也不会被误写进配置文件。
    """
    src = "none"
    key = ""
    try:
        env_key = (os.environ.get("BTSRHUNTER_AI_KEY") or "").strip()
        if env_key:
            src = "env"
            key = env_key
    except Exception:
        pass
    if src == "none":
        try:
            fk = cfg.read_ai_key_file()
            if fk:
                src = "file"
                key = fk
        except Exception:
            pass
    return {"ok": True, "present": src != "none", "source": src,
            "path": cfg.ai_key_path(),
            # round76：明文回显（用户拍板），前端直接填进输入框
            "key": key}


def ai_key_save(b):
    """把密钥写进密钥文件（round74）。**绝不写进 config.json**。

    前端传 {"api_key": "sk-..."} 落盘；传空串则清除密钥文件。
    """
    key = str((b or {}).get("api_key") or "")
    ok, msg = cfg.write_ai_key_file(key)
    out = {"ok": bool(ok), "msg": msg}
    out.update(ai_key_status())
    return out


def save_config(patch):
    """浅层合并写回 config.json（只允许已知顶层键）。

    round69：写入前递归剥离 api_key（密钥只从环境变量读，绝不落盘），
    并清掉既有配置里历史残留的 api_key，避免旧数据把红线带回去。

    round74：放行 ``takeover`` 段——缺省配置里虽有该键，但历史用户的
    config.json 可能压根没有它（正是"三个闸门都开不了"的成因之一）。
    只对这一**白名单段**允许新建，其余未知顶层键仍被忽略，避免前端
    把任意垃圾键写进配置。
    """
    # round76：先摘出前端随配置一起提交的密钥（字段名 __ai_key，刻意不与
    # api_key 同名，避免被 _strip_secrets 剥掉）。用户要求「点一次保存就
    # 端点+模型+三个开关+密钥全写完」，所以密钥必须能搭这趟车。
    # 密钥仍然**只进 data/ai_key.txt**，绝不进 config.json（round69 红线）。
    _new_key = None
    if isinstance(patch, dict) and "__ai_key" in patch:
        try:
            _new_key = str(patch.pop("__ai_key") or "")
        except Exception:
            _new_key = None
    patch = _strip_secrets(patch)
    c = cfg.Config()
    c.scrub_secrets()  # 清掉历史残留密钥（round69）
    allowed = set(c.data.keys()) | {"takeover"}
    for k, v in (patch or {}).items():
        if k in allowed and isinstance(v, dict):
            c.data.setdefault(k, {})
            if isinstance(c.data[k], dict):
                c.data[k].update(v)
            else:
                c.data[k] = v
    c.save()
    # round76：密钥落盘（在配置写盘之后做，配置写失败就不动密钥文件）
    if _new_key is not None:
        try:
            cfg.write_ai_key_file(_new_key)
        except Exception:
            pass
    return c.data


# ----------------------------------------------------------------------
# 扫描触发（后台线程，单例）
# ----------------------------------------------------------------------
def classify_targets(targets):
    """扫前识别授权状态（本地判定，不联网）。返回 [(target, level, reason)]。

    round60：用户填入的目标一律视为已授权，返回的 level 恒为
    ``authorized``（除非命中 out_of_scope 排除规则）。
    """
    out = []
    from core.scope import Scope
    sc = Scope()
    for t in targets:
        try:
            lvl, rsn, _rule = sc.classify(t)
        except Exception as e:
            lvl, rsn = "denied", "识别异常：%s" % e
        out.append((t, lvl, rsn))
    return out

def scan_status():
    """任务状态快照。

    round75：必须把 ``eng`` 摘掉 —— Engine 实例不可 JSON 序列化，
    直接 dict(_SCAN) 会让 /api/scan/status 直接 500、页面轮询全断。
    """
    with _SCAN_LOCK:
        d = dict((k, v) for k, v in _SCAN.items() if k != "eng")
        d["log"] = _SCAN["log"][-120:]
        d["paused"] = bool(_SCAN.get("paused"))
        return d


def _scan_eng():
    """取当前正在跑的 Engine（没跑就是 None）。不返回副本，只借引用做控制。"""
    with _SCAN_LOCK:
        return _SCAN.get("eng")

def scan_pause():
    """暂停：**先原子落盘会话，再置暂停位**。

    顺序不能反：置位后扫描线程随时可能在批次边界挂起，
    那时再写盘就得等锁；先写盘保证「任何时刻被杀都有档可续」。
    """
    eng = _scan_eng()
    if eng is None:
        return {"ok": False, "error": "当前没有正在运行的扫描"}
    try:
        eng._session_pause("paused")
        eng.pause()
        with _SCAN_LOCK:
            _SCAN["paused"] = True
        return {"ok": True, "msg": "已暂停（进度已保存）"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def scan_resume():
    """继续：清暂停位，扫描线程从检查点接着跑。"""
    eng = _scan_eng()
    if eng is None:
        return {"ok": False, "error": "当前没有正在运行的扫描"}
    try:
        eng.unpause()
        with _SCAN_LOCK:
            _SCAN["paused"] = False
        return {"ok": True, "msg": "已继续"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def scan_stop():
    """停止，但**保留进度**（可续跑）。

    与 GUI 关窗同语义：stop() 内部会落一份 status=stopped 的会话档，
    下次开窗 / 点「继续上次扫描」只跑剩下的目标。
    """
    eng = _scan_eng()
    if eng is None:
        return {"ok": False, "error": "当前没有正在运行的扫描"}
    try:
        eng.stop()
        with _SCAN_LOCK:
            _SCAN["paused"] = False
        return {"ok": True, "msg": "已停止（进度已保存，可续跑）"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def scan_session_info():
    """给页面用：有没有「未完成的扫描」。

    「扫描任务完成的不用」由 core.db.load_session 在数据层兜住，
    本函数只做展示层整形。
    """
    db = None
    try:
        from core.db import DB
        from core.engine import Engine
        db = DB()
        sess = db.load_session()
        if not sess:
            return {"present": False, "targets": [], "done": [], "pending": []}
        pend = Engine.session_pending(sess)
        return {"present": bool(pend),
                "targets": list(sess.get("targets") or []),
                "done": list(sess.get("done") or []),
                "pending": pend,
                "status": str(sess.get("status") or "")}
    except Exception as e:
        return {"present": False, "targets": [], "done": [], "pending": [],
                "error": str(e)}
    finally:
        try:
            if db is not None:
                db.close()
        except Exception:
            pass

def scan_resume_last(targets=None):
    """一键继续上次未完成的扫描：只跑剩余目标（不重扫已完成的）。"""
    if targets:
        pend = [str(t) for t in targets if str(t).strip()]
    else:
        pend = list(scan_session_info().get("pending") or [])
    if not pend:
        return {"ok": False, "error": "没有可续跑的目标"}
    ok, msg = start_scan(pend, None, False, False)
    return {"ok": ok, "error": "" if ok else msg, "targets": pend}

def session_pause_by_exit():
    """进程退出兜底：把「还剩哪些目标」落盘，让下次能续跑。

    覆盖 Ctrl+C / 正常退出（atexit）；被强杀（SIGKILL）无钩子可用，
    此时靠「每目标收尾即时落盘」+「暂停期每 2s 兜底落盘」兜住，
    最坏情况只丢「最后一个未跑完目标之后的进度」。
    """
    eng = _scan_eng()
    if eng is None:
        return False
    try:
        eng._session_pause("paused")
        eng.pause()
        try:
            eng.wait_idle(3.0)
        except Exception:
            pass
        return True
    except Exception:
        return False


def start_scan(targets, mode=None, verify=False, no_poc=False):
    with _SCAN_LOCK:
        if _SCAN["running"]:
            return False, "已有扫描在进行中"
        _SCAN.update({"running": True, "target": ",".join(targets),
                      "started": time.time(), "done": 0, "log": [],
                      "error": "", "summary": "",
                      "eng": None, "paused": False})
    t = threading.Thread(target=_scan_worker,
                         args=(list(targets), mode, verify, no_poc),
                         daemon=True)
    t.start()
    return True, "已启动"


def _scan_worker(targets, mode, verify, no_poc):
    def emit(msg):
        with _SCAN_LOCK:
            _SCAN["log"].append("%s %s" % (
                time.strftime("%H:%M:%S"), msg))

    try:
        from core import logger
        try:
            logger.init()
        except Exception:
            pass
        from core.engine import Engine
        from core.scope import ScopeError
        c = cfg.Config()
        if mode:
            c.set("scan.mode", str(mode))
        if no_poc:
            c.set("scan.enable_poc", False)
        emit("目标: %s | mode=%s | verify=%s"
             % (", ".join(targets), c.get("scan.mode"), verify))
        # 需求 ④：扫前逐目标显示授权状态（与 GUI/CLI 一致）。
        try:
            from core.scope import AUTH_CN
            for _t, _lvl, _rsn in classify_targets(targets):
                emit("[授权状态] %s → %s（%s）"
                     % (_t, AUTH_CN.get(_lvl, _lvl), _rsn))
        except Exception as e:
            emit("授权状态识别失败：%s" % e)
        # Scope 必须用关键字 config= 传入；Engine 在 scope 为空时也会按同一方式自建。
        eng = Engine(config=c, verbose=False)
        # round75：把引擎挂进 _SCAN，暂停/继续/停止三个按钮才有下手对象。
        # 注意 scan_status 里必须把 eng 摘掉，否则 json 序列化会炸。
        with _SCAN_LOCK:
            _SCAN["eng"] = eng
            _SCAN["paused"] = False
        # 统一走 Engine.run：它负责把显式目标并入 scope（仍受 out_of_scope 约束）、
        # 自动核验先于主报告、报告目录预建等顺序约束。逐个 scan_target 会漏掉这些。
        try:
            out = eng.run(targets=targets, report=True, verify=verify)
        except ScopeError as e:
            emit("范围错误: %s" % e)
            out = {"summaries": []}
        for s in (out or {}).get("summaries", []):
            if s.get("error"):
                emit("[失败] %s -> %s" % (s.get("target"), s.get("error")))
            else:
                emit("[完成] %s -> 漏洞 %s 条"
                     % (s.get("target"), s.get("findings", "?")))
                if s.get("auth_cn"):
                    emit("[授权状态] %s（%s）｜强度：主动=%s PoC=%s（同档）"
                         % (s.get("auth_cn"), s.get("auth_reason") or "-",
                            s.get("scan_active"), s.get("scan_poc")))
            with _SCAN_LOCK:
                _SCAN["done"] = _SCAN.get("done", 0) + 1
        db = getattr(eng, "db", None)
        try:
            if db:
                st = db.stats()
                with _SCAN_LOCK:
                    _SCAN["summary"] = json.dumps(st, ensure_ascii=False)
                emit("统计: %s" % st)
        except Exception:
            pass
        try:
            eng.close()
        except Exception:
            pass
        emit("全部完成")
    except Exception:
        tb = traceback.format_exc()
        with _SCAN_LOCK:
            _SCAN["error"] = tb
        emit("失败: %s" % (tb.splitlines()[-1] if tb else "未知错误"))
    finally:
        with _SCAN_LOCK:
            _SCAN["running"] = False
            _SCAN["eng"] = None
            _SCAN["paused"] = False


# ----------------------------------------------------------------------
# 页面
# ----------------------------------------------------------------------
_PAGE = u"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cardinal-SRC-Hunter 控制台 __APPVER__</title>
<style>
:root{--bg:#0f1115;--fg:#e6e6e6;--dim:#8b949e;--card:#171a21;--line:#262b36;
--crit:#ff4d4f;--high:#ff7a45;--med:#faad14;--low:#52c41a;--info:#8b949e;--acc:#4096ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);
font:14px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Noto Sans SC",sans-serif}
header{padding:16px 20px;border-bottom:1px solid var(--line);display:flex;
align-items:center;gap:12px;position:sticky;top:0;background:var(--bg);z-index:9}
h1{font-size:16px;margin:0;font-weight:600}
.wrap{padding:20px;max-width:1280px;margin:0 auto}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px}
.card .n{font-size:24px;font-weight:700}.card .l{color:var(--dim);font-size:12px}
button{background:var(--acc);color:#fff;border:0;border-radius:8px;padding:8px 14px;
cursor:pointer;font-size:13px}button:hover{filter:brightness(1.1)}
input,select,textarea{background:#0c0e12;border:1px solid var(--line);color:var(--fg);
border-radius:8px;padding:8px 10px;font-size:13px;width:100%}
.tabs{display:flex;gap:8px;margin:18px 0 12px;flex-wrap:wrap}
.tab{padding:6px 12px;border:1px solid var(--line);border-radius:20px;cursor:pointer;
color:var(--dim);font-size:13px}.tab.on{color:#fff;border-color:var(--acc)}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--dim);font-weight:500;position:sticky;top:61px;background:var(--bg)}
.sev{padding:1px 8px;border-radius:10px;font-size:12px;color:#000;font-weight:600}
.sev.critical{background:var(--crit);color:#fff}.sev.high{background:var(--high);color:#fff}
.sev.medium{background:var(--med)}.sev.low{background:var(--low);color:#fff}
.sev.info{background:var(--info)}
pre{background:#0c0e12;border:1px solid var(--line);border-radius:8px;padding:12px;
overflow:auto;max-height:420px;font-size:12px;white-space:pre-wrap}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
.muted{color:var(--dim)}.hide{display:none}
.listbox{border:1px solid var(--line);border-radius:8px;padding:6px 10px;
max-height:440px;overflow:auto;background:#0c0e12}
.item{display:flex;gap:8px;align-items:center;padding:7px 4px;flex-wrap:wrap;
border-bottom:1px solid var(--line)}
.item:last-child{border-bottom:0}
.item .nm{font-weight:600}
.item .sub{color:var(--dim);font-size:12px;flex:1;min-width:160px}
.item button{padding:4px 10px;font-size:12px}
.mask{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;
align-items:flex-start;justify-content:center;z-index:99;overflow:auto;
-webkit-overflow-scrolling:touch;padding:3vh 0}
.modal{background:var(--card);border:1px solid var(--line);border-radius:12px;
padding:16px;width:min(580px,92vw);max-height:94vh;min-height:0;
margin:0 auto;display:flex;flex-direction:column;gap:10px}
.modal .mlist{overflow:auto;flex:1 1 auto;min-height:88px;
border:1px solid var(--line);border-radius:8px;padding:6px 10px;
-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
.modal .mbar{flex:0 0 auto;position:sticky;bottom:0;background:var(--card);
padding-top:6px;border-top:1px solid var(--line)}
.modal .mfind{width:100%;box-sizing:border-box}
.modal label{display:flex;gap:8px;align-items:center;padding:4px 0;font-size:13px}
button.ghost{background:#2a3040}
.log{background:#0c0e12;border:1px solid var(--line);border-radius:8px;padding:10px;
font-family:ui-monospace,Menlo,monospace;font-size:12px;max-height:280px;overflow:auto}
a{color:var(--acc);text-decoration:none}a:hover{text-decoration:underline}
</style></head><body>
<header><h1>🛡️ Cardinal-SRC-Hunter <span style="font-size:13px;opacity:.65">__APPVER__</span></h1>
<span class="muted" id="hdr"></span>
<button style="margin-left:auto" onclick="loadAll()">刷新</button></header>
<div class="wrap">
 <div class="cards" id="cards"></div>

 <div class="tabs">
  <div class="tab on" data-t="findings">漏洞</div>
  <div class="tab" data-t="verify">核验</div>
  <div class="tab" data-t="assets">资产</div>
  <div class="tab" data-t="reports">报告</div>
  <div class="tab" data-t="scan">扫描</div>
  <div class="tab" data-t="config">配置</div>
<div class="tab" data-t="ai">\u7aef\u70b9/API</div>
<div class="tab" data-t="skill">SKILL</div>
<div class="tab" data-t="mcp">MCP</div>
 </div>

 <div id="p-findings">
   <div class="row">
     <input id="f-target" placeholder="按目标过滤（留空=全部）" style="max-width:320px">
     <select id="f-sev" style="max-width:180px">
       <option value="">全部等级</option><option>critical</option><option>high</option>
       <option>medium</option><option>low</option><option>info</option></select>
     <button onclick="loadFindings()">查询</button>
   </div>
   <div id="findings"></div>
 </div>

 <div id="p-verify" class="hide"><div id="verify"></div></div>
 <div id="p-assets" class="hide"><div id="assets"></div></div>

  <div id="p-reports" class="hide">
    <div class="row"><select id="r-sel" style="display:none"></select>
    <button onclick="openReport()">打开</button>
    <button onclick="openReportInTab()">\u5728\u6d4f\u89c8\u5668\u65b0\u6807\u7b7e\u6253\u5f00</button>
    <button onclick="loadReports()">刷新</button>
    <span class="muted" id="rep-msg"></span></div>
    <div class="listbox" id="report-list"></div>
    <pre id="report-body" class="hide"></pre>
  </div>

 <div id="p-scan" class="hide">
   <div class="row">
     <input id="s-target" placeholder="目标，多个用逗号分隔，如 http://127.0.0.1:8081" >
     <select id="s-mode" style="max-width:160px">
       <option value="safe">safe</option><option value="normal">normal</option>
       <option value="aggressive" selected>aggressive</option></select>
     <label class="muted"><input type="checkbox" id="s-verify" style="width:auto"> 扫后核验</label>
     <button onclick="doScan()">开始扫描</button>
     <button id="btn-pause" onclick="doPause()">暂停</button>
     <button id="btn-resume" onclick="doResume()">继续</button>
     <button id="btn-stop" onclick="doStop()">停止</button>
     <span class="muted" id="scan-state"></span>
   </div>
   <div class="row"><button id="btn-resume-last" style="display:none"
     onclick="resumeLast()">继续上次扫描</button>
     <span class="muted" id="scan-sess">（读取中…）</span></div>
   <div class="log" id="scan-log">（无）</div>
 </div>

 <div id="p-config" class="hide">
   <textarea id="cfg" rows="22" spellcheck="false"></textarea>
   <div class="row" style="margin-top:10px"><button onclick="saveCfg()">保存</button>
   <span class="muted" id="cfg-msg"></span></div>
 </div>
<div id="p-ai" class="hide">
<div class="row"><span class="muted">\u63a5\u53e3\u5730\u5740</span><input id="ai-base" placeholder="https://api.example.com/v1" style="max-width:420px"></div>
<div class="row"><span class="muted">API \u5bc6\u94a5</span><input id="ai-key" type="text" placeholder="sk-...\uff08\u4fdd\u5b58\u540e\u6c38\u4e45\u843d\u76d8\uff0c\u4e0b\u6b21\u81ea\u52a8\u56de\u586b\uff09" style="max-width:420px"><span class="muted" id="ai-key-msg"></span></div>
 <div class="row"><span class="muted">模型名</span><input id="ai-model" placeholder="gpt-4o-mini" style="max-width:420px"><button onclick="refreshModels()">刷新模型</button><span class="muted">可多选，多个用逗号分隔</span></div>
 <div class="row" style="border-top:1px solid #ddd;padding-top:8px">
  <label class="muted"><input type="checkbox" id="ai-enabled" style="width:auto"> 启用 AI</label>
  <label class="muted"><input type="checkbox" id="ai-online" style="width:auto"> 允许联网</label>
  <label class="muted"><input type="checkbox" id="ai-takeover" style="width:auto"> AI 接管扫描</label>
  <label class="muted" title="round93 FIX-36：这两个勾选框才是真正的 AI 侧闸门（takeover.allow_active / allow_poc）。取消勾选后 AI 只能出候选洞，不发主动检测包、不跑 PoC。"><input type="checkbox" id="ai-allow-active" style="width:auto"> AI 可主动发包</label>
  <label class="muted"><input type="checkbox" id="ai-allow-poc" style="width:auto"> AI 可跑 PoC</label>
  <select id="ai-mode" style="max-width:140px">
   <option value="advisory">advisory（有人环）</option>
   <option value="auto">auto（无人驾驶）</option></select>
 </div>
 <div class="row"><span class="muted" id="ai-status">（状态未读取）</span></div>
 <div class="row"><button onclick="saveAI()">\u4fdd\u5b58</button><span class="muted" id="ai-msg"></span></div>
</div>
<div id="p-skill" class="hide">
<div class="row"><button onclick="loadSkill()">刷新列表</button><button onclick="pickSkillFile()">安装(.md/.zip)</button><button id="skill-all" onclick="skillAllToggle()">总开关</button><input id="skill-file" type="file" accept=".md,.zip" style="display:none" onchange="onSkillFile(this)"><span class="muted" id="skill-msg"></span></div>
<div class="listbox" id="skill-list"></div>
</div>
<div id="p-mcp" class="hide">
<div class="row"><input id="mcp-name" placeholder="名称" style="max-width:160px"><input id="mcp-command" placeholder="命令" style="max-width:440px"><button onclick="addMCP()">添加</button><button onclick="pickMcpFile()">导入(.json/.zip)</button><input id="mcp-file" type="file" accept=".json,.zip" style="display:none" onchange="onMcpFile(this)"><button onclick="loadMCP()">刷新</button><button id="mcp-all" onclick="mcpAllToggle()">总开关</button><span class="muted" id="mcp-msg"></span><span class="muted" id="mcp-bg"></span></div>
<div class="listbox" id="mcp-list"></div>
</div>

</div>

<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function sev(s){return '<span class="sev '+esc(s)+'">'+esc(s||'-')+'</span>';}
async function J(u,o){
 let r;
 try{r=await fetch(u,o)}catch(e){throw new Error('\u7f51\u7edc\u9519\u8bef '+e.message)}
 const t=await r.text();let d;
 try{d=JSON.parse(t)}catch(e){d=t}
 if(d&&typeof d==='object'&&!Array.isArray(d)){d.__status=r.status;d.__http_ok=r.ok}
 else if(!r.ok){d={__status:r.status,__http_ok:false,error:String(t).slice(0,300)}}
 return d}
function note(m){try{$('#hdr').textContent=m}catch(e){}}
window.addEventListener('unhandledrejection',function(ev){
 note('\u64cd\u4f5c\u51fa\u9519\uff1a'+((ev.reason&&ev.reason.message)||ev.reason));
});
window.addEventListener('error',function(ev){
 note('页面出错：'+((ev.message)||'unknown')+' @'+((ev.lineno)||'?'));
});

document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{
  document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on',x===t));
  ['findings','verify','assets','reports','scan','config','ai','skill','mcp'].forEach(k=>
    $('#p-'+k).classList.toggle('hide',k!==t.dataset.t));
  // round76：切到 AI 页就立刻按磁盘真值重载一次。
  // 旧版切 tab 只 toggle class，不触发任何 load —— 首屏 loadAll() 是串行的
  // （findings 257KB、reports 2.3s、scan-session 3s…），loadAI 排第 8 位，
  // 用户点进来时往往还没轮到，看到的就是空框，误以为「被清空了」。
  if(t.dataset.t==='ai'){try{loadAI()}catch(e){}}
  if(t.dataset.t==='skill'){try{loadSkill()}catch(e){}}
  if(t.dataset.t==='mcp'){try{loadMCP()}catch(e){}}
});

function fail(msg){try{$('#hdr').textContent='\u26a0 '+msg}catch(e){}}
function ok(){try{$('#hdr').textContent='\u5c31\u7eea'}catch(e){}}
function needArr(d,name){
 if(Array.isArray(d))return d;
 const st=(d&&d.__status)||'';
 const er=(d&&d.error)||'';
 fail(name+' \u52a0\u8f7d\u5931\u8d25'+(st?(' HTTP '+st):'')+(er?(' \u2014 '+er):''));
 return null;}
async function loadCards(){
 try{
  const s=await J('/api/stats');
  const f=s.findings||{};const items=[['\u603b\u6f0f\u6d1e',f.total||0],['\u4e25\u91cd',f.critical||0],
    ['\u9ad8\u5371',f.high||0],['\u4e2d\u5371',f.medium||0],['\u4f4e\u5371',f.low||0],
    ['\u8d44\u4ea7',s.assets||0],['\u6838\u9a8c',s.verifications||0]];
  $('#cards').innerHTML=items.map(([l,n])=>'<div class="card"><div class="n">'+
    n+'</div><div class="l">'+l+'</div></div>').join('');
  const ls=s.last_scan||{};
  $('#hdr').textContent=ls.target?('\u4e0a\u6b21\u626b\u63cf '+ls.target):'\u5c31\u7eea';
 }catch(e){fail('\u6982\u89c8\u52a0\u8f7d\u5931\u8d25\uff1a'+e.message)}}
// ---- batch delete (frontend common) ----
function ckList(listId){var w=document.getElementById(listId);return w?w.querySelectorAll('input.ck'):[]}
function pickIds(listId){var a=[];ckList(listId).forEach(function(c){if(c.checked)a.push(c.value)});
 /*r87e*/ if(!a.length){var ks=ckList(listId);if(ks.length===1)a.push(ks[0].value);}
 return a}
function ckAll(box,listId){ckList(listId).forEach(function(c){c.checked=box.checked})}
async function delSel(kind,listId,btn,refreshFn){
  var ids=pickIds(listId);
  if(!ids.length){alert('pick items first');return}
  if(!confirm('delete '+ids.length+' items? irreversible'))return;
  if(btn)btn.disabled=true;
  try{
    var d=await J('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:kind,ids:ids})});
    if(d&&d.ok){alert('deleted '+(d.deleted||0));if(refreshFn&&window[refreshFn])window[refreshFn]()}
    else{alert('delete failed: '+((d&&d.error)||'unknown'))}
  }catch(e){alert('delete failed: '+e.message)}
  finally{if(btn)btn.disabled=false}
}

async function loadFindings(){
 try{
  const t=$('#f-target').value.trim(),sv=$('#f-sev').value;
  const d=await J('/api/findings?target='+encodeURIComponent(t)+
    '&severity='+encodeURIComponent(sv));
  const rows=needArr(d,'\u6f0f\u6d1e');if(rows===null){$('#findings').innerHTML='';return;}
  if(!rows.length){$('#findings').innerHTML='<p class="muted">\u65e0\u8bb0\u5f55</p>';return;}
  $('#findings').innerHTML='<table><tr><th>ID</th><th>\u7b49\u7ea7</th><th>\u7c7b\u578b</th><th>\u6807\u9898</th>'+
   '<th>URL</th><th>\u6838\u9a8c</th></tr>'+rows.map(r=>'<tr><td>'+r.id+'</td><td>'+sev(r.severity)+
   '</td><td>'+esc(r.vuln_type)+'</td><td>'+esc(r.title)+'</td><td>'+esc(r.url)+
   '</td><td>'+esc((r.extra&&(r.extra.verify_verdict||(r.extra.verified?'verified':'')))||'-')+
   '</td></tr>').join('')+'</table>';
 }catch(e){fail('\u6f0f\u6d1e\u52a0\u8f7d\u5931\u8d25\uff1a'+e.message)}}
async function loadVerify(){
 try{
  const d=await J('/api/verifications?limit=200');
  const rows=needArr(d,'\u6838\u9a8c');if(rows===null){$('#verify').innerHTML='';return;}
  if(!rows.length){$('#verify').innerHTML='<p class="muted">\u65e0\u8bb0\u5f55</p>';return;}
  $('#verify').innerHTML='<table><tr><th>ID</th><th>\u76ee\u6807</th><th>\u7c7b\u578b</th><th>\u5224\u5b9a</th>'+
   '<th>\u65b9\u6cd5</th><th>\u65f6\u95f4</th></tr>'+rows.map(r=>'<tr><td>'+r.id+'</td><td>'+esc(r.target)+
   '</td><td>'+esc(r.vuln_type)+'</td><td>'+esc(r.verdict)+'</td><td>'+esc(r.method_used)+
   '</td><td>'+new Date((r.created_at||0)*1000).toLocaleString()+'</td></tr>').join('')+'</table>';
 }catch(e){fail('\u6838\u9a8c\u52a0\u8f7d\u5931\u8d25\uff1a'+e.message)}}
async function loadAssets(){
 try{
  const d=await J('/api/assets?limit=500');
  const rows=needArr(d,'\u8d44\u4ea7');if(rows===null){$('#assets').innerHTML='';return;}
  if(!rows.length){$('#assets').innerHTML='<p class="muted">\u65e0\u8bb0\u5f55</p>';return;}
  $('#assets').innerHTML='<table><tr><th>\u4e3b\u673a</th><th>URL</th><th>IP</th><th>\u72b6\u6001</th>'+
   '<th>\u6807\u9898</th><th>\u6280\u672f</th></tr>'+rows.map(r=>'<tr data-id="'+r.id+'"><td>'+esc(r.host)+'</td><td>'+
   esc(r.url)+'</td><td>'+esc(r.ip)+'</td><td>'+esc(r.status)+'</td><td>'+esc(r.title)+
   '</td><td>'+esc(r.tech)+'</td></tr>').join('')+'</table>';
 }catch(e){fail('\u8d44\u4ea7\u52a0\u8f7d\u5931\u8d25\uff1a'+e.message)}}
async function loadReports(){
 try{
  const d=await J('/api/reports');
  const rows=needArr(d,'\u62a5\u544a');if(rows===null){$('#r-sel').innerHTML='';return;}
  $('#r-sel').innerHTML=rows.map(r=>'<option value="'+esc(r.name)+'">'+esc(r.name)+
    ' ('+((r.files||[]).length)+' \u6587\u4ef6)</option>').join('')||'<option>\u65e0\u62a5\u544a</option>';
  const box=$('#report-list');
  if(box){box.innerHTML='';
   if(!rows.length){box.textContent='\uff08\u6682\u65e0\u62a5\u544a\uff09';}
   else rows.forEach(function(r){
    const w=document.createElement('div');w.className='item';
    const ck=document.createElement('input');ck.type='checkbox';ck.className='ck';
    ck.value=(r.name||'');w.appendChild(ck);
    const nm=document.createElement('span');nm.className='nm';nm.textContent=(r.name||'?');
    const sub2=document.createElement('span');sub2.className='sub';
    sub2.textContent=((r.files||[]).length)+' \u4e2a\u6587\u4ef6';
    w.appendChild(nm);w.appendChild(sub2);
    const b=document.createElement('button');b.textContent='\u9009\u4e2d';
    b.onclick=function(){$('#r-sel').value=r.name;$('#rep-msg').textContent='\u5df2\u9009\u4e2d '+r.name;};
    w.appendChild(b);box.appendChild(w);});}
 }catch(e){fail('\u62a5\u544a\u5217\u8868\u5931\u8d25\uff1a'+e.message)}}
async function openReport(){
 const n=$('#r-sel').value;if(!n){alert('\u8bf7\u5148\u9009\u62e9\u62a5\u544a');return;}
 try{
  const d=await J('/api/report?name='+encodeURIComponent(n));
  const files=(d&&d.files)||[];if(!files.length){alert('\u8be5\u62a5\u544a\u76ee\u5f55\u65e0\u6587\u4ef6');return;}
  const md=files.find(f=>f.endsWith('.md'))||files[0];
  const c=await J('/api/report?name='+encodeURIComponent(n)+'&file='+encodeURIComponent(md));
  $('#report-body').classList.remove('hide');
  $('#report-body').textContent=(c&&c.content)||'';
 }catch(e){alert('\u6253\u5f00\u62a5\u544a\u5931\u8d25\uff1a'+e.message)}}
function openReportInTab(){
 const n=$('#r-sel').value;if(!n){alert('\u8bf7\u5148\u9009\u62e9\u62a5\u544a');return;}
 J('/api/report?name='+encodeURIComponent(n)).then(function(d){
  const files=(d&&d.files)||[];
  const md=files.find(f=>String(f).endsWith('.md'))||files[0];
  if(!md){alert('\u8be5\u62a5\u544a\u76ee\u5f55\u65e0\u6587\u4ef6');return;}
  window.open('/api/report/raw?name='+encodeURIComponent(n)+'&file='+encodeURIComponent(md),'_blank');
 }).catch(function(e){alert('\u6253\u5f00\u62a5\u544a\u5931\u8d25\uff1a'+e.message)});}
async function doScan(){
 const t=$('#s-target').value.trim();if(!t){alert('\u8bf7\u5148\u586b\u76ee\u6807');return;}
 try{
  const body={targets:t.split(',').map(x=>x.trim()).filter(Boolean),
    mode:$('#s-mode').value,verify:$('#s-verify').checked};
  const r=await J('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)});
  if(!r||!r.ok){alert((r&&r.error)||'\u542f\u52a8\u5931\u8d25');return;}
  note('\u626b\u63cf\u5df2\u542f\u52a8');pollScan();
 }catch(e){alert('\u542f\u52a8\u626b\u63cf\u5931\u8d25\uff1a'+e.message)}}
async function pollScan(){
 try{
  const s=await J('/api/scan/status');
  $('#scan-log').textContent=(s&&s.log?(Array.isArray(s.log)?s.log.join('\\n'):String(s.log)):'\uff08\u65e0\uff09');
  $('#scan-log').scrollTop=1e9;
  const st=$('#scan-state');
  if(st)st.textContent=(s&&s.running)?(s.paused?'\u5df2\u6682\u505c':'\u8fd0\u884c\u4e2d'):'';
  if(s&&s.running)setTimeout(pollScan,1500);else{loadCards();loadScanSession();}
 }catch(e){note('\u72b6\u6001\u8bfb\u53d6\u5931\u8d25\uff1a'+e.message)}}
async function _scanAction(path,msg){
 try{
  const r=await J(path,{method:'POST',headers:{'Content-Type':'application/json'},
    body:'{}'});
  if(!r||!r.ok){alert((r&&r.error)||msg+'\u5931\u8d25');return;}
  note(msg);pollScan();loadScanSession();
 }catch(e){alert(msg+'\u5931\u8d25\uff1a'+e.message)}}
function doPause(){_scanAction('/api/scan/pause','\u5df2\u6682\u505c\uff08\u8fdb\u5ea6\u5df2\u4fdd\u5b58\uff09')}
function doResume(){_scanAction('/api/scan/resume','\u5df2\u7ee7\u7eed')}
function doStop(){_scanAction('/api/scan/stop','\u5df2\u505c\u6b62\uff08\u8fdb\u5ea6\u5df2\u4fdd\u5b58\uff0c\u53ef\u7eed\u8dd1\uff09')}
async function loadScanSession(){
 try{
  const s=await J('/api/scan/session');
  const el=$('#scan-sess');if(!el)return;
  const b=$('#btn-resume-last');
  if(s&&s.present){
   el.textContent='\u6709\u672a\u5b8c\u6210\u7684\u626b\u63cf\uff1a\u8fd8\u5269 '+s.pending.length+' \u4e2a\u76ee\u6807\uff08'+s.pending.join('\uff0c')+'\uff09';
   if(b)b.style.display='';
  }else{
   el.textContent='\uff08\u65e0\u672a\u5b8c\u6210\u7684\u626b\u63cf\uff09';
   if(b)b.style.display='none';
  }
 }catch(e){}}
async function resumeLast(){
 try{
  const r=await J('/api/scan/resume-last',{method:'POST',
    headers:{'Content-Type':'application/json'},body:'{}'});
  if(!r||!r.ok){alert((r&&r.error)||'\u7eed\u8dd1\u5931\u8d25');return;}
  note('\u5df2\u4ece\u4e0a\u6b21\u4e2d\u65ad\u5904\u7ee7\u7eed');
  pollScan();loadScanSession();
 }catch(e){alert('\u7eed\u8dd1\u5931\u8d25\uff1a'+e.message)}}
async function loadCfg(){
 try{$('#cfg').value=JSON.stringify(await J('/api/config'),null,2);$('#cfg-msg').textContent='';}
 catch(e){$('#cfg-msg').textContent='\u8bfb\u53d6\u5931\u8d25: '+e.message;}}
async function saveCfg(){
 try{const p=JSON.parse($('#cfg').value);
  const r=await J('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(p)});
  $('#cfg-msg').textContent=(r&&r.__http_ok)?'\u5df2\u4fdd\u5b58':('\u4fdd\u5b58\u5931\u8d25 HTTP '+((r&&r.__status)||'?'));}
 catch(e){$('#cfg-msg').textContent='JSON \u89e3\u6790\u5931\u8d25: '+e.message;}}
async function loadAll(){
 const _e=async(f,n)=>{try{await f()}catch(err){note(n+' 出错：'+((err&&err.message)||err))}};
 await _e(loadCards,'概览');
 await _e(loadFindings,'漏洞');
 await _e(loadVerify,'核验');
 await _e(loadAssets,'资产');
 await _e(loadReports,'报告');
 await _e(loadScanSession,'扫描会话');
 await _e(loadCfg,'配置');
 await _e(loadAI,'端点');
 await _e(loadSkill,'SKILL');
 await _e(loadMCP,'MCP');
 ok();}
async function loadAI(){
 try{const c=await J('/api/config');const a=(c&&c.ai)||{};
  $('#ai-base').value=a.api_base||'';
  // round76：密钥落盘 + 完全回显（用户拍板）。旧代码这里无条件清空，
  // 导致「刷新后密钥框永远空白、用户以为没存上」。
  $('#ai-key').value=((c&&c.__ai_status&&c.__ai_status.key_preview)||'');
  $('#ai-key-msg').textContent='';
  $('#ai-model').value=a.model||'';
  const s=(c&&c.__ai_status)||{};
  const tk=((c&&c.takeover)||{});
  const cb=function(id,v){const e=$(id);if(e)e.checked=!!v};
  cb('#ai-enabled', a.enabled);
  cb('#ai-online', a.online);
  cb('#ai-takeover', (s.takeover!==undefined?s.takeover:tk.enabled));
  // round93 FIX-36：AI 侧闸门回填。取运行态快照（缺键时退回磁盘值）。
  cb('#ai-allow-active', (s.allow_active!==undefined?s.allow_active:tk.allow_active));
  cb('#ai-allow-poc', (s.allow_poc!==undefined?s.allow_poc:tk.allow_poc));
  const md=(s.takeover_mode||tk.mode||'advisory');
  if($('#ai-mode'))$('#ai-mode').value=(md==='auto'?'auto':'advisory');
  $('#ai-msg').textContent='';
  renderAIStatus();}
 catch(e){$('#ai-msg').textContent='\u8bfb\u53d6\u5931\u8d25: '+e.message;}}
function renderAIStatus(){
 const el=$('#ai-status');if(!el)return;
 J('/api/config').then(function(c){
  const s=(c&&c.__ai_status)||{};
  const y=function(v){return v?'已开':'未开'};
  const p=[];
  p.push('AI='+y(s.ai_enabled));
  p.push('联网='+y(s.ai_online));
  p.push('接管='+y(s.takeover));
  p.push('AI主动包='+(s.can_active?'许':'禁'));
  p.push('AI PoC='+(s.can_poc?'许':'禁'));
  p.push('端点='+y(s.base_set));
  p.push('模型='+y(s.model_set));
  p.push('密钥='+y(s.key_set));
  const tail=s.ready?'\u2714 全部就绪，扫描时会调用 AI':'\u2716 未就绪，扫描时不会调用 AI（不消耗 token）';
  el.textContent=p.join(' | ')+'  '+tail;
  el.style.color=s.ready?'#0a0':'#c00';
 }).catch(function(){});}
async function saveAI(){
 // round76：一次保存写全「端点 + 模型 + 三开关 + 模式 + 密钥」。
 // 旧版把密钥交给另一个独立按钮单独写，用户点「保存」后密钥其实没存，
 // 于是下次打开要重填 —— 这正是需求 2/3 的成因。
 const key=$('#ai-key').value.trim();
 $('#ai-msg').textContent='保存中…';
 try{
  const c=await J('/api/config');
  // 只提交后端认识的段，避免把 __status/__http_ok/__ai_status 这些
  // 前端注入键回灌（后端白名单会忽略，但少传更干净、回包更小）。
  const body={};
  ['target','http','scan','tools','report','bootstrap','ai','takeover'].forEach(function(k){
   if(c&&c[k]!==undefined)body[k]=c[k];
  });
  body.ai=body.ai||{};
  body.ai.api_base=$('#ai-base').value.trim();
  body.ai.model=$('#ai-model').value.trim();
  body.ai.enabled=!!($('#ai-enabled')&&$('#ai-enabled').checked);
  body.ai.online=!!($('#ai-online')&&$('#ai-online').checked);
  body.takeover=body.takeover||{};
  body.takeover.enabled=!!($('#ai-takeover')&&$('#ai-takeover').checked);
  body.takeover.mode=($('#ai-mode')&&$('#ai-mode').value)||'advisory';
  // round93 FIX-36：AI 侧闸门一并写回（这两个键已接到 tool_registry 强度闸门）。
  body.takeover.allow_active=!!($('#ai-allow-active')&&$('#ai-allow-active').checked);
  body.takeover.allow_poc=!!($('#ai-allow-poc')&&$('#ai-allow-poc').checked);
  // 密钥单独字段：后端摘出来写 data/ai_key.txt，绝不进 config.json
  body.__ai_key=key;
  const r=await J('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)});
  if(r&&r.__http_ok){
   const st=(r.__ai_status)||{};
   // 保存后立刻把磁盘真值回填，避免「界面上是 A、磁盘里是 B」。
   // 注意顺序：loadAI() 会清空 ai-msg / ai-key-msg，所以提示必须写在它之后。
   await loadAI();
   $('#ai-msg').textContent='已保存（配置文件 + 密钥文件均已落盘）';
   $('#ai-key-msg').textContent=key?('密钥已落盘：'+((st.key_path)||'data/ai_key.txt')):'';
   note(st.ready?'AI 配置已保存，全部就绪':'AI 配置已保存（尚有闸门未开，扫描不会调用 AI）');
  }else{
   $('#ai-msg').textContent='保存失败 HTTP '+((r&&r.__status)||'?')+
     ((r&&(r.error||r.msg))?(' — '+(r.error||r.msg)):'');
  }
 }catch(e){$('#ai-msg').textContent='保存失败: '+e.message;}
 renderAIStatus();}
function _mask(build){
 const box=document.createElement('div');box.className='mask';
 const inner=document.createElement('div');inner.className='modal';
 build(inner,box);box.appendChild(inner);
 box.onclick=function(e){if(e.target===box)box.remove()};
 document.body.appendChild(box);}
function showText(title,text){
 _mask(function(inner,box){
  const h=document.createElement('div');h.innerHTML='<b>'+esc(title)+'</b>';
  const pre=document.createElement('pre');pre.textContent=text||'（空）';
  pre.style.maxHeight='50vh';
  const bar=document.createElement('div');bar.className='row';bar.style.margin='0';
  const b=document.createElement('button');b.textContent='关闭';
  b.onclick=function(){box.remove()};bar.appendChild(b);
  inner.appendChild(h);inner.appendChild(pre);inner.appendChild(bar);});}
async function refreshModels(){
 const base=$('#ai-base').value.trim(),key=$('#ai-key').value.trim();
 if(!base){$('#ai-msg').textContent='请先填接口地址';return;}
 $('#ai-msg').textContent='正在拉取模型…';
 try{
  const r=await J('/api/ai/models',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({api_base:base,api_key:key})});
  if(!r||!r.ok){$('#ai-msg').textContent='拉取失败：'+((r&&r.error)||'未知错误');return;}
  const ms=(r.models||[]);
  if(!ms.length){$('#ai-msg').textContent='接口返回空模型列表';return;}
  $('#ai-msg').textContent='共 '+ms.length+' 个模型，请勾选';
  showModelPicker(ms);}
 catch(e){$('#ai-msg').textContent='拉取失败: '+e.message;}}
function showModelPicker(models){
 const cur=($('#ai-model').value||'').split(',').map(function(x){return x.trim()}).filter(Boolean);
 _mask(function(inner,box){
  const h=document.createElement('div');
  h.innerHTML='<b>选择模型</b> <span class="muted">可单选也可多选，多个用逗号分隔</span>';
  /* r89 UI修：模型可能几百条，先给一个过滤框，免得滑到手残 */
  const find=document.createElement('input');find.type='text';find.className='mfind';
  find.placeholder='输入关键字过滤（如 gpt / claude / qwen）';
  const list=document.createElement('div');list.className='mlist';
  const cnt=document.createElement('span');cnt.className='muted';cnt.style.fontSize='12px';
  function render(){
   const kw=(find.value||'').trim().toLowerCase();
   list.innerHTML='';
   let shown=0;
   models.forEach(function(m){
    if(kw && String(m).toLowerCase().indexOf(kw)<0) return;
    shown++;
    const lb=document.createElement('label');
    const cb=document.createElement('input');cb.type='checkbox';cb.value=m;
    cb.checked=cur.indexOf(m)>=0;cb.style.width='auto';
    cb.onchange=function(){const i=cur.indexOf(m);if(cb.checked){if(i<0)cur.push(m)}else{if(i>=0)cur.splice(i,1)}};
    const sp=document.createElement('span');sp.textContent=m;
    lb.appendChild(cb);lb.appendChild(sp);list.appendChild(lb);});
   cnt.textContent='已选 '+(cur.length||0)+' / 共 '+models.length+'，当前显示 '+shown;
  }
  find.oninput=render;
  render();
  const bar=document.createElement('div');bar.className='row mbar';bar.style.margin='0';
  const mk=function(label,fn,cls){const b=document.createElement('button');
   b.textContent=label;if(cls)b.className=cls;b.onclick=fn;return b;};
  /* 全选/清空只作用于当前过滤后可见项，避免误伤已选 */
  const visible=function(){return Array.prototype.slice.call(list.querySelectorAll('input'))};
  /* r89 修复：勾选状态以 DOM 为准再回填 cur。原因：脚本化/无障碍点击
     （以及部分移动端 WebView）会直接改 checked 而不触发 onchange，只靠
     onchange 维护 cur 会丢勾选 -> 点「确定」写回空值。这里在写回前做一次
     可见项同步：checked 的补进 cur，未勾的从 cur 移除，过滤外的保留。 */
  const sync=function(){visible().forEach(function(c){
   const i=cur.indexOf(c.value);
   if(c.checked){if(i<0)cur.push(c.value)}else if(i>=0){cur.splice(i,1)}});};
  const bOk=mk('确定',function(){
   sync();
   $('#ai-model').value=cur.join(',');
   $('#ai-msg').textContent=cur.length?('已选择 '+cur.length+' 个模型'):'未选择';
   box.remove();});
  bar.appendChild(mk('全选当前',function(){visible().forEach(function(c){c.checked=true;if(cur.indexOf(c.value)<0)cur.push(c.value)});render();},'ghost'));
  bar.appendChild(mk('清空当前',function(){visible().forEach(function(c){c.checked=false;const i=cur.indexOf(c.value);if(i>=0)cur.splice(i,1)});render();},'ghost'));
  bar.appendChild(mk('清空全部',function(){cur.length=0;render();},'ghost'));
  bar.appendChild(bOk);
  bar.appendChild(mk('取消',function(){box.remove()},'ghost'));
  inner.appendChild(h);inner.appendChild(find);inner.appendChild(cnt);
  inner.appendChild(list);inner.appendChild(bar);});}
function _skillRow(r){
 const wrap=document.createElement('div');wrap.className='item';
 const ck=document.createElement('input');ck.type='checkbox';ck.className='ck';ck.value=(r.file||'');
 wrap.appendChild(ck);
 const nm=document.createElement('span');nm.className='nm';
 nm.textContent=(r.name||r.file||'?');
 const sub=document.createElement('span');sub.className='sub';
 sub.textContent=(r.enabled==='ON'?'已启用':'已停用')+' · '+(r.file||'').split('/').pop();/*r87e*/
 wrap.appendChild(nm);
 if(r.tools&&r.tools.length){
  const t2=document.createElement('span');t2.className='sub';
  t2.textContent=' 工具 '+r.tools.length+' 个：'+r.tools.slice(0,6).join(', ')+(r.tools.length>6?' …':'');/*r87e*/
  wrap.appendChild(t2);}
 if(r.unknown&&r.unknown.length){
  const u2=document.createElement('span');u2.className='sub';
  u2.style.color='#c62828';
  u2.textContent=' ⚠ 未知工具：'+r.unknown.join(', ');
  wrap.appendChild(u2);}
 wrap.appendChild(sub);
 const mk=function(label,act){const b=document.createElement('button');
  b.textContent=label;b.onclick=function(){skillAct(act,r.file)};return b;};
 wrap.appendChild(mk('启用','enable'));wrap.appendChild(mk('停用','disable'));
 wrap.appendChild(mk('查看','show'));
 return wrap;}
async function loadSkill(){
 try{const d=await J('/api/skill/list');window._skillLastD=d||{};
  const box=$('#skill-list');box.innerHTML='';
  const txt=(d&&(d.stdout||d.stderr))||'';
  let rows=[];
  // round80 ①：结构化字段优先（带 tools/unknown），拿不到再回落解析 stdout。
  const st=(d&&d.skills)||[];
  if(st.length){
   rows=st.map(function(s){return {enabled:(s.enabled?'ON':'off'),kind:s.kind||'all',
     file:s.file||'',pri:(s.priority===undefined?0:s.priority),name:s.name||'',
     tools:s.tools||[],unknown:s.unknown||[]};});
  }else{
   txt.split('\\n').forEach(function(ln){
    const m=ln.match(/^\\s*(ON|off)\\s+(\\S+)\\s+(.+?)\\s+p=(\\d+)\\s*(.*)$/);
    if(m)rows.push({enabled:m[1],kind:m[2],file:m[3].trim(),pri:m[4],
                    name:(m[5]||'').trim(),tools:[],unknown:[]});});}
  if(!rows.length){box.textContent=txt||'（skills/ 下暂无技能）';}
  else rows.forEach(function(r){box.appendChild(_skillRow(r))});
  $('#skill-msg').textContent=(d&&d.ok)?('共 '+rows.length+' 个技能'):'失败';
  window._skillAllOn=!!(d&&d.ok&&d.enabled);
  var _sb=document.getElementById('skill-all');
  if(_sb)_sb.textContent=window._skillAllOn?'总开关：已开 · 点击关闭':'总开关：已关 · 点击开启';}
 catch(e){$('#skill-msg').textContent='读取失败: '+e.message;}
}
async function skillAct(act,nm){
 if(!nm&&act.indexOf('all_')!==0){const hint={install:'安装',enable:'启用',disable:'停用',show:'查看',uninstall:'卸载'}[act]||act;
  const v=prompt('请输入要'+hint+'的技能名（可留空=all）','');
  if(v===null){$('#skill-msg').textContent='已取消';return;}
  nm=(v||'').trim();}
 try{const r=await J('/api/skill',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({action:act,name:nm})});
  const okk=(r&&r.ok);
  if(act==='show'){showText('技能：'+(nm||'all'),(r&&(r.stdout||r.stderr))||'');}
  $('#skill-msg').textContent=okk?('OK '+act):('失败 '+((r&&(r.error||r.stderr))||''));
  loadSkill();}
 catch(e){$('#skill-msg').textContent='操作失败: '+e.message;}}
function pickSkillFile(){$('#skill-file').click();}
function onSkillFile(inp){
 const f=inp.files&&inp.files[0];inp.value='';
 if(!f)return;
 const rd=new FileReader();
 rd.onload=function(){
  const b64=String(rd.result).split(',')[1]||'';
  $('#skill-msg').textContent='正在安装 '+f.name+' …';
  J('/api/skill',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'upload',filename:f.name,data_b64:b64})})
  .then(function(r){
   if(r&&r.ok){
    const sk=(r.skipped||[]);
    $('#skill-msg').textContent='已安装：'+((r.installed||[]).join('、')||'0 个')+
      (sk.length?('；跳过：'+sk.join('、')):'');
   }else{$('#skill-msg').textContent='安装失败：'+((r&&r.error)||'');}
   loadSkill();})
  .catch(function(e){$('#skill-msg').textContent='安装失败: '+e.message});};
 rd.onerror=function(){$('#skill-msg').textContent='读取文件失败';};
 rd.readAsDataURL(f);}

function _mcpRow(s){
 const wrap=document.createElement('div');wrap.className='item';
 const ck=document.createElement('input');ck.type='checkbox';ck.className='ck';ck.value=(s.name||'');
 wrap.appendChild(ck);
 const nm=document.createElement('span');nm.className='nm';nm.textContent=(s.name||'?');
 const sub=document.createElement('span');sub.className='sub';
 sub.textContent=(s.enabled===false?'已停用':'已启用')+(s.n_tools?(' · '+s.n_tools+' 个工具'):' · 待探活');/*r87e*/
 wrap.appendChild(nm);wrap.appendChild(sub);
 const mk=function(label,act){const b=document.createElement('button');
  b.textContent=label;b.onclick=function(){mcpAct(act,s.name)};return b;};
 wrap.appendChild(mk(s.enabled===false?'启用':'停用',s.enabled===false?'enable':'disable'));
 const pb=document.createElement('button');
 pb.textContent='测试连接';pb.onclick=function(){probeMCP(s.name)};
 wrap.appendChild(pb);
 return wrap;}
async function loadMCP(){
 try{const d=await J('/api/mcp/list');
  window._mcpLastD=d||{};
  const box=$('#mcp-list');box.innerHTML='';
  const sv=(d&&d.servers)||[];
  if(!sv.length){box.textContent='（暂无 MCP 服务）';}
  else sv.forEach(function(s){box.appendChild(_mcpRow(s))});
  window._mcpOn=!!(d&&d.ok&&d.enabled);
  var _ab=document.getElementById('mcp-all');
  if(_ab)_ab.textContent=window._mcpOn?'总开关：已开 · 点击关闭':'总开关：已关 · 点击开启';
  const _rc=(d&&d.reason_code)||'';
  const _rs=(d&&d.reason)||'';
  $('#mcp-msg').textContent=(d&&d.ok)
    ?((_rc==='ready')
       ?('共 '+sv.length+' 个 MCP 服务 · 已生效 '+((d.active_servers||[]).length)+' 个')
       :(_rs||'共 '+sv.length+' 个 MCP 服务'))
    :('失败 '+((d&&d.error)||''));}
 catch(e){$('#mcp-msg').textContent='读取失败: '+e.message;}
  _mcpBgShow();}
function _mcpBgText(b){
 if(!b||!b.show)return '';
 var ag=(b.age>=0)?(b.age+'s 前'):'尚未完成首轮';
 return b.ok?('已注册 '+b.n_tools+' 个工具 / '+b.servers.length+' 个服务（'+ag+'）')
            :('探活未通过：'+(b.reason||'未知')+'（'+ag+'）');}
function _mcpBgShow(){
 return J('/api/mcp/list').then(function(d){
  var b=(d&&d.mcp_bg)||{};
  var el=document.getElementById('mcp-bg');
  if(el)el.textContent=(b&&b.started)?('MCP 后台探活：'+_mcpBgText(b)):'';
 }).catch(function(){});}
function mcpAllToggle(){
 if(window._mcpOn){mcpAct('off')}else{mcpAct('on')}}


async function probeMCP(nm){
 $('#mcp-msg').textContent='正在测试连接：'+(nm||'全部服务')+' …';
 try{const r=await J('/api/mcp',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({action:'probe',name:nm||''})});
  const rs=(r&&r.results)||[];
  if(!rs.length){$('#mcp-msg').textContent='无可测试服务：'+((r&&r.reason)||'');return;}
  $('#mcp-msg').textContent=rs.map(function(x){
    return x.name+' → '+(x.ok?('已注册 '+x.n_tools+' 个工具 · '+x.ms+'ms')
                             :('失败：'+(x.error||'未知')+' · '+x.ms+'ms'));}).join('；');
 }catch(e){$('#mcp-msg').textContent='测试失败: '+e.message;}}
function skillAllToggle(){
 skillAct(window._skillAllOn?'all_disable':'all_enable')}
async function addMCP(){
 const nm=$('#mcp-name').value.trim(),cm=$('#mcp-command').value.trim();
 if(!nm||!cm){$('#mcp-msg').textContent='\u540d\u79f0\u548c\u547d\u4ee4\u90fd\u8981\u586b';return;}
 try{const r=await J('/api/mcp',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({action:'add',name:nm,command:cm})});
  $('#mcp-msg').textContent=(r&&r.ok)?'OK':('\u5931\u8d25 '+((r&&r.error)||''));
  if(r&&r.ok){$('#mcp-name').value='';$('#mcp-command').value='';}
  loadMCP();}
 catch(e){$('#mcp-msg').textContent='\u6dfb\u52a0\u5931\u8d25: '+e.message;}}
async function mcpAct(act,nm){
 const hint={enable:'启用',disable:'停用',remove:'删除'}[act];
 if(hint&&!nm)nm=$('#mcp-name').value.trim();
 if(hint&&!nm){$('#mcp-msg').textContent='请先在名称框填写目标服务名';return;}
 try{const r=await J('/api/mcp',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({action:act,name:nm})});
  $('#mcp-msg').textContent=(r&&r.ok)?('OK '+(hint||act)):('失败 '+((r&&r.error)||''));
  loadMCP();}
 catch(e){$('#mcp-msg').textContent='操作失败: '+e.message;}}
function pickMcpFile(){$('#mcp-file').click();}
function onMcpFile(inp){
 const f=inp.files&&inp.files[0];inp.value='';
 if(!f)return;
 const rd=new FileReader();
 rd.onload=function(){
  const b64=String(rd.result).split(',')[1]||'';
  $('#mcp-msg').textContent='正在导入 '+f.name+' …';
  J('/api/mcp',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'upload',filename:f.name,data_b64:b64})})
  .then(function(r){
   if(r&&r.ok){
    const sk=(r.skipped||[]);
    $('#mcp-msg').textContent='已导入：'+((r.added||[]).join('、')||'0 个')+
      (sk.length?('；跳过（同名）：'+sk.join('、')):'');
   }else{$('#mcp-msg').textContent='导入失败：'+((r&&r.error)||'');}
   loadMCP();})
  .catch(function(e){$('#mcp-msg').textContent='导入失败: '+e.message});};
 rd.onerror=function(){$('#mcp-msg').textContent='读取文件失败';};
 rd.readAsDataURL(f);}
loadAll();setInterval(loadCards,15000);setInterval(_mcpBgShow,60000);

// ---- batch delete UI (auto decorate) ----
function decorateTable(listId){
  var w=document.getElementById(listId); if(!w)return;
  var tb=w.querySelector('table'); if(!tb||!tb.rows||tb.rows.length<2)return;
  var head=tb.rows[0]; if(!head.cells.length)return;
  if(head.querySelector('input.ckh'))return;
  var th=document.createElement('th'); th.innerHTML='<input type="checkbox" class="ckh">';
  if(th.firstChild)th.firstChild.onchange=function(){ckAll(this,listId)};
  head.insertBefore(th,head.cells[0]);
  for(var i=1;i<tb.rows.length;i++){
    var tr=tb.rows[i]; if(!tr.cells.length)continue;
    var id=(tr.getAttribute('data-id')||'').trim();
    if(!id)id=(tr.cells[0].textContent||'').trim();
    var td=document.createElement('td');
    td.innerHTML='<input type="checkbox" class="ck" value="'+id+'">';
    tr.insertBefore(td,tr.cells[0]);
  }
}
async function delReport(btn){
  var s=document.getElementById('r-sel'); if(!s||!s.value){alert('no report selected');return}
  if(!confirm('delete report '+s.value+' ? irreversible'))return;
  if(btn)btn.disabled=true;
  try{
    var d=await J('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'reports',ids:[s.value]})});
    if(d&&d.ok){alert('deleted '+(d.deleted||0));if(window.loadReports)loadReports()}
    else{alert('delete failed: '+((d&&d.error)||'unknown'))}
  }catch(e){alert('delete failed: '+e.message)}
  finally{if(btn)btn.disabled=false}
}
function selAllIn(listId,v){ckList(listId).forEach(function(c){c.checked=v})}
async function delReports(btn){
 var ids=pickIds('report-list');
 if(!ids.length){alert('\u8bf7\u5148\u52fe\u9009\u8981\u5220\u9664\u7684\u62a5\u544a');return}
 if(!confirm('\u5220\u9664 '+ids.length+' \u4efd\u62a5\u544a\uff08\u542b\u78c1\u76d8\u76ee\u5f55\u4e0e\u8bc1\u636e\uff09\uff1f\u4e0d\u53ef\u6062\u590d'))return;
 if(btn)btn.disabled=true;
 try{
  var d=await J('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'reports',ids:ids})});
  if(d&&d.ok){alert('\u5df2\u5220\u9664 '+(d.deleted||0));if(window.loadReports)loadReports()}
  else{alert('\u5220\u9664\u5931\u8d25: '+((d&&d.error)||'unknown'))}
 }catch(e){alert('\u5220\u9664\u5931\u8d25: '+e.message)}
 finally{if(btn)btn.disabled=false}
}
async function delSkills(btn){
 var ids=pickIds('skill-list');
 if(!ids.length){alert('请先勾选要删除的技能');return}
 if(!confirm('删除 '+ids.length+' 个技能？不可恢复'))return;
 if(btn)btn.disabled=true;
 try{
  var d=await J('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'skills',ids:ids})});
  if(d&&d.ok){alert('已删除 '+(d.deleted||0));if(window.loadSkill)loadSkill()}
  else{alert('删除失败: '+((d&&d.error)||'unknown'))}
 }catch(e){alert('删除失败: '+e.message)}
 finally{if(btn)btn.disabled=false}
}
async function delMcp(btn){
 var ids=pickIds('mcp-list');
 if(!ids.length){alert('请先勾选要删除的 MCP 服务');return}
 if(!confirm('删除 '+ids.length+' 个 MCP 服务？不可恢复'))return;
 if(btn)btn.disabled=true;
 try{
  var d=await J('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:'mcp',ids:ids})});
  if(d&&d.ok){alert('已删除 '+(d.deleted||0));if(window.loadMCP)loadMCP()}
  else{alert('删除失败: '+((d&&d.error)||'unknown'))}
 }catch(e){alert('删除失败: '+e.message)}
 finally{if(btn)btn.disabled=false}
}
function injectDelBtns(){
  var defs=[['p-findings','findings',"delSel('findings','findings',this,'loadFindings')"],
            ['p-verify','verify',"delSel('verifications','verify',this,'loadVerify')"],
            ['p-assets','assets',"delSel('assets','assets',this,'loadAssets')"],
            ['p-reports','report-list',"delReports(this)"],
            ['p-skill','skill-list',"delSkills(this)"],
            ['p-mcp','mcp-list',"delMcp(this)"]];
  defs.forEach(function(d){
    var pn=document.getElementById(d[0]); if(!pn)return;
    if(pn.querySelector('.del-bar'))return;
    var bar=document.createElement('div'); bar.className='row del-bar';
    bar.innerHTML='<button class="danger" onclick="'+d[2]+'">\u5220\u9664\u9009\u4e2d</button>'+
      '<button class="ghost" onclick="selAllIn(\\''+d[1]+'\\',true)">\u5168\u9009</button>'+
      '<button class="ghost" onclick="selAllIn(\\''+d[1]+'\\',false)">\u6e05\u7a7a</button>';
    pn.insertBefore(bar,pn.firstChild);
  });
}
function initBD(){
  injectDelBtns();
  ['findings','verify','assets'].forEach(function(x){
    var w=document.getElementById(x); if(!w)return;
    new MutationObserver(function(){decorateTable(x)}).observe(w,{childList:true});
  });
}
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',initBD)}else{initBD()}

</script></body></html>"""


def _proj_root():
    import os
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _cfg_json_path():
    # round69：统一到 cfg.CONFIG_PATH（开发态=源码根；EXE 态=%LOCALAPPDATA%\\CardinalSRCHunter\\userdata）。
    # 旧实现拼 _proj_root()/config/config.json，EXE 下写进包内 app/ 会被 run.bat 的 xcopy 整份覆盖。
    return cfg.CONFIG_PATH


def _read_cfg_json():
    import json, os
    p = _cfg_json_path()
    if not os.path.exists(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _write_cfg_json(d):
    import json, os
    d = _strip_secrets(d)
    _p = _cfg_json_path()
    os.makedirs(os.path.dirname(_p), exist_ok=True)
    with open(_p, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
        f.write("\n")


def _b64_to_bytes(b):
    """把前端 FileReader 的 base64 还原成 bytes；失败返回 None。"""
    import base64
    try:
        raw = str((b or {}).get("data_b64") or "").strip()
        if not raw:
            return None
        return base64.b64decode(raw)
    except Exception:
        return None


def _skill_tools_of(se, d):
    """round84 S 组：对单个包目录做 discover，返回它的工具列表。"""
    try:
        if not d:
            return []
        info = se.discover(d) or {}
        return info.get("tools") or []
    except Exception:
        return []


def _skill_exec_mod():
    """round84 S 组：惰性加载 tools.skill_exec（ui/ 不 import tools 顶层）。"""
    import sys as _sys
    pr = _proj_root()
    if pr not in _sys.path:
        _sys.path.insert(0, pr)
    try:
        from tools import skill_exec as _se
        return _se
    except Exception:
        return None


def _skill_list():
    """round73 D 组：与 _mcp_list() 同构——返回结构化对象，带全局开关位。

    字段：ok / enabled（SKILL 总开关，读 takeover.skill.enabled）/
    skills（每个技能一条：enabled 为 bool）/ stdout（沿用 CLI 原文，兼容旧前端）。
    """
    r = _skill_cli(["list"])
    rows = []
    try:
        from tools import skill_loader as sl
        for it in sl.list_skills():
            _tools = list(it.get("tools") or [])
            _unk = list(it.get("unknown") or [])
            rows.append({"name": it.get("name") or it.get("file") or "",
                         "file": it.get("file") or "",
                         "kind": it.get("kind") or "all",
                         "priority": it.get("priority", 0),
                         "enabled": bool(it.get("enabled")),
                         # round80 ①：工具声明与写错的工具名一并透出，
                         # 前端可在行内直接标红，无需翻日志。
                         "tools": _tools,
                         "unknown": _unk})
    except Exception:
        pass
    out = {"ok": bool(r.get("ok")), "skills": rows,
           "stdout": r.get("stdout") or "", "stderr": r.get("stderr") or ""}
    if r.get("error"):
        out["error"] = r.get("error")
    try:
        from tools import skill_loader as sl
        out["enabled"] = bool(sl.global_enabled())
    except Exception:
        out["enabled"] = True
    return out

def _skill_action(b):
    act = (b.get("action") or "").strip()
    nm = (b.get("name") or "").strip()
    if act == "upload":
        return _skill_upload(b)
    if act in ("all_enable", "all_disable"):
        sub = "on" if act == "all_enable" else "off"
        # round73 D 组：总开关先写全局位（takeover.skill.enabled），与 MCP 的
        # on/off 同源同构；再逐条同步各技能文件，避免"总开关开了个别技能仍 off"。
        try:
            c = _read_cfg_json()
            tk = c.setdefault("takeover", {})
            sk = tk.setdefault("skill", {})
            sk["enabled"] = (act == "all_enable")
            _write_cfg_json(c)
        except Exception:
            pass
        lst = _skill_list()
        names = []
        for ln in (lst.get("stdout") or "").split("\n"):
            parts = ln.split()
            if len(parts) >= 4 and parts[0] in ("ON", "off"):
                names.append(parts[2])
        n = 0
        for name in names:
            r = _skill_cli([sub, name])
            if isinstance(r, dict) and r.get("ok"):
                n += 1
        return {"ok": True, "changed": n, "total": len(names)}
    mp = {"enable": "on", "disable": "off", "install": "install", "uninstall": "uninstall", "show": "show", "list": "list"}
    sub = mp.get(act)
    if not sub:
        return {"ok": False, "error": "unknown action"}
    return _skill_cli([sub] + ([nm] if nm else []))


class _Handler(BaseHTTPRequestHandler):
    server_version = "CardinalSRCHunter/1.0"

    def log_message(self, fmt, *args):  # 静音默认 stderr 噪声
        pass

    # ---------- 输出 ----------
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, obj, code=200):
        self._send(code, obj)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    # ---------- 路由 ----------
    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/api/skill/list":
            self._json(_skill_list()); return
        if p == "/api/mcp/list":
            if "probe=1" in (self.path.split("?", 1) + [""])[1]:
                self._json(_mcp_probe()); return
            self._json(_mcp_list()); return
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path in ("/", "/index.html"):
                return self._send(200, _PAGE.replace("__APPVER__", _APP_VER), "text/html; charset=utf-8")
            if u.path == "/api/ver":
                return self._json({"ok": True, "app": "Cardinal-SRC-Hunter",
                                   "ver": _APP_VER, "pid": os.getpid()})
            if u.path == "/api/stats":
                return self._json(api_stats(q.get("target")))
            if u.path == "/api/findings":
                return self._json(api_findings(q.get("target"),
                                               q.get("severity"),
                                               q.get("limit", 500)))
            if u.path == "/api/verifications":
                return self._json(api_verifications(q.get("target"),
                                                    q.get("limit", 200)))
            if u.path == "/api/assets":
                return self._json(api_assets(q.get("limit", 500)))
            if u.path == "/api/reports":
                return self._json(api_reports())
            if u.path == "/api/report":
                r = read_report(q.get("name", ""), q.get("file"))
                if r is None:
                    return self._json({"error": "不存在"}, 404)
                return self._json(r)
            if u.path == "/api/report/raw":
                # 以纯文本原样吐出报告文件，供「在浏览器新标签打开」使用
                r = read_report(q.get("name", ""), q.get("file"))
                if r is None or "content" not in r:
                    return self._send(404, "报告不存在", "text/plain; charset=utf-8")
                return self._send(200, r.get("content") or "",
                                  "text/plain; charset=utf-8")
            if u.path == "/api/config":
                return self._json(api_config())
            if u.path == "/api/ai/key":
                return self._json(ai_key_status())
            if u.path == "/api/scan/status":
                return self._json(scan_status())
            if u.path == "/api/scan/session":
                return self._json(scan_session_info())
            return self._json({"error": "not found"}, 404)
        except Exception as e:
            return self._json({"error": str(e),
                               "trace": traceback.format_exc()}, 500)

    def do_POST(self):
        if self.path.split("?")[0] == "/api/delete":
            _bd = self._body()
            if isinstance(_bd, (bytes, str)):
                try: _bd = json.loads(_bd)
                except Exception: _bd = {}
            self._json(_delete_action(_bd))
            return
        p = self.path.split("?")[0]
        if p == "/api/skill":
            self._json(_skill_action(self._body())); return
        if p == "/api/mcp":
            self._json(_mcp_action(self._body())); return
        if p == "/api/ai/models":
            self._json(_ai_models(self._body())); return
        if p == "/api/ai/key":
            self._json(ai_key_save(self._body())); return
        u = urlparse(self.path)
        try:
            if u.path == "/api/scan/pause":
                return self._json(scan_pause())
            if u.path == "/api/scan/resume":
                return self._json(scan_resume())
            if u.path == "/api/scan/stop":
                return self._json(scan_stop())
            if u.path == "/api/scan/resume-last":
                return self._json(scan_resume_last(
                    (self._body() or {}).get("targets")))
            if u.path == "/api/scan":
                b = self._body()
                tg = b.get("targets") or []
                if isinstance(tg, str):
                    tg = [x.strip() for x in tg.split(",") if x.strip()]
                if not tg:
                    return self._json({"ok": False, "error": "无目标"}, 400)
                # round60：用户填入的目标一律视为已授权，不再有"需先确认"
                # 的 409 闸门；out_of_scope 排除规则仍由 Engine.run 生效。
                ok, msg = start_scan(tg, b.get("mode"),
                                     bool(b.get("verify")),
                                     bool(b.get("no_poc")))
                return self._json({"ok": ok, "error": "" if ok else msg})
            if u.path == "/api/config":
                return self._json(save_config(self._body()))
            return self._json({"error": "not found"}, 404)
        except Exception as e:
            return self._json({"error": str(e)}, 500)

def _skill_upload(b):
    """浏览器上传的 .md / .zip -> 装进 skills/（纯本地文件操作）。

    .md 直接交给 skill_loader.install()；.zip 先解到临时目录再逐个 install()。
    同名已存在由 install() 自身拒绝（返回 None），这里归到 skipped。
    红线不变：只做文本落盘，不执行技能正文、不发网络请求。
    """
    import os as _os
    import shutil
    import sys as _sys
    import tempfile
    import zipfile
    fn = _os.path.basename(str(b.get("filename") or "").strip())
    raw = _b64_to_bytes(b)
    if not fn or raw is None:
        return {"ok": False, "error": "缺少文件名或内容"}
    low = fn.lower()
    if not (low.endswith(".md") or low.endswith(".zip")):
        return {"ok": False, "error": "只支持 .md 或 .zip"}
    pr = _proj_root()
    if pr not in _sys.path:
        _sys.path.insert(0, pr)
    try:
        from tools import skill_loader as sl
    except Exception as e:
        return {"ok": False, "error": "加载 skill_loader 失败: %s" % e}
    installed, skipped, reaped = [], [], []
    docs_n = 0
    extract_info = None
    tmpd = tempfile.mkdtemp(prefix="btsrc_skill_")
    try:
        if low.endswith(".zip"):
            zp = _os.path.join(tmpd, fn)
            with open(zp, "wb") as f:
                f.write(raw)
            docs = []
            try:
                with zipfile.ZipFile(zp) as z:
                    for n in z.namelist():
                        if n.startswith("__MACOSX/") or n.endswith("/"):
                            continue
                        if not n.lower().endswith(".md"):
                            continue
                        base = _os.path.basename(n)
                        if not base or base.lower() == "readme.md":
                            continue
                        try:
                            txt = z.read(n).decode("utf-8", "replace")
                        except Exception:
                            continue
                        docs.append((base, txt))
            except zipfile.BadZipFile:
                return {"ok": False, "error": "不是有效的 zip 文件"}
            if not docs:
                # round84 S 组：包里没有 .md（纯脚本包）时走真解压安装，
                # 由 skill_exec 落盘到 skills/<包名>/ 供 discover 扫描。
                se = _skill_exec_mod()
                if se is None:
                    return {"ok": False, "error": "zip 内没有可安装的 .md",
                            "installed": [], "skipped": []}
                zres = se.install_zip(zp, _os.path.splitext(fn)[0])
                if not zres.get("ok"):
                    return {"ok": False,
                            "error": "解压失败: " + str(zres.get("error") or "?"),
                            "installed": [], "skipped": []}
                _inf = _skill_tools_of(se, zres.get("dir"))
                return {"ok": True, "installed": [zres.get("dir")],
                        "skipped": [], "reaped": [],
                        "docs": 0, "mode": "extract",
                        "files": zres.get("files", 0),
                        "tools": len(_inf),
                        "tool_names": [t.get("name") for t in _inf][:40]}
            pack = _os.path.splitext(fn)[0]
            reaped = sl._reap(sl._skill_dir(), fn, [b for b, _t in docs])
            p = sl.install_pack(pack, docs, source=fn)
            if p:
                installed.append(pack + ".md")
            docs_n = len(docs)
            # round84 S 组：.md 落盘只解决"提示词"，脚本工具要能调用必须
            # 真解压一份到 skills/<pack>/，否则 discover 扫不到可执行入口。
            try:
                se = _skill_exec_mod()
                if se is not None:
                    zres = se.install_zip(zp, pack)
                    if zres.get("ok"):
                        _inf = _skill_tools_of(se, zres.get("dir"))
                        extract_info = {"dir": zres.get("dir"),
                                        "files": zres.get("files", 0),
                                        "tools": len(_inf),
                                        "tool_names": [t.get("name") for t in _inf][:40]}
            except Exception:
                pass
        else:
            dest = _os.path.join(tmpd, fn)
            with open(dest, "wb") as f:
                f.write(raw)
            p = sl.install(dest, _os.path.splitext(fn)[0])
            if p:
                installed.append(fn)
            else:
                skipped.append(fn)
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)
    if not installed:
        return {"ok": False, "error": "未装进任何技能（同名已存在或内容无效）",
                "installed": [], "skipped": skipped}
    out = {"ok": True, "installed": installed, "skipped": skipped,
           "reaped": reaped, "docs": docs_n}
    if extract_info:
        out["extract"] = extract_info
    return out


def _mcp_servers_from_obj(obj):
    """从任意 MCP 配置对象里抽 [{name, command}]。

    兼容：{"mcpServers":{name:{command,args}}}、{"servers":[...]}、
    顶层数组、以及单个 {name, command} 对象。
    """
    out = []

    def _one(d):
        if not isinstance(d, dict):
            return
        nm = str(d.get("name") or d.get("id") or "").strip()
        cmd = str(d.get("command") or d.get("cmd") or "").strip()
        args = d.get("args") or []
        if not isinstance(args, list):
            args = [args]
        args = [str(a) for a in args if str(a).strip()]
        # round84 M6: never glue args into command. Older code produced
        # command="python3 server.py" which Popen treats as one literal
        # binary name -> FileNotFoundError on every probe.
        if nm and cmd:
            out.append({"name": nm, "command": cmd,
                        "args": args})

    if isinstance(obj, list):
        for it in obj:
            _one(it)
    elif isinstance(obj, dict):
        for k in ("servers", "mcpServers", "mcp_servers", "clients"):
            v = obj.get(k)
            if isinstance(v, dict):
                for nm, d in v.items():
                    if isinstance(d, dict):
                        d = dict(d)
                        d.setdefault("name", nm)
                        _one(d)
            elif isinstance(v, list):
                for it in v:
                    _one(it)
        _one(obj)
    return out


def _mcp_install_root():
    """round84 M3: where imported MCP plugin bundles get extracted.

    Must live under USER_ROOT (userdata/) so that run.bat's xcopy over app/
    never wipes an installed plugin. One subfolder per server name.
    """
    import os as _os
    from core import config as _cfg
    return _os.path.join(_cfg.USER_ROOT, "mcp")


def _mcp_extract_zip(zp, dest):
    """round84 M3: extract a plugin bundle to dest, zip-slip safe.

    Returns (n_files, err). Skips __MACOSX noise and refuses any member whose
    resolved path escapes dest.
    """
    import os as _os
    import zipfile
    n = 0
    try:
        with zipfile.ZipFile(zp) as z:
            root = _os.path.abspath(dest)
            for info in z.infolist():
                nm = info.filename
                if not nm or nm.endswith("/"):
                    continue
                if nm.startswith("__MACOSX/") or "/__MACOSX/" in nm:
                    continue
                target = _os.path.abspath(_os.path.join(root, nm))
                if not (target == root or target.startswith(root + _os.sep)):
                    return n, "压缩包内含非法路径：%s" % nm
                _os.makedirs(_os.path.dirname(target), exist_ok=True)
                with z.open(info) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                n += 1
    except zipfile.BadZipFile:
        return n, "不是有效的 zip 文件"
    except Exception as e:
        return n, "解压失败：%s" % e
    return n, ""


def _mcp_find_entry(dest):
    """round84 M3: locate the plugin entry script inside an extracted bundle.

    Handles both "server.py at top level" and "one extra wrapper folder",
    which is what every real-world zip we have seen does.
    """
    import os as _os
    pref = ("server.py", "main.py", "index.js", "server.js")
    for nm in pref:
        p = _os.path.join(dest, nm)
        if _os.path.isfile(p):
            return p
    try:
        for e in sorted(_os.listdir(dest)):
            sub = _os.path.join(dest, e)
            if not _os.path.isdir(sub):
                continue
            for nm in pref:
                p = _os.path.join(sub, nm)
                if _os.path.isfile(p):
                    return p
    except Exception:
        pass
    return ""


def _mcp_import(b):
    """round84 M3: import a MCP plugin bundle for real.

    Before this change a .zip was only scanned for *.json and thrown away:
    the actual server.py was never written to disk, so every import ended up
    as a config entry pointing at a non-existent relative path and the probe
    failed in a few milliseconds with a generic "handshake failed" text.

    Now a .zip is **installed**: every member is extracted under
    USER_ROOT/mcp/<server>/ , a relative script arg is rewritten to the
    extracted absolute path, the launcher is normalised, and the master
    switch is turned on so the user does not have to hunt for it.
    """
    import json as _json
    import os as _os
    import shutil
    import tempfile
    import zipfile
    fn = _os.path.basename(str(b.get("filename") or "").strip())
    raw = _b64_to_bytes(b)
    if not fn or raw is None:
        return {"ok": False, "error": "缺少文件名或内容"}
    low = fn.lower()
    if not (low.endswith(".json") or low.endswith(".zip")):
        return {"ok": False, "error": "只支持 .json 或 .zip"}
    objs = []
    kept_zip = ""
    tmpd = tempfile.mkdtemp(prefix="btsrc_mcp_")
    try:
        if low.endswith(".zip"):
            zp = _os.path.join(tmpd, fn)
            with open(zp, "wb") as f:
                f.write(raw)
            kept_zip = zp
            try:
                with zipfile.ZipFile(zp) as z:
                    for n in z.namelist():
                        if not n.lower().endswith(".json") or n.startswith("__MACOSX/"):
                            continue
                        try:
                            objs.append(_json.loads(z.read(n).decode("utf-8", "replace")))
                        except Exception:
                            pass
            except zipfile.BadZipFile:
                return {"ok": False, "error": "不是有效的 zip 文件"}
        else:
            try:
                objs.append(_json.loads(raw.decode("utf-8", "replace")))
            except Exception as e:
                return {"ok": False, "error": "JSON 解析失败: %s" % e}
        cands = []
        for o in objs:
            cands.extend(_mcp_servers_from_obj(o))
        if not cands:
            return {"ok": False, "error": "未解析出 MCP 服务（需含 name/command）"}
        c = _read_cfg_json()
        tk = c.setdefault("takeover", {})
        m = tk.setdefault("mcp", {})
        sv = m.setdefault("servers", [])
        added, skipped, installed = [], [], []
        for it in cands:
            nm = it["name"]
            if any((x.get("name") or "") == nm for x in sv):
                skipped.append(nm)
                continue
            rec = {"name": nm, "command": it["command"],
                   "args": list(it.get("args") or []), "enabled": True}
            # round84 M3: actually install the bundle for zip imports.
            if kept_zip:
                from core import config as _cfg
                safe = "".join(ch for ch in nm
                               if ch.isalnum() or ch in "-_.") or "mcp_srv"
                dest = _os.path.join(_mcp_install_root(), safe)
                nf, err = _mcp_extract_zip(kept_zip, dest)
                if err:
                    return {"ok": False,
                            "error": "安装 %s 失败：%s" % (nm, err)}
                entry = _mcp_find_entry(dest)
                if entry:
                    rec["cwd"] = _os.path.dirname(entry)
                    rec["args"] = [entry]
                    rec["command"] = _norm_mcp_launcher(rec["command"])
                    installed.append({"name": nm, "dir": dest,
                                      "entry": entry, "files": nf})
                else:
                    return {"ok": False,
                            "error": "安装 %s 失败：包内未找到 server.py" % nm}
            else:
                rec["command"] = _norm_mcp_launcher(rec["command"])
            sv.append(rec)
            added.append(nm)
        if added:
            # round84 M4: importing a plugin is an explicit "I want this".
            m["enabled"] = True
            _write_cfg_json(c)
        return {"ok": True, "added": added, "skipped": skipped,
                "installed": installed, "auto_on": bool(added)}
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)


def _norm_mcp_launcher(cmd):
    """round84 M5: Web-side twin of mcp_client._norm_launcher.

    Kept separate so ui/ never imports tools/ at module import time; the
    behaviour must stay identical (python3 -> running interpreter).
    """
    import os as _os
    import sys as _sys
    c = str(cmd or "").strip()
    base = _os.path.basename(c).lower()
    if base in ("python", "python3", "python.exe", "python3.exe", "py"):
        return _sys.executable or c
    return c


def _ai_models(b):
    """用当前接口地址 + 密钥拉一次 OpenAI 兼容 /models（用户点击才触发）。

    只读、不落盘、异常一律转成 ok=False + error 文案回给前端，
    绝不把 traceback 抛给浏览器。api_base 尾部的 /v1 两种拼法都试。
    """
    import json as _json
    import ssl
    import urllib.request
    base = str(b.get("api_base") or "").strip().rstrip("/")
    key = str(b.get("api_key") or "").strip()
    if not base:
        return {"ok": False, "error": "接口地址为空"}
    if base.endswith("/chat/completions"):
        base = base[:-len("/chat/completions")].rstrip("/")
    cands = [base + "/models"]
    if not base.endswith("/v1"):
        cands.append(base + "/v1/models")
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    err = ""
    for url in cands:
        try:
            req = urllib.request.Request(url, headers={
                "Authorization": "Bearer " + key,
                "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:
            err = str(e)
            continue
        ids = []
        for it in (data.get("data") or []):
            if isinstance(it, dict) and it.get("id"):
                ids.append(str(it["id"]))
        if not ids:
            for it in (data.get("models") or []):
                if isinstance(it, dict):
                    nm = it.get("name") or it.get("id") or it.get("model")
                    if nm:
                        ids.append(str(nm))
                elif isinstance(it, str):
                    ids.append(it)
        if ids:
            return {"ok": True, "models": sorted(set(ids)), "url": url}
        err = "接口返回中未找到模型列表"
    return {"ok": False, "error": err or "拉取失败"}


def _mcp_shape(c):
    """round79 ②：把 MCP 配置判成五种形态，返回 (enabled, servers, code, reason)。

    四种「0 个」成因必须在 Web 侧也说得出来 —— 页面只显示「共 0 个」等于
    什么都没告诉用户（round78 只在能力清单/引擎日志里修了同一问题）。
    """
    tk = c.get("takeover") if isinstance(c, dict) else None
    m = tk.get("mcp") if isinstance(tk, dict) else None
    if not isinstance(m, dict):
        return False, [], "no_config", "MCP 段未配置（先添加一个服务）"
    enabled = bool(m.get("enabled"))
    rows = [x for x in (m.get("servers") or [])
            if isinstance(x, dict) and x.get("name")
            ]
    if not rows:
        return enabled, rows, ("off" if not enabled else "no_servers"), (
            "总开关未开，且未配置任何 MCP 服务" if not enabled
            else "总开关已开，但未配置任何 MCP 服务")
    active = [x for x in rows if x.get("enabled") is not False]
    if not enabled:
        return enabled, rows, "off", (
            "总开关未开（已配置 %d 个服务，打开总开关后才生效）" % len(rows))
    if not active:
        return enabled, rows, "no_active", (
            "总开关已开，但 %d 个服务全部处于停用状态" % len(rows))
    return enabled, rows, "ready", ""


# round80 ②：MCP 后台探活（daemon 线程 + 内存缓存）
# 为什么要有它：round79 的探活是「点一次按钮连一次」，页面打开时仍只有
# 「共 N 个服务」这种看不出连通性的静态文案。这里加常驻 daemon 线程，
# 进程启动后立刻探一轮，之后每 _MCP_BG_EVERY 秒一轮；结果只写内存
# （不落盘、不改配置、不发扫描请求），页面打开即显示
# 「已注册 N 个工具 / m 个服务（Xs 前）」或「探活未通过：<原因>」。
_MCP_BG_EVERY = 60
_MCP_BG = {"lock": threading.Lock(), "started": 0.0, "running": False,
           "ts": 0.0, "ok": False, "reason_code": "", "reason": "",
           "n_tools": 0, "servers": [], "err": "", "show": False}


def _mcp_bg_snapshot():
    """取一份后台探活结果（纯内存读，零 IO，永不抛异常）。"""
    with _MCP_BG["lock"]:
        d = dict(_MCP_BG)
    d.pop("lock", None)
    d.pop("running", None)
    # round80 ②：servers 深一层拷贝 —— snapshot 用 dict() 是浅拷贝，
    # 外部若就地改这个列表会改到全局内存（HTTP 侧只读无碍，
    # 但把这条隐式共享路径堵掉更稳）。
    d["servers"] = [dict(x) for x in (d.get("servers") or [])]
    d["age"] = (int(time.time() - d["ts"]) if d["ts"] else -1)
    return d


def _mcp_bg_tick():
    """跑一轮只读探活并把结果写进内存。互斥，绝不并发起子进程。"""
    with _MCP_BG["lock"]:
        if _MCP_BG["running"]:
            return False
        _MCP_BG["running"] = True
    ok, rc, rs, n_tools, servers, err, show = False, "", "", 0, [], "", False
    try:
        c = _read_cfg_json()
        _en, rows, code, why = _mcp_shape(c)
        # 只探「已启用」的服务；总开关关 / 全停用时不出探活文案，
        # 页面里已经有静态成因，后台探活不该把同一件事报两遍。
        # round80 ③：总开关是**前置闸门** —— 关着就一个都别探，否则页面
        # 会同时出现「总开关未开」和「已注册 N 个工具」两句自相矛盾的话。
        act = ([x for x in rows if x.get("enabled") is not False]
               if _en else [])
        res = ((_mcp_probe() or {}).get("results") or []) if act else []
        by = {}
        for x in res:
            by[str(x.get("name") or "")] = x
        for actr in act:
            nm = str(actr.get("name") or "")
            if not nm:
                continue
            p = by.get(nm) or {}
            servers.append({"name": nm, "ok": bool(p.get("ok")),
                            "n_tools": int(p.get("n_tools") or 0),
                            "error": str(p.get("error") or "")})
        good = [x for x in servers if x["ok"]]
        n_tools = sum(x["n_tools"] for x in good)
        if not act:
            ok, rc, rs, show = False, code, (why or "无可探活的 MCP 服务"), False
        elif not good:
            ok, rc, show = False, "no_tools", True
            rs = "服务已配置，但一个都没注册出工具（连接或握手失败）"
        else:
            ok, rc, rs, show = True, "ready", "", True
    except Exception as e:
        err = str(e)[:200]
        rc, show = (rc or "error"), bool(servers)
        rs = rs or ("后台探活异常：" + err)
    finally:
        with _MCP_BG["lock"]:
            _MCP_BG["ts"] = time.time()
            _MCP_BG["ok"] = ok
            _MCP_BG["reason_code"] = rc
            _MCP_BG["reason"] = rs
            _MCP_BG["n_tools"] = n_tools
            _MCP_BG["servers"] = servers
            _MCP_BG["err"] = err
            _MCP_BG["show"] = show
            _MCP_BG["running"] = False
    return ok


def _mcp_bg_loop():
    """daemon 循环：首次立即探，之后每 _MCP_BG_EVERY 秒一轮。"""
    while True:
        try:
            _mcp_bg_tick()
        except Exception:
            pass
        time.sleep(_MCP_BG_EVERY)


def _mcp_bg_has_servers():
    try:
        return bool(_mcp_shape(_read_cfg_json())[1])
    except Exception:
        return False


def _mcp_bg_start():
    """幂等启动后台探活线程；只在 serve() 里调用。"""
    if _MCP_BG.get("started"):
        return False
    _MCP_BG["started"] = time.time()
    t = threading.Thread(target=_mcp_bg_loop, name="mcp-probe", daemon=True)
    t.start()
    return True



def _mcp_probe(names=None):
    """round79 ②：实地连一次 MCP server，回答「到底注册出几个工具、为什么没有」。

    只做 initialize + tools/list，**不调用任何工具、不发扫描请求**；
    子进程用完即关，失败只记录原因，绝不抛给前端。
    """
    import time as _t
    c = _read_cfg_json()
    _en, rows, code, why = _mcp_shape(c)
    if not rows:
        return {"ok": False, "reason_code": code,
                "reason": why or "无可测试的 MCP 服务", "results": []}
    want = set(str(x) for x in (names or []) if str(x).strip())
    out = []
    for srv in rows:
        nm = str(srv.get("name") or "")
        if want and nm not in want:
            continue
        cmd = str(srv.get("command") or "").strip()
        t0 = _t.time()
        item = {"name": nm, "command": cmd, "ok": False, "tools": [],
                "n_tools": 0, "error": "", "ms": 0}
        if not cmd:
            item["error"] = "未配置启动命令"
            item["ms"] = int((_t.time() - t0) * 1000)
            out.append(item)
            continue
        cli = None
        try:
            from tools.mcp_client import MCPClient
            # round84 M2/M5：根据配置重建真实启动命令（绝对路径 + cwd），并把 stderr 真实原因透出给前端
            from tools.mcp_client import _norm_launcher as _nl, _resolve_script as _rs
            _cmd = _nl(cmd)
            _args, _cwd = _rs(srv.get("args"), srv.get("cwd"), _cmd, nm)
            item["command"] = _cmd
            item["cwd"] = _cwd or ""
            cli = MCPClient(_cmd, args=_args, env=srv.get("env"), cwd=_cwd,
                            timeout=srv.get("timeout") or 15)
            if not cli.initialize():
                # round84 M2：把子进程写到 stderr 的真实原因带出来
                _fr = ""
                try:
                    _fr = cli.failure_reason() or ""
                except Exception:
                    _fr = ""
                item["error"] = _fr or "握手失败（未返回原因）"
                _low = _fr.lower()
                if ("filenotfound" in _low or "找不到" in _fr
                        or "no such file" in _low or "cannot find" in _low
                        or "不是内部或外部命令" in _fr):
                    item["hint"] = ("进程未能启动：command 指向的可执行文件不存在"
                                    "（Windows 常见是 python3 不存在）")
                elif _fr:
                    item["hint"] = "子进程起来但没回 JSON-RPC：看上面的 exit 与 stderr 原文"
                else:
                    item["hint"] = "进程未能启动：先看 command 是不是绝对路径"
            else:
                ts = cli.list_tools() or []
                names_ok = [str(x.get("name")) for x in ts
                            if isinstance(x, dict) and x.get("name")]
                item["tools"] = names_ok
                item["n_tools"] = len(names_ok)
                item["ok"] = bool(names_ok)
                if not names_ok:
                    item["error"] = "握手成功但未返回任何工具"
        except Exception as e:
            item["error"] = str(e)[:200]
        finally:
            try:
                if cli is not None:
                    cli.close()
            except Exception:
                pass
        item["ms"] = int((_t.time() - t0) * 1000)
        out.append(item)
    ok_any = any(x["ok"] for x in out)
    _why = ""
    if not ok_any:
        _bad = [x for x in out if x.get("error")]
        _why = (_bad[0].get("error") or "") if _bad else ""
        _why = "服务已配置，但未注册出任何工具：" + (_why[:180] or "连接或握手失败")
    return {"ok": ok_any,
            "reason_code": "ok" if ok_any else "no_tools",
            "reason": "" if ok_any else _why,
            "results": out}

def _mcp_list():
    c = _read_cfg_json()
    enabled, rows, code, why = _mcp_shape(c)
    return {"ok": True, "enabled": enabled, "servers": rows,
            "reason_code": code, "reason": why,
            "active_servers": [x.get("name") for x in rows
                               if x.get("enabled") is not False],
            "mcp_bg": _mcp_bg_snapshot()}


def _mcp_action(b):
    act = (b.get("action") or "").strip()
    nm = (b.get("name") or "").strip()
    if act == "upload":
        return _mcp_import(b)
    if act == "probe":
        # round79 ②：只读探活，绝不改配置
        return _mcp_probe([nm] if nm else None)
    if act in ("", "list", "show"):
        # 与 GET /api/mcp/list 同源，POST 侧也支持一次查询（前端某些路径会走 POST）
        return _mcp_list()
    c = _read_cfg_json()
    tk = c.setdefault("takeover", {})
    m = tk.setdefault("mcp", {})
    sv = m.setdefault("servers", [])
    if act == "add":
        if not nm or not (b.get("command") or "").strip():
            return {"ok": False, "error": "\u540d\u79f0\u548c\u547d\u4ee4\u4e0d\u80fd\u4e3a\u7a7a"}
        if any((x.get("name") or "") == nm for x in sv):
            return {"ok": False, "error": "\u540c\u540d\u670d\u52a1\u5df2\u5b58\u5728"}
        sv.append({"name": nm, "command": (b.get("command") or "").strip(), "enabled": True})
    elif act in ("remove", "uninstall", "delete"):
        m["servers"] = [x for x in sv if (x.get("name") or "") != nm]
        # round91 FIX-25: 卸载必须连物理目录一起删。
        # zip 导入时包体已解压到 USER_ROOT/mcp/<name>，以前只从配置里拿掉条目，
        # 目录残留导致「删了又长」（round66 验证里的两个探针 MCP 就是这样复活的）。
        if nm:
            try:
                import os as _osrm
                import shutil as _sh
                safe = "".join(ch for ch in nm
                               if ch.isalnum() or ch in "-_.") or ""
                if safe:
                    root = _osrm.path.realpath(_mcp_install_root())
                    dst = _osrm.path.realpath(_osrm.path.join(root, safe))
                    if dst.startswith(root + _osrm.sep) and _osrm.path.isdir(dst):
                        _sh.rmtree(dst, ignore_errors=True)
            except Exception as _e:
                print("mcp remove dir failed: %s" % _e)
    elif act in ("enable", "disable"):
        for x in sv:
            if (x.get("name") or "") == nm:
                x["enabled"] = (act == "enable")
    elif act in ("on", "off"):
        m["enabled"] = (act == "on")
    else:
        return {"ok": False, "error": "unknown action"}
    _write_cfg_json(c)
    return {"ok": True}


def _skill_cli(args, timeout=25):
    import subprocess, sys
    try:
        r = subprocess.run([sys.executable, "-m", "tools.skill_loader"] + list(args),
                           cwd=_proj_root(), capture_output=True, text=True, timeout=timeout)
        return {"ok": (r.returncode == 0), "code": r.returncode,
                "stdout": r.stdout or "", "stderr": r.stderr or ""}
    except Exception as e:
        return {"ok": False, "error": str(e), "stdout": "", "stderr": ""}


def _open_browser(url):
    """尽力唤起系统默认浏览器打开 url（全程不抛异常）。

    顺序（Windows 优先走最可靠的一路）：
      1) os.startfile —— 直接交给 shell 的 URL 关联处理器，不经过 cmd.exe，
         也不受 pythonw.exe 无控制台的影响，是 Windows 上最稳的一条路；
      2) webbrowser.open —— 标准库，读注册表 / BROWSER 环境变量；
      3) 平台命令兜底：win 用 cmd /c start 与 rundll32 两道保险，
         darwin 用 open，其它用 xdg-open / termux-open-url / am。
    返回 True 表示至少一条路成功启动，False 表示全部失败（调用方据此提示手动打开）。
    """
    import subprocess
    import sys as _sys

    # 1) Windows：os.startfile 直接把 URL 交给系统关联程序
    if _sys.platform.startswith("win"):
        try:
            os.startfile(url)  # noqa: S606  （仅 Windows 存在）
            print("opened default browser (startfile): %s" % url)
            return True
        except Exception as e:
            print("startfile failed: %s" % e)

    # 2) 标准库 webbrowser（跨平台）
    try:
        import webbrowser
        if webbrowser.open(url):
            print("opened default browser: %s" % url)
            return True
    except Exception as e:
        print("webbrowser failed: %s" % e)

    # 3) 平台命令兜底
    if _sys.platform.startswith("win"):
        cmds = [["cmd", "/c", "start", "", url],
                ["rundll32", "url.dll,FileProtocolHandler", url]]
    elif _sys.platform == "darwin":
        cmds = [["open", url]]
    else:
        cmds = [["xdg-open", url], ["termux-open-url", url],
                ["am", "start", "-a", "android.intent.action.VIEW", "-d", url]]
    for c in cmds:
        try:
            kw = {}
            if _sys.platform.startswith("win"):
                # 0x08000000 = CREATE_NO_WINDOW：pythonw 起 cmd.exe 时不要闪黑框
                kw["creationflags"] = 0x08000000
            subprocess.Popen(c, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, **kw)
            print("opened browser: %s" % url)
            return True
        except Exception:
            continue
    print("please open manually: %s" % url)
    return False


def _open_browser_retry(url, attempts=3, gap=1.2):
    """带重试的唤起：首试失败才补试，成功即停（不会开重复标签）。"""
    for i in range(max(1, int(attempts))):
        if _open_browser(url):
            return True
        if i + 1 < attempts:
            time.sleep(gap)
    return False


def create_server(host="127.0.0.1", port=8770, tries=10):
    """round65：返回 (httpd, url, existing)。

    为什么重写绑定逻辑：Windows 上 SO_REUSEADDR 允许两个进程绑同一端口，
    新连接仍被先起的（旧版）僵尸进程接走 —— 用户看到的就是旧页面、
    按钮点不动。这里改成：
      * Windows 关闭 allow_reuse_address；
      * 端口被占则依次试 port+1..port+tries-1，并把真实 URL 返回给调用方，
        保证浏览器一定打开到**本次新起的**控制台。
    existing=True 表示该端口上已有我们自己的控制台在跑（此时 httpd 为 None）。
    """
    cfg.ensure_dirs()
    if sys.platform.startswith("win"):
        ThreadingHTTPServer.allow_reuse_address = False
    else:
        ThreadingHTTPServer.allow_reuse_address = True
    return _new_server(host, port, tries)


def _new_server(host, port, tries):
    """真正起一个控制台实例（create_server 的实体部分）。
    round80 ③：从 create_server 里拆出来，只为让 verify_round80 能在不起
    真 HTTP 服务的前提下拿到同一种 server 对象（snapshot 线程安全不靠网络）。
    """
    url_host = "127.0.0.1" if host in ("0.0.0.0", "", "::") else host
    last = None
    for i in range(max(1, int(tries))):
        cand = port + i
        try:
            return (ThreadingHTTPServer((host, cand), _Handler),
                    "http://%s:%d/" % (url_host, cand), False)
        except OSError as e:
            last = e
            if _console_alive(host, cand):
                # 已有控制台在跑：交给调用方决定（浏览器指向它即可）
                return None, "http://%s:%d/" % (url_host, cand), True
            continue
    raise OSError("端口 %d-%d 均不可用：%s" % (port, port + tries - 1, last))


def _console_alive(host, port, timeout=0.5):
    """探测该端口上是否已有**同版本**的 Cardinal-SRC-Hunter 控制台在监听。"""
    try:
        import urllib.request as _ur
        with _ur.urlopen("http://%s:%d/api/ver" % (host, port), timeout=timeout) as r:
            raw = r.read(8192)
            try:
                data = json.loads(raw.decode("utf-8", "replace"))
            except Exception:
                data = {}
            if data.get("app") != "Cardinal-SRC-Hunter":
                return False
            return data.get("ver") == _APP_VER
    except Exception:
        return False


_EXIT_HOOKED = {"v": False}


def serve(host="127.0.0.1", port=8770, open_browser=False):
    httpd, url, existing = create_server(host, port)
    if existing:
        print("=" * 56)
        print("  已有控制台在运行：%s" % url)
        print("=" * 56)
        if open_browser:
            _open_browser_retry(url)
        return
    print("=" * 56)
    print("  Cardinal-SRC-Hunter Web 控制台")
    print("  %s" % url)
    print("  若浏览器未自动打开，请手动复制上面的地址访问")
    print("  Ctrl+C 退出")
    for _ln in _ai_banner_notes():
        print(_ln)
    # round80 ②：常驻后台探活（daemon，只读；不写盘、不改配置）
    try:
        if _mcp_bg_start() and _mcp_bg_has_servers():
            print("  MCP 后台探活：已启动（每 %ds 一轮，只读）" % _MCP_BG_EVERY)
    except Exception:
        pass
    print("=" * 56)
    if open_browser:
        # 0.6s 后开始试（此时 serve_forever 已就绪）；失败会自动补试到 3 次。
        # 放在独立线程里，绝不阻塞 HTTP 服务本身。
        threading.Timer(0.6, _open_browser_retry, args=(url,)).start()
    # round75：注册退出兜底 —— Ctrl+C / 正常退出时把未完成会话落盘，
    # 下次打开控制台（或桌面端）能一键续跑剩余目标。
    try:
        import atexit as _atexit
        if not _EXIT_HOOKED.get("v"):
            _atexit.register(session_pause_by_exit)
            _EXIT_HOOKED["v"] = True
    except Exception:
        pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出")
    finally:
        try:
            session_pause_by_exit()
        except Exception:
            pass
        httpd.server_close()


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(prog="web", description="Web 控制台")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("-p", "--port", type=int, default=8770)
    # 默认自动打开浏览器；用 --no-open 显式关闭（CI / 纯服务场景）。
    ap.add_argument("--open", dest="open_browser", action="store_true",
                    default=True, help="启动后自动打开浏览器（默认开）")
    ap.add_argument("--no-open", dest="open_browser", action="store_false",
                    help="启动后不自动打开浏览器")
    a = ap.parse_args(argv)
    serve(a.host, a.port, a.open_browser)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
