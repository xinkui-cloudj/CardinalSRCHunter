# -*- coding: utf-8 -*-
"""命令行界面。

子命令：
    doctor     环境诊断（+ 可选自愈）
    install    一键安装前置工具（Python 依赖 / Go 工具链）
    scan       对授权目标扫描
    report     生成补天格式报告
    status     查看进度与统计
    gui        启动图形界面

设计：本层只做「参数解析 + 调 engine/bootstrap」，不含任何检测逻辑。
"""
import argparse
import os
import sys

from core import config as cfg
from core import logger
from core.db import DB
from core.scope import Scope, ScopeError

log = logger.get("bt.cli")


# ------------------------------------------------------------
# 参数
# ------------------------------------------------------------
def build_parser():
    p = argparse.ArgumentParser(
        prog="CardinalSRCHunter",
        description="Cardinal-SRC-Hunter · 补天 / SRC 授权漏洞挖掘套件",
    )
    p.add_argument("-v", "--verbose", action="store_true", help="输出调试日志")
    sub = p.add_subparsers(dest="cmd")

    # doctor
    d = sub.add_parser("doctor", help="环境诊断")
    d.add_argument("--fix", action="store_true", help="诊断后自动修复（自愈循环）")
    d.add_argument("--rounds", type=int, default=None, help="自愈最大轮次")

    # install
    i = sub.add_parser("install", help="一键安装前置工具")
    i.add_argument("--mirror", default="auto", help="pip 镜像（auto / 自定义 URL）")
    i.add_argument("--no-go", action="store_true", help="跳过 Go 工具链")

    # scan
    s = sub.add_parser("scan", help="对授权目标扫描")
    s.add_argument("-t", "--target", action="append", default=[],
                   help="目标（域名/IP/URL），可多次指定；缺省取 scope.in_scope")
    s.add_argument("-y", "--yes", action="store_true",
                   help="兼容保留：所有填入的目标均默认视为已授权，无需人工确认")
    s.add_argument("--no-report", action="store_true", help="扫完不生成报告")
    s.add_argument("--no-poc", action="store_true", help="跳过 PoC 复现")
    s.add_argument("--no-resume", action="store_true",
                   help="忽略断点续扫记录，重扫全部 URL（默认开启续扫）")
    s.add_argument("--resume-last", dest="resume_last", action="store_true",
                   help="一键续跑上次未完成的扫描：只跑上次被中断时还没跑完的"
                        "目标，已完成的目标与 URL 全部跳过（与 GUI 开窗提示、"
                        "Web「继续上次扫描」同一数据源）")
    s.add_argument("--full", action="store_true",
                   help="全量档：放开目录爆破等主动检测，并开启 PoC 复现")
    s.add_argument("--verify", action="store_true",
                   help="扫完自动核验：对已落库漏洞逐条走独立证据通道判定真伪，"
                        "证伪项从主报告剔除并另出独立核验报告")
    s.add_argument("--weak-password", action="store_true",
                   help="显式开启弱口令探测（默认关闭，可能触发账号锁定）；"
                        "受 scan.weak_password_max_targets/max_try/max_fail 三重限制")

    # report
    r = sub.add_parser("report", help="生成补天格式报告")
    r.add_argument("-t", "--target", required=True, help="要出报告的目标")
    # 增强 U-4：按需选择产物，避免在 CI/平台上产出用不到的格式
    r.add_argument("-f", "--format", default="all",
                   help="产物格式：all（默认）/ md / html / csv / json / evidence，"
                        "可逗号组合如 md,json；all 或留空表示全出")

    # verify
    v = sub.add_parser("verify", help="核验漏洞真实性（独立证据通道，不重跑检测）")
    v.add_argument("-t", "--target", required=True, help="要核验的目标")
    v.add_argument("-n", "--limit", type=int, default=None,
                   help="最多核验多少条（默认全部）")
    v.add_argument("--max-requests", type=int, default=None,
                   help="本次核验的总请求上限（默认取 config verify.max_requests=400）")

    # tune（误报率驱动的规则收紧·自我升级消费层）
    tu = sub.add_parser("tune", help="根据历史核验误报率收紧检测规则阈值")
    tu.add_argument("--dry-run", action="store_true",                   help="只输出建议，不写入 data/tuning.json")
    tu.add_argument("--reset", action="store_true",                   help="删除调参文件，恢复默认阈值")
    tu.add_argument("-t", "--target", default=None,                   help="仅统计某个目标的核验记录（默认全局）")

    # status
    sub.add_parser("status", help="查看进度与统计")

    # gui
    sub.add_parser("gui", help="启动图形界面")

    # web
    w = sub.add_parser("web", help="启动 Web 控制台（零依赖 stdlib）")
    w.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    w.add_argument("-p", "--port", type=int, default=8770, help="监听端口（默认 8770）")
    w.add_argument("--open", action="store_true", help="启动后自动打开浏览器")
    # scope-sync：离线同步授权范围（白名单）
    ss = sub.add_parser("scope-sync", help="离线同步授权范围（AI 只提候选，人审后 --apply）")
    ss.add_argument("--list", action="store_true", help="查看草稿与当前 in_scope")
    ss.add_argument("--fetch", action="store_true", help="联网检索公开 SRC 平台并写 .draft 候选")
    ss.add_argument("--ai", action="store_true", help="额外让模型从检索摘要抽域名")
    ss.add_argument("--apply", action="store_true", help="人审通过后并入 config/scope.yaml（先备份）")
    ss.add_argument("--dry-run", action="store_true", help="只打印，不落盘")
    ss.add_argument("--engine", default="auto", help="检索引擎（auto/bing/baidu）")
    ss.add_argument("--max-per-source", type=int, default=5, help="每源最多取几条（默认 5）")
    ss.add_argument("--sources", default=None, help="仅用指定源，逗号分隔，如 butian,cnvd")
    ss.add_argument("--out-dir", default=None, help="草稿输出目录（默认 data/）")
    return p


# ------------------------------------------------------------
# 子命令实现
# ------------------------------------------------------------
def cmd_doctor(args):
    from bootstrap import doctor
    if args.fix:
        res = doctor.heal(max_rounds=args.rounds) or {}
        # 已判定通过时报告走离线校验，避免再联网白等
        doctor.print_report(check_net=not res.get("ok"))
        if res.get("ok"):
            print("环境自愈完成：全部可用。")
            return 0
        print("自愈未全绿：%s" % res.get("reason", "仍有缺失"))
        for h in res.get("history", []):
            print("  第%s轮 [%s] %s" % (h.get("round"), h.get("kind"), h.get("note")))
        return 2
    rep = doctor.diagnose(verbose=True)
    for it in rep.get("items", []):
        # items 元素为四元组 (name, ok, detail, required)
        name, good, detail, required = it
        mark = "OK " if good else ("!! " if required else "-- ")
        print("%s%-18s %s" % (mark, name, detail))
    return 0 if rep.get("ok") else 2


def cmd_install(args):
    from bootstrap import installer
    try:
        res = installer.install_all(mirror=args.mirror, with_go=not args.no_go)
    except installer.InstallError as e:
        log.error("安装失败：%s", e)
        print("安装未完成，可执行 `doctor --fix` 自动修复重试。")
        return 2
    print("安装完成：")
    for k, v in (res or {}).items():
        print("  - %s: %s" % (k, v))
    return 0


def cmd_scan(args):
    # 扫描前确保环境可用（缺依赖则自愈）
    from bootstrap import doctor
    if not doctor.ensure_ready():
        print("环境未就绪，请先执行 `install` 或 `doctor --fix`。")
        return 2

    from core.engine import Engine
    eng = Engine(verbose=args.verbose)
    # B 方案（round71）：扫描前提示「AI 增强可用性」——AI 未开或 SKILL/MCP
    # 清单为空时，明确告知本轮只有确定性扫描产出，避免"扫不出漏洞"被误判为缺陷。
    # 文案与 Web 控制台共用同一份（tools/capability.py::scan_note），单点维护。
    try:
        from tools import capability
        _anote = capability.scan_note(eng)
        if _anote:
            print("-" * 60)
            print(_anote)
            print("-" * 60)
    except Exception:
        pass
    # --full = 全量档：主动检测 + PoC 复现都开（相当于 mode=aggressive）。
    # 顺序很关键：先让 --full 放开，再让 --no-poc 收口，避免两个开关互相覆盖。
    if args.full:
        eng.enable_active = True
        eng.enable_poc = True
    if args.no_poc:
        eng.enable_poc = False
    # --no-resume：关掉断点续扫。默认开启续扫会让"复测只出 1 条"，
    # 因为历史 URL 被 scanned 表跳过；用户需要显式开关才能全量重扫。
    if getattr(args, "no_resume", False):
        eng.resume = False
    # --weak-password：弱口令默认关闭（可能触发账号锁定），只在显式指定时打开。
    # 与 GUI 的「弱口令探测」勾选框等价，两侧能力对齐。
    if getattr(args, "weak_password", False):
        eng.weak_password = True
    # --resume-last（round75）：一键续跑上次未完成的扫描。
    # 会话档由 Engine 在跑每个目标时即时落盘（data/ 下，不进源码包），
    # 进程被关 / 被暂停时也会落一份；这里只负责"取还剩哪些目标"。
    # 已跑完的目标由会话档的 done 列表过滤，已扫过的 URL 由 scanned 表跳过。
    if getattr(args, "resume_last", False) and not getattr(args, "target", None):
        try:
            from core.db import DB
            _db = DB()
            try:
                _sess = _db.load_session()
            finally:
                _db.close()
            _pend = Engine.session_pending(_sess) if _sess else []
        except Exception as e:
            print("读取上次扫描会话失败：%s" % e)
            return 2
        if not _pend:
            print("没有可续跑的目标（上次扫描已完成，或从未开始过扫描）。")
            return 0
        args.target = _pend
        print("-" * 60)
        print("续跑上次未完成的扫描：还剩 %d 个目标" % len(_pend))
        for _p in _pend:
            print("  · %s" % _p)
        print("-" * 60)

    # round60：扫前展示授权状态（本地判定，不联网）。用户在界面/命令行填入的
    # 目标一律视为已授权，不再有"额外确认"的阻断；仅 out_of_scope
    # 排除规则仍然生效（排除项会在 Engine.run 里被跳过）。
    _tgts = list(getattr(args, "target", []) or [])
    if _tgts:
        from core.scope import AUTH_CN
        _sc = Scope()
        print("-" * 60)
        print("识别目标授权状态（共 %d 个）：" % len(_tgts))
        for _t in _tgts:
            _lvl, _rsn, _rule = _sc.classify(_t)
            print("  [授权状态] %s → %s（%s）" % (_t, AUTH_CN.get(_lvl, _lvl), _rsn))
        print("-" * 60)
    try:
        out = eng.run(targets=args.target, report=not args.no_report,
                      verify=getattr(args, "verify", False))
    except ScopeError as e:
        print("范围错误：%s" % e)
        return 3
    finally:
        # 资源收口：HttpClient 按线程各建一个 requests.Session，Engine 自己 new 的
        # DB 也持有 sqlite 连接。命令行在 CI / 循环调用下若不收口，句柄会一路累积。
        # 放在 finally 里，范围报错提前 return 时也能回收。
        try:
            eng.close()
        except Exception as e:
            log.warning("关闭引擎资源失败：%s", e)

    print("-" * 60)
    for s in out.get("summaries", []):
        if s.get("error"):
            print("[失败] %s → %s" % (s.get("target"), s.get("error")))
            continue
        st = s.get("stats", {}) or {}
        print("[完成] %s：存活 %s/%s，漏洞 %s 条，用时 %ss"
              % (s.get("target"), s.get("alive"), s.get("hosts"),
                 st.get("total", 0), s.get("elapsed")))
        # 授权状态：只展示"已授权/已拒绝"，与强度无关（所有目标同档）。
        _acn = s.get("auth_cn")
        if _acn:
            print("[授权状态] %s（%s）｜强度：主动=%s PoC=%s（所有目标同档）"
                  % (_acn, s.get("auth_reason") or "-",
                     s.get("scan_active"), s.get("scan_poc")))
        # 可达性诊断：全部主机都没 HTTP 响应时，明确告诉用户
        # “连不上”而不是“扫了没漏洞”，避免把网络问题误判成程序故障。
        _nr = int(s.get("unreachable") or 0)
        if _nr and not s.get("alive"):
            print("[不可达] %s：%d 个主机均无 HTTP 响应，请按下列原因排查："
                  % (s.get("target"), _nr))
            _by = s.get("unreachable_by_reason") or {}
            if isinstance(_by, dict):
                for _k, _v in sorted(_by.items(), key=lambda kv: -int(kv[1] or 0)):
                    print("    · %s × %d" % (_k, int(_v or 0)))
            for _d in (s.get("unreachable_detail") or []):
                if not isinstance(_d, dict):
                    continue
                print("    - %-32s %s | IP=%s | %s"
                      % (_d.get("host", ""), _d.get("reason", ""),
                         _d.get("ip") or "-", _d.get("hint", "")))
    for rp in out.get("reports", []) or []:
        if isinstance(rp, dict):
            print("报告：%s" % rp.get("markdown", rp))
    # 自动核验结果（--verify 时才有）
    for v in out.get("verifications", []) or []:
        if v.get("error"):
            print("[核验失败] %s → %s" % (v.get("target"), v.get("error")))
            continue
        _vd = int(v.get("decidable", -1))
        _vt = ("—（无可判定样本）" if _vd == 0 else
               "%.1f%%" % (float(v.get("false_positive_rate", 0) or 0) * 100))
        print("[核验] %s：证实 %s / 证伪 %s / 无法判定 %s / 未核验 %s，误报率 %s"
              % (v.get("target"), v.get("confirmed"), v.get("refuted"),
                 v.get("inconclusive"), v.get("not_verified", 0), _vt))
        _rp = v.get("report") or {}
        if _rp.get("markdown"):
            print("核验报告：%s" % _rp.get("markdown"))
    print("累计请求：%s" % out.get("requests"))
    return 0


def cmd_verify(args):
    """独立核验入口：对已落库漏洞走独立证据通道判定真伪。"""
    from core.engine import Engine
    eng = Engine(verbose=args.verbose)
    try:
        res = eng.verify(args.target, limit=getattr(args, "limit", None),
                         max_requests=getattr(args, "max_requests", None))
    except Exception as e:
        print("核验失败：%s" % e)
        return 2
    finally:
        try:
            eng.close()
        except Exception as e:
            log.warning("关闭引擎资源失败：%s", e)
    print("-" * 60)
    print("[核验] %s" % res.get("target"))
    print("  总计 %s 条：证实 %s / 证伪 %s / 无法判定 %s / 未核验 %s"
          % (res.get("total"), res.get("confirmed"), res.get("refuted"),
             res.get("inconclusive"), res.get("not_verified", 0)))
    _dec = int(res.get("decidable", -1))
    if _dec == 0:
        print("  误报率：—（无可判定样本，不能当作 0%）")
    else:
        print("  误报率：%.1f%%（口径：证伪 /（证实 + 证伪））"
              % (float(res.get("false_positive_rate", 0) or 0) * 100))
    for r in res.get("results", []) or []:
        print("  - [%s] %s %s（%s）"
              % (r.get("verdict"), r.get("vuln_type") or r.get("type") or "?",
                 r.get("url", ""), r.get("method") or ""))
    rp = res.get("report") or {}
    if rp.get("markdown"):
        print("核验报告：%s" % rp.get("markdown"))
    if rp.get("json"):
        print("核验数据：%s" % rp.get("json"))
    return 0


def cmd_report(args):
    from core.engine import Engine
    eng = Engine(verbose=args.verbose)
    try:
        try:
            paths = eng.make_report(args.target, formats=getattr(args, "format", None))
        except TypeError as e:
            # 兼容不支持 formats 形参的 Engine（旧版/第三方插件）。
            # 只对"参数不匹配"这一种 TypeError 回退，其它异常照常上报，
            # 避免把真实错误吞掉。
            if "formats" not in str(e):
                raise
            paths = eng.make_report(args.target)
    except Exception as e:
        print("报告生成失败：%s" % e)
        return 2
    finally:
        # 报告路径同样自建了 Engine（连带 DB 连接与 HTTP 客户端），必须收口，
        # 否则每次出报告都漏一个 sqlite 句柄 + 一个连接池。
        try:
            eng.close()
        except Exception as e:
            log.warning("关闭引擎资源失败：%s", e)
    print("报告目录：%s" % paths.get("dir", ""))
    # 增强 U-4：只打印本次实际产出的文件，避免 --format csv 时打印空路径误导用户
    for _k, _label in (("markdown", "Markdown"), ("html", "HTML"),
                       ("csv", "CSV"), ("json", "JSON"),
                       ("evidence_dir", "Evidence")):
        if paths.get(_k):
            print("%-9s：%s" % (_label, paths.get(_k)))
    return 0


def cmd_tune(args):
    """误报率驱动的规则收紧入口（实现见 core/tuning.cli）。"""
    from core import tuning
    return tuning.cli(args)

def cmd_status(args):
    db = DB()
    prog = db.get_progress("last_scan", None)
    if prog:
        print("上次扫描：%s @ %s" % (prog.get("target"), prog.get("at")))
    else:
        print("暂无扫描记录。")
    try:
        stats = db.stats()
        print("累计漏洞：%s" % stats)
    except Exception as e:
        print("统计失败：%s" % e)
    db.close()
    return 0


def cmd_gui(args):
    from ui import gui
    try:
        return gui.main()
    except Exception:
        # round77 实机事故教训：`start.bat` / `run.bat` 走的是「main.py gui」，
        # 不进 main() 里那个无参数分支，所以这里的异常**没有任何上层兜住**。
        # 配合 pythonw.exe（无控制台），崩了就是「黑框闪一下就没反应」。
        # 因此这里必须自己留证：写 <用户目录>/logs/gui_crash.log 后继续抛，
        # 让 main.py 顶层的 _crash_log 照旧记一份 crash.log（双份证据）。
        import traceback
        try:
            from main import _gui_crash_log
            _gui_crash_log(traceback.format_exc())
        except Exception:
            pass
        raise


def cmd_web(args):
    from ui import web
    return web.serve(host=args.host, port=args.port, open_browser=args.open)


def cmd_scope_sync(args):
    """离线同步授权范围：把 tools/scope_sync.py 的参数原样透传。"""
    import importlib.util
    path = os.path.join(cfg.ROOT, "tools", "scope_sync.py")
    spec = importlib.util.spec_from_file_location("bt_scope_sync", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    argv = []
    for flag, key in (("--list", "list"), ("--apply", "apply"),
                      ("--fetch", "fetch"), ("--ai", "ai"),
                      ("--dry-run", "dry_run")):
        if getattr(args, key, False):
            argv.append(flag)
    if getattr(args, "engine", None):
        argv += ["--engine", str(args.engine)]
    if getattr(args, "max_per_source", None) is not None:
        argv += ["--max-per-source", str(args.max_per_source)]
    if getattr(args, "sources", None):
        argv += ["--sources", str(args.sources)]
    if getattr(args, "out_dir", None):
        argv += ["--out-dir", str(args.out_dir)]
    return mod.main(argv)


# ------------------------------------------------------------
# 入口
# ------------------------------------------------------------
HANDLERS = {
    "doctor": cmd_doctor,
    "install": cmd_install,
    "scan": cmd_scan,
    "report": cmd_report,
    "verify": cmd_verify,
    "status": cmd_status,
    "tune": cmd_tune,
    "gui": cmd_gui,
    "web": cmd_web,
    "scope-sync": cmd_scope_sync,
}


def main(argv=None):
    cfg.ensure_dirs()
    parser = build_parser()
    args = parser.parse_args(argv)
    logger.init(verbose=getattr(args, "verbose", False))
    if not args.cmd:
        parser.print_help()
        return 0
    fn = HANDLERS.get(args.cmd)
    if not fn:
        parser.print_help()
        return 1
    return fn(args)


if __name__ == "__main__":
    sys.exit(main())
