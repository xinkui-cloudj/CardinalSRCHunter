# 交接文档 — round80

> 接手前先读 `进度.md`（任务锚点 + 逐轮进度）与 `项目总结报告.md` §20（本轮完整交代）。

## 1. 本轮做了什么（三件）

1. **`tools:` 声明强校验**：技能写了注册表里没有的工具名时，Web 技能行红字标注、`agent_loop` 打 warning。落在 `tools/skill_loader.py`（`_known_tool_names` / `_unknown_of` / `list_skills` 补 `unknown` / `skill_tools` 复用）、`tools/agent_loop.py`、`ui/web.py`。
2. **MCP 后台探活**：程序启动后每 60s 只读探活一次（只 `initialize` + `tools/list`），结果进内存，页面 `#mcp-bg` 显示。落在 `ui/web.py`（`_MCP_BG_EVERY` / `_MCP_BG` / `_mcp_bg_snapshot` / `_mcp_bg_tick` / `_mcp_bg_loop` / `_mcp_bg_start` / `_mcp_list` / `serve()` / 前端）。
3. **版本戳 r80 连锁**：`_APP_VER = "r80"`、`BUILD_ID = "r80-"`、`lab/check_exe_r80.py`（旧 `check_exe_r79.py` 已删）、`regall.sh` 的 `EX80_DIR`/`/tmp/verify80`、历史断言区间化。

## 2. 版本戳两端（同一条事实，必须同步）

| 位置 | 值 |
|---|---|
| `ui/web.py::_APP_VER` | `"r80"` |
| `build/make_sfx_exe.py::BUILD_ID` | `"r80-" + time.strftime(...)` |

`_APP_VER` 同时是 `/api/ver` 的握手标识：`create_server()` 端口被占时会依次试 `port+1..port+tries-1`，撞到**同版本**控制台则认领（`_console_alive()` 判 `app == "Cardinal-SRC-Hunter"` 且 `ver == _APP_VER`）。

## 3. `mcp_bg` 字段契约（`/api/mcp/list` 返回体）

```
"mcp_bg": {
  "started": bool,      # 后台线程是否已起（serve() 里起的）
  "show":    bool,      # 是否值得在前端显示本轮状态
  "ts":      float,     # 最近一轮完成时间戳（0 = 从未完成）
  "age":     float,     # 距上一轮的秒数；ts==0 时为 -1
  "ok":      bool,      # 最近一轮是否探到工具
  "reason_code": str,   # 与 _mcp_shape 同码：no_config/off/no_servers/no_active/ready/...
  "reason":  str,       # 中文原因（可直接上屏）
  "n_tools": int,       # 最近一轮注册出的工具总数
  "servers": [ {...}, ],# 逐项拷贝，绝不含 lock/running
  "err":     str        # 异常文本（空串为正常）
}
```

- **线程名 `mcp-probe`**：daemon 线程，`_mcp_bg_start()` 幂等起线程；`import ui.web` 不起线程，只有 `serve()` 调用它。
- **`show` 语义**：总开关关 / 服务全停用 → `show=False`。成因已由 round79 的五态文案说清，后台探活不再重复报同一件事（否则页面会自相矛盾）。
- **绝不外泄锁对象**：`snapshot` 已 `pop("lock")` / `pop("running")`，`servers` 也逐项 `dict()` 拷贝（隐式共享会让调用方改到内部状态）。

## 4. `tools:` 声明的"校验"边界

- 未知名**不阻断**加载，仍留在 `names`/`pairs` 里，只红字 + warning 留痕（不夺模型判断权）。
- 注册表取不到时 `_known_tool_names()` 返回 `None` → `_unknown_of()` 返回 `[]` → **不误报**。
- **两处出口**：`list_skills()`（Web 走这条）**和** `skill_tools()`（agent_loop 走这条）都必须带 `unknown`。round80 初版只改了后者，是回归抓出来的死代码。

## 5. `lab/verify_round80.py` 覆盖范围（六组）

| 组 | 内容 |
|---|---|
| A | 静态契约（helper 取值、`unknown` 字段、只读、`_MCP_BG` 字段、snapshot 纯内存与 servers 拷贝、tick 互斥与总开关闸门、loop daemon/线程名、start 幂等、只在 `serve()` 起、`_new_server` 无自递归） |
| B | 真跑 `skill_loader`（造三份 md：名字正确 / 名字写错 / 无声明） |
| C | 真跑 `_skill_requirements`（未知名仍进 names、打 warning、全对时不打） |
| D | 真跑 `_mcp_bg_*`（自造假 MCP server；覆盖未配置/总开关关/全停用/就绪/命令不存在/拷贝隔离/不下传锁/running 位挡并发/起线程幂等/6 秒内完成首轮） |
| E | 前端与路由锚点 + 只读铁律 |
| F | 版本戳连锁（两端 r80、`check_exe_r80.py` 在且 r79 已删、regall 登记与无残留、区间窗口、8 条 r80 锚点、FILES 覆盖） |

## 6. 跑回归的前置条件（易踩）

- `lab/regall.sh` 会**自己拉靶机** `python3 lab/vuln_server.py`（端口 8081）并等就绪；若靶机起不来会打印 `WARN: vuln_server not reachable` 并让 live 检查变红。
- **类 A 全量跑依赖 `dist-win/CardinalSRCHunter.exe` 与工作区一致**：改完源码没重打包 → EXE 复核组红（设计意图，不许静默跳过）。
- 重打包三连顺序：`make_src_zip.py`（含 `MD5SUMS.txt`）→ `make_sfx_exe.py pack` → 再刷 `MD5SUMS.txt`。**文档必须在最后一次 `make_src_zip` 之前写完**。
- 回归判定口径：只看汇总行 `REGALL TOTAL PASS=n FAIL=n SCRIPTS_FAILED=n` 的 `FAIL=0` 与 `SCRIPTS_FAILED=0`，不看 PASS 绝对值。

## 7. 本轮教训（防复发）

1. 算出了字段 ≠ 透出了字段：同一事实若有两个出口（`list_skills` / `skill_tools`），两处都要对，或者收敛成一个 helper。
2. 回归脚本的断言本身也会错：本轮 4 条红里 3 条是断言写错（位置错 / 模拟手法无效 / 锚点过期）。先看 `extra` 输出定位真因，别默认"红了就是代码坏"。
3. 替换串不要嵌"引号 + 正则转义"：`(?:` 写成 `(?>`、修它又多加一层反斜杠，两次翻车同处。用切片 + `startswith` 的笨写法。
4. 抽函数后必须回看被替换片段是否落在新函数体内（本轮踩到自递归，`py_compile` 抓不出）。
5. 批量改名不要猜出现次数：用哨兵 + `want=None` / `opt=True`，并以 leftover 自扫收尾。
6. 后台线程只在服务真正启动时起（库导入不起线程），且快照绝不外泄锁对象。
