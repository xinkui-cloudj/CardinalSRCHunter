# Cardinal-SRC-Hunter · round60 交接文档（新会话对接用）

> 生成时间：2026-10-12 08:10（round60 收口后）
> 项目根：`/storage/emulated/0/Audiobooks/src/bt-src-hunter`
> 定位：**round59 + round60 已闭环交付。** 本轮把"未授权域名"概念从程序内**整体删除**（用户填入的域名一律视为已授权），
> 并顺带收口了上一轮遗留的 round59（AI 工具接管）半成品。全量回归 `PASS=2184 FAIL=0 SCRIPTS_FAILED=0`（54 脚本）。

---

## 0. 这份文档怎么用（新会话先读这段）

- 本文件是**会话交接摘要**：让新对话不用翻旧记录，直接接上工作。
- **默认路径（任务已完工）**：照 §1 跑核验命令 → 照 §2 看成果 → 照 §3 看交付物。核验通过即确认交付，**不需要重跑扫描、不需要重改代码**。
- **继续开发路径**：看 §6「下一轮方向（round61）」+ §4 环境坑，直接开工。
- **⚠️ 最高优先级红线（用户明确要求）**：**禁止后台自动跑任何长任务**。不要用 `nohup ... &`、不要用 `background=true` 启动 `lab/regall.sh` / `lab/vuln_server.py`。用户反馈后台自动触发的东西会干扰其他对话、导致工作无法进行或数据丢失。
  - 正确做法：**前台受控执行** + 显式 `timeout`，跑完即退，不留残留进程。
  - 全量回归单轮约 20 分钟（`timeout 1700 sh lab/regall.sh` 可覆盖全部 54 脚本）。
  - 每次跑完**必须**复核残留进程（命令见 §1）；`regall.sh` 会自行拉起 `lab/vuln_server.py`，跑完需手动 `kill`。

---

## 1. 当前实时状态（核验命令）

**任务已全部收口。** 新会话第一件事：

```bash
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter
cat dist-win/MD5SUMS.txt                          # 三行 md5 应与本文件 §3 一致
for p in /proc/[0-9]*; do pid=${p#/proc/}; c=$(cat $p/cmdline 2>/dev/null | tr "\0" " "); case "$c" in *vuln_server*|*regall*|*verify_*) echo "残留 $pid $c";; esac; done   # 应无输出（vuln_server 需手动清）
grep -c 'round60' 项目总结报告.md                  # 应为 19+
ls -l lab/verify_round59.py                       # 485 行
python3 -c "import json;d=json.load(open('config/config.json',encoding='utf-8'));print('allow_unscoped' in d['scan'])"   # 应为 False
```

- 回归日志：`/tmp/regall_r60b.txt`（54 脚本，**2184 PASS / 0 FAIL / 0 脚本失败**）。

---

## 2. 本轮已完成（round60 + round59 收口）

### 2.0 需求原文与施工含义

> **需求原文：将程序内所有关于未授权域名的内容进行删除，并确保程序内所有功能正常运行，而填入的域名均视为已授权。**

含义：取消"未授权域名"这一维度——不再有未授权提示、不再有扫前确认阻断、不再有报告"未授权"标注，
用户填入的域名一律按已授权处理。

**关键辨识（本轮最重要的判断）**：代码里有两类"未授权"字样，**只有一类要删**：

| 类别 | 判定 | 处置 |
|---|---|---|
| **① 授权状态档位**（域名是否在白名单内） | 属需求要删的"未授权域名" | **删除**（`AUTH_UNSCOPED` / `allow_unscoped` / 扫前确认闸） |
| **② 漏洞类型**（"未授权访问"漏洞名） | 属检测能力，与域名授权无关 | **绝不可动**（`core/dicts.py` 34 处路径/CVE 描述、`core/confidence.py` 的 `UNAUTH_STRONG/WEAK`、`core/verify.py::verify_unauth` 等） |

### 2.1 改动清单（按文件）

| 文件 | 改动 |
|---|---|
| `core/scope.py` | 删 `AUTH_UNSCOPED` 常量；`AUTH_CN` 由三档 → 两档；删 `self.allow_unscoped` 与配置读取；`_classify()` 三档 → 两档（白名单外一律 `AUTHORIZED` + `user_supplied`）；`summary()` 删 `allow_unscoped` 键 |
| `core/engine.py` | 导入行去 `AUTH_UNSCOPED`；`auth_scan_profile` 文档改「所有目标统一强度」；强度日志改「所有目标同档」；`_auth_levels` 注释去未授权措辞（共 11 处命中） |
| `core/report.py` | markdown / HTML / CSV / JSON 四格式授权状态文案去"未授权"（3 处命中） |
| `core/config.py` | `DEFAULT_CONFIG["scan"]` 删 `"allow_unscoped": True` |
| `config/config.json` | 删 `"allow_unscoped": true`（第 41 行） |
| `dist/CardinalSRCHunter/_internal/config/config.json` | 同步删键（**铁律：两份 config 必须一致**） |
| `ui/cli.py` | 删 `_unscoped` 收集 / `input()` 询问 / `return 4` 取消路径 / `AUTH_UNSCOPED` 导入；保留扫前 `[授权状态]` 展示；`-y/--yes` 兼容保留（改 help 文案） |
| `ui/gui.py` | `do_scan()` 删未授权分支与 `_ask_yes_no` 调用；输入框提示改「填入即视为已授权目标」；输入区控件保留为通用确认 |
| `ui/web.py` | 删 `/api/scan` 的 409 `need_confirm` 闸 + 前端 `confirm()` 重试 + `"unscoped"` 回填；`classify_targets()` 保留 |
| `build/make_sfx_exe.py` | 使用说明「四、使用范围」改为「填入的域名/IP 一律视为已授权目标，可直接扫描」 |
| `tools/tool_registry.py` | 授权前置注释改口径（"未授权直接返回" → "被 out_of_scope 排除的目标直接返回"） |
| `lab/verify_round52.py` | 断言同步改写（49 → **51**）：A2 断言 `AUTH_UNSCOPED` 已移除、A9 断言 `allow_unscoped` 已移除、A4 两档映射、A11/E5 白名单外=已授权、C 组 `unscoped` → `user_supplied`、D5 文案改「授权状态」 |
| `lab/verify_round53.py` | **整体重写**（37 → **35** 断言）：从「三入口含未授权识别 + 人工确认」改为「三入口已无未授权识别 + 无确认闸」 |
| `lab/verify_round21.py` | A5/A5b 改为「未命中白名单默认视为已授权」；A7/B1 改用 `out_of_scope` 排除构造越界（不再设 `allow_unscoped`） |
| `lab/verify_round27.py` | scope 闸测试改用 `scope2.out_of_scope = ["evil.example.com"]` 构造越界 |
| `lab/regall.sh` | 清单加入 `verify_round59.py`（52 → 53 脚本；连同 round58 后共 54 个执行项） |

### 2.2 round59 收口（上一轮遗留）

- 补入 `lab/regall.sh` 清单（`verify_round59.py` 单跑 `PASS=63 FAIL=0`）。
- `verify_round59.py:424` 引用已删夹具 `lab/_fake_mcp_round59.py`，但**重跑仍全绿**（脚本运行时自建/容错），无需恢复夹具。
- 本轮把 `tools/tool_registry.py` 的授权前置注释一并改口径（原写"未授权直接返回"，与新语义不符）。

### 2.3 本轮踩到的坑（重要，务必记住）

**编辑工具在文件尾部追加了重复碎片。** 用 `edit_file` 修改文件末尾区域（如 `summary()` 的返回字典结尾）后，
工具在文件尾部追加了半截重复内容（如 `'(self, "allow_unscoped", True)),'`、`'    return paths))'`、`'k", "all"):'`），
导致 8 个文件出现 `SyntaxError`。

**检测方法**（改完必跑）：

```bash
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter
python3 - <<'PYEOF'
import ast, io, json
for f in ['core/scope.py','core/engine.py','core/config.py','core/report.py',
          'ui/cli.py','ui/gui.py','ui/web.py',
          'lab/verify_round21.py','lab/verify_round27.py','lab/verify_round52.py',
          'lab/verify_round53.py','lab/verify_round59.py']:
    s = io.open(f, encoding='utf-8').read()
    try:
        ast.parse(s); print('OK   ' + f)
    except SyntaxError as e:
        print('BAD  %s | %s line %s' % (f, e.msg, e.lineno))
PYEOF
```

**修复方法**：定位真实结尾行号 → `lines[:keep]` 截断重写（不要试图用 `edit_file` 再改，会继续追加碎片）。

**⇒ 铁律：凡用 `edit_file` 改过文件尾部，必须立即跑一次全量 `ast.parse` 体检，再跑回归。**

### 2.4 另一个坑：遗留备份目录污染回归

`lab/verify_round39.py` D5 断言「`.draft` 字面量仅出现在契约处（dicts/config/selfheal/学习器）」。
本轮工程根存在旧式备份目录 **`.bak_round60/`**（含 `core_config.py`，其内有 `".draft"` 字面量），
被 `os.walk(ROOT)` 扫到 → D5 失败 → `REGALL FAIL=1`。

**处置**：把 `.bak_round60/` 移出工程根（→ `/storage/emulated/0/Audiobooks/bak_round60_offsite_20261012`），回归恢复全绿。

**⇒ 铁律：回归要求工程根下不得存在含 `.draft` 字面量的备份目录。** 备份一律用**后缀式**（`foo.py.bak_r60`），不要用**目录式**（`.bak_round60/`）。

### 2.5 验证结果

- `lab/verify_round52.py`：**51 PASS / 0 FAIL**
- `lab/verify_round53.py`：**35 PASS / 0 FAIL**
- `lab/verify_round21.py`：**47 PASS / 0 FAIL**
- `lab/verify_round27.py`：全部通过
- `lab/verify_round59.py`：**63 PASS / 0 FAIL**
- 全量：`REGALL TOTAL PASS=2184 FAIL=0 SCRIPTS_FAILED=0`

---

## 3. 交付物（权威 md5 以 `dist-win/MD5SUMS.txt` 为准）

| 文件 | 说明 |
|---|---|
| `dist-win/CardinalSRCHunter.exe` | 见 `MD5SUMS.txt` |
| `dist-win/CardinalSRCHunter-src.zip` | 见 `MD5SUMS.txt` |
| `项目总结报告.md`（项目根） | 见 `MD5SUMS.txt` |

- **权威基准文件：`dist-win/MD5SUMS.txt`（三行）——一切以它为准。**
- **为何本表不写死 exe/zip 的 md5**：本交接文档自身在 zip 内、也在 EXE payload 内，写死它们的 md5 会形成自指循环（改文档 → 包变 → 值失效）。
- 重打包命令：`python3 build/make_src_zip.py`（输出 `PACK files=... size=... md5=...` + `BAK_LEAK bad=0` + `VERIFY bad=0`）。
- EXE 重建：`python3 build/make_sfx_exe.py pack` → `[verify] MZ=True PE=True (PE offset=0xF8)`。**EXE 内嵌代码副本，改任何 `.py`/`config.json` 后必须重建 EXE**。
- 打包顺序：**先写文档 → 再 `make_src_zip.py`（纳入文档）→ 再 `make_sfx_exe.py pack` → 最后 `make_src_zip.py` 刷新 MD5SUMS**。

---

## 4. 环境硬约束（踩过的坑，务必遵守）

- 工作区 `/storage/emulated/0/Audiobooks/`；主工作目录 `src/bt-src-hunter/`。
- **`SCOPE_PATH` 实际 = `/sdcard/Audiobooks/src/bt-src-hunter/config/scope.yaml`**（`cfg.ROOT` 派生）。
- **`read_file` / `read_file_part` 直读 `/storage/emulated/0/...` 会报 `File does not exist`，必须走 terminal 或用 `repo:Audiobooks` 环境。**
- **禁止 `set -e` / `set -o errexit`**（会让终端会话直接退出卡死）。
- **禁止后台自动跑长任务**（见 §0 红线）；改用前台 `timeout N cmd`，跑完复核残留进程。
- **PTY 回显会在长 heredoc 中向中文字符串插空格**，但**落盘字节是干净的**，判断以 `repr()` 为准。
  **含中文 + 复杂引号的批量替换，不要用 heredoc 内联 Python（PTY 会把引号改坏导致 SyntaxError）——写成 `.py` 文件用 `create_file` 落盘再 `python3 file.py` 执行。**
- 文本级 patch 前必须 `repr()` / `cat -A` 取样真实字节；patch 时必须断言 `s.count(old) == 1` 锚点唯一。
- **`edit_file` 改文件尾部会追加重复碎片**（见 §2.3），改完必跑 `ast.parse` 体检。
- **`create_file` 的 path 语义有坑**：曾把 `lab/x.py` 落到工作区根，需 `find` 确认落点后 `mv` 补救。
- `ui/cli.py` 直跑需 `PYTHONPATH=.`。
- 无 `ps` / `unzip` / `nslookup` / `xxd`；有 `7z` / `7zr`；`yaml 6.0.3` 可用；模块导入须 `from modules import probe`。
- 进程存活检测：`ls /proc/<pid> >/dev/null 2>&1`；端口检测：`grep -i :1F91 /proc/net/tcp`（8081 = 0x1F91）。
- 网络依赖型断言必须契约化；三连跑是区分抖动与真回归的有效手段。
- `super_admin:terminal` 的 `package_proxy` 只接受 `tool_name` / `params` 两个参数，`timeoutMs` 必须放进 `params` 里。

---

## 5. 关键行号速查（round60 后）

| 位置 | 说明 |
|---|---|
| `core/scope.py:30-36` | 授权等级常量（round60 两档：`AUTHORIZED` / `DENIED`）+ `AUTH_CN` |
| `core/scope.py:89-93` | `__init__` 中已无 `allow_unscoped` |
| `core/scope.py:165-196` | `_classify()` 两档判定（白名单外 → `user_supplied` 已授权） |
| `core/scope.py:257-264` | `summary()`（已删 `allow_unscoped` 键） |
| `core/engine.py:26-27` | scope 导入（已去 `AUTH_UNSCOPED`） |
| `core/engine.py:176-187` | `auth_scan_profile(level=None)` 恒等契约 |
| `core/engine.py:1003` | 强度日志「所有目标同档」 |
| `core/report.py:535-540` | markdown 授权状态行 |
| `core/report.py:869-877` | HTML 授权状态 |
| `core/report.py:998-1002` | CSV「报告授权状态」行 |
| `core/report.py:1064-1072` | JSON `auth` 对象（`note` 已改「所有目标同档」） |
| `ui/cli.py:176-187` | 扫前授权状态展示（无确认闸） |
| `ui/gui.py:224-237` | `do_scan()` 授权状态展示（无未授权分支） |
| `ui/web.py:544-550` | `/api/scan`（无 409 闸） |
| `lab/regall.sh:33` | 54 脚本清单（round7~round59 + verify_fixes + verify_e2e + t_malformed） |

---

## 6. 下一轮方向（round61）与历史编号

### 6.1 可继续项

1. 基线 12 项里工具仍未覆盖的：**账号枚举** / **硬编码 RSA 公钥** / **token 跨主机复用**，可继续补检测规则（沿用 round58 的「三条硬门槛 + 无危害约束」范式）。
2. `www.langhanyun.cn` 报告命中 `Knife4j` / `Druid`，而基线报告是 `Swagger springfox 2.9.2` / 无 Druid → 站点组件随时间变化，可在报告里加「组件版本漂移」说明。
3. `tools/scope_sync.py --fetch` 的 AI 自动学习可改造为「指定目标域 + 相关性过滤」，而非纯公网泛检索。
4. round59 的 AI 接管（`takeover` 段）默认全关，可做一次 `mode=advisory` 的真实联调验证（需 AI 端点与密钥）。

### 6.2 round 编号（防冲突）

`round48`=config 运行时环境变量覆盖层；`round49`=技能加载器；`round50`=Operit 端点接入；
`round52`=授权状态自动分辨；`round53`=未授权扫前识别（37 断言）；
`round54`=授权文案对齐 + Setup.exe 二次双击自愈；`round55`=`tools/scope_sync.py` 离线同步（46 断言）；
`round56`=交付物单点化；`round57`=域名 NXDOMAIN 自动接管可解析形态（37 断言）；
`round58`=开放 API 注册端点未鉴权 + 下发会话凭据检测器（54 断言）；
`round59`=AI 工具接管（MCP + function calling，63 断言）；
**`round60`=取消"未授权域名"概念：填入即视为已授权（52 改 51 / 53 重写 35 断言，本会话）**。
**下一轮编 round61。**

### 6.3 本轮备份文件（回滚用）

后缀式快照（`.bak_r60`）：`config/config.json`、`core/config.py`、`core/engine.py`、`core/report.py`、`core/scope.py`、
`dist/CardinalSRCHunter/_internal/config/config.json`、`lab/regall.sh`、`lab/verify_round15.py`、`lab/verify_round21.py`、
`lab/verify_round27.py`、`lab/verify_round52.py`、`lab/verify_round53.py`、`ui/cli.py`、`ui/gui.py`、`ui/web.py`。

另：`lab/verify_round53.py.bak_r60` 为**改写前**的旧版（37 断言版本），可用于比对。
旧式目录备份 `.bak_round60/` 已移出工程根（→ `/storage/emulated/0/Audiobooks/bak_round60_offsite_20261012`），**不要再放回工程根**（会打破 `verify_round39` D5）。

### 6.4 round59 备份文件（回滚用）

`core/config.py.bak_r59`、`core/engine.py.bak_r59`、`config/config.json.bak_r59`、`tools/ai_client.py.bak_r59`。