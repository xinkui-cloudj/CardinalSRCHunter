# -*- coding: utf-8 -*-
"""资产探测：存活判定 / Web 指纹 / 标题抓取 / 目录爆破 / 敏感信息扫描。

所有出网动作都走 core.httpclient，天然受 scope 与限速约束。
"""
import difflib
import re
import socket
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import zlib
from urllib.parse import urlparse

from core import dicts, logger, netdiag
from core import dict_merge as _dm
from core.scope import _norm_host

log = logger.get("bt.probe")


def _hostport(target):
    """归一为 host[:port]，**保留显式端口**（探测必须连对端口）。"""
    t = (target or "").strip()
    if not t:
        return ""
    if "://" not in t:
        t = "//" + t
    try:
        p = urlparse(t)
        h = (p.hostname or "").lower()
        if not h:
            return _norm_host(target)
        return "%s:%d" % (h, p.port) if p.port else h
    except Exception:
        return _norm_host(target)

TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)
HEADER_KEYS = ("Server", "X-Powered-By", "Set-Cookie", "X-Generator",
               "Via", "X-AspNet-Version", "X-Drupal-Cache", "WWW-Authenticate")

# 目录爆破里"软 404"判定阈值
SOFT404_RATIO = 0.98


# round89 FIX-15b：软 404 / 拦截墙的「正文相似度」必须白化后再比。
# 与 FIX-14 同一根因：nginx 往错误页里塞随机条数的
# `<!-- a padding to disable MSIE and Chrome friendly error page -->`，
# 两个**同一页面**的 ratio 会掉到 0.98 以下 → is_soft404 判「不同质地」 →
# 一个本来不存在的路径被当成"被单独处理"，后面的判定全部带偏。
# 复用 vulnchecks 的实现（失败则原样返回，绝不把流程打断）。
def _white(t):
    try:
        from modules.vulnchecks import _normalize_body as _nb
        return _nb(t)
    except Exception:
        return t or ""


def _sim_white(a, b):
    """白化后比较；白化后完全相同直接 1.0。"""
    na, nb = _white(a), _white(b)
    if na == nb:
        return 1.0
    if not na or not nb:
        return 0.0
    try:
        return float(difflib.SequenceMatcher(None, na[:4000], nb[:4000]).ratio())
    except Exception:
        return 0.0

# 软 404 基线缓存：同一 base_url 只取一次随机路径。
# 目录爆破 / 敏感路径 / 敏感信息扫描 / 组件检测共用同一条基线，
# 避免各模块各取一个随机路径导致判定口径不一致。
_BASELINE_CACHE = {}


def clear_baseline_cache():
    """清空软 404 基线缓存（换目标 / 单测隔离时调用）。"""
    _BASELINE_CACHE.clear()


def soft404_baseline(base_url, client):
    """取随机不存在路径作"软 404 基线"，供全流程统一比对。

    返回 dict：
        path   —— 使用的随机路径（crc32 稳定生成，跨进程可复现）
        status —— 基线状态码（0 表示请求失败）
        length —— 基线响应长度
        hash   —— 基线响应体 md5
        text   —— 基线响应体前 2000 字节（供相似度比对）

    为什么必须存在：WAF 前置站点对任意路径统一回 403、nginx 兜底站点
    对任意路径统一回 200 首页——这两种响应都不代表"路径存在"。没有
    基线，检测器只能靠状态码猜，必然把整站判成漏洞。
    """
    if base_url in _BASELINE_CACHE:
        return _BASELINE_CACHE[base_url]
    rand_path = "/bt-nonexist-%08x" % (
        zlib.crc32(base_url.encode("utf-8", "ignore")) & 0xFFFFFFFF)
    info = {"path": rand_path, "status": 0, "length": 0, "hash": "", "text": ""}
    try:
        r = client.get(base_url.rstrip("/") + rand_path, purpose="probe:baseline")
        if r is not None:
            info["status"] = r.status or 0
            info["length"] = r.length or 0
            info["hash"] = r.body_hash or ""
            info["text"] = (r.text or "")[:2000]
    except Exception as e:  # 基线失败不阻断主流程，退化为"无基线"
        log.warning("软 404 基线获取失败 %s: %s", base_url, e)
    _BASELINE_CACHE[base_url] = info
    return info


# ------------------------------------------------------------
# round89 FIX-1：运行期「拦截墙」识别
# ------------------------------------------------------------
# 背景（真实扫描暴露）：基线在扫描开始时抓取——那时 pay.ztgame.com 还是
# 200/20930 的正常首页。扫到第 2 阶段站点风控被触发，此后**任意路径**
# 都返回同一份 403/2785 拦截页。此时：
#   · is_soft404(resp, base) 因状态码不同（403 vs 200）而恒 False；
#   · 「403 且基线也是 403」那条跳过规则也失效（基线是 200）；
# 结果 340 条字典命中 337 条——把整站 WAF 当成漏洞，报告全废。
# my.ztgame.com 首阶段就 403/2785 全同质，但因「403 且基线 403」
# 这条规则恰好挡住了，掩盖了同一个根因。
#
# 修法：加一条与基线无关的**自证式**判据——探测一个随机不存在的路径，
# 若当前对该随机路径的响应与本条响应同质（状态码+长度贴近 或 正文相似），
# 说明服务端对本条路径并无差异化处理，它不可能"存在"。
# 这与前向基线互补：基线防「一开始就是软 404」，本条防「扫到一半变墙」。
def _wall_snapshot(base_url, client, tag="runtime"):
    """取一个随机不存在路径的**当前**响应作拦截墙快照（带缓存，进程内一次）。

    返回 dict：``{status, length, hash, text}``；请求失败时 status=0。
    缓存键带 tag，避免和 soft404_baseline 的缓存互相污染。
    """
    key = "wall:%s:%s" % (tag, base_url)
    if key in _BASELINE_CACHE:
        return _BASELINE_CACHE[key]
    info = {"status": 0, "length": 0, "hash": "", "text": ""}
    try:
        rp = "/bt-nowall-%08x" % (
            (zlib.crc32(base_url.encode("utf-8", "ignore")) ^ 0x5A5A5A5A) & 0xFFFFFFFF)
        # round89 FIX-1b：快照必须与实际探测同口径（不跟跳转），
        # 否则基线类站点（任意路径 302 -> 首页 200）快照会落成 200/首页长度，
        # 与探测到的 302/154 永不相等，墙判据静默失效（这是 337/340
        # 全量误报的真正机制）。
        r = client.get(base_url.rstrip("/") + rp, purpose="probe:wall",
                       allow_redirects=False)
        if r is not None:
            info["status"] = r.status or 0
            info["length"] = r.length or 0
            info["hash"] = r.body_hash or ""
            info["text"] = (r.text or "")[:2000]
    except Exception as e:
        log.warning("拦截墙快照获取失败 %s: %s", base_url, e)
    _BASELINE_CACHE[key] = info
    return info


def blocking_wall(resp, base_url, client, tag="runtime", cache=None):
    """判断 ``resp`` 是否为服务端统一的拦截墙响应（即该路径实际不存在）。

    判据（满足任一即视为墙）：
      1) 与**当前**随机路径响应同质：状态码相同，且长度差异在
         max(32, 2%) 以内，或正文前 2000 字节相似度 >= SOFT404_RATIO；
      2) 正文长度过短（< 256B）且状态码为 403/412/429/503——这类极短
         拦截页对任意路径一致，本身就是墙的特征。

    ``cache`` 传入 dict 可让同一主机只取一次快照（扫描阶段用）。
    """
    if resp is None or not getattr(resp, "status", 0):
        return False
    st = resp.status or 0
    if cache is not None:
        snap = cache.get("snap")
        if snap is None:
            snap = _wall_snapshot(base_url, client, tag)
            cache["snap"] = snap
    else:
        snap = _wall_snapshot(base_url, client, tag)
    sst = snap.get("status") or 0
    sl = snap.get("length") or 0
    rl = resp.length or 0
    if sst and sst == st:
        if sl and rl and abs(rl - sl) <= max(32, sl * 0.02):
            return True
        stxt = snap.get("text") or ""
        rtxt = (resp.text or "")[:2000]
        if stxt and rtxt:
            try:
                if _sim_white(stxt, rtxt) >= SOFT404_RATIO:
                    return True
            except Exception:
                pass
    if st in (403, 412, 429, 503) and rl and rl < 256:
        return True
    return False

def wall_batch(entries):
    """批次内聚类：若多数不同路径返回**完全同一**响应，该响应即拦截墙。

    round89 FIX-5：真实站点风控存在"双通道"——随机路径回软 404（如 302/154），
    而字典里的高价值路径全部回统一拦截页（如 39 个互不相同的路径都是
    403/2785）。单点快照只能抓前一种，抓不到后一种；而"几十个语义无关的
    路径返回逐字节相同的响应"本身就是墙的硬证据。

    ``entries`` 为 ``[(url, resp), ...]``。返回 ``(signatures, total)``：
    signatures 是**同质条目数 >= 5 且占比 >= 25%** 的
    ``(status, length, body_hash)`` 集合，调用方据此丢弃对应响应。
    口径从严：样本少于 5 条一律不判，避免小字典场景误杀真实命中。
    """
    try:
        from collections import Counter
    except Exception:
        return set(), 0
    sigs = []
    for _e in (entries or []):
        _r = _e[1] if isinstance(_e, (tuple, list)) and len(_e) > 1 else _e
        if _r is None or not getattr(_r, "status", 0):
            continue
        sigs.append((_r.status, _r.length or 0, _r.body_hash or ""))
    total = len(sigs)
    if total < 5:
        return set(), total
    cnt = Counter(sigs)
    need = max(5, int(total * 0.25))
    hot = set(s for s, n in cnt.items() if n >= need)
    # round89 FIX-5b：拦截页常把请求路径/随机盐回显进正文，导致「长度相同
    # 但 body_hash 各不相同」（实测 pay 39 条全是 403/2785 却 39 个不同 hash）。
    # 对拒绝类状态码放宽到「同状态 + 长度成簇」即可认定统一拦截；
    # 正常状态码（200/301/302）仍要求逐字节相同，避免不同页面长度撞车误杀。
    # round89 FIX-5c：www.ztgame.com 的拦截页长度在 2739/2740 之间抖动，
    # 精确长度分组会散成两个簇各 12 条、都够不到阈值，故改为邻接聚类。
    _deny_lens = {}
    for s in sigs:
        if s[0] in (401, 403, 412, 429, 503):
            _deny_lens.setdefault(s[0], []).append(s[1])
    hot_len = set()
    for _st, _lens in sorted(_deny_lens.items()):
        _lens = sorted(_lens)
        _i = 0
        while _i < len(_lens):
            _j = _i
            while (_j + 1 < len(_lens)
                   and _lens[_j + 1] - _lens[_i] <= max(16, _lens[_i] * 0.01)):
                _j += 1
            if _j - _i + 1 >= need:
                for _L in _lens[_i:_j + 1]:
                    hot_len.add((_st, _L))
                log.info("[拦截墙] 拒绝页同构 status=%s len≈%s 覆盖 %d/%d 条路径（正文各异），判为统一拦截页",
                         _st, _lens[_i], _j - _i + 1, total)
            _i = _j + 1
    for s in sorted(hot, key=lambda x: -cnt[x]):
        log.info("[拦截墙] 同质响应 status=%s len=%s 覆盖 %d/%d 条路径，判为统一拦截页",
                 s[0], s[1], cnt[s], total)
    return {"exact": hot, "bylen": hot_len}, total

def wall_sig_hit(resp, hot):
    """``wall_batch`` 结果的命中判定：精确签名或「拒绝类同状态同长度」任一命中。"""
    if not hot or resp is None or not getattr(resp, "status", 0):
        return False
    sig = (resp.status, resp.length or 0, resp.body_hash or "")
    if sig in (hot.get("exact") or ()):
        return True
    return (resp.status, resp.length or 0) in (hot.get("bylen") or ())

def is_soft404(resp, base):
    """判断响应是否与软 404 基线"同质"——即该路径实际并不存在。

    同质判据（满足任一）：
      1) 状态码与基线相同，且长度差异在 max(32, 2%) 以内；
      2) 状态码相同，且正文前 2000 字节相似度 >= SOFT404_RATIO。

    状态码不同（例如基线 404、本路径 200）说明服务端对该路径做了
    单独处理，不能判为同质，交给调用方继续判断。
    """
    if not resp or not base or not base.get("status"):
        return False
    if (resp.status or 0) != base["status"]:
        return False
    bl = base.get("length") or 0
    rl = resp.length or 0
    if bl and rl and abs(rl - bl) <= max(32, bl * 0.02):
        return True
    bt = base.get("text") or ""
    rt = (resp.text or "")[:2000]
    if bt and rt:
        try:
            if _sim_white(bt, rt) >= SOFT404_RATIO:
                return True
        except Exception:
            pass
    return False


# 兼容旧名（内部调用/历史测试引用）
_is_soft404 = is_soft404


def _base_url_of(url):
    """从完整 URL 取 scheme://host[:port]/ 形式的基础地址。"""
    try:
        p = urlparse(url)
        if not p.scheme or not p.netloc:
            return ""
        return "%s://%s/" % (p.scheme, p.netloc)
    except Exception:
        return ""


def home_baseline(base_url, client):
    """取站点首页作「同体基线」，用于主基线不可用时的兜底比对。

    主基线走随机不存在路径，一旦该请求失败（超时 / WAF 抖动 / 连接重置），
    is_soft404 就失去唯一参照，会退化为「一律放行」，把整站兜底首页判成
    几十条漏洞。首页响应必定存在且稳定，用它做第二条参照，可在主基线
    挂掉时仍识别出「所有路径都返回同一个兜底首页」这类误报。
    """
    key = base_url + "#home"
    if key in _BASELINE_CACHE:
        return _BASELINE_CACHE[key]
    info = {"kind": "home", "path": "/", "status": 0, "length": 0,
            "hash": "", "text": ""}
    try:
        r = client.get(base_url.rstrip("/") + "/", purpose="probe:homebase")
        if r is not None:
            info["status"] = r.status or 0
            info["length"] = r.length or 0
            info["hash"] = r.body_hash or ""
            info["text"] = (r.text or "")[:2000]
    except Exception as e:
        log.warning("首页基线获取失败 %s: %s", base_url, e)
    _BASELINE_CACHE[key] = info
    return info


def home_baseline_cached(base_url):
    """只读首页基线缓存，不发请求（供下游检测器零成本二次复核）。"""
    return _BASELINE_CACHE.get(base_url + "#home")


def baseline_usable(base):
    """基线是否可信：请求成功（status 非 0）才算可用。"""
    return bool(base) and bool(base.get("status"))


def same_length(a, b, ratio=0.02, floor=32):
    """两个长度是否同量级——用于判断响应是否与基线同体。"""
    try:
        a = int(a or 0)
        b = int(b or 0)
    except Exception:
        return False
    if not a or not b:
        return False
    return abs(a - b) <= max(floor, b * ratio)


def _pick_scheme(host, client):
    """先 https 后 http，返回 (base_url, resp, last_err)。不可达时前两项为 None。"""
    last_err = ""
    for scheme in ("https", "http"):
        url = "%s://%s/" % (scheme, host)
        r = client.get(url, purpose="probe:alive")
        if r.status:
            return url, r, ""
        if not last_err:
            last_err = (getattr(r, "error", "") or "")[:200]
    return None, None, last_err


def _title(text):
    m = TITLE_RE.search(text or "")
    if not m:
        return ""
    t = re.sub(r"\s+", " ", m.group(1)).strip()
    return t[:120]


def fingerprint(resp):
    """基于响应头 + 响应体做组件识别，返回命中的组件名列表。"""
    blob = " ".join("%s %s" % (k, v) for k, v in (resp.headers or {}).items())
    blob += " " + (resp.text or "")[:20000]
    hits = []
    for name, pattern, _cat in dicts.FINGERPRINTS:
        try:
            if re.search(pattern, blob, re.I):
                hits.append(name)
        except re.error:
            continue
    return hits


def fingerprint_versions(resp):
    """在 fingerprint 基础上抽取具体版本号。

    返回 [(组件显示名, 版本, 组件键), ...]。用 dicts.VERSION_PATTERNS 逐条在
    “响应头 + 响应体前 20000 字节”里 re.search，第一个非空分组即版本号。
    同一个组件键只保留首次命中，避免同页多处 banner 造成重复条目。
    本函数只读响应，不发起任何额外请求。
    """
    blob = " ".join("%s %s" % (k, v) for k, v in (resp.headers or {}).items())
    blob += " " + (resp.text or "")[:20000]
    out, seen = [], set()
    for disp, pattern, key in getattr(dicts, "VERSION_PATTERNS", []):
        if key in seen:
            continue
        try:
            m = re.search(pattern, blob, re.I)
        except re.error:
            continue
        if not m:
            continue
        ver = ""
        for g in m.groups():
            if g:
                ver = g.strip()
                break
        if not ver:
            continue
        seen.add(key)
        out.append((disp, ver, key))
    return out


def tech_with_versions(resp):
    """指纹 + 版本合并成落库用字符串列表。

    形如 ['nginx', 'nginx/1.18.0', 'PHP']：既保留组件名（兼容旧报告消费），
    又把“组件/版本”作为独立 token 塞进同一个 tech 字段，无需改 db 表结构。
    """
    tech = list(fingerprint(resp))
    vers = fingerprint_versions(resp)
    for disp, ver, _key in vers:
        tag = "%s/%s" % (disp, ver)
        if tag not in tech:
            tech.append(tag)
    return tech, vers


def collect_headers(resp):
    out = {}
    for k in HEADER_KEYS:
        v = resp.header(k)
        if v:
            out[k] = v
    return out


# ------------------------------------------------------------
# 单主机探测
# ------------------------------------------------------------
def _tcp_latency(h, port=443, budget=2.0):
    """测一次 TCP 建连耗时（秒）；连不上返回 None。只建连、不发任何 HTTP。

    round86 D5：换形态时用来给候选排序。实测同一站点不同前缀能差 10 倍
    （lani.com 24s vs www.lani.com 2.2s），不排序会先撞上最慢的那个，
    用户体感就是"点了半天不动"。
    """
    try:
        _t = time.time()
        _sk = socket.create_connection((h, port), timeout=budget)
        try:
            _sk.close()
        except Exception:
            pass
        return time.time() - _t
    except Exception:
        return None


def _try_alt_host(host, bare, client, diag=None):
    """原形态解析不出时，切到第一个「真能解析」的候选形态再试一次。

    round86 D4。背景：裸域（apex）只挂 MX/TXT、站点只配在 www / 其他前缀
    或另一后缀上，这在真实授权目标里极常见（lani.cc 就是：apex 无 A 记录，
    但 lani.cn / lani.com 都在线）。旧实现把候选写进 hint 就判死，结果是
    整台主机进不了 7 个阶段。

    约束：
      · 只切一个形态，切到即返回，不会串行试 12 个；
      · 候选必须**先解析成功**才发 HTTP，避免对死域名多发请求；
      · 返回的摘要里记 original_host / via_variant，报告能看出是一次跳转。
    """
    try:
        from core import dnsx
    except Exception:
        return None
    alts = []
    try:
        alts = dnsx.probe_variants(bare, limit=6)
    except Exception:
        alts = []
    # round86 D5: 本机首探实测 lani.com 要 24s、www.lani.com 只要 2.2s，同一站点
    # 差一个前缀就差十倍。所以候选**按实测连通性排序**而不是按生成顺序：
    # 先做一轮短超时 TCP 探活（只连不取页面、不占请求预算），再按延迟升序去试。
    _ranked = []
    for _cand, _ips in alts:
        if not _cand or _cand == bare:
            continue
        _d = _tcp_latency(_cand, port=443, budget=2.0)
        _ranked.append((_d if _d is not None else 99.0, _cand, _ips))
    _ranked.sort(key=lambda x: x[0])
    for _lat, _cand, _ips in _ranked:
        try:
            _h = _cand
            _base, _resp, _err = _pick_scheme(_h, client)
            if not _resp:
                continue
            _tech, _vers = tech_with_versions(_resp)
            info = {
                "host": _h,
                "url": _base,
                "status": _resp.status,
                "title": _title(_resp.text),
                "tech": _tech,
                "versions": _vers,
                "server": _resp.header("Server"),
                "ip": (_ips or [""])[0],
                "headers": collect_headers(_resp),
                "waf": _resp.waf,
                "final_url": _resp.url,
                "original_host": host,
                "via_variant": _cand,
            }
            log.info("[存活] %-40s %s %s %s", _h, _resp.status,
                     ",".join(_tech[:4]) or "-", _title(_resp.text)[:30])
            log.warning("[换形态] %s 无法解析，已切到 %s（%s）继续 7 阶段",
                        host, _cand, (_ips or [""])[0])
            if diag is not None:
                try:
                    diag["switched_to"] = _cand
                    diag["switched_ips"] = list(_ips or [])
                except Exception:
                    pass
            return info
        except Exception:
            continue
    return None


def probe_host(host, client, db=None, diag=None):
    """探测单个主机：存活、标题、指纹、server、跳转链。

    diag：可选 dict。不可达时把结构化归因（code / reason / hint / ip / tcp）
    回填给它，供编排层写进 summary 与报告——避免旧实现只留一句笼统的
    "无 HTTP 响应"，让用户分不清是 DNS、端口没开还是被防火墙吞包。
    """
    host = _hostport(host)            # 出网必须带端口
    bare = _norm_host(host)           # 纯主机名：DNS 解析 / 展示
    base, resp, last_err = _pick_scheme(host, client)
    if not resp:
        d = netdiag.diagnose(host, last_err, port=netdiag.port_of(host, 443))
        # 变体推断：原形态解析不出来时，试一次常见主机名变体（www 有无 / m / oa ...）。
        # 真实报告里用户给 ahqt.com.cn，而记录可能只配在 www.ahqt.com.cn（或反之），
        # 旧实现直接判死；这里补一次推断，把"建议改用某形态"写进 hint 与 variants。
        if d.get("code") in ("nxdomain", "nodata", "dns"):
            # 标记"已做过域名级联想"：供 selfheal.should_stop 判断——
            # 联想后仍无候选才算确定性失败（见 core/selfheal.py）。
            d["variants_probed"] = True
            try:
                from core import dnsx
                alts = dnsx.probe_variants(bare, limit=12)
                if alts:
                    names = [c for c, _ips in alts][:3]
                    d["variants"] = names
                    d["hint"] = "%s；但 %s 在本机可解析，请改用该形态重试" % (
                        d.get("hint") or "", "、".join(names))
            except Exception:
                pass
        # round86 D4: 裸域（apex）本身常只挂 MX/TXT，站点实际活在另一形态上。
        # 旧实现只把可解析候选写进 hint 就判死，用户看到的永远是"不可达"、
        # 7 个阶段一个都跑不到——这正是"以前能扫、现在直接出错"的真实成因。
        # 现在：候选**本身能解析**才切换过去真发一次 HTTP，切换后原来那套
        # 存活/指纹/记录逻辑照旧跑；强制要求 alts 里带 IP，等于先用 DNS
        # 筛掉不能用的形态，不会对死域名多发一个请求（不占预算放大）。
        if d.get("code") in ("nxdomain", "nodata", "dns"):
            _alt = _try_alt_host(host, bare, client, d)
            if _alt is not None:
                return _alt
        if diag is not None:
            try:
                diag.clear()
                diag.update(d)
            except Exception:
                pass
        log.error("[不可达] %-40s %s（%s）", host,
                  d.get("reason") or "无 HTTP 响应",
                  d.get("hint") or (last_err or "连接超时或被拒绝"))
        try:
            logger.audit("unreachable", host=host, code=d.get("code", ""),
                         reason=d.get("reason", ""), ip=d.get("ip", ""),
                         tcp=d.get("tcp", ""), err=d.get("err", ""))
        except Exception:
            pass
        return None

    _tech, _vers = tech_with_versions(resp)
    info = {
        "host": host,
        "url": base,
        "status": resp.status,
        "title": _title(resp.text),
        "tech": _tech,
        "versions": _vers,
        "server": resp.header("Server"),
        "ip": (client.scope.resolve_ips(bare) or [""])[0],
        "headers": collect_headers(resp),
        "waf": resp.waf,
        "final_url": resp.url,
    }
    log.info("[存活] %-40s %s %s %s", host, resp.status,
             ",".join(info["tech"][:4]) or "-", info["title"][:30])

    if db is not None:
        db.add_asset(host=host, url=base, ip=info["ip"], status=resp.status,
                     title=info["title"], tech=info["tech"],
                     server=info["server"], source="probe")
    return info


# ------------------------------------------------------------
# 目录 / 敏感路径探测
# ------------------------------------------------------------
def probe_sensitive_paths(base_url, client, db=None, host=""):
    """探测字典里的高价值路径，命中即记一条资产线索。

    缺陷 B 修复：原实现只按状态码 200/401/403/500 判"存在"，在两类真实
    站点上会全量误报——
      · WAF 前置站点（如 Wwebsvr）对任意路径一律回 403；
      · nginx 兜底站点对任意路径一律回 200 首页。
    两种响应都不代表路径存在。现在：
      1) 先取随机路径软 404 基线；
      2) 与基线同质的响应直接丢弃；
      3) 403/401 不再单独作为"存在"证据——只有基线本身不是 403/401、
         且该路径响应与基线不同（说明服务端对该路径做了差异化处理）
         时才采纳，避免 WAF 一刀切造成整站命中。
    """
    hits = []
    base = soft404_baseline(base_url, client)
    # round21 基线降级保护：主基线请求失败时 is_soft404 恒 False，
    # 会把整站兜底首页判成几十条敏感路径。宁可不报，不靠状态码猜。
    if not baseline_usable(base):
        log.warning("软 404 基线不可用，跳过敏感路径探测 %s", base_url)
        return []
    base_status = base.get("status") or 0
    # round89 FIX-1：拦截墙快照只取一次（并发共享，只读）
    _wall_snap = _wall_snapshot(base_url, client, tag="probe:path")

    def _wall_hit(resp):
        return blocking_wall(resp, base_url, client, tag="probe:path",
                             cache={"snap": _wall_snap})
    # round86 P2: 串行 63 条 × 每条约 2.9s = 182s，用户体感就是"卡死"。
    # 改为并发投递（并发度默认 8，与阶段2 目录爆破同档），并行结果保序
    # 回填后仍逐条走同一套 软404/基线/WAF 判定，不改变命中口径。
    # 每 ready_n 条打一行进度，避免长时间无输出。
    _workers = 8
    try:
        from core import config as _cfg
        _workers = int(_cfg.Config().get("http.concurrency_max") or 8)
    except Exception:
        _workers = 8
    _workers = max(1, min(_workers, 8))
    _total = len(dicts.SENSITIVE_PATHS)

    def _one(item):
        _p, _d, _s = item
        _u = base_url.rstrip("/") + _p
        try:
            _r = client.get(_u, purpose="probe:path", allow_redirects=False)
        except Exception:
            return None
        return (_p, _d, _s, _u, _r)

    _done = [0]
    _items = []
    try:
        with ThreadPoolExecutor(max_workers=_workers) as _ex:
            for _item in _ex.map(_one, dicts.SENSITIVE_PATHS):
                _done[0] += 1
                if _done[0] % 20 == 0 or _done[0] == _total:
                    log.info("[敏感路径] 进度 %d/%d（并发 %d）", _done[0], _total, _workers)
                if _item:
                    _items.append(_item)
        # round89 FIX-5：先收齐全部响应再聚类，识别"统一拦截页"签名。
        # 站点风控可能在任意时刻升级，整批一致的长响应（如 39 条均为
        # 403/2785）单点快照抓不到，只能靠批内同质性自证。
        _hot, _ntot = wall_batch([(it[3], it[4]) for it in _items])
        for path, desc, sev, url, r in _items:
                if not r.status:
                    continue
                if r.status not in (200, 401, 403, 500):
                    continue
                if is_soft404(r, base):
                    continue
                if r.status in (401, 403) and base_status in (401, 403):
                    continue
                # round89 FIX-1：扫到一半站点触发风控，任意路径统一回
                # 403/2785 拦截页——此时基线还是风控前的 200，上面两条
                # 判据全部失效。用当前随机路径快照自证，堵住这条误报。
                if _wall_hit(r):
                    continue
                # round89 FIX-5：批内同质 → 统一拦截页（站点风控升级后的形态）。
                if wall_sig_hit(r, _hot):
                    continue
                if _is_real_hit(r, desc):
                    hit = {"url": url, "path": path, "desc": desc,
                           "severity": sev, "status": r.status,
                           "length": r.length, "evidence": r.dump(800),
                           "baseline_ok": True}
                    hits.append(hit)
                    log.warning("[命中] %s [%s] %s", url, r.status, desc)
                    if db is not None:
                        db.mark_scanned(url, r.status, r.length,
                                        r.header("Content-Type"), r.body_hash)
    except Exception as e:
        log.warning("敏感路径并发异常 %s: %s", base_url, e)
    return hits


def _is_real_hit(resp, desc):
    """过滤"伪命中"：404 页面、登录跳转、空白页。"""
    body = resp.text or ""
    if resp.status == 200 and len(body.strip()) < 10:
        return False
    low = body.lower()
    if "not found" in low[:200] or "404" == body.strip()[:3]:
        return False
    return True


def dir_bruteforce(base_url, client, words=None, db=None, workers=1):
    """目录爆破：先取一个随机路径作软 404 基线，再比对长度差异。"""
    words = words or _dm.merged_dir_words()
    # 基线统一走 soft404_baseline（crc32 稳定哈希，跨进程可复现），
    # 与敏感路径 / 组件检测共用同一条基线，保证判定口径一致。
    base = soft404_baseline(base_url, client)
    # round21 基线降级保护：主基线失败时长度判据失效，会把整站兜底
    # 首页判成大量目录存在。宁可不报，不靠状态码猜。
    if not baseline_usable(base):
        log.warning("软 404 基线不可用，跳过目录爆破 %s", base_url)
        return []
    base_len = base.get("length") or 0
    # round89 FIX-1：拦截墙快照只取一次（并发共享，只读）
    _wall_snap = _wall_snapshot(base_url, client, tag="probe:dir")

    def _wall_hit(resp):
        return blocking_wall(resp, base_url, client, tag="probe:dir",
                             cache={"snap": _wall_snap})

    found = []
    # round23：单主机目录爆破原本 190 词纯串行，2 req/s x 190 ~= 95s 且循环内
    # 零日志，用户会误以为卡死。这里按 workers 并发（复用同一 HttpClient，
    # 其内部按线程持有独立 Session，限速器全局生效），workers<=1 时退化为原串行。
    _raw = []
    def _one(w):
        url = base_url.rstrip("/") + "/" + w.lstrip("/")
        if db is not None and db.is_scanned(url):
            return None
        r = client.get(url, purpose="probe:dir", allow_redirects=False)
        if db is not None:
            db.mark_scanned(url, r.status or 0, r.length or 0,
                            r.header("Content-Type"), r.body_hash)
        if not r.status:
            return None
        if r.status in (200, 301, 302, 401, 403):
            # 与软 404 基线过于接近 -> 疑似伪命中
            if base_len and r.length and abs(r.length - base_len) <= max(16, base_len * 0.02):
                return None
            # round89 FIX-1：基线本身可用但早已过期。站点中途触发风控后，
            # 任意路径统一回 302/154 或 403/2785，与旧基线状态码不同、
            # 长度比对也过不了，340 条字典会命中 337 条。
            # 用「当前随机路径快照」自证：同质即视为墙，丢弃。
            if _wall_hit(r):
                return None
            # round89 FIX-5：单点快照抓不到「风控升级后整批同质的长拦截页」，
            # 先原样保留，等整批跑完做聚类再统一剔除。
            return (r, url)
        return None
    def _collect(iterable):
        for _h in iterable:
            if _h:
                _raw.append(_h)
    if workers > 1 and len(words) > 1:
        with ThreadPoolExecutor(max_workers=min(workers, len(words))) as ex:
            _collect(ex.map(_one, words))
    else:
        _collect(_one(w) for w in words)
    # round89 FIX-5：目录字典同样可能整批撞上统一拦截页，用批内同质聚类剔除。
    _hot, _ntot = wall_batch([(h[1], h[0]) for h in _raw])
    for r, url in _raw:
        if wall_sig_hit(r, _hot):
            continue
        found.append({"url": url, "status": r.status, "length": r.length,
                      "ctype": r.header("Content-Type")})
    return found


# ------------------------------------------------------------
# 敏感信息扫描（响应体正则）
# ------------------------------------------------------------
# 静态资源后缀：.js/.css 等第三方库里会大量出现 password/email 之类的
# 普通标识符（如 jQuery 的 `password: true,`），跑启发式匹配必然误报。
STATIC_ASSET_RE = re.compile(
    r"\.(?:js|css|map|json|png|jpe?g|gif|svg|ico|woff2?|ttf|eot|webp)(?:[?#]|$)", re.I)
# 已知第三方库文件名特征，命中则进一步降低启发式匹配的权重。
LIB_HINT_RE = re.compile(
    r"(jquery|bootstrap|modernizr|iscroll|respond|angular|react|vue|"
    r"underscore|lodash|moment|axios|swiper|font-awesome|popper|zepto)", re.I)
# 这些"松口径"模式（只是普通单词赋值，非强特征）不在静态资源上触发。
LOOSE_SECRET_TYPES = {"数据库密码", "邮箱", "手机号"}
# 这些模式的前缀是固定大小写（AKIA/LTAI/AIza），一旦用 re.I 会退化成
# "任意大小写的 4 个字母 + 16 位字母数字"，base64 数据流里必出假命中。
# 实测：www.easthope.cn 首页字体 base64 里凑出 AKIArAC2AMAAygDUAN4A。
CASE_SENSITIVE_TYPES = {"AWS AccessKey", "AK/SK (阿里云)", "Google API Key"}
# base64 数据流特征：命中项两侧若都是长串 [A-Za-z0-9+/]，说明它只是
# 编码数据的一部分，不是可读的密钥字面量。
B64_CONTEXT_RE = re.compile(r"[A-Za-z0-9+/=]{16,}")
# 公开角色邮箱：只收「协议规定必须存在 / 纯机器用途」的地址，
# 它们是站点对外公布的固定联系方式，不算信息泄露。
# 注意：admin@ / info@ / support@ 这类**不**纳入——真实站点上它们
# 可能是运维/员工邮箱，属于真泄露，宁可报也不能漏。
ROLE_EMAIL_RE = re.compile(
    r"^(?:postmaster|webmaster|hostmaster|abuse|noreply|no-reply|"
    r"donotreply|mailer-daemon)@", re.I)
def _in_base64_blob(text, start, end):
    """判断命中项是否被包在更长的 base64 串里（两侧连续 [A-Za-z0-9+/=]）。"""
    left = text[max(0, start - 24):start]
    right = text[end:end + 24]
    m1 = B64_CONTEXT_RE.search(left)
    m2 = B64_CONTEXT_RE.search(right)
    return bool(m1 and m2)
def scan_secrets(url, text):
    """在响应体里找密钥 / 内网 IP / 身份证等敏感信息。
    强特征模式（AK/SK、私钥、JWT、JDBC、Git 凭证等）在所有资源上都测；
    松口径模式（password=xxx、邮箱、手机号）只在非静态资源上测，
    避免在 jquery/bootstrap 这类库里刷出一堆误报。
    三重降误报：
      1) 固定大小写前缀（AKIA/LTAI/AIza）用大小写敏感匹配，防 base64 假命中；
      2) 命中项两侧若都是长 base64 串，直接丢弃；
      3) 公开角色邮箱（postmaster@ 等）不算泄露，直接丢弃。
    注：早先签名带 db / host 两个参数，但函数体从未使用——落库由
    engine 的 _persist 统一负责，这里只做纯匹配，故把死参数删掉。
    """
    hits = []
    is_static = bool(STATIC_ASSET_RE.search(url or ""))
    is_lib = bool(LIB_HINT_RE.search(url or ""))
    body = text or ""
    for name, pattern, sev in dicts.SECRET_PATTERNS:
        # 静态资源 / 第三方库上跳过松口径模式
        if (is_static or is_lib) and name in LOOSE_SECRET_TYPES:
            continue
        flags = 0 if name in CASE_SENSITIVE_TYPES else re.I
        try:
            m = re.search(pattern, body, flags)
        except re.error:
            continue
        if not m:
            continue
        val = m.group(0)
        # 抑制 1：base64 数据流里的巧合命中
        if _in_base64_blob(body, m.start(), m.end()):
            log.debug("[敏感信息] 疑似 base64 巧合，跳过 %s → %s", url, name)
            continue
        # 抑制 2：公开角色邮箱（站点对外联系地址）
        if name == "邮箱" and ROLE_EMAIL_RE.match(val):
            log.debug("[敏感信息] 公开角色邮箱，跳过 %s → %s", url, val)
            continue
        # 邮箱 / 手机号这类低危只留前几位，避免把全量数据带进报告
        masked = val if len(val) <= 12 else val[:6] + "***" + val[-4:]
        hits.append({"url": url, "type": name, "severity": sev,
                     "match": masked, "raw": val})
        log.warning("[敏感信息] %s → %s", url, name)
    return hits