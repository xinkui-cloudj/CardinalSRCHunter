# -*- coding: utf-8 -*-
"""无危害 PoC 验证层。

设计红线（来自 src-hunter 方法论）：
- 只做"证明存在"，不做"利用到底"；
- 每个漏洞最多 1~3 次验证请求，禁止批量拖数据；
- 所有 payload 都是只读语义（SELECT/回显/时间延迟），不含 DROP/DELETE/UPDATE；
- 不写入、不删除、不篡改目标任何数据。

本模块把 vulnchecks 给出的"疑似"提升为"已复现"，并生成可直接粘进
补天报告的复现三要素：请求原文 / 响应原文 / 判定依据。
"""
import re
import time

from core import dicts, logger

log = logger.get("bt.poc")

# 危险 SQL 关键字：一旦出现在我们要发送的 payload 里就直接拒绝
FORBIDDEN_SQL = re.compile(
    r"\b(drop|delete|update|insert|truncate|alter|grant|shutdown|outfile|dumpfile)\b",
    re.I)


def _safe_payload(payload):
    """拒绝任何带破坏性语义的 payload（代码层面的红线守卫）。"""
    if FORBIDDEN_SQL.search(payload or ""):
        logger.audit("poc_rejected", payload=payload, reason="forbidden_sql")
        log.error("已拒绝破坏性 payload: %s", payload)
        return False
    return True


# ------------------------------------------------------------
# SQLi 复现
# ------------------------------------------------------------
def verify_sqli(url, client, param, method="GET", body=None, delay=5,
                inject_query=None, inject_form=None):
    """二次验证时间盲注：对比 base / sleep(0) / sleep(d) 三次耗时。"""
    if inject_query is None:
        from modules.vulnchecks import _inject_query as inject_query
    if inject_form is None:
        from modules.vulnchecks import _inject_form as inject_form

    def _send(payload):
        # r88 缺陷5：计时用 Response.elapsed，排除本地限速排队。
        if method == "GET":
            r = client.get(inject_query(url, param, payload), purpose="poc:sqli")
        else:
            r = client.post(url, data=inject_form(body, param, payload),
                            purpose="poc:sqli")
        return r, float(getattr(r, "elapsed", 0) or 0)

    # 1) 基线（原始值）

    if method == "GET":
        base = client.get(url, purpose="poc:sqli:base")
    else:
        base = client.post(url, data=body, purpose="poc:sqli:base")
    t_base = float(getattr(base, "elapsed", 0) or 0)
    if not base.status:
        return None

    # 2) 对照组：语法等价但无延迟（sleep(0)）
    ctrl_payload = "1' AND SLEEP(0)-- -"
    if not _safe_payload(ctrl_payload):
        return None
    _, t_ctrl = _send(ctrl_payload)

    # 3) 实验组：真延迟
    exp_payload = "1' AND SLEEP(%d)-- -" % delay
    r_exp, t_exp = _send(exp_payload)

    # 判定：实验组显著慢于对照组与基线，且对照组不明显变慢
    if (t_exp >= delay * 0.7 and t_exp > t_ctrl * 3 and t_exp > t_base * 3
            and t_ctrl < delay * 0.5):
        return {
            "verified": True,
            "type": "SQL 时间盲注",
            "severity": "critical",
            "confidence": "high",
            "param": param,
            "payload": exp_payload,
            "baseline": round(t_base, 3),
            "control": round(t_ctrl, 3),
            "elapsed": round(t_exp, 3),
            "evidence": ("基线 %.3fs → 对照组(SLEEP(0)) %.3fs → "
                         "实验组(SLEEP(%d)) %.3fs" % (t_base, t_ctrl, delay, t_exp)),
            "request": r_exp.raw_request or "",
            "response": r_exp.dump(800),
            "cvss": "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H",
            "fix": "使用参数化查询（PreparedStatement / ORM 绑定变量），"
                   "禁止字符串拼接 SQL；对输入做类型与白名单校验。",
        }
    return None


def verify_sqli_error(url, client, param, method="GET", body=None,
                      inject_query=None, inject_form=None):
    """报错注入复现：注入单引号，命中数据库报错特征即确认。"""
    if inject_query is None:
        from modules.vulnchecks import _inject_query as inject_query
    if inject_form is None:
        from modules.vulnchecks import _inject_form as inject_form

    payload = "'"
    if method == "GET":
        r = client.get(inject_query(url, param, payload), purpose="poc:sqli:err")
    else:
        r = client.post(url, data=inject_form(body, param, payload),
                        purpose="poc:sqli:err")
    if not r.status:
        return None
    for sign in dicts.SQLI_ERROR_SIGNS:
        if re.search(sign, r.text or "", re.I):
            m = re.search(sign, r.text or "", re.I)
            return {
                "verified": True,
                "type": "SQL 报错注入",
                "severity": "high",
                "confidence": "high",
                "param": param,
                "payload": payload,
                "evidence": "注入单引号后回显数据库报错：%s" % m.group(0)[:120],
                "request": r.raw_request or "",
                "response": r.dump(800),
                "cvss": "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:N/VA:N",
                "fix": "统一异常处理，禁止把数据库报错回显到前端；改用参数化查询。",
            }
    return None


# ------------------------------------------------------------
# XSS 复现
# ------------------------------------------------------------
def verify_xss(url, client, param, method="GET", body=None,
               inject_query=None, inject_form=None):
    """反射型 XSS：用一个唯一 marker 确认反射位置与编码状态。"""
    if inject_query is None:
        from modules.vulnchecks import _inject_query as inject_query
    if inject_form is None:
        from modules.vulnchecks import _inject_form as inject_form

    marker = dicts.XSS_MARKER
    payload = '<svg/onload=alert("%s")>' % marker
    if method == "GET":
        r = client.get(inject_query(url, param, payload), purpose="poc:xss")
    else:
        r = client.post(url, data=inject_form(body, param, payload),
                        purpose="poc:xss")
    if not r.status:
        return None
    body_text = r.text or ""
    if marker not in body_text:
        return None

    idx = body_text.find(marker)
    ctx = body_text[max(0, idx - 120):idx + 160]
    # 判断是否被实体编码
    encoded = ("&lt;" in ctx and "svg" in ctx.lower()) or "&#" in ctx
    # 判断是否落在可执行上下文
    exec_ctx = bool(re.search(r"<script|on\w+\s*=|javascript:", ctx, re.I))

    sev = "high" if (not encoded and exec_ctx) else "medium"
    conf = "high" if (not encoded and exec_ctx) else "medium"
    return {
        "verified": True,
        "type": "反射型 XSS",
        "severity": sev,
        "confidence": conf,
        "param": param,
        "payload": payload,
        "evidence": ("marker 被原样反射，编码状态=%s，可执行上下文=%s\n上下文：%s"
                     % ("已编码" if encoded else "未编码",
                        "是" if exec_ctx else "否", ctx)),
        "request": r.raw_request or "",
        "response": r.dump(800),
        "cvss": ("CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:H/VI:L/VA:N" if sev == "high"
                 else "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:L/VI:L/VA:N"),
        "fix": "对输出做上下文相关编码（HTML 实体 / JS 转义 / 属性引号）；"
               "启用严格 CSP；富文本使用白名单过滤（如 DOMPurify）。",
    }


# ------------------------------------------------------------
# 开放重定向复现
# ------------------------------------------------------------
def verify_open_redirect(url, client, param, method="GET", body=None,
                         inject_query=None, inject_form=None):
    if inject_query is None:
        from modules.vulnchecks import _inject_query as inject_query
    if inject_form is None:
        from modules.vulnchecks import _inject_form as inject_form
    payload = "https://evil.com/bt-poc"
    if method == "GET":
        r = client.get(inject_query(url, param, payload), purpose="poc:redirect",
                       allow_redirects=False)
    else:
        r = client.post(url, data=inject_form(body, param, payload),
                        purpose="poc:redirect", allow_redirects=False)
    if r.status in (301, 302, 303, 307, 308):
        loc = r.header("Location")
        if loc and "evil.com" in loc:
            return {
                "verified": True,
                "type": "开放重定向",
                "severity": "medium",
                "confidence": "high",
                "param": param,
                "payload": payload,
                "evidence": "服务端 302 跳转到外部域：Location: %s" % loc,
                "request": r.raw_request or "",
                "response": r.dump(400),
                "cvss": "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:N/VI:L/VA:N",
                "fix": "跳转目标使用白名单域名校验；禁止直接使用用户传入的 URL 作为 Location。",
            }
    return None


# ------------------------------------------------------------
# 统一入口：把 vulnchecks 的疑似项升级为已复现项
# ------------------------------------------------------------
def upgrade(findings, client, limit=6):
    """对疑似漏洞做二次无危害复现，返回已确认的 PoC 列表。"""
    from urllib.parse import urlparse, parse_qs

    confirmed = []
    for f in (findings or [])[:limit]:
        vtype = f.get("vuln_type", "")
        url = f.get("url", "")
        param = f.get("payload_param") or ""
        # 关键：把检测层记录的请求语义（method / body）一并带下去。
        # 旧实现只取 url+param，一律按 GET 复现——POST 表单型漏洞会被
        # 静默降级成 GET，服务端读的是 body 而不是 query，PoC 永远验不出来
        # （假阴性，且报告里看不出是"没复现"还是"复现方式错了"）。
        method = (f.get("method") or "GET").upper()
        body = f.get("body")
        if not param:
            # 从 URL 里取第一个 query 参数名兜底
            qs = parse_qs(urlparse(url).query)
            param = next(iter(qs), "")
        if not param and isinstance(body, dict) and body:
            # POST 且 URL 无 query 时，参数名只能从表单体里取
            param = next(iter(body), "")
        if not param:
            continue

        res = None
        try:
            if "时间盲注" in vtype:
                res = verify_sqli(url, client, param, method=method, body=body)
            elif "报错注入" in vtype:
                res = verify_sqli_error(url, client, param, method=method, body=body)
            elif "XSS" in vtype:
                res = verify_xss(url, client, param, method=method, body=body)
            elif "重定向" in vtype:
                res = verify_open_redirect(url, client, param,
                                           method=method, body=body)
        except Exception as e:
            log.warning("PoC 复现异常 %s: %s", url, e)

        if res and res.get("verified"):
            res["url"] = url
            # 缺陷 P 修复配套：把检测层的请求语义（method/body）带进确认项。
            # 旧实现只回填 url，method 缺省成 GET，POST 表单型确认项的去重键
            # 与疑似项不一致，既无法原地升级、又会另落一条重复条目。
            res["method"] = method
            if isinstance(body, dict) and body:
                res["body"] = body
            res["title"] = "%s @ %s" % (res["type"], url)
            confirmed.append(res)
            logger.audit("poc_confirmed", url=url, type=res["type"],
                         param=param)
            log.warning("[已复现] %s %s 参数=%s", res["type"], url, param)
    return confirmed
