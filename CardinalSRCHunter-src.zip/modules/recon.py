# -*- coding: utf-8 -*-
"""被动侦察：子域枚举 / DNS 解析 / 证书透明日志 / 子域接管检测。

设计取舍：
- 优先走被动数据源（crt.sh 证书透明），减少对目标的直接请求；
- 子域爆破仅在配置允许且已通过 scope 校验时执行；
- 通配符 DNS 自动识别，避免把泛解析域名误报成一堆"子域"。
"""
import json
import re
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from core import dicts, logger
from core import dict_merge as _dm
from core.scope import _norm_host

log = logger.get("bt.recon")

try:
    import dns.resolver
except Exception:  # pragma: no cover
    dns = None

CRT_URL = "https://crt.sh/?q=%25.{domain}&output=json"
COMMON_SUFFIX = ("com", "net", "org", "cn", "com.cn", "net.cn", "org.cn",
                 "gov.cn", "edu.cn", "io", "co", "top", "xyz", "vip", "cc")


# ------------------------------------------------------------
# DNS
# ------------------------------------------------------------
def dns_query(host, rtype="A"):
    """返回记录列表；失败返回空列表。

    A 记录优先走 core.dnsx 的多源并发解析（单台 DNS 失效自动跳过、
    IPv4 优先、失败可精确归因），避免 /etc/resolv.conf 首选服务器一挂
    整个子域枚举静默返回空集。非 A 记录（CNAME/MX/TXT）仍走 dnspython。
    """
    if rtype == "A":
        try:
            from core import dnsx
            ips = dnsx.resolve(host)
            if ips:
                return ips
        except Exception:
            pass
    if dns is not None:
        try:
            ans = dns.resolver.resolve(host, rtype, lifetime=6)
            return [r.to_text().strip('"') for r in ans]
        except Exception:
            pass
    # 回退到 socket（仅 A 记录）
    if rtype == "A":
        try:
            return sorted({i[4][0] for i in socket.getaddrinfo(host, None)})
        except Exception:
            return []
    return []


def resolves(host):
    return bool(dns_query(host, "A"))


def has_wildcard(domain):
    """检测泛解析：随机标签若能解析，说明存在通配符。"""
    probe = "bt-wildcard-%d.%s" % (int(time.time()) % 100000, domain)
    return resolves(probe)


# ------------------------------------------------------------
# 证书透明日志
# ------------------------------------------------------------
def crt_sh_subdomains(domain, client=None):
    """从 crt.sh 拉取证书里出现过的子域。

    注意：crt.sh 是第三方被动数据源，**不属于目标 scope**。
    因此这里必须用独立请求发出（裸 requests），不能走 client.get ——
    client 的 scope 守卫会因 crt.sh 不在授权范围内而直接返回
    out_of_scope，导致子域枚举静默返回空集（原实现的真实后果）。
    """
    out = set()
    url = CRT_URL.format(domain=domain)
    text = ""
    try:
        import requests
        text = requests.get(url, timeout=20,
                            headers={"User-Agent": "Mozilla/5.0 (bt-src-hunter recon)"}).text
    except Exception as e:
        log.warning("crt.sh 查询失败: %s", e)
        return []
    try:
        data = json.loads(text)
    except Exception:
        # 有些返回是分片 JSON，用正则兜底
        for m in re.finditer(r"[A-Za-z0-9_\-.]+\.%s" % re.escape(domain), text):
            out.add(m.group(0).lower())
        return sorted(out)
    for item in data:
        for name in (item.get("name_value") or "").split("\n"):
            name = name.strip().lower().lstrip("*.")
            if name.endswith("." + domain) or name == domain:
                if "*" not in name:
                    out.add(name)
    return sorted(out)


# ------------------------------------------------------------
# 子域爆破
# ------------------------------------------------------------
def bruteforce_subdomains(domain, client, words=None, max_workers=10):
    """字典爆破子域。用 DNS 解析判断存活（不发 HTTP，最轻量）。

    DNS 查询是纯 I/O 等待，串行几百个词会非常慢；这里用线程池并发
    （max_workers 真正生效），并发度上限 32 防止打爆本地 resolver。
    """
    words = words or _dm.merged_subdomain_words()
    found = set()
    wildcard = has_wildcard(domain)
    if wildcard:
        log.warning("%s 存在泛解析，爆破结果需人工复核", domain)
    workers = max(1, min(int(max_workers or 10), 32))
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(dns_query, "%s.%s" % (w, domain), "A"): w
                    for w in words}
            for fu in as_completed(futs):
                try:
                    if fu.result():
                        found.add("%s.%s" % (futs[fu], domain))
                except Exception:
                    pass
    except Exception:
        # 线程池不可用时回退串行
        for w in words:
            host = "%s.%s" % (w, domain)
            if dns_query(host, "A"):
                found.add(host)
    return sorted(found)


# ------------------------------------------------------------
# 子域接管
# ------------------------------------------------------------
def check_takeover(host, client):
    """CNAME 指向已知易接管服务，且响应命中特征字符串 → 疑似可接管。"""
    cnames = dns_query(host, "CNAME")
    if not cnames:
        return None
    target = cnames[0].rstrip(".").lower()
    for suffix, sign in dicts.TAKEOVER_SIGNS:
        if target.endswith(suffix):
            for scheme in ("http", "https"):
                r = client.get("%s://%s/" % (scheme, host),
                               purpose="recon:takeover")
                if r.status and sign.lower() in (r.text or "").lower():
                    return {
                        "host": host, "cname": target, "sign": sign,
                        "severity": "high",
                        "title": "子域接管（%s → %s）" % (host, suffix),
                        "evidence": r.dump(1024),
                    }
    return None


# ------------------------------------------------------------
# 主入口
# ------------------------------------------------------------
def enumerate_subdomains(domain, client, db=None, config=None):
    """返回去重后的子域列表，并写入资产库；顺带做子域接管检测。"""
    domain = _norm_host(domain)
    _t0 = time.time()          # round81 B4：枚举总耗时（含 crt.sh + 字典爆破）
    result = set([domain])
    result.update(crt_sh_subdomains(domain, client))

    use_brute = True
    if config is not None:
        use_brute = bool(config.get("scan.subdomain_bruteforce", True))
    if use_brute:
        # 仅对已授权域名的子域做爆破；scope 会在 HTTP 层再次拦截
        result.update(bruteforce_subdomains(domain, client))

    # 去掉明显无效项：只保留真正的子域（h == domain 或 h 以 "." + domain 结尾），
    # 避免 evil<domain> 这类"同后缀异域"被当成子域带进后续扫描。
    cleaned = sorted(h for h in result
                     if (h == domain or h.endswith("." + domain)) and "*" not in h)
    log.info("子域枚举完成：%s → %d 个（耗时 %.1fs）", domain, len(cleaned),
             time.time() - _t0)

    # 子域接管检测（此前 check_takeover 定义了却从未被调用，属死代码）。
    # 只对除主域外的子域做，且受配置开关控制；命中即落一条高危 finding。
    takeovers = []
    check_on = True
    if config is not None:
        check_on = bool(config.get("scan.subdomain_takeover", True))
    _n_probe = max(0, len(cleaned) - 1)   # 主域自身不查 CNAME（见循环内 continue）
    _i = 0
    _last_beat = time.time()

    def _beat():
        """子域接管检测的进度心跳（round81 B3）。

        实机反馈：枚举完成之后长时间一行不吐，界面无法区分「在干活」与
        「卡死」。这里用「每 20 个子域」+「每 15 秒」双闸门、先到先打：
        子域少但每个都慢时靠时间触发，子域多但每个都快时靠计数触发。
        纯日志，不改控制流、不新增任何出网请求。
        """
        nonlocal _last_beat
        _now = time.time()
        if not (_i % 20 == 0 or _i == _n_probe or (_now - _last_beat) >= 15.0):
            return
        _last_beat = _now
        log.info("[接管检测] %d/%d 已完成（命中 %d）", _i, _n_probe,
                 len(takeovers))

    if check_on and client is not None:
        log.info("[接管检测] 开始：%d 个子域逐个查 CNAME（串行，预计 %.0fs 起，"
                 "DNS 慢时更久）", _n_probe, _n_probe * 0.3)
        for h in cleaned:
            if h == domain:
                continue
            try:
                hit = check_takeover(h, client)
            except Exception as e:
                log.warning("子域接管检测异常 %s: %s", h, e)
                _i += 1
                _beat()
                continue
            _i += 1
            _beat()
            if hit:
                takeovers.append(hit)
                log.warning("[接管] %s → %s", h, hit.get("cname"))
                if db is not None:
                    try:
                        db.add_finding(
                            target=domain, host=h, url="http://%s/" % h,
                            vuln_type="子域接管", severity="high",
                            confidence="medium",
                            title=hit.get("title", "子域接管"),
                            description="CNAME 指向 %s，响应命中特征 %s，疑似可被第三方接管。"
                                        % (hit.get("cname"), hit.get("sign")),
                            request="", response="", payload="", cvss="",
                            fix="删除失效的 CNAME 记录，或在对应第三方服务上重新认领该名称。",
                            extra={"verified": False, "evidence": hit.get("evidence", "")})
                    except Exception as e:
                        log.warning("接管结果落库失败 %s: %s", h, e)

    if _n_probe > 0:
        log.info("[接管检测] 完成：%d/%d 已查，命中 %d 个",
                 _i, _n_probe, len(takeovers))
    log.info("子域处理完成：%s 共 %d 个子域（含主域），接管检测%s，即将并入扫描队列",
             domain, len(cleaned),
             "已做" if (check_on and client is not None) else "未做")
    if db is not None:
        for h in cleaned:
            db.add_asset(host=h, url="", source="recon")
    return cleaned
