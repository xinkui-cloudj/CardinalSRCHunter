# -*- coding: utf-8 -*-
"""声明式模板引擎（借鉴 nuclei 的 YAML 模板 + matcher 范式）。

设计目标
--------
把"某路径存在 + 某特征串命中"这类**纯声明式**检测从 Python 代码里搬出来，
放进 `templates/*.yaml`。新增一类检测 = 新增一个 YAML 文件，不动引擎代码。

与 nuclei 的差异（刻意的）
--------------------------
1) **只用本地模板**。不做远程模板仓库拉取——本项目所有流量必须经
   `core/httpclient.HttpClient.send()`，远程模板会引入不可审计的检测逻辑。
2) **method 白名单**。模板只允许 GET / HEAD / POST，且 POST 仅用于
   "表单提交式探测"。PUT/DELETE/PATCH 一律拒绝加载，避免模板作者写出
   破坏性请求。
3) **状态码不做唯一判据**。只带 status matcher 的模板必须与软 404 基线
   不同质才计数，否则整站 200/403 的站点会把每条模板全部命中
   （这正是 `check_cn_components` 缺陷 A 的翻版）。
4) **DSL 不用 eval**。自己写白名单表达式求值器，模板里写不出任意代码。

模板结构（简化版 nuclei）
-------------------------
    id: git-config-exposed
    info:
      name: Git 配置泄露
      severity: high
      description: 站点 .git/config 可读，源码与远端地址可能泄露
      tags: [exposure, git]
      reference: https://example.com/ref
    http:
      - method: GET
        path:
          - "{{BaseURL}}/.git/config"
        matchers-condition: and
        matchers:
          - type: status
            status: [200]
          - type: word
            part: body
            words: ["[core]", "repositoryformatversion"]
            condition: and
          - type: regex
            part: body
            regex: ["(?i)\\[core\\]"]
          - type: dsl
            dsl:
              - "contains(body, '[core]')"
              - "status_code == 200"

matcher 支持字段
----------------
- type: status  → status: [200] 或 status: 200
- type: word    → words: [...]  part: body|header|all  condition: and|or
- type: regex   → regex: [...]  part: body|header|all  condition: and|or
- type: dsl     → dsl: [...]    condition: and|or（默认 or）

`matchers-condition` 默认 or（与 nuclei 一致）；单个 matcher 内
`condition` 默认 or。

输出契约
--------
每条命中都经 `vulnchecks._finding()` 构造，字段与内置检测器完全一致，
因此可以直接进 `pending`，由 `poc.upgrade()` 升级、由 `_persist()` 去重落库。
"""
import os
import re

from core import logger
from modules import probe
from modules.vulnchecks import _finding

log = logger.get("bt.templates")

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

# ---- 安全白名单 ----
ALLOWED_METHODS = ("GET", "HEAD", "POST")
ALLOWED_MATCHER_TYPES = ("status", "word", "regex", "dsl")
ALLOWED_PARTS = ("body", "header", "all")
ALLOWED_SEVERITY = ("critical", "high", "medium", "low", "info")

# 模板 id 允许字符（同时用于目录内文件名与日志，防路径穿越）
_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_\-]{1,63}$")

# 单模板最多跑几条 path（防某条模板把预算吃光）
MAX_PATHS_PER_TEMPLATE = 6

_TEMPLATE_CACHE = {"dir": None, "items": None}


# ============================================================
# 加载与校验
# ============================================================
def templates_dir():
    """模板目录：<项目根>/templates。"""
    from core import config as cfg
    return os.path.join(cfg.ROOT, "templates")


def _norm_list(v):
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v if str(x).strip()]
    return [str(v)]


def _match_cond(v, default="or"):
    s = str(v or default).strip().lower()
    return s if s in ("and", "or") else default


def validate_template(t):
    """校验单个模板，返回 (ok, reason)。不通过的直接不加载、不执行。"""
    if not isinstance(t, dict):
        return False, "模板不是映射"
    tid = str(t.get("id") or "").strip()
    if not _ID_RE.match(tid):
        return False, "id 非法或缺失（须小写字母/数字/下划线/中划线）"
    info = t.get("info")
    if not isinstance(info, dict):
        return False, "缺少 info 段"
    if not str(info.get("name") or "").strip():
        return False, "info.name 缺失"
    sev = str(info.get("severity") or "").strip().lower()
    if sev not in ALLOWED_SEVERITY:
        return False, "info.severity 非法：%s" % sev
    reqs = t.get("http")
    if not isinstance(reqs, list) or not reqs:
        return False, "缺少 http 段"
    for i, req in enumerate(reqs):
        if not isinstance(req, dict):
            return False, "http[%d] 不是映射" % i
        method = str(req.get("method") or "GET").strip().upper()
        if method not in ALLOWED_METHODS:
            return False, "http[%d] 方法 %s 不在白名单（只允许 %s）" % (
                i, method, "/".join(ALLOWED_METHODS))
        paths = _norm_list(req.get("path"))
        if not paths:
            return False, "http[%d] 缺少 path" % i
        if len(paths) > MAX_PATHS_PER_TEMPLATE:
            return False, "http[%d] path 超过 %d 条" % (i, MAX_PATHS_PER_TEMPLATE)
        mats = req.get("matchers")
        if not isinstance(mats, list) or not mats:
            return False, "http[%d] 缺少 matchers" % i
        for j, m in enumerate(mats):
            if not isinstance(m, dict):
                return False, "http[%d].matchers[%d] 不是映射" % (i, j)
            mt = str(m.get("type") or "").strip().lower()
            if mt not in ALLOWED_MATCHER_TYPES:
                return False, "matcher 类型非法：%s" % mt
            part = str(m.get("part") or "body").strip().lower()
            if mt in ("word", "regex") and part not in ALLOWED_PARTS:
                return False, "matcher part 非法：%s" % part
            if mt == "status" and not _norm_list(m.get("status")):
                return False, "status matcher 缺少 status"
            if mt == "word" and not _norm_list(m.get("words")):
                return False, "word matcher 缺少 words"
            if mt == "regex" and not _norm_list(m.get("regex")):
                return False, "regex matcher 缺少 regex"
            if mt == "dsl" and not _norm_list(m.get("dsl")):
                return False, "dsl matcher 缺少 dsl"
            if mt == "regex":
                for pat in _norm_list(m.get("regex")):
                    try:
                        re.compile(pat)
                    except re.error as e:
                        return False, "正则编译失败 %r: %s" % (pat, e)
    return True, ""


def load_templates(tpl_dir=None, force=False):
    """加载并校验 templates/*.yaml，返回模板列表。

    单文件坏掉只跳过该文件，不影响其余模板（一个 YAML 写错不该让整个
    模板引擎停摆）。结果带目录缓存，目录 mtime 变化时自动失效。
    """
    tpl_dir = tpl_dir or templates_dir()
    if yaml is None:
        log.warning("PyYAML 未安装，模板引擎停用")
        return []
    try:
        stamp = os.path.getmtime(tpl_dir)
    except OSError:
        stamp = None
    if (not force and _TEMPLATE_CACHE["items"] is not None
            and _TEMPLATE_CACHE["dir"] == tpl_dir
            and _TEMPLATE_CACHE.get("stamp") == stamp):
        return _TEMPLATE_CACHE["items"]

    items = []
    if stamp is not None:
        for fn in sorted(os.listdir(tpl_dir)):
            if not fn.lower().endswith((".yaml", ".yml")):
                continue
            path = os.path.join(tpl_dir, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    docs = list(yaml.safe_load_all(f))
            except Exception as e:
                log.warning("[模板跳过] %s 解析失败: %s", fn, e)
                continue
            for t in docs:
                if t is None:
                    continue
                ok, reason = validate_template(t)
                if not ok:
                    log.warning("[模板跳过] %s: %s", fn, reason)
                    continue
                t["_file"] = fn
                items.append(t)
    _TEMPLATE_CACHE.update({"dir": tpl_dir, "items": items, "stamp": stamp})
    log.info("模板引擎：加载 %d 条模板（%s）", len(items), tpl_dir)
    return items


# ============================================================
# DSL 求值（白名单，不用 eval）
# ============================================================
_NUM_RE = re.compile(r"^(-?\d+)$")
_CMP_RE = re.compile(r"^status_code\s*(==|!=|>=|<=|>|<)\s*(-?\d+)$")
_LEN_RE = re.compile(r"^len\(\s*(body|header|all)\s*\)\s*(==|!=|>=|<=|>|<)\s*(-?\d+)$")
_CONTAINS_RE = re.compile(
    r"^contains\(\s*(body|header|all)\s*,\s*(['\"])(.*?)\2\s*\)$", re.S)
_REGEX_RE = re.compile(
    r"^regex\(\s*(['\"])(.*?)\1\s*,\s*(body|header|all)\s*\)$", re.S)


def _pick(part, ctx):
    return ctx.get(part, "")


def _cmp(a, op, b):
    if op == "==":
        return a == b
    if op == "!=":
        return a != b
    if op == ">=":
        return a >= b
    if op == "<=":
        return a <= b
    if op == ">":
        return a > b
    if op == "<":
        return a < b
    return False


def _eval_atom(expr, ctx):
    """求值单个原子表达式。无法识别的语法一律返回 False（宁可不报）。"""
    m = _CMP_RE.match(expr)
    if m:
        return _cmp(int(ctx["status_code"]), m.group(1), int(m.group(2)))
    m = _LEN_RE.match(expr)
    if m:
        return _cmp(len(_pick(m.group(1), ctx)), m.group(2), int(m.group(3)))
    m = _CONTAINS_RE.match(expr)
    if m:
        return m.group(3) in _pick(m.group(1), ctx)
    m = _REGEX_RE.match(expr)
    if m:
        try:
            return re.search(m.group(2), _pick(m.group(3), ctx)) is not None
        except re.error:
            return False
    if _NUM_RE.match(expr):      # 裸数字：非 0 即真
        return int(expr) != 0
    return False


def _eval_dsl(expr, ctx):
    """支持 `!` 取反、`&&`、`||`（|| 优先级低于 &&）。不处理括号嵌套。"""
    expr = str(expr or "").strip()
    if not expr:
        return False
    if expr.startswith("!"):
        return not _eval_dsl(expr[1:], ctx)
    if "||" in expr:
        return any(_eval_dsl(p, ctx) for p in expr.split("||"))
    if "&&" in expr:
        return all(_eval_dsl(p, ctx) for p in expr.split("&&"))
    return _eval_atom(expr, ctx)


# ============================================================
# matcher 求值
# ============================================================
def _resp_ctx(resp):
    headers = resp.headers or {}
    htxt = "\n".join("%s: %s" % (k, v) for k, v in headers.items())
    body = resp.text or ""
    return {
        "status_code": int(resp.status or 0),
        "body": body,
        "header": htxt,
        "all": htxt + "\n" + body,
    }


def _match_one(m, ctx):
    mt = str(m.get("type") or "").strip().lower()
    cond = _match_cond(m.get("condition"), "or")
    if mt == "status":
        codes = []
        for s in _norm_list(m.get("status")):
            if _NUM_RE.match(s.strip()):
                codes.append(int(s.strip()))
        return int(ctx["status_code"]) in codes
    if mt == "word":
        hay = _pick(str(m.get("part") or "body").lower(), ctx).lower()
        words = [w.lower() for w in _norm_list(m.get("words"))]
        hits = [w for w in words if w in hay]
        return (len(hits) == len(words)) if cond == "and" else bool(hits)
    if mt == "regex":
        hay = _pick(str(m.get("part") or "body").lower(), ctx)
        flags = re.I if m.get("case-insensitive", True) else 0
        hits = []
        for pat in _norm_list(m.get("regex")):
            try:
                if re.search(pat, hay, flags):
                    hits.append(pat)
            except re.error:
                continue
        return (len(hits) == len(_norm_list(m.get("regex")))) \
            if cond == "and" else bool(hits)
    if mt == "dsl":
        exprs = _norm_list(m.get("dsl"))
        hits = [_eval_dsl(e, ctx) for e in exprs]
        return all(hits) if cond == "and" else any(hits)
    return False


def _match_all(req, resp, ctx):
    mats = req.get("matchers") or []
    cond = _match_cond(req.get("matchers-condition"), "or")
    results = [_match_one(m, ctx) for m in mats]
    return all(results) if cond == "and" else any(results)


def _status_may_decide(req):
    """判断命中是不是可能被 status matcher 单独决定。

    r88：「status OR word」这类模板里，泛解析会让 status=200 单条成立，
    从而绕过 _status_only 的软404基线比对。只要命中条件为 or
    且存在 status matcher，就可能是 status 单独命中，必须一并过基线。
    """
    mats = req.get("matchers") or []
    if _match_cond(req.get("matchers-condition"), "or") != "or":
        return False
    for m in mats:
        if str(m.get("type") or "").strip().lower() == "status":
            return True
    return False

def _status_only(req):
    """模板是否"只靠状态码"判定——这类命中必须再与软 404 基线比对。"""
    for m in req.get("matchers") or []:
        if str(m.get("type") or "").lower() != "status":
            return False
    return True


# ============================================================
# 执行
# ============================================================
def _expand(path, base_url, host):
    p = str(path)
    p = p.replace("{{BaseURL}}", base_url.rstrip("/"))
    p = p.replace("{{RootURL}}", base_url.rstrip("/"))
    p = p.replace("{{Hostname}}", host or "")
    p = p.replace("{{Host}}", host or "")
    if p.startswith("http://") or p.startswith("https://"):
        return p
    if not p.startswith("/"):
        p = "/" + p
    return base_url.rstrip("/") + p


def run_templates(base_url, client, host=None, templates=None,
                  max_templates=None, max_requests=None):
    """对单主机跑模板引擎，返回 findings 列表（`_finding` 契约）。

    - 所有请求经 client.send()，自动受 scope 闸与限速约束；
    - 软 404 基线只取一次，供"仅状态码模板"复核；
    - 单模板异常只跳过该模板，不中断整体扫描。
    """
    if not base_url:
        return []
    items = templates if templates is not None else load_templates()
    if not items:
        return []
    if max_templates:
        items = items[:int(max_templates)]

    base = None
    try:
        base = probe.soft404_baseline(base_url, client)
    except Exception:
        base = None
    base_ok = False
    try:
        base_ok = probe.baseline_usable(base)
    except Exception:
        base_ok = False

    findings = []
    used = 0
    for t in items:
        if max_requests and used >= int(max_requests):
            log.info("模板引擎达请求上限 %d，停止", int(max_requests))
            break
        info = t.get("info") or {}
        sev = str(info.get("severity") or "info").strip().lower()
        name = str(info.get("name") or t.get("id"))
        tid = str(t.get("id"))
        desc = str(info.get("description") or name)
        ref = str(info.get("reference") or "")
        tags = info.get("tags") or []
        if isinstance(tags, str):
            tags = [tags]
        try:
            for req in t.get("http") or []:
                method = str(req.get("method") or "GET").strip().upper()
                for p in _norm_list(req.get("path"))[:MAX_PATHS_PER_TEMPLATE]:
                    if max_requests and used >= int(max_requests):
                        break
                    url = _expand(p, base_url, host)
                    used += 1
                    try:
                        r = client.send(method, url, purpose="tpl:%s" % tid)
                    except Exception as e:
                        log.warning("模板 %s 请求异常 %s: %s", tid, url, e)
                        continue
                    if not r or not r.status:
                        continue
                    ctx = _resp_ctx(r)
                    if not _match_all(req, r, ctx):
                        continue
                    # r88: 泛解析防护。
                    # 旧逻辑只在「仅状态码」模板上做软404比对，但「status OR word」类模板会绕过这道门：
                    # 泛解析把任意路径都返200，status 单条成立即命中，实测 lanli.cc 一条模板就垃了21条误报。
                    if _status_only(req) or _status_may_decide(req):
                        # r88: base_ok=False 时旧逻辑直接 continue 会连真漏洞一起丢掉；
                        # 泛解析站点上基线一定可用，所以这里只在基线可用时比对软404，
                        # 基线不可用时退回按原样判定（不静默丢弃全部命中）。
                        if base_ok:
                            try:
                                if probe.is_soft404(r, base):
                                    continue
                            except Exception:
                                pass
                    findings.append(_finding(
                        name, sev, "medium", url,
                        "%s（模板 %s，HTTP %d）%s"
                        % (desc, tid, r.status,
                           ("  参考：%s" % ref) if ref else ""),
                        request=(r.raw_request or ""),
                        response=r.dump(500), payload="",
                        cvss="", fix=str(info.get("fix") or
                                         "按厂商公告修复；下线非必要接口并加访问控制。"),
                        method=method))
        except Exception as e:
            log.warning("模板 %s 执行异常: %s", tid, e)
            continue
    if findings:
        log.info("模板引擎命中 %d 条（%s）", len(findings), base_url)
    return findings


def stats():
    """给报告/界面用：模板数量与 id 清单。"""
    items = load_templates()
    return {"count": len(items), "ids": [t.get("id") for t in items]}
