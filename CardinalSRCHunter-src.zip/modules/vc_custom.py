# -*- coding: utf-8 -*-
"""AI 自造 payload 通道（round73 选项2）。

定位
----
原有参数级检测（sqli / xss）的 payload 全部来自 ``core.dicts``：
SQLi 20 条、XSS 11 条、跳转 9 条、SSRF 11 条 —— 共 51 条，写死在代码里。
AI 即使接管扫描，也只能决定"打哪个参数"，换不了"用什么打"。

本模块给这条链开一个**可选**入口：AI 自己造 payload 传进来，检测工具
负责发出去 + 判响应。判定口径与内置通道完全一致，只多两条硬上限：

    CUSTOM_MAX        = 12   单次最多接受 12 条自定义 payload
    CUSTOM_PARAM_MAX  = 12   最多覆盖 12 个参数

出网仍走调用方传入的同一个 ``client``（同限速器、同 scope、同计数），
本模块不建连接、不写文件、不落库。

红线
----
1. 纯加法：不传 ``extra_payloads`` 时，调用方行为与改动前逐字一致；
2. 不做判定以外的动作：只发请求、只产出 finding，不写 findings 表；
3. 不绕过闸门：能否被调用仍由 ``tool_registry`` 的 gate / scope 决定。
"""
import re
import time

from core import dicts

# 自定义 payload 上限（硬上限，控请求爆炸）
CUSTOM_MAX = 12
# 自定义 payload 覆盖的参数上限
CUSTOM_PARAM_MAX = 12


def _inject_query(url, param, payload):
    """把 payload 注入到 URL 的指定 query 参数（保留其它参数）。"""
    from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
    u = urlparse(url)
    q = dict(parse_qsl(u.query, keep_blank_values=True))
    q[param] = payload
    return urlunparse((u.scheme, u.netloc, u.path, u.params,
                       urlencode(q), u.fragment))


def _inject_form(data, param, payload):
    """把 payload 注入到 POST 表单字段（浅拷贝，不改原 dict）。"""
    d = dict(data or {})
    d[param] = payload
    return d


def custom_list(extra_payloads):
    """清洗 + 截断 AI 递进来的 payload 列表（空值丢弃，硬顶 CUSTOM_MAX）。"""
    out = []
    for p in (extra_payloads or []):
        s = str(p or "").strip()
        if s:
            out.append(s[:200])
        if len(out) >= CUSTOM_MAX:
            break
    return out


def _time_hit(elapsed, base_elapsed, delay):
    """与内置时间盲注同口径的慢响应判定（复测用）。"""
    return elapsed >= delay * 0.7 and elapsed > base_elapsed * 3


def check_sqli_custom(url, client, params, method, body, extra_payloads,
                      delay, base_elapsed, finding):
    """AI 自造 SQLi payload 通道。

    ``finding`` 是调用方传进来的 ``_finding`` 构造器（避免循环 import）。
    报错注入特征命中即报（最多 1 条）；时间盲注需再复测一次也偏慢才报
    （最多 1 条）。两类合计最多 2 条 finding。
    """
    out = []
    pls = custom_list(extra_payloads)
    if not pls or not params:
        return out
    time_hit = False
    err_hit = False
    for p in params[:CUSTOM_PARAM_MAX]:
        for payload in pls:
            if err_hit and time_hit:
                return out
            if method == "GET":
                r = client.get(_inject_query(url, p, payload),
                               purpose="sqli:custom")
            else:
                r = client.post(url, data=_inject_form(body, p, payload),
                                purpose="sqli:custom")
            if not r.status:
                continue
            # --- 报错注入：特征命中即判定（只报一条）---
            if not err_hit:
                hit = None
                for sign in dicts.SQLI_ERROR_SIGNS:
                    if re.search(sign, r.text or "", re.I):
                        hit = sign
                        break
                if hit:
                    err_hit = True
                    out.append(finding(
                        "SQL 报错注入", "high", "medium", url,
                        "参数 %s 注入 AI 自造 payload %s 后响应出现数据库报错特征：%s"
                        % (p, payload, hit),
                        request=(r.raw_request or ""), response=r.dump(600),
                        payload=payload, param=p, method=method, body=body,
                        cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:N/VA:N",
                        fix="统一异常处理，禁止把数据库报错回显到前端；使用参数化查询。",
                        kind="sqli_error"))
                    continue
            if time_hit:
                continue
            # --- 时间盲注：复测一次，也偏慢才判定 ---
            if method == "GET":
                pass  # r88 缺陷5：不再用墙钟，改用 Response.elapsed
                r2 = client.get(_inject_query(url, p, payload),
                                purpose="sqli:custom:time")
                e = float(getattr(r2, "elapsed", 0) or 0)
            else:
                pass
                r2 = client.post(url, data=_inject_form(body, p, payload),
                                 purpose="sqli:custom:time")
                e = float(getattr(r2, "elapsed", 0) or 0)
            if r2.status and _time_hit(e, base_elapsed, delay):
                time_hit = True
                out.append(finding(
                    "SQL 时间盲注", "critical", "high", url,
                    "参数 %s 注入 AI 自造 payload %s 后响应延迟 %.1fs（基线 %.1fs），疑似时间盲注。"
                    % (p, payload, e, base_elapsed),
                    request=(r2.raw_request or ""), response=r2.dump(600),
                    payload=payload, param=p, method=method, body=body,
                    cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H",
                    fix="对参数使用参数化查询（PreparedStatement），禁止字符串拼接 SQL。"))
    return out


def check_xss_custom(url, client, params, method, body, extra_payloads, finding):
    """AI 自造 XSS payload 通道。判定口径与内置通道一致：payload 未编码地
    出现在响应体里即命中。"""
    out = []
    pls = custom_list(extra_payloads)
    if not pls or not params:
        return out
    for p in params[:CUSTOM_PARAM_MAX]:
        for payload in pls:
            if method == "GET":
                r = client.get(_inject_query(url, p, payload),
                               purpose="xss:custom")
            else:
                r = client.post(url, data=_inject_form(body, p, payload),
                                purpose="xss:custom")
            if not r.status:
                continue
            if payload in (r.text or ""):
                idx = r.text.find(payload)
                ctx = r.text[max(0, idx - 80):idx + len(payload) + 80]
                out.append(finding(
                    "反射型 XSS", "medium", "high", url,
                    "参数 %s 对 AI 自造 payload 原样反射（未做实体编码）。上下文片段：\n%s"
                    % (p, ctx),
                    request=(r.raw_request or ""), response=r.dump(600),
                    payload=payload, param=p, method=method, body=body,
                    cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:L/VI:L/VA:N",
                    fix="对输出做上下文相关编码（HTML/JS/属性）；启用 CSP。"))
                break
    return out
