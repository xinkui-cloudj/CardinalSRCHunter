# -*- coding: utf-8 -*-
"""漏洞检测器集合。

原则：**无危害验证**。
- SQL 注入只用时间盲注 / 报错回显证明，绝不 UNION 拖库；
- XSS 只验证反射与可执行上下文，不构造蠕虫载荷；
- SSRF 只回连用户自有 OOB 域名或内网探针地址；
- 弱口令只做少量常见凭据尝试，绝不字典轰炸（避免锁号 + DoS）。
"""
import difflib
import re
import time
import zlib

from core import dicts, logger
from core import dict_merge as _dm
from modules import probe

log = logger.get("bt.vuln")

# ------------------------------------------------------------
# 工具
# ------------------------------------------------------------
# round89 FIX-14：两个反向修正，否则会造出大量误报。
#   1) 这些判定都是「两个响应是不是同样」，而 SequenceMatcher.ratio() 对
#      「长文本里有一小段差异」非常敏感，两个同样的 nginx 错误页只要
#      填充注释条数不同，ratio 就可能跌到 0.83 以下，被当成「响应可区分」。
#      改用「去白化（去注释 + 折叠空白）后的等价性 / 整体相似度」，文件夹式
#      错误页变异不再被当成“服务端区分了用户”。
#   2) 错误页不是业务响应：405/501 等「端点不接受该方法」的状态码下，
#      服务端根本没跑用户名判定，必须直接排除。
_COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
_WS_RE = re.compile(r"\s+")
# 「端点不接受该方法 / 未实现」的状态码：这些响应不能作为任何语义型判定的证据。
_NON_BUSINESS_STATUS = (404, 405, 501, 505)


def _normalize_body(t):
    """去掉注释与所有空白，抹平“填充注释 / 换行差异”。"""
    return _WS_RE.sub("", _COMMENT_RE.sub("", (t or "")[:8000]))


def _body_similarity(a, b):
    """两段响应体的相似度（已白化）。判定口径不变，只把文件夹式差异归零。"""
    na, nb = _normalize_body(a), _normalize_body(b)
    if na == nb:
        return 1.0
    if not na and not nb:
        return 1.0
    return difflib.SequenceMatcher(None, na[:4000], nb[:4000]).ratio()


def _is_non_business(status):
    """该状态码是否不可能携带“业务判定”（错误页）。"""
    try:
        return int(status) in _NON_BUSINESS_STATUS
    except Exception:
        return False


# round89 FIX-15：**对照名**（admin 这类“已存在名”）落到这些码时，只能说明
# 「这条请求被拒 / 被限流 / 后端炸了」，不能说明「这个用户名存在」。
# 实测口径：不存在名 200 正常业务页，对照名 403(WAF) / 429(限流) / 5xx(后端故障)
# —— 原逻辑只看 `rc.status == r1.status` 是否相等，不等就直接产 findings，
# 等于把基础设施故障当成漏洞（admin 这个常见词最容易触发风控/黑名单）。
# 401 特意**不列入**：登录接口普遍用 401 表达“凭据无效”，
# 「不存在名 200 错误文案 / 对照名 401」确实可能是合法信号，不能一刀切。
_CONTROL_UNRELIABLE_STATUS = (403, 429, 500, 502, 503, 504,
                              521, 522, 523, 524)


def _is_control_unreliable(status):
    """对照名的状态码是否属于“请求被拒/服务端故障”这类不可信情形。"""
    try:
        return int(status) in _CONTROL_UNRELIABLE_STATUS
    except Exception:
        return False


def _inject_query(url, param, payload):
    """把 payload 注入到 URL 的指定 query 参数（保留其它参数）。"""
    from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
    u = urlparse(url)
    q = dict(parse_qsl(u.query, keep_blank_values=True))
    q[param] = payload
    return urlunparse((u.scheme, u.netloc, u.path, u.params,
                       urlencode(q), u.fragment))


def _inject_form(data, param, payload):
    d = dict(data or {})
    d[param] = payload
    return d

def _to_path(t, base_url=""):
    """把 found_dirs 里的条目统一成"以 / 开头的路径"（缺陷修复 round19）。

    修复的真实缺陷：`probe.dir_bruteforce` 返回的 `d["url"]` 是**完整 URL**
    （如 http://host/admin），而 check_backup_files / check_directory_listing
    原来按 `t.startswith("/")` 判断，完整 URL 会被二次拼接成
    `http://host/http://host/admin` —— 导致 **found_dirs 全程失效**（既探不到
    真备份，也探不到真目录列表），只有硬编码的兜底路径在工作。

    这里统一剥离 scheme / netloc，只保留 path（含 query）；传入已是路径的
    原样返回，保证向后兼容。
    """
    t = (t or "").strip()
    if not t:
        return ""
    if t.startswith("http://") or t.startswith("https://"):
        from urllib.parse import urlparse
        u = urlparse(t)
        t = u.path or "/"
        if u.query:
            t += "?" + u.query
    if not t.startswith("/"):
        t = "/" + t
    return t


def _param_candidates(url, body=None):
    """从 URL query 与表单体里提取可注入参数名。"""
    from urllib.parse import urlparse, parse_qsl
    names = [k for k, _ in parse_qsl(urlparse(url).query, keep_blank_values=True)]
    if isinstance(body, dict):
        names += [k for k in body.keys()]
    return sorted(set(names))


# ------------------------------------------------------------
# 1. SQL 注入
# ------------------------------------------------------------
def check_sqli(url, client, params=None, method="GET", body=None, delay=5,
               extra_payloads=None):
    """时间盲注 + 报错注入检测。

    判定逻辑：
    - 先测一次基线响应时间；
    - 注入 SLEEP(delay)，若耗时显著增加（>= delay*0.7 且超过基线 3 倍）→ 疑似时间盲注；
    - 注入单引号，若响应出现数据库报错特征 → 报错注入。
    """
    findings = []
    params = params or _param_candidates(url, body)
    if not params:
        return findings

    # 基线：多次采样取中位数，抑制首请求冷连接抖动（round24 误报修复）
    _base_samples = []
    for _i in range(3):
        base = client.get(url, purpose="sqli:baseline") if method == "GET" \
            else client.post(url, data=body, purpose="sqli:baseline")
        if not base.status:
            break
        _base_samples.append(float(getattr(base, "elapsed", 0) or 0))
    if not _base_samples:
        return findings
    base_elapsed = sorted(_base_samples)[len(_base_samples) // 2]
    # r88 缺陷5：时间盲注必须用 Response.elapsed（纯网络耗时）判定。
    # 旧逻辑用墙钟 time.time() 包裹 client.get()，把 rate.wait() 的本地限速
    # 排队时间也算了进去——并发8线程共享12令牌/秒时排队可累积数秒，
    # 静态页也会被量成 7.2s，从而把静态 200 页误报成 SQL 时间盲注。

    def _time_probe(_p, _payload):
        # r88 缺陷5：返回纯网络耗时（Response.elapsed），不含本地限速排队。
        if method == "GET":
            _r = client.get(_inject_query(url, _p, _payload), purpose="sqli:time")
            return _r, float(getattr(_r, "elapsed", 0) or 0)
        _r = client.post(url, data=_inject_form(body, _p, _payload),
                         purpose="sqli:time")
        return _r, float(getattr(_r, "elapsed", 0) or 0)

    def _looks_slow(_elapsed):
        return _elapsed >= delay * 0.7 and _elapsed > base_elapsed * 3

    for p in params[:12]:
        # --- 时间盲注（多次复测确认，抑制单次抖动误报） ---
        for tpl, dbtype in dicts.SQLI_TIME_PAYLOADS:
            payload = tpl.format(d=delay)
            r, elapsed = _time_probe(p, payload)
            if not r.status:
                continue
            if not _looks_slow(elapsed):
                continue
            # 首次偏慢：再复测 2 次，至少 2/3 次都慢才判定命中
            _slow = 1
            _slow_r = r
            _slow_e = elapsed
            for _j in range(2):
                r2, e2 = _time_probe(p, payload)
                if r2.status and _looks_slow(e2):
                    _slow += 1
                    _slow_r = r2
                    _slow_e = e2
            if _slow < 2:
                log.info("时间盲注复测未确认(%d/3)，跳过：%s param=%s",
                         _slow, url, p)
                continue
            findings.append(_finding(
                "SQL 时间盲注", "critical", "high", url,
                "参数 %s 注入 %s 后响应延迟 %.1fs（基线 %.1fs，复测 %d/3 次确认），疑似时间盲注。"
                % (p, dbtype, _slow_e, base_elapsed, _slow),
                request=(_slow_r.raw_request or ""), response=_slow_r.dump(600),
                payload=payload, cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H",
                fix="对参数使用参数化查询（PreparedStatement），禁止字符串拼接 SQL；"
                    "对输入做白名单校验。", param=p, method=method, body=body))
            break

        # --- 报错注入 ---
        for payload in dicts.SQLI_ERROR_PAYLOADS:
            if method == "GET":
                e_url = _inject_query(url, p, payload)
                r = client.get(e_url, purpose="sqli:error")
            else:
                r = client.post(url, data=_inject_form(body, p, payload),
                                purpose="sqli:error")
            if not r.status:
                continue
            for sign in dicts.SQLI_ERROR_SIGNS:
                if re.search(sign, r.text or "", re.I):
                    findings.append(_finding(
                        "SQL 报错注入", "high", "medium", url,
                        "参数 %s 注入 %s 后响应出现数据库报错特征：%s"
                        % (p, payload, sign),
                        request=(r.raw_request or ""), response=r.dump(600),
                        payload=payload, cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:N/VA:N",
                        fix="统一异常处理，禁止把数据库报错回显到前端；使用参数化查询。",
                        param=p, method=method, body=body, kind="sqli_error"))
                    break
            else:
                continue
            break
    if extra_payloads:
        try:
            from modules import vc_custom as c
            findings.extend(c.check_sqli_custom(
                url, client, params, method, body,
                extra_payloads, delay, base_elapsed, _finding))
        except Exception as e:
            log.debug("ski %s", e)
    return findings


# ------------------------------------------------------------
# 2. XSS（反射型）
# ------------------------------------------------------------
def check_xss(url, client, params=None, method="GET", body=None,
              extra_payloads=None):
    findings = []
    params = params or _param_candidates(url, body)
    for p in params[:12]:
        for payload in dicts.XSS_PAYLOADS[:6]:
            if method == "GET":
                r = client.get(_inject_query(url, p, payload), purpose="xss")
            else:
                r = client.post(url, data=_inject_form(body, p, payload),
                                purpose="xss")
            if not r.status:
                continue
            # 反射判定：原始 payload 未编码地出现在响应里
            if payload in (r.text or ""):
                # 进一步确认上下文（是否在 script/属性里）
                idx = r.text.find(payload)
                ctx = r.text[max(0, idx - 80):idx + len(payload) + 80]
                findings.append(_finding(
                    "反射型 XSS", "medium", "high", url,
                    "参数 %s 的输入被原样反射到 HTML 中，且未做实体编码。上下文片段：\n%s"
                    % (p, ctx),
                    request=(r.raw_request or ""), response=r.dump(600),
                    payload=payload,
                    cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:L/VI:L/VA:N",
                    fix="对输出做上下文相关编码（HTML/JS/属性）；启用 CSP；"
                        "对富文本使用白名单过滤。", param=p, method=method, body=body))
                break
    if extra_payloads:
        try:
            from modules import vc_custom as c
            findings.extend(c.check_xss_custom(
                url, client, params, method, body,
                extra_payloads, _finding))
        except Exception as e:
            log.debug("skx %s", e)
    return findings


# ------------------------------------------------------------
# 3. 开放重定向
# ------------------------------------------------------------
def check_open_redirect(url, client, params=None, method="GET", body=None):
    findings = []
    redirect_keys = ("url", "redirect", "redirect_uri", "redirect_url", "next",
                     "return", "returnUrl", "return_url", "goto", "target",
                     "to", "link", "jump", "callback", "continue", "dest")
    params = params or _param_candidates(url, body)
    params = [p for p in params if p.lower() in
              [k.lower() for k in redirect_keys]] or params[:6]
    for p in params[:8]:
        for payload in dicts.REDIRECT_PAYLOADS:
            if method == "GET":
                r = client.get(_inject_query(url, p, payload),
                               purpose="redirect", allow_redirects=False)
            else:
                r = client.post(url, data=_inject_form(body, p, payload),
                                purpose="redirect", allow_redirects=False)
            if r.status in (301, 302, 303, 307, 308):
                loc = r.header("Location")
                if loc and ("evil.com" in loc):
                    findings.append(_finding(
                        "开放重定向", "medium", "high", url,
                        "参数 %s 可控跳转目标，Location: %s" % (p, loc),
                        request=(r.raw_request or ""), response=r.dump(400),
                        payload=payload,
                        cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:N/VI:L/VA:N",
                        fix="跳转目标使用白名单域名校验，禁止直接使用用户传入的 URL。",
                        param=p, method=method, body=body))
                    break
    return findings


# ------------------------------------------------------------
# 4. SSRF
# ------------------------------------------------------------
def _ssrf_echo_probe(url, client, params, method, body, echo_host,
                    mark=None):
    """F3（round88-F）：SSRF 回显实证。

    与 ``check_ssrf`` 的特征串通道的根本区别：
      特征串（root:x:0:0 / redis_version …）只是「响应里出现了内网痕迹」，
      可能是页面静态文案、也可能是错误页把请求 URL 贴回来了；
      回显标记则是「我们事先埋下的、目标不可能自己知道的随机串」出现了——
      这只能来自目标真的替我们发出请求并取回了内容。

    实现约束：
      1) 标记每次运行随机生成（8 位十六进制），写死在字典里等于给目标伪造的机会；
      2) 先取基线，任何「注入前就已存在」的标记一律不算命中（防静态文案）；
      3) 参数被原样回显（响应里出现完整探针 URL）→ 判为回显型，跳过；
      4) 响应体与基线逐字节相同 → 判为静态页，跳过；
      5) 不新建连接：全部走传入的同一个 client（同限速、同 scope、同计数）。

    ``echo_host`` 形如 ``192.168.1.5:8899``，由调用方从配置写入；
    留传即为关闭本通道，行为与改动前逐字一致。
    """
    out = []
    if not echo_host or not params:
        return out
    try:
        import random
        import string as _string
        if mark is None:
            mark = "btr88" + "".join(
                random.choice(_string.hexdigits.lower()[:16]) for _ in range(8))
        mark = str(mark).lower()
        _host = echo_host
        if chr(58) not in _host.split(chr(93))[-1]:
            _host = _host + chr(58) + "80"
        probe = dicts.SSRF_ECHO_TMPL % (_host, dicts.SSRF_ECHO_PATHS[0])
        _probe_low = probe.lower()
        _host_low = _host.lower()
        # 基线：未注入时响应里是否已含标记（理论上不可能，兜底防巧合）
        try:
            b = client.get(url, purpose="ssrf:echo:base") if method == "GET" \
                else client.post(url, data=body, purpose="ssrf:echo:base")
            base_low = (b.text or "").lower()
        except Exception:
            base_low = ""
        if mark in base_low:
            return out
        reported = set()
        for p in params[:6]:
            if p in reported:
                continue
            if method == "GET":
                r = client.get(_inject_query(url, p, probe), purpose="ssrf:echo")
            else:
                r = client.post(url, data=_inject_form(body, p, probe),
                                purpose="ssrf:echo")
            if not r.status:
                continue
            text = r.text or ""
            low = text.lower()
            # (3) 判定顺序：标记优先。只有「响应里没有随机标记、却出现了探针字面量」
            # 才算参数回显（不是 SSRF）。原实现用 A or (B and C) 会让探针地址
            # 自身的回显掩盖标记命中，属运算符优先级缺陷。
            hit_mark = mark in low
            echo_back = (_probe_low in low) or (_host_low in low)
            if not hit_mark and echo_back:
                continue
            # (4) 与基线完全相同 -> 静态页
            if base_low and low == base_low:
                continue
            if mark not in low:
                continue
            reported.add(p)
            out.append(_finding(
                "SSRF（服务端请求伪造）", "high", "high", url,
                "参数 %s 注入回显探针 %s 后，响应中出现探针随机标记 %s "
                "（基线中不存在），可判定服务端确实发起了该请求并回显内容。"
                % (p, probe, mark),
                request=(r.raw_request or ""), response=r.dump(600),
                payload=probe,
                cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:N/VA:N",
                fix="对请求目标做域名/IP 白名单；禁止访问内网段与元数据地址；"
                    "统一出口网关并在网关层做目标地址校验。",
                param=p, method=method, body=body, kind="ssrf"))
            out[-1]["_ssrf_echo"] = mark
            break
    except Exception:
        # 探针通道任何异常都不得影响主流程判定
        return out
    return out


def _b64url_dec(seg):
    try:
        import base64
        pad = chr(61) * (-len(seg) % 4)
        return base64.urlsafe_b64decode((seg + pad).encode(chr(97)+chr(115)+chr(99)+chr(105)+chr(105)))
    except Exception:
        return None


def _jwt_parse(tok):
    try:
        import json as _json
        parts = tok.split(chr(46))
        if len(parts) != 3:
            return None
        hraw = _b64url_dec(parts[0])
        if not hraw:
            return None
        hdr = _json.loads(hraw.decode(chr(117)+chr(116)+chr(102)+chr(45)+chr(56), chr(105)+chr(103)+chr(110)+chr(111)+chr(114)+chr(101)))
        if not isinstance(hdr, dict):
            return None
        sig = _b64url_dec(parts[2])
        return hdr, parts[0] + chr(46) + parts[1], sig
    except Exception:
        return None


def _jwt_collect_tokens(base_url, client, limit=3):
    out = []
    try:
        r = client.get(base_url, purpose=chr(106)+chr(119)+chr(116)+chr(58)+chr(99)+chr(111)+chr(108)) 
        blobs = []
        try:
            for k, v in (r.headers or {}).items():
                blobs.append(str(k) + chr(58)+chr(32) + str(v))
        except Exception:
            pass
        blobs.append(r.text or chr(0)[:0]) 
        seen = set()
        for blob in blobs:
            for m in re.findall(dicts.JWT_RE, blob):
                if m in seen:
                    continue
                seen.add(m)
                out.append(m)
                if len(out) >= limit:
                    return out
    except Exception:
        return out
    return out


def check_jwt_weak_key(base_url, client, max_tokens=3):
    out = []
    try:
        import hmac as _hmac
        import hashlib as _hashlib
        toks = _jwt_collect_tokens(base_url, client, limit=max_tokens)
        for tok in toks:
            parsed = _jwt_parse(tok)
            if not parsed:
                continue
            hdr, signing_input, sig = parsed
            alg = str(hdr.get(chr(97)+chr(108)+chr(103), chr(0)[:0]))
            digest = dicts.JWT_HMAC_ALGS.get(alg)
            if not digest or not sig:
                continue
            hit = None
            for secret in dicts.JWT_WEAK_SECRETS:
                try:
                    calc = _hmac.new(secret.encode(chr(117)+chr(116)+chr(102)+chr(45)+chr(56)), signing_input.encode(chr(97)+chr(115)+chr(99)+chr(105)+chr(105)), getattr(_hashlib, digest)).digest()
                except Exception:
                    continue
                if _hmac.compare_digest(calc, sig):
                    hit = secret
                    break
            if hit is None:
                continue
            out.append(_finding(vuln_type="JWT 弱密钥", severity="critical", confidence="high", url=base_url, description="JWT 使用弱密钥签名，alg=" + alg + "，密钥 " + hit + "。已用本地 HMAC 复算签名并比对成功，攻击者可伪造任意身份令牌。", response=tok[:600], payload=hit, kind="weakpass", cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:N", fix="改用长度不低于 32 字节的强随机密钥，存于环境变量或密钥管理服务，并禁用弱默认值。"))
            break
    except Exception:
        return out
    return out

def check_ssrf(url, client, params=None, oob_domain="", method="GET", body=None,
                echo_url=""):
    """SSRF 检测：注入内网/OOB 地址，观察响应差异或回连。

    支持 GET（query 注入）与 POST（表单体注入）两种形态：真实业务里
    "url/redirect/proxy" 这类参数大量出现在 POST 表单中，只测 query 会漏。
    """
    findings = []
    url_keys = ("url", "uri", "path", "src", "source", "target", "dest",
                "redirect", "proxy", "image", "img", "file", "load", "fetch",
                "request", "host", "domain", "callback", "webhook", "link")
    params = params or _param_candidates(url, body)
    params = [p for p in params if p.lower() in url_keys] or []
    if not params:
        return findings
    # F3（round88-F）：回显实证通道。
    # 与下方的「特征串命中」严格分开：特征串只能证明「响应里有内网痕迹」，
    # 可能是页面静态内容、也可能是错误页贴了请求 URL；只有回显标记才能证明
    # 「服务端真的替我们发出请求并取回了内容」。因此两路分别判定、分别定级：
    #   回显命中 -> high（实证）；仅特征串命中 -> medium（疑似）。
    if echo_url:
        findings.extend(_ssrf_echo_probe(url, client, params, method, body,
                                         echo_url))
        if any(f.get("_ssrf_echo") for f in findings):
            # 已有实证，不再跑特征串通道，避免同一参数被报两条
            return findings

    payloads = list(dicts.SSRF_PAYLOADS)
    if oob_domain:
        payloads.insert(0, "http://bt-oob.%s/" % oob_domain)

    # 基线响应（缺陷 J）：用于排除"参数被原样回显"造成的假阳性。
    # 若 signs 里的弱特征（127.0.0.1 / localhost）在未注入时就已经出现在响应里，
    # 说明它来自页面本身或参数回显，而不是服务端真的发起了请求。
    try:
        base_r = client.get(url, purpose="ssrf:baseline") if method == "GET" \
            else client.post(url, data=body, purpose="ssrf:baseline")
        baseline = (base_r.text or "").lower()
    except Exception:
        baseline = ""

    # 去重（缺陷 K）：同一参数被多个 payload 命中时只报一条，
    # 否则一个 SSRF 点会被 8 个 payload 各报一次，把报告灌成重复项。
    reported = set()
    for p in params[:6]:
        if p in reported:
            continue
        for payload in payloads[:8]:
            if method == "GET":
                r = client.get(_inject_query(url, p, payload), purpose="ssrf")
            else:
                r = client.post(url, data=_inject_form(body, p, payload),
                                purpose="ssrf")
            if not r.status:
                continue
            body_text = r.text or ""
            low = body_text.lower()
            # 回显排除（缺陷 J）：注入的 URL 原样出现在响应里 →
            # 只是把参数回显了，不是服务端替我们请求；真 SSRF 返回的是"取回的内容"。
            if payload.lower() in low:
                continue
            # 命中内网服务特征
            signs = ["root:x:0:0", "redis_version", "amazon", "meta-data",
                     "127.0.0.1", "localhost", "connection refused"]
            hit = None
            for s in signs:
                sl = s.lower()
                # 基线里已有的特征不算（排除静态/回显），只有注入后才出现才算
                if sl in low and sl not in baseline:
                    hit = s
                    break
            if hit:
                reported.add(p)
                findings.append(_finding(
                    "SSRF（服务端请求伪造）", "high", "medium", url,
                    "参数 %s 可注入外部地址，响应中出现内网服务特征：%s"
                    % (p, hit),
                    request=(r.raw_request or ""), response=r.dump(600),
                    payload=payload,
                    cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:N/VA:N",
                    fix="对请求目标做域名/IP 白名单；禁止访问内网段与元数据地址；"
                        "统一出口网关。", param=p, method=method, body=body,
                    kind="ssrf"))
                break
    return findings


# ------------------------------------------------------------
# 5. 未授权访问 / 信息泄露（敏感路径）
# ------------------------------------------------------------
def check_unauthorized(path_hits, client, db=None):
    """把 probe_sensitive_paths 的命中转成漏洞项。

    判定口径（修缺陷 H）：
    - 401/403 → 需要认证，属正常，不报；
    - 200 → 可直接访问。critical/high 直接报；medium 直接报；
      low/info 只有在"管理后台/控制台/面板/未授权/泄露"这类语义下才报，
      避免 /metrics、/robots.txt 这类低价值 200 把报告灌水。
    """
    findings = []
    SOFT_KW = ("后台", "管理", "控制台", "面板", "未授权", "泄露", "监控", "用户列表")
    for h in path_hits:
        if h["status"] != 200:
            continue
        # round21 纵深防御：上游基线不可用时不会产出命中；此处再兜底
        # 过滤一次，防止外部/历史来源的 path_hits 绕过基线校验。
        if not h.get("baseline_ok", True):
            continue
        sev = h["severity"]
        desc = h.get("desc", "")
        if sev in ("critical", "high", "medium"):
            pass
        elif any(k in desc for k in SOFT_KW):
            sev = "low"          # 语义命中 → 升级为 low 并报告
        else:
            continue
        findings.append(_finding(
            h["desc"], sev, "medium", h["url"],
            "路径 %s 可直接访问（HTTP %d，无需认证），返回 %d 字节。"
            % (h["path"], h["status"], h["length"]),
            request="", response=h.get("evidence", ""), payload="",
            cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:N/VA:N",
            fix="对该路径增加认证与权限校验；生产环境关闭调试/管理端点。",
            # 增强 U-5：接入证据化置信度（medium → high）。
            # 未授权访问的最强证据常在响应头（Server / Set-Cookie / Location）
            # 与正文（phpinfo、用户列表、后台 UI），故保留头部参与评分。
            kind="unauth"))
    return findings


# ------------------------------------------------------------
# 6. 弱口令（少量尝试，避免锁号）
# ------------------------------------------------------------
# 登录失败 / 成功的证据词表与探测器（弱口令判定用）。
_WEAK_FAIL_WORDS = ("密码错误", "用户名或密码错误", "账号或密码错误", "密码不正确",
                    "登录失败", "认证失败", "用户不存在", "账号不存在",
                    "invalid password", "incorrect password", "wrong password",
                    "login failed", "authentication failed", "bad credentials",
                    "invalid credentials")
_WEAK_OK_WORDS = ("success", "welcome", "登录成功", "token", "dashboard",
                  "access_token", "refresh_token", "main.html", "console")
_JWT_RE = re.compile(r"eyJ[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{4,}")
_SESSION_KEY_RE = re.compile(r"(session|token|jwt|auth|sid|ticket)", re.I)


def _weak_evidence(r, body_low, base_len, base_body):
    """收集“疑似登录成功”的独立证据名。

    强证据：成功关键词（基线里没有）/ JWT / 下发会话 Cookie / 跳转非登录页。
    弱证据：响应长度相对失败基线显著变化（单独不足以判定，避免误报）。
    """
    ev = []
    for w in _WEAK_OK_WORDS:
        if w in body_low and w not in base_body:
            ev.append("成功关键词:%s" % w)
            break
    m = _JWT_RE.search(r.text or "")
    if m:
        ev.append("JWT:%s..." % m.group(0)[:16])
    for k, v in (r.headers or {}).items():
        if _SESSION_KEY_RE.search(str(k or "")) and len(str(v or "")) >= 16:
            ev.append("会话Cookie:%s" % k)
            break
    loc = r.header("Location") or ""
    if r.status in (301, 302, 303, 307) and loc and not re.search(
            r"login|signin|sign-in|error|fail", loc, re.I):
        ev.append("跳转:%s" % loc[:60])
    if abs(r.length - base_len) > max(200, base_len * 0.3):
        ev.append("长度变化:%d→%d" % (base_len, r.length))
    return ev


def _weak_candidates(user_fields, pass_fields, max_try):
    """生成 (用户字段, 口令字段, 用户名, 口令) 候选序列。

    第一轮覆盖主字段组合 × 全部默认凭据（命中率最高、请求最少）；
    仍有余额时才用其余常见字段组合补测高频凭据。总长严格受 max_try 限制。
    """
    ufs, pfs = [], []
    for u in user_fields:
        if u and u not in ufs:
            ufs.append(u)
    for p in pass_fields:
        if p and p not in pfs:
            pfs.append(p)
    if not ufs:
        ufs = ["username"]
    if not pfs:
        pfs = ["password"]
    creds = _dm.merged_creds()
    out, seen = [], set()
    for user, pwd in creds:
        if len(out) >= max_try:
            break
        k = (ufs[0], pfs[0], user, pwd)
        if k in seen:
            continue
        seen.add(k)
        out.append(k)
    if len(out) < max_try:
        for uf in ufs[1:3]:
            for pf in pfs[1:2]:
                for user, pwd in creds[:8]:
                    if len(out) >= max_try:
                        break
                    k = (uf, pf, user, pwd)
                    if k in seen:
                        continue
                    seen.add(k)
                    out.append(k)
    return out


def check_weak_password(login_url, client, user_field="username",
                        pass_field="password", extra=None, max_try=24,
                        user_fields=None, pass_fields=None):
    """少量默认凭据尝试（**不做字典轰炸**，避免锁号与 DoS）。

    与旧实现的差异：
    - 凭据源从 20 条扩到 dicts.DEFAULT_CREDS_ALL（300+ 条，round87c 扩充至 308），但**总量仍受
      max_try 硬限制**，且每次出网都经 http.rate_limit 统一限速；
    - 支持字段组合枚举（username/user/name/account/... × password/passwd/pwd/...），
      解决“字段名猜错 → 明明有弱口令也测不出来”的漏检；
    - 成功判定改为**负证据优先 + 强证据门槛**：出现“密码错误”类文案直接否定；
      必须有成功关键词/JWT/会话 Cookie/跳转等强证据才判定命中，杜绝误报。
    """
    findings = []
    if not login_url:
        return findings
    try:
        max_try = max(1, int(max_try or 1))
    except Exception:
        max_try = 1
    ufs = [user_field] + list(user_fields or dicts.LOGIN_USER_FIELDS)
    pfs = [pass_field] + list(pass_fields or dicts.LOGIN_PASS_FIELDS)
    # 先取一次失败响应作为基线
    probe = client.post(login_url, data={ufs[0]: "bt_no_such_user_%d" % int(time.time()),
                                         pfs[0]: "wrong_pass_xyz"},
                        purpose="weakpass:baseline")
    if not probe.status:
        return findings
    base_len = probe.length
    base_body = (probe.text or "").lower()

    for uf, pf, user, pwd in _weak_candidates(ufs, pfs, max_try):
        data = {uf: user, pf: pwd}
        if extra:
            data.update(extra)
        r = client.post(login_url, data=data, purpose="weakpass")
        if not r.status:
            continue
        body_low = (r.text or "").lower()
        # 负证据优先：明确的“凭据错误”文案 → 直接否定，绝不误报。
        if any(w in body_low for w in _WEAK_FAIL_WORDS):
            continue
        ev = _weak_evidence(r, body_low, base_len, base_body)
        strong = [e for e in ev if not e.startswith("长度变化")]
        if r.status in (200, 302, 303) and (strong or len(ev) >= 2):
            findings.append(_finding(
                "弱口令 / 默认凭据", "critical", "low", login_url,
                "使用默认凭据 %s=%s / %s=%s 疑似登录成功（证据：%s；"
                "响应长度 %d，基线 %d）。请在人工确认后提交，避免误报。"
                % (uf, user, pf, pwd, "、".join(ev), r.length, base_len),
                request=(r.raw_request or ""), response=r.dump(400),
                payload="%s=%s&%s=%s" % (uf, user, pf, pwd),
                param=uf, method="POST",
                cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H",
                fix="强制修改默认口令；启用登录失败锁定与验证码；"
                    "口令复杂度策略 + 多因素认证。",
                # 增强 U-5：接入证据化置信度（low → medium）。
                # 弱口令命中往往只有"响应长度变化"这类弱信号，
                # 仅当同时出现 token / JWT / Set-Cookie session / 成功关键词
                # 等强证据（>= 阈值）时才上调，避免把误报吹成高置信。
                kind="weakpass"))
            break
    return findings


# ------------------------------------------------------------
# 7. CORS 配置错误
# ------------------------------------------------------------
def check_cors(url, client):
    """CORS 配置错误检测。

    round90 FIX-17：原实现只要 `acao` 里含 `evil.com` **或等于 `*`** 就报。
    实测在「任意响应统一带 `Access-Control-Allow-Origin: *`」的站点上
    （CDN/网关默认加头，非常普遍），任意一个带参 URL 都稳定产 1 条假
    CORS 漏洞——换哪个域名都躲不掉。

    关键事实：`ACAO: *` 与 `Allow-Credentials: true` 在浏览器里**互斥**，
    带 `*` 的响应根本不会被允许携带 Cookie，构不成"跨域窃取凭据"。
    所以现在：
      · `*` 一律不报（无论 ACAC 是什么）——它最多是"公开只读接口"，
        不是漏洞；
      · 只有服务端**回显了本次注入的具体 Origin**（说明按输入反射）才报；
      · 响应与软 404 基线同质 → 是兜底页/WAF 页统一加的头，丢弃。
    """
    findings = []
    probe_origin = "https://evil.com"
    r = client.get(url, headers={"Origin": probe_origin}, purpose="cors")
    acao = (r.header("Access-Control-Allow-Origin") or "").strip()
    acac = (r.header("Access-Control-Allow-Credentials") or "").strip()
    # FIX-17 闸 1：通配符不构成漏洞（浏览器拒绝与凭据共存），一律不报。
    if not acao or acao == "*":
        return findings
    # FIX-17 闸 2：必须回显本次注入的 Origin，而不是某个固定白名单域。
    if acao != probe_origin:
        return findings
    # FIX-17 闸 3：与软 404 基线同质 → 兜底页/WAF 页统一加头，非业务响应。
    # 例外：若同时回显了 `Allow-Credentials: true`，则即使基线同质也报——
    # 站点级「反射任意 Origin + 允许携带凭据」本身就是可读任意已登录接口的
    # 真实配置错误，不是噪声（round90 复跑探针场景 F 验证：该分支必须保留）。
    if acac.lower() != "true":
        try:
            base_url = "%s://%s/" % (url.split("://")[0], url.split("://")[1].split("/")[0])
            base = probe.soft404_baseline(base_url, client)
            if probe.baseline_usable(base) and probe.is_soft404(r, base):
                return findings
        except Exception:
            pass

    sev = "high" if acac.lower() == "true" else "medium"
    findings.append(_finding(
        "CORS 配置不当", sev, "high", url,
        "服务端反射了任意 Origin（%s），Allow-Credentials=%s。"
        % (acao, acac or "false"),
        request=(r.raw_request or ""), response=r.dump(400), payload="",
        cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:H/VI:N/VA:N",
        fix="Access-Control-Allow-Origin 使用白名单，禁止反射任意 Origin；"
            "携带凭据时不得使用通配符。"))
    return findings


# ------------------------------------------------------------
# 8. 敏感文件 / 备份文件
# ------------------------------------------------------------
def check_backup_files(base_url, client, found_dirs=None):
    """备份 / 源码文件泄露探测。

    round90 FIX-16：原实现**完全没有软 404 基线守卫**——只判
    `HEAD status == 200 and length > 1000`。实测在「任意路径统一回 200 +
    同一大首页」的兜底站点（nginx try_files 兜底、SPA history 模式）上，
    `/www.zip`、`/backup.zip`、`/web.zip`、`/site.tar.gz`、`/db.sql`、
    `/dump.sql` 六条**全部命中**，每台这类站点稳定产 6 条假备份泄露，
    与"扫哪个域名都一堆重复"完全吻合。

    现在加两道闸：
      1) 主基线（随机路径软 404）不可用 → 整轮不报（宁可不报）；
      2) HEAD 粗筛后必须 GET 回正文，与基线同质（is_soft404）即丢弃；
         GET 失败时退化为「长度与基线同量级」判定，同样丢弃。
    """
    findings = []
    base = probe.soft404_baseline(base_url, client)
    # FIX-16 闸 1：基线不可用时 is_soft404 恒 False，会把兜底首页当备份文件。
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过备份文件检测 %s", base_url)
        return []
    targets = list(found_dirs or []) + ["/www.zip", "/backup.zip", "/web.zip",
                                        "/site.tar.gz", "/db.sql", "/dump.sql"]
    for t in targets[:30]:
        t = _to_path(t)
        if not t:
            continue
        url = base_url.rstrip("/") + t
        r = client.head(url, purpose="backup")
        if not (r.status == 200 and r.length > 1000):
            continue
        # 主动增强 U-3：HEAD 只能证明"可访问且体积像备份"，
        # but nginx/兜底页、WAF 占位页也可能 200 + 大体积。
        # 再 GET 回前 2KB 校验文件魔数 / DDL 关键字，把"疑似"变成"实证"：
        #   命中强特征（PK/gzip 魔数、CREATE TABLE、私钥）→ 置信度 high；
        #   无特征 → 保持 medium，交人工确认。
        body = ""
        _got = False
        try:
            g = client.get(url, purpose="backup")
            _got = bool(g and g.status)
        except Exception:
            g = None
            _got = False
        if _got:
            # FIX-16 闸 2：与软 404 基线同质 → 该路径并未被单独处理，不是备份。
            if probe.is_soft404(g, base):
                continue
            if g.status == 200:
                body = g.dump(600)
        else:
            # GET 拿不到时退化为长度判定：与基线同量级 → 兜底页，丢弃。
            if probe.same_length(r.length, base.get("length")):
                continue
        findings.append(_finding(
                "备份/源码文件泄露", "critical", "medium", url,
                "可下载备份文件（%d 字节），可能包含源码与数据库配置。" % r.length,
                request="", response=body or r.dump(300), payload="",
                cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H",
                fix="禁止 Web 目录存放备份/源码文件；配置服务器拒绝访问常见备份扩展名。",
                kind="backup"))
    return findings


# ------------------------------------------------------------
# 9. 国产组件一次性检测
# ------------------------------------------------------------
def check_cn_components(base_url, client):
    """国产组件高危路径一次性探测。

    缺陷 A 修复：原实现把 `status in (200,302,401,403,500)` 一律当"路径
    存在 → 组件存在"，实测在 WAF 前置站点（整站 403）与 nginx 兜底站点
    （整站 200 首页）上会把整站判成"严重/高危组件漏洞"，是本次误报的
    头号来源。现在收紧为：
      1) 只有 200 才考虑——401/403 是被拦截、500 是报错，都不能证明
         组件存在；302 单独处理（必须跳到该组件自身的特征路径）；
      2) 必须与随机路径软 404 基线不同（排除兜底首页）；
      3) marker 必须非空且命中——marker 是空串说明该条目没有可用的存在
         性判据，宁可不报，也不靠状态码猜。
    """
    findings = []
    base = probe.soft404_baseline(base_url, client)
    # round21 基线降级保护：基线不可用时 is_soft404 恒 False，
    # 会把整站兜底首页判成大量国产组件存在。宁可不报。
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过国产组件检测 %s", base_url)
        return []
    for name, method, path, marker, sev in dicts.CN_COMPONENT_CHECKS:
        url = base_url.rstrip("/") + path
        r = client.send(method, url, purpose="cn:component")
        if not r.status:
            continue
        # 403/401/500 不再作为组件存在判据
        if r.status not in (200, 302):
            continue
        # 兜底首页 / WAF 统一响应 → 该路径并未被单独处理
        if probe.is_soft404(r, base):
            continue
        # 302 必须跳到组件自身特征路径，否则视为普通跳转，不报
        if r.status == 302:
            loc = (r.header("Location") or "").lower()
            if not loc or path.lower().split("?")[0] in loc:
                continue
        body = (r.text or "")
        if r.status == 200 and len(body.strip()) < 5:
            continue
        # marker 空 → 无可信判据，跳过（不靠状态码猜）
        if not marker:
            continue
        # marker 支持 `|` 分隔的多候选，任一命中即可（组件特征串往往有多种写法）
        body_l = body.lower()
        cands = [c.strip().lower() for c in marker.split("|") if c.strip()]
        if not cands or not any(c in body_l for c in cands):
            continue
        findings.append(_finding(
            name, sev, "medium", url,
            "组件特征路径 %s 可访问且命中特征串 `%s`（HTTP %d），"
            "疑似存在已知高危问题，需人工确认版本与利用条件。"
            % (path, marker, r.status),
            request=(r.raw_request or ""), response=r.dump(500), payload="",
            cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H",
            fix="升级组件到最新版本；关闭非必要接口；增加访问控制。"))
    return findings


# ------------------------------------------------------------
# 9. 目录列表泄露（主动增强 U-6）
# ------------------------------------------------------------
def _dir_entries(body):
    """从索引页正文里解析出"看起来像文件/子目录"的条目名。

    判据刻意保守，只认能明确成条目的东西，避免把普通页面的导航链接
    误当目录条目：
      · 带扩展名的文件名（`db.sql`、`backup.zip`、`.env`）；
      · 结尾是 `/` 的相对链接（子目录）；
      · Apache/nginx 的 `Parent Directory` 行（不计数，仅用于佐证）。
    返回去重后的条目列表。
    """
    if not body:
        return []
    text = body[:20000]
    names = set()
    # href="xxx" / href='xxx'
    for m in re.finditer(r"""href\s*=\s*["']([^"'#>?]+)["']""", text, re.I):
        name = m.group(1).strip()
        if not name:
            continue
        if name.startswith("http://") or name.startswith("https://"):
            continue
        # 先剥掉尾部斜杠再判，保证 `../` / `./` / `/` 都被正确排除
        # （早期版本只比较原始串，`../` 会漏过并被当成一个子目录条目）。
        core = name.rstrip("/")
        if not core or core in (".", ".."):
            continue
        # 含 `/` 说明是站内其它路径的链接，不是本目录条目，不计入
        if "/" in core:
            continue
        # 子目录（原名以 / 结尾）
        if name.endswith("/"):
            names.add(core + "/")
            continue
        # 带扩展名的文件名（排除纯锚点/脚本）
        if "." in core and not core.lower().endswith((".js", ".css", ".ico")):
            names.add(core)
    return sorted(names)


def check_directory_listing(base_url, client, found_dirs=None):
    """目录列表泄露检测（CWE-548，主动增强 U-6）。

    为什么单独做一个检测器：这类漏洞此前**全项目零覆盖**。它与"备份文件
    泄露"互为线索但判定口径完全不同——备份检测看"下载到的文件内容像不像
    备份"（PK 魔数 / CREATE TABLE），而目录列表看"页面像不像可枚举的索引"。
    两者都命中时是**两个独立问题**，应当分别上报。

    误报控制（三条硬门槛，缺一不报）：
      1) 状态必须是 200；
      2) 必须与随机路径的软 404 基线**不同质**（排除兜底首页 / WAF 占位页）；
      3) 正文必须同时满足——
         a. 命中至少一个索引页标记家族（`Index of /` / `Directory listing
            for` / 中文目录列表 等）；
         b. 能解析出 **>= 2 个**真实条目（单个链接不足以证明是索引页，
            很多正常页面的"返回上级"链接也长这样）。

    只做只读 GET，不下载、不枚举子目录，无危害。
    """
    findings = []
    targets = list(found_dirs or [])
    # 兜底：即使目录爆破没跑（或没命中），也探一批高价值目录
    for d in ("/backup", "/backups", "/upload", "/uploads", "/files",
              "/download", "/downloads", "/static", "/assets", "/data",
              "/logs", "/temp", "/old", "/bak", "/db", "/sql"):
        if d not in targets:
            targets.append(d)
    base = probe.soft404_baseline(base_url, client)
    # round21 基线降级保护：基线不可用时 is_soft404 恒 False，
    # 门槛 2 失效，会把整站兜底首页当索引页。宁可不报。
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过目录列表检测 %s", base_url)
        return []
    seen = set()
    for t in targets[:40]:
        t = _to_path(t)
        if not t:
            continue
        key = t.rstrip("/").lower() or "/"
        if key in seen:
            continue
        seen.add(key)
        # 目录类路径（最后一段不含扩展名）补尾斜杠：真实服务器对
        # `/files` 常回 301 跳到 `/files/`，不补就会因"非 200"被漏掉。
        _last = t.rsplit("/", 1)[-1]
        if not t.endswith("/") and "." not in _last:
            t = t + "/"
        url = base_url.rstrip("/") + t
        # 健壮性：单个目标的请求异常（连接重置 / 超时 / 解析失败）不应
        # 中断整轮目录检测——其它目标仍应继续探测。
        try:
            r = client.get(url, purpose="dirlist", allow_redirects=False)
        except Exception as e:
            log.debug("目录列表探测异常 %s: %s", url, e)
            continue
        if not r.status:
            continue
        # 门槛 1：只有 200 才可能是索引页（301/302 是规范化跳转，403 是被拦）
        if r.status != 200:
            continue
        # 门槛 2：与软 404 基线同质 → 兜底首页 / WAF 占位页，不是真索引
        if probe.is_soft404(r, base):
            continue
        body = r.text or ""
        if len(body.strip()) < 32:
            continue
        body_l = body.lower()
        # 门槛 3a：必须命中索引页标记家族
        fams = 0
        for _name, marks in dicts.DIR_LIST_MARKERS:
            if any(m in body_l for m in marks):
                fams += 1
        if fams <= 0:
            continue
        # 门槛 3b：必须能解析出 >= 2 个真实条目
        entries = _dir_entries(body)
        if len(entries) < 2:
            continue
        findings.append(_finding(
            "目录列表泄露", "medium", "medium", url,
            "目录 %s 开启了列表浏览（HTTP 200，命中 %d 类索引特征，"
            "可枚举 %d 个条目，如：%s），泄露文件结构、文件名与备份线索，"
            "攻击者可据此定位敏感文件。"
            % (t, fams, len(entries), ", ".join(entries[:5])),
            request=(r.raw_request or ""), response=r.dump(1200), payload="",
            cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:L/VI:N/VA:N",
            fix="关闭 Web 服务器目录浏览（nginx: autoindex off；"
                "Apache: Options -Indexes；IIS: 禁用目录浏览），"
                "并为每个目录放置 index 文件。",
            kind="dirlist"))
    return findings


# ------------------------------------------------------------
# 统一构造
# ------------------------------------------------------------
def _finding(vuln_type, severity, confidence, url, description,
             request="", response="", payload="", cvss="", fix="", param="",
             method="GET", body=None, kind=None):
    """统一构造漏洞项。

    主动增强 U-3：`kind` 用于**证据化置信度**——原来 confidence 是
    按漏洞类型写死的字面量，现在若给了 kind（sqli_error / ssrf /
    backup），会结合 response 里命中的独立证据数做"多证据交叉上调"
    （medium → high）。只升不降，证据不足时保持原档，判定口径不变。
    """
    _conf = confidence
    if kind:
        try:
            from core import confidence as _cf
            _conf = _cf.effective_confidence(
                {"response": response}, confidence, kind=kind)
        except Exception:
            _conf = confidence   # 评分模块异常绝不改变原判定
    return {
        "vuln_type": vuln_type, "severity": severity, "confidence": _conf,
        "url": url, "description": description, "request": request,
        "response": response, "payload": payload, "cvss": cvss, "fix": fix,
        "payload_param": param, "method": method, "body": body,
        "title": "%s @ %s" % (vuln_type, url),
    }


# ------------------------------------------------------------
# 10. 开放 API 注册端点（未鉴权 + 直接下发会话凭据）
# ------------------------------------------------------------
# round58 新增，闭合 round57 基线高危 #1 的检测盲区。
#
# 为什么必须单独做：基线成功报告的高危 #1 是「开放注册接口无鉴权 +
# 响应体直接下发会话 token」——匿名 `POST /openApi/faUser/register`
# 即回 `{"data":{"token":"b79376..."}}`。这条此前**全项目零覆盖**：
#   · SENSITIVE_PATHS 只做 GET 路径存在性探测，POST 注册接口探不到；
#   · 参数级检测只注入 URL/表单里**已有**的参数，无参注册接口没有注入面；
#   · 敏感信息扫描是正则扫响应体，能扫到 token 字符串，但不会把它
#     关联成「这个接口匿名可调用」这一事实（没有请求语义）。
#
# 判定口径（三条硬门槛，缺一不报）：
#   1) 状态必须是 200/201 —— 401/403 是被拦、302 是跳登录、5xx 是报错，
#      都不能证明「匿名注册成功」；
#   2) 响应不得与随机路径的软 404 基线同质（排除 WAF/兜底首页）；
#   3) 正文必须**真的解析出会话凭据值** —— 命中 token/sessionId/jwt 等
#      键名，且值长度 >= 8 且不是 null/undefined 之类的占位。
# 只靠状态码猜「注册接口存在」会大面积误报，故宁可不报。
#
# 无危害：每个端点恰好 1 次匿名 POST，测试账号带 srctest_ 前缀，
# 不做爆破、不重复提交、不枚举用户；仅观测回包是否吐凭据。
_OPEN_API_CRED_RE = re.compile(
    r"""["']?(token|access_?token|accesstoken|auth_?token|authtoken|
         session_?id|sessionid|jwt|ticket|bearer|authorization)["']?
        \s*[:=]\s*["']([^"']{8,})["']""",
    re.I | re.X)
# 占位值：这些不是真凭据，命中不算
_OPEN_API_PLACEHOLDER = ("null", "undefined", "none", "false", "true",
                         "todo", "xxx", "placeholder", "your_token",
                         "your-token", "example", "changeme", "***")


def _open_api_placeholder(val):
    """值是否是占位串（不是真凭据）。"""
    v = (val or "").strip()
    if not v:
        return True
    low = v.lower()
    if low in _OPEN_API_PLACEHOLDER:
        return True
    # 单一字符重复（"00000000" / "aaaaaaaa"）视为占位
    if len(set(low)) <= 1:
        return True
    # 明显的模板串
    if low.startswith(("your", "xxx", "<", "${", "{{")):
        return True
    return False


def _open_api_body(tpl, seed):
    """把 body 模板里的 {u}/{p}/{m}/{e} 换成一次性测试账号。

    后缀由 seed 的 crc32 稳定派生 —— 同一目标同一端点重复扫描得到同一
    账号，便于人工复核时在后台按 `srctest_` 前缀定位，也避免每轮都往
    目标库里塞新账号。
    """
    suf = "%08x" % (zlib.crc32((seed or "").encode("utf-8", "ignore"))
                    & 0xFFFFFFFF)
    num = "%08d" % (zlib.crc32((seed or "m").encode("utf-8", "ignore"))
                    % 100000000)
    repl = {"{u}": "srctest_" + suf,
            "{p}": "Abc123456",
            "{m}": "137" + num,
            "{e}": "srctest_%s@example.com" % suf}
    out = {}
    for k, v in (tpl or {}).items():
        out[k] = repl.get(v, v) if isinstance(v, str) else v
    return out


def check_open_api_auth(base_url, client):
    """匿名调用开放注册接口，观测回包是否直接下发会话凭据。

    缺陷背景见上方注释（round57 基线高危 #1 零覆盖）。三条硬门槛缺一不报。
    只做只读语义的 1 次注册调用，不写业务数据、不爆破、不枚举。
    """
    findings = []
    base = probe.soft404_baseline(base_url, client)
    # 基线不可用时 is_soft404 恒 False，会把兜底首页判成注册成功。宁可不报。
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过开放 API 检测 %s", base_url)
        return []
    for path, method, body_tpl, desc, sev in dicts.OPEN_API_PROBES:
        url = base_url.rstrip("/") + path
        body = _open_api_body(body_tpl, base_url + path)
        try:
            if (method or "POST").upper() == "POST":
                r = client.post(url, json_body=body, purpose="openapi:register")
            else:
                r = client.get(url, purpose="openapi:register")
        except Exception as e:
            log.debug("开放 API 探测异常 %s: %s", url, e)
            continue
        if not r or not r.status:
            continue
        # 门槛 1：只有 200/201 才算「匿名调用成功」
        if r.status not in (200, 201):
            continue
        # 门槛 2：与兜底首页 / WAF 统一响应同质 → 该接口并未被单独处理
        if probe.is_soft404(r, base):
            continue
        # 门槛 3：必须真的解析出会话凭据值
        m = _OPEN_API_CRED_RE.search(r.text or "")
        if not m:
            continue
        key, val = m.group(1), m.group(2)
        if _open_api_placeholder(val):
            continue
        masked = (val[:4] + "***" + val[-4:]) if len(val) > 12 else "***"
        findings.append(_finding(
            desc, sev, "medium", url,
            "匿名 %s %s 无需任何认证即调用成功（HTTP %d），响应体直接下发"
            "会话凭据 `%s`（值已脱敏：%s）。攻击者可批量注册并直接获得可用"
            "会话，进而访问登录后的业务接口。"
            % ((method or "POST").upper(), path, r.status, key, masked),
            request=(r.raw_request or ""), response=r.dump(800), payload="",
            cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:N",
            fix="注册接口增加鉴权/风控（图形验证码、频率限制、手机号实名校验）；"
                "注册成功不得直接下发可用的会话凭据，须经二次登录验证。",
            method=(method or "POST").upper()))
        log.warning("[命中] %s [%s] %s", url, r.status, desc)
    return findings

# ------------------------------------------------------------
# 11. 账号枚举（用户名存在性泄露）
# ------------------------------------------------------------
# round71c 遗留③-1。基线 12 项里工具仍未覆盖的一条。
# 为什么单独做：参数级检测只注入 payload 看回显，不做「同一个字段喂不同
# 取值、比对响应差异」这种**语义型**判定；而账号枚举的本质正是「服务端对
# 存在的用户与不存在的用户给出可区分的响应」。
#
# 判定口径（三条硬门槛，缺一不报）：
#   1) 两次「不存在名」响应必须**互相同质**（状态码相同 + 正文相似度 >= 0.9）
#      —— 否则说明响应本身不稳定（随机码/时间戳/轮询），差异不可归因；
#   2) 探测路径与对照路径都不得与软 404 基线同质（排除兜底首页/WAF 统一响应）；
#   3) 对照名（常见默认名）的响应必须与不存在名**可区分**（状态码不同，或
#      正文相似度 < 0.9）—— 这才构成"服务端区分了用户是否存在"的证据。
#
# 无危害：每个端点恰好 3 次只读请求（2 个一次性不存在名 + 1 个对照名），
# 探测名带 srctest_no 前缀便于后台定位；**不带字典、不枚举真实用户名、
# 不试密码、不写任何数据**。
_USER_ENUM_SIM = 0.9


def _enum_probe_name(seed, tag):
    """一次性「几乎肯定不存在」的探测名（crc32 稳定派生，可复现）。"""
    h = zlib.crc32((seed + "|" + tag).encode("utf-8", "ignore")) & 0xFFFFFFFF
    return "srctest_no%s_%08x" % (tag, h)


def _enum_call(client, url, method, param, value):
    """按 GET/POST 形态发一次账号探测请求。"""
    if (method or "POST").upper() == "POST":
        return client.post(url, json_body={param: value},
                           purpose="enum:probe")
    sep = "&" if "?" in url else "?"
    return client.get(url + sep + param + "=" + value, purpose="enum:probe")


def check_user_enum(base_url, client):
    """探测登录/校验类端点是否泄露「用户名是否存在」。

    三条硬门槛见上方注释；缺一不报。全流程只读，每端点 3 次请求。
    """
    findings = []
    base = probe.soft404_baseline(base_url, client)
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过账号枚举检测 %s", base_url)
        return []
    for path, method, param, desc, sev in dicts.USER_ENUM_PROBES:
        url = base_url.rstrip("/") + path
        try:
            n1 = _enum_probe_name(url, "a")
            n2 = _enum_probe_name(url, "b")
            r1 = _enum_call(client, url, method, param, n1)
            r2 = _enum_call(client, url, method, param, n2)
            rc = _enum_call(client, url, method, param,
                            getattr(dicts, "USER_ENUM_CONTROL", "admin"))
        except Exception as e:
            log.debug("账号枚举探测异常 %s: %s", url, e)
            continue
        if not r1 or not r1.status or not r2 or not r2.status \
                or not rc or not rc.status:
            continue
        # 门槛 2：任一响应与兜底页同质 → 该路径未被单独处理
        if probe.is_soft404(r1, base) or probe.is_soft404(rc, base):
            continue
        # round89 FIX-14：错误页不携带业务判定。实测 lanli.cc 的
        # /api/login 返回 nginx 默认 405 页，两次 padding 注释条数不同，
        # 白化前的相似度跌破门槛，被误判成「服务端区分了用户是否存在」；
        # 31 条证据 100% 是 HTTP 405，等于把「端点不接受该方法」当成枚举。
        # 405/501 等状态下服务端根本没跑用户名判定，直接放弃该端点。
        if _is_non_business(r1.status) or _is_non_business(r2.status) \
                or _is_non_business(rc.status):
            log.debug("账号枚举跳过（非业务状态码 %s/%s/%s）：%s",
                      r1.status, r2.status, rc.status, url)
            continue
        # 门槛 1：两次不存在名必须互相同质（响应本身要稳定）
        if r1.status != r2.status:
            continue
        if _body_similarity(r1.text, r2.text) < _USER_ENUM_SIM:
            continue
        # round89 FIX-15：对照名（admin 等常见名）落到 403/429/5xx 时，差异
        # 来自「被拒 / 被限流 / 后端故障」，不是「这个用户名存在」。原逻辑
        # 只要状态码不相等就当可区分，会把基础设施故障成批报成账号枚举。
        if _is_control_unreliable(rc.status):
            log.debug("账号枚举跳过（对照名状态码不可信 HTTP %s）：%s",
                      rc.status, url)
            continue
        # 门槛 3：对照名必须与不存在名可区分
        if rc.status == r1.status and \
                _body_similarity(rc.text, r1.text) >= _USER_ENUM_SIM:
            continue
        findings.append(_finding(
            desc, sev, "medium", url,
            "该端点对「不存在的用户名」与「已存在的用户名」返回**可区分**的响应"
            "（不存在名两次均 HTTP %d，对照名 HTTP %d）。攻击者可据此批量判断"
            "哪些账号真实存在，为撞库/钓鱼/短信轰炸提供目标清单。"
            % (r1.status, rc.status),
            request=(rc.raw_request or ""), response=rc.dump(600), payload="",
            cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:L/VI:N/VA:N",
            fix="登录/校验接口对「用户不存在」与「密码错误」返回统一的提示文案与"
                "状态码，并加图形验证码/频率限制，避免通过响应差异枚举账号。",
            method=(method or "POST").upper()))
        log.warning("[命中] %s [%s] %s", url, r1.status, desc)
    return findings


# ------------------------------------------------------------
# 12. 硬编码公钥（前端可读位置的密钥材料）
# ------------------------------------------------------------
# round71c 遗留③-2。与 SECRET_PATTERNS 的「私钥」互补：私钥只抓
# PRIVATE KEY；这里专抓被写死在前端可读位置（首页 / 前端 JS / 配置脚本）
# 的**公钥材料**。公钥本身不致命，但它意味着签名/加密逻辑在前端可完整
# 复现，常与「客户端可篡改凭据」链路相连，属于必须人工确认的高价值线索。
#
# 判定口径（三条硬门槛，缺一不报）：
#   1) 必须是 200 且与软 404 基线不同质（排除兜底页）；
#   2) 必须命中**真实公钥材料**正则（PEM 公钥/证书/PGP/SSH 公钥/JWK n+e）；
#   3) 命中串长度 >= 64 且不含示例占位词（example/sample/test key/your_）。
# 只读 GET，每条路径 1 次请求，不写数据。
_KEY_MATERIAL = [
    ("RSA/EC 公钥（PEM）",
     re.compile(r"-----BEGIN (?:RSA |EC |DSA )?PUBLIC KEY-----[\s\S]{32,}?"
                r"-----END (?:RSA |EC |DSA )?PUBLIC KEY-----")),
    ("数字证书（PEM）",
     re.compile(r"-----BEGIN CERTIFICATE-----[\s\S]{32,}?"
                r"-----END CERTIFICATE-----")),
    ("PGP 公钥",
     re.compile(r"-----BEGIN PGP PUBLIC KEY BLOCK-----[\s\S]{32,}?"
                r"-----END PGP PUBLIC KEY BLOCK-----")),
    ("SSH 公钥",
     re.compile(r"ssh-(?:rsa|ed25519|dss)\s+AAAA[A-Za-z0-9+/=]{32,}")),
    ("JWK 公钥（模数 n）",
     re.compile(r'"(?:n|modulus)"\s*:\s*"([A-Za-z0-9_\-+/=]{64,})"')),
]
_KEY_PLACEHOLDER = ("example", "sample", "your_", "your-", "test key",
                    "testkey", "placeholder", "changeme", "xxxx")


def _key_is_placeholder(material):
    low = (material or "").lower()
    return any(p in low for p in _KEY_PLACEHOLDER)


def check_hardcoded_key(base_url, client):
    """在前端可读位置找被写死的公钥/证书材料。三条硬门槛缺一不报。"""
    findings = []
    base = probe.soft404_baseline(base_url, client)
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过硬编码公钥检测 %s", base_url)
        return []
    seen = set()
    for path in dicts.HARDCODED_KEY_PATHS:
        url = base_url.rstrip("/") + path if path != "/" else base_url.rstrip("/") + "/"
        try:
            r = client.get(url, purpose="key:hardcoded")
        except Exception as e:
            log.debug("硬编码公钥探测异常 %s: %s", url, e)
            continue
        if not r or not r.status or r.status != 200 or not r.text:
            continue
        if probe.is_soft404(r, base):
            continue
        for name, rx in _KEY_MATERIAL:
            m = rx.search(r.text)
            if not m:
                continue
            material = m.group(0)
            # 门槛 3：长度 + 非占位
            if len(material) < 64 or _key_is_placeholder(material):
                continue
            key = (name, material[:48])
            if key in seen:
                continue
            seen.add(key)
            masked = material[:24].replace("\n", " ") + "...(%d 字符)" % len(material)
            findings.append(_finding(
                "硬编码公钥材料（%s）" % name, "medium", "medium", url,
                "前端可读资源 %s 中内联了%s材料（已截断：%s）。该材料随页面下发，"
                "任何匿名访客均可取得，说明签名/加密逻辑在前端可完整复现；"
                "若配套私钥管理不当或校验逻辑可绕过，可导致凭据伪造。"
                % (path, name, masked),
                request=(r.raw_request or ""), response=r.dump(600), payload="",
                cvss="CVSS:4.0/AV:N/AC:H/AT:N/PR:N/UI:N/VC:L/VI:L/VA:N",
                fix="把公钥/证书改为按需从服务端接口获取并缓存，避免随前端资源"
                    "长期固化；确认签名校验在服务端完成，前端材料仅用于展示。"))
            log.warning("[命中] %s [%s] %s", url, r.status, name)
    return findings


# ------------------------------------------------------------
# 13. token 跨端点复用（服务端静态下发会话标识）
# ------------------------------------------------------------
# round71c 遗留③-3 的单主机侧实现。
# 语义：同一个会话凭据值（token/sessionId/jwt）在**多条彼此独立的路径**上
# 被匿名观测到 —— 说明它不是按会话随机签发，而是服务端静态/全局下发，
# 一旦泄露即对所有端点通用。跨主机汇总由 engine 在 scan_target 收尾完成。
#
# 判定口径（三条硬门槛，缺一不报）：
#   1) 每条路径必须 200 且与软 404 基线不同质；
#   2) 凭据值必须达到强度门槛（长度 >= 16 且字符集 >= 8 种），排除序号/占位；
#   3) 同一凭据值必须出现在 >= 2 条**不同路径**上。
# 只读 GET，每条路径 1 次请求。
_TOKEN_VAL_RE = re.compile(
    r"""["']?(token|access_?token|accesstoken|auth_?token|authtoken|
         session_?id|sessionid|jwt|ticket)["']?\s*[:=]\s*["']([A-Za-z0-9_\-.]{16,})["']""",
    re.I | re.X)
_TOKEN_COOKIE_RE = re.compile(
    r"(?:^|;\s*)(token|session|sessionid|jsessionid|sid)=([A-Za-z0-9_\-.]{16,})",
    re.I)


def _token_strong(v):
    """凭据值强度门槛：够长 + 字符集够丰富（排除 0000… / 递增序号）。"""
    v = (v or "").strip()
    if len(v) < 16:
        return False
    return len(set(v)) >= 8


def collect_token_map(base_url, client):
    """单主机：返回 {凭据值: [命中路径, ...]}（仅强度达标值）。

    拆出来是为了让 engine 能在 scan_target 收尾做**跨主机**汇总
    （同一凭据值出现在多台主机上 → 服务端全局静态下发）。
    """
    base = probe.soft404_baseline(base_url, client)
    if not probe.baseline_usable(base):
        log.warning("软 404 基线不可用，跳过 token 复用检测 %s", base_url)
        return {}
    where = {}
    for path in dicts.TOKEN_REUSE_PATHS:
        url = base_url.rstrip("/") + path
        try:
            r = client.get(url, purpose="token:reuse")
        except Exception as e:
            log.debug("token 复用探测异常 %s: %s", url, e)
            continue
        if not r or not r.status or r.status != 200 or not r.text:
            continue
        if probe.is_soft404(r, base):
            continue
        vals = set()
        for m in _TOKEN_VAL_RE.finditer(r.text):
            if _token_strong(m.group(2)):
                vals.add(m.group(2))
        for ck in (r.headers or {}).items():
            if ck[0].lower() != "set-cookie":
                continue
            for m in _TOKEN_COOKIE_RE.finditer(str(ck[1] or "")):
                if _token_strong(m.group(2)):
                    vals.add(m.group(2))
        for v in vals:
            where.setdefault(v, []).append(path)
    return where


def token_reuse_findings(base_url, tmap, scope_word="路径", min_hits=2):
    """由 {凭据值: [命中点]} 生成漏洞项（>= min_hits 个不同命中点才报）。"""
    findings = []
    for val, paths in (tmap or {}).items():
        if len(paths) < min_hits:
            continue
        masked = val[:6] + "***" + val[-4:]
        if scope_word == "主机":
            title = "会话凭据跨主机复用（服务端全局静态下发）"
            body = ("%d 台彼此独立的主机（%s）均返回**同一个**会话凭据值"
                    "（已脱敏：%s）。说明该凭据不是按会话随机签发，而是"
                    "服务端全局静态下发——任一主机泄露即对所有主机通用，"
                    "且无法通过重新登录轮换。"
                    % (len(paths), "、".join(paths[:4]), masked))
        else:
            title = "会话凭据跨端点复用（服务端静态下发）"
            body = ("匿名访问 %d 条彼此独立的路径（%s）均返回**同一个**会话"
                    "凭据值（已脱敏：%s）。说明该凭据不是按会话随机签发，"
                    "而是服务端静态/全局下发——任一途径泄露即对所有端点通用，"
                    "且无法通过重新登录轮换。"
                    % (len(paths), "、".join(paths[:4]), masked))
        findings.append(_finding(
            title, "medium", "medium",
            base_url.rstrip("/") if scope_word == "主机" else
            base_url.rstrip("/") + paths[0],
            body,
            request="", response="", payload="",
            cvss="CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:L/VI:L/VA:N",
            fix="会话凭据必须按会话随机签发（高熵、服务端存储），登录时轮换，"
                "并绑定会话有效期与来源约束；禁止使用全局静态 token。"))
        log.warning("[命中] %s token 复用 %d 个%s", base_url, len(paths), scope_word)
    return findings


def check_token_reuse(base_url, client):
    """单主机：同一会话凭据值跨多条路径复用 → 服务端静态下发。"""
    return token_reuse_findings(base_url, collect_token_map(base_url, client))
