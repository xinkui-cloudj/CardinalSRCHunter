@echo off
setlocal
title Cardinal-SRC-Hunter
rem ============================================================
rem  Portable launcher (ASCII only, no network, no pip at runtime).
rem  Prefers the bundled python\ next to this file; falls back to
rem  a system Python 3 if the bundle is absent.
rem ============================================================
cd /d "%~dp0"

set "PY="
set "PYW="
if exist "%~dp0python\python.exe" set "PY=%~dp0python\python.exe"
if exist "%~dp0python\pythonw.exe" set "PYW=%~dp0python\pythonw.exe"
if not defined PY if exist "%~dp0..\python\python.exe" set "PY=%~dp0..\python\python.exe"
if not defined PYW if exist "%~dp0..\python\pythonw.exe" set "PYW=%~dp0..\python\pythonw.exe"

if not defined PY (
  where py >nul 2>nul && set "PY=py -3"
)
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo [ERROR] No Python found and no bundled python\ directory.
  echo         Re-extract the package, or install Python 3.9+ with
  echo         "Add python.exe to PATH" enabled.
  pause
  exit /b 1
)
if not defined PYW set "PYW=%PY%"

if not exist "%~dp0logs" mkdir "%~dp0logs" >nul 2>nul
set "LOG=%~dp0logs\start.log"
echo ==== Cardinal-SRC-Hunter %DATE% %TIME% ==== > "%LOG%"

echo.
echo ============================================================
echo   Cardinal-SRC-Hunter - SRC vulnerability hunting suite
echo ============================================================
echo.
echo Checking GUI runtime ...
%PY% -c "import tkinter" >> "%LOG%" 2>&1
if errorlevel 1 (
  echo [WARN] tkinter check failed. Full log:
  echo ----- logs\start.log -----
  type "%LOG%"
  echo ---------------------------
  echo Falling back to console mode ...
  %PY% "%~dp0main.py" --help
  echo.
  echo [HINT] See "%~dp0logs\crash.log" for details.
  pause
  exit /b 1
)

echo Starting GUI ...
start "Cardinal-SRC-Hunter" /D "%~dp0" "%PYW%" "%~dp0main.py" gui
exit /b 0