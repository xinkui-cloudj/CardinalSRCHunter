# Cardinal-SRC-Hunter 交接文档 · round72

> 生成：2026-10-16 ｜ 代码版本 round72（round71 基线 + 三项遗留落地）
> 交付物：`dist-win/CardinalSRCHunter.exe` + `dist-win/CardinalSRCHunter-src.zip`
>         （哈希见 `dist-win/MD5SUMS.txt`，以该文件为准）

---

## §1 本轮做了什么

| 遗留 | 结论 | 落点 |
|---|---|---|
| ① engine.py 两处 `as_completed` 未传 timeout | round71b 已补 timeout；本轮补**超时后可判读**（观测缺口） | `core/engine.py::_log_pending_futures` |
| ② check_exe 未入 regall.sh | 已纳入，无条件执行、失败即红灯 | `lab/regall.sh` + `lab/check_exe_r72.py` |
| ③ round60 §6.1 三项检测器扩展 | 核实**已实现**（round71c），本轮补登记 | `core/dicts.py` / `modules/vulnchecks.py` / `core/engine.py` |

版本戳：`ui/web.py::_APP_VER = "r72"`、`build/make_sfx_exe.py::BUILD_ID = "r72-"`。

---

## §2 验证证据（可复现）

```sh
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter
python3 lab/verify_round71b.py      # round71b PASS=19 FAIL=0（超时+观测）
python3 lab/verify_round71c.py      # PASS=96 FAIL=0（三项检测器）
python3 lab/check_exe_r72.py        # 需先把 EXE 解到 /tmp/verify72
sh lab/regall.sh                    # 全量回归（64 脚本），日志自行重定向
```

EXE 解包复核已并入 `lab/regall.sh` 末尾，**无需再手工到 /tmp 跑**。

---

## §3 环境硬约束（继续有效）

- `read_file` 直读 `/storage/emulated/0/...` 可能报 `File does not exist`，走 terminal 或 `repo:Audiobooks`；
- 禁止 `set -e`（会卡死终端会话）；
- 含中文 + 复杂引号的批量替换，一律写成 `.py` 落 `/tmp/` 再执行（PTY 会改写中文引号致 `SyntaxError`）；
- `_PAGE` 内联 JS 拼 `onclick="fn(\'x\',true)"` 需**四重**反斜杠；改完必须 `node --check` 抽 `<script>` 校验；
- jsdom 子进程要 `cwd=/tmp/jsdomtest`；脚本末尾必须 `process.exit(0)`；
- 长命令必须拆短 + 显式传 `timeoutMs`；全量回归 > 5 分钟，用 `setsid nohup ... &` 后台跑再轮询 `grep -c '^===== '`；
- 跑完回归必查 `vuln_server.py` 残留（`pkill -9 -f vuln_server.py`）；
- 备份一律后缀式（`foo.py.bak_rNN`）+ `cp -p` 复制，**绝不能 `mv`/改名源文件**。

---

## §4 交付物重建顺序（权威）

```sh
python3 build/make_src_zip.py        # PACK + BAK_LEAK bad=0 + VERIFY bad=0
python3 build/make_sfx_exe.py pack   # [verify] MZ=True PE=True
python3 build/make_src_zip.py        # 再跑一次，刷新 dist-win/MD5SUMS.txt
```

---

## §5 下一轮方向

1. 工作区根目录 8 个 `tmp_patch_*.py` 临时补丁脚本清理（不进交付包，但会造成误读）；
2. 备份命名历史不统一（`.r62bak` / `.r63bak` 与 `.bak_rNN` 并存）；
3. 回归里 EXE 复核组目前是"零成本绿灯"路径，可在下一轮加入对 `dist-win` 之外
   残留（`/tmp/btsfx/payload/app/core/engine.py`）的比对，验证 EXE 载荷未陈旧。

---

*本文档随 round72 交付生成，与 `dist-win/CardinalSRCHunter-src.zip` 内源码一致。*
