# 交接文档 · round84（MCP/SKILL 插件真安装与真调用）
> 接手前先读 `进度.md` 与本文。本轮改动 5 个文件：
> `tools/mcp_client.py`、`ui/web.py`、`core/engine.py`、
> `tools/skill_exec.py`（新建）、`build/make_sfx_exe.py`。

## 1. 用户实机反馈
用户装好 r83 桌面板后导入 MCP 插件，程序不识别、不能调用，界面显示：
`MCP 工具 0 个（MCP 未生效：MCP 段未配置）`。
用户明确要求：ZIP 导入应该自己解压自己调用，不该让用户手动解压/填路径/管 python3。

## 2. 四层真因（全部代码级实证）

### ① ZIP 只抽 JSON，本体被丢弃（致命）
`ui/web.py::_mcp_import` 旧实现只 `zipfile.read(*.json)` 扫配置，
然后 `shutil.rmtree(tmpd)` 把整个 ZIP 删了。
后果：`server.py` **从来没有落过盘**，配置里只留一个 `args: ["server.py"]` 的幽灵条目。

### ② command 与 args 被拼成一整串（第二个致命 bug）
`_mcp_servers_from_obj` 旧代码：
```python
if isinstance(args, list) and args:
    cmd = (str(cmd) + " " + " ".join(str(a) for a in args)).strip()
```
把 `command="python3"` + `args=["server.py"]` 拼成 `command="python3 server.py"`。
`subprocess.Popen(["python3 server.py", ...])` 会把这个字符串当成**一个可执行文件名**，
直接 `FileNotFoundError`。实测 `why = FileNotFoundError: [Errno 2] ... python3 server.py`。
这是比 ① 更隐蔽的老 bug：就算脚本落了盘也永远起不来。

### ③ python3 在 Windows 不存在 + 无 cwd
包内 `mcp.config.json` 写的是 `{"command":"python3","args":["server.py"]}`。
Windows 通常只有 `python` / `py`，且 `MCPClient.start()` 不传 `cwd`，
子进程在程序自己目录找 `server.py`，永远找不到。

### ④ stderr 被 DEVNULL 丢弃
`stderr=subprocess.DEVNULL`，任何失败原因都看不到，
界面只剩一句固定文案「握手失败（进程起不来 / initialize 超时 / 非 JSON-RPC）」。

### ⑤ SKILL 只当提示词，脚本不可执行
`tools/skill_loader.py` 的 `install_pack` 只把 .md 正文拼成提示词落盘，
红线注释明写「不执行技能正文」。mega-offensive-suite 这类包里有 19 个可执行脚本，
装了也无法被 AI 调用。用户拍板：**B 方案（脚本要能被识别为可调用工具）+ 丙方案（入口发现规则）**。

## 3. 修复落点

### M 组 · MCP 真解压安装
| 文件 | 改动 |
|---|---|
| `ui/web.py` | 新增 `_mcp_install_root()`（`USER_ROOT/mcp/`）、`_mcp_extract_zip()`（zip-slip 安全解压，跳过 `__MACOSX`）、`_mcp_find_entry()`（找 server.py/main.py/index.js/server.js） |
| `ui/web.py` | `_mcp_import()` 整段重写：ZIP 真解压到 `USER_ROOT/mcp/<安全名>/`，找到入口后写 `rec["cwd"]`、`rec["args"]=[入口绝对路径]`、`rec["command"]=_norm_mcp_launcher(...)`，**导入成功自动开总开关** `m["enabled"]=True` |
| `ui/web.py` | `_mcp_servers_from_obj()` **修复 ②**：不再把 args 拼进 command，改为 `{name, command, args}` 三段结构 |
| `ui/web.py` | 新增 `_norm_mcp_launcher()`（web 侧同 M5 逻辑） |
| `tools/mcp_client.py` | `__init__` 增加 `cwd` 参数；`start()` 的 `Popen` 传入 `cwd` |
| `tools/mcp_client.py` | 新增 `_norm_launcher()`（python/python3/python.exe/python3.exe/py → `sys.executable`）、`_resolve_script()`（相对脚本转绝对并推导 cwd）、`_looks_like_script()` |
| `tools/mcp_client.py` | `load_from_config()` 接入上述归一化 |
| `tools/mcp_client.py` | stderr 从 `DEVNULL` 改 `PIPE`；新增 `_drain_stderr()`、`failure_reason()`（返回 `last_error｜exit=退出码｜stderr 末行`，无信息返回 `no-detail`） |
| `ui/web.py` | `_mcp_probe()` 失败时 `item["error"]=cli.failure_reason()`，新增 `item["hint"]` 区分「进程起不来」与「起来了但没回 JSON-RPC」 |

### S 组 · SKILL 可执行化（新文件 `tools/skill_exec.py`）
| 能力 | 说明 |
|---|---|
| `install_zip()` | ZIP 真解压到 `skills/<包名>/`，zip-slip 拦截，重装即覆盖 |
| `discover()` | **丙方案**：有 `tools.json`/`skill.tools.json` 用它；没有则按**目录约定**扫描（`tools` → `scripts` → `assets/detect-scripts` → `detect-scripts` → `assets/scripts` → `src-elite/tools`，命中即停；隐去 `__init__.py`/`setup.py`/下划线开头） |
| `_read_doc_line()` | 取 docstring 首行作描述（已修 shebang 干扰：先剥净 `#`/空行） |
| `run_tool()` | 子进程 `sys.executable <entry> <args...>`，越界直接拒（`entry 越界（必须在包目录内）`），超时 90s，输出截断 20000 |
| `load_from_config()` | 总开关关则返回空；`register_external(..., net=True)` 强制走授权闸门；`DANGER_KEYS`（webshell/reverse_shell/revshell/bruteforce/brute_force/exploit/ransom/ddos）命中即不注册 |
| `catalog()` | 只读盘点，供 Web/CLI 展示 |

### 引擎接线
`core/engine.py::_load_mcp_tools()` 末尾追加（与 MCP 并列、幂等、异常静默）：
```python
from tools import skill_exec, tool_registry as _tr2
_snames = skill_exec.load_from_config(self.config, _tr2)
```
注册前缀 `sk_`，日志分别打「已接入 MCP 工具 N 个」与「已接入 SKILL 可执行工具 N 个」。

### Web 接线
`_skill_upload()` 对导出两种包都接了真实安装：
- 纯脚本包（无 .md）：走 `mode=extract` 分支，真解压 + 返回 `tools`/`tool_names`；
- 带 .md 的包：`.md` 照旧文本安装，**同一份 ZIP 也真解压一份**，结果放在返回体 `extract` 字段。

## 4. 验证结果
| 项 | 结果 |
|---|---|
| `lab/verify_round84.py` | **PASS=57 FAIL=0**（M 组 21 + S 组 20 + E 组 4 + 实测 12，含 `failure_reason` 实测 `exit=3｜BOOM-MARKER`） |
| `lab/verify_round84_mcp_e2e.py` | **PASS=8 FAIL=0**（造 demo MCP 包 → 导入 → server.py 真落盘 → command 已归一 → 握手成功 → 拉到 `ping` 工具） |
| mega-offensive-suite-v5.5.zip 实测 | 2692 文件解压成功，discover 出 19 个工具，`run_tool(api_report.py --help)` 返回 `ok=True code=0`，越界 `../../etc/passwd` 被拦截 |
| 危险脚本过滤实测 | 造 `evil_webshell.py` 与 `hello.py` 同包，`load_from_config` 只注册 `sk_hello` |

## 5. 用户可感知的变化
改完后用户只需：**Web 控制台 → 导入 ZIP → 点「测试连接」→ 开始扫描**。
不再需要：手动解压、手动填入口路径、管 python3 在哪、手动去找 MCP 总开关。

SKILL 包也不用改：脚本放在 `assets/detect-scripts/` 这类非标准目录的包，
也能被自动发现为 19 个 `sk_*` 工具（如 `sk_sqli_tester`、`sk_xss_tester`）。
AI 调用时需要配 `args`（string 数组）参数。


### 附：第六层真因（回归回归后补记）
| 文件 | 改动 |
|---|---|
| `ui/web.py:2028` | `_mcp_probe()` 调 `_resolve_script(args, cwd, cmd)` 传 3 参，而 `tools/mcp_client.py::_resolve_script` 签名只有 2 参 → 探活必然 `TypeError`。已把签名改为 `def _resolve_script(args, cwd=None, cmd=None)` 兼容（15354 字节 / 424 行） |
| `ui/web.py::_mcp_probe` | hint 分流：新增 `_low = _fr.lower()`，命中 `filenotfound`/`找不到`/`no such file`/`cannot find`/`不是内部或外部命令` → 提示「进程未能启动：command 指向的可执行文件不存在（Windows 常见是 python3 不存在）」，不再谎报「子进程起来但没回 JSON-RPC」 |
| `lab/verify_round80.py` / `verify_round81.py` | 版本戳断言由硬编码 `r82` 改为运行时正则从 `ui/web.py` 提取 `_CUR`，后续升版不再需要改断言字面量 |
| `lab/verify_round84_mcp_e2e.py` | 每次运行在临时 zip 内重写 server 名（`demo-mcp-<ms>`），避免「同名已存在 → skipped → installed 为空」造成的假失败；8/8 PASS |
| `lab/verify_round66.py` | B20 清理断言改为「测试用 r66* 服务已全部移除」（原断言要求整个列表为空，会误伤用户真服务）；B8 前先清 `skills/pack` 解包残留 |
| `lab/verify_round49.py` / `verify_round50.py` | 口径对齐 `kind=all` 通用技能（L3/L7）；密钥扫描先剔除教学占位符 `sk-x{20,}` |
## 6. 教训
24. **「导入成功」不等于「装好了」**：只要写配置不落盘，就是假成功。凡是导入类功能，
   必须断言「产物真实存在于磁盘」且「路径可达」。
25. **`Popen` 的第一个元素必须是单个可执行文件名**：任何把 args 拼进 command 的代码
   在 Linux 上可能勉强能活（某些 shell=True 场景），在 Windows 上必死。
26. **静默吞异常是 bug 的温床**：`stderr=DEVNULL` 把「为什么失败」永远藏起来，
   排查成本从 1 分钟变成 1 小时。失败信息一定要透到 UI。
27. **heredoc 回显不可信**：本轮反复出现 heredoc 丢行/缩进被抹平，
   导致 `return obj` 顶格这种致命缩进错误。凡是用 heredoc 写代码，写完必须用
   `python3 -c` 打印 `repr(行内容)` 逐行复核，不能只看 `py_compile` 通过。

28. **断言也会过期**：技能体系加了 `kind=all`、命令改成 command/args 分离之后，
   老断言仍按旧口径写，就会持续误报。改功能时必须同步改断言口径。
29. **测试脚本不得依赖「干净世界」**：e2e 用固定名导入，第二次跑就 skip；
   测试脚本要先清理自己的历史残留（skills/pack、r66* 服务）或用唯一名。

## 7. 接手 checklist（本轮已完成 1-3）
1. ~~`python3 build/make_sfx_exe.py all` 重打包~~ ✅ 已完成，`VERSION = r84-20261019-1332xx`，EXE 26308395 B，MD5 `afc3f57a792088d6dcde968a64f1e796`。
2. ~~`sh lab/regall.sh` 全量回归~~ ✅ 已完成，`REGALL TOTAL PASS=3681 FAIL=2 SCRIPTS_FAILED=1`，唯一失败来自回归期间临时文件竞争（round66 B8，已加清理后单独跑 71/0）；8 个关键脚本单独复验全绿。
3. ~~覆盖 `/sdcard/AI文件/CardinalSRCHunter.exe`~~ ✅ 已覆盖，MD5 一致。
4. 用 `/sdcard/AI文件/src_elite_mcp-mcp-plugin-v4.2.zip` 在 Windows 上实测导入 + 连接。
