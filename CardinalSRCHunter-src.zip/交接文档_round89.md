# 交接文档 round89 —— 真实报告驱动的误报修复（FIX-14）+ Web 控制台模型弹窗可用性修复

> 本轮无虚构、无角色扮演。全部改动落在工作区源码与 `dist-win/`，以实测断言与真实报告证据为准。
> 交付校验值一律以 `dist-win/MD5SUMS.txt` 为唯一来源（不在文档里写死 md5，避免「文档变则 EXE 变」的自指循环）。

---

## 1. 用户本轮两条诉求（原话照录）

1. 「我刚测的 `lanli.cc`，报告 31 条，**31 条重复是不是不太正常**？」
2. 「Web 控制台里点『刷新模型』，列表太长**滑不下去**，**点不到全选/确定**的按钮。」

两条都在既定授权内（该升级的升级、该修的修、发现即修不请示），本轮全部修完并固化为断言。

---

## 2. 诉求一：31 条「重复」不正常 —— 是 31 条**误报**，且核验层同步失效

### 2.1 证据硬事实（用户补发的报告包，实测）

| 项 | 实测值 |
|---|---|
| `findings.json` 条数 | 31 |
| 类型分布 | 100% 为「账号枚举（用户名存在性泄露）」 |
| `grep '^HTTP ' evidence/*.txt` | **31/31 全部 HTTP 405** |
| 覆盖主机数 | 21 台（`beta.lanli.cc`、`alipay.lanli.cc` 各 3；`assets/android/announce/callcenter/cdn/channel` 各 2；其余 15 台各 1） |
| 证据内标记 | `Verified: yes`（核验器盖章通过） |
| 请求体 / 头 | `{"username":"admin"}`、带 `X-Bug-Bounty: bt-src-hunter` |
| 响应特征 | `Server: nginx/1.26.1`、`Content-Length` 559/157 等，正文为 nginx 默认 405 页 + `<!-- a padding to disable MSIE and Chrome friendly error page -->` |
| `summary.json` | `stats {total:31, medium:31}`、`meta.intensity=aggressive`、`deduped_count=0` |

**先纠正一个理解偏差**：这不是「去重没生效导致 31 条重复」，`deduped_count=0` 是因为 31 条的**主机/路径各不相同**，去重器本来就不该合并。真正的问题是 31 条**全部为假**。

### 2.2 根因链（一句话版）

> nginx 把 405 错误页随机填充到约 512 字节 → 两次请求正文不同 → `difflib.SequenceMatcher.ratio()` 对长文本小差异极敏感、跌破 `_USER_ENUM_SIM=0.9` → 检测层门槛 3「对照名必须与不存在名可区分」被**误满足** → 产 finding；核验层同口径 `d1<0.9 and d2<0.9` → 判 `confirmed` 并写 `Verified: yes`。

**语义判决**：`405 Method Not Allowed` = 端点不接受该请求方法，服务端**根本没有执行用户名判定**。在 405 上讨论「用户名是否存在」在任何口径下都不成立。所以 31 条是 100% 误报，修完重扫应当归零。

### 2.3 修法（FIX-14：非业务状态码 + 正文白化，检测/核验双层闸）

| 落点 | 内容 |
|---|---|
| `modules/vulnchecks.py:35` | `_NON_BUSINESS_STATUS = (404, 405, 501, 505)` |
| `modules/vulnchecks.py:38` | `_normalize_body()`：`_COMMENT_RE` 去 HTML 注释 + `_WS_RE` 去空白，截 8000 字符 |
| `modules/vulnchecks.py:43` | `_body_similarity()`：白化后相等直接 `1.0`；双空也 `1.0`；否则 `ratio(na[:4000], nb[:4000])` |
| `modules/vulnchecks.py:53` | `_is_non_business(status)` |
| `modules/vulnchecks.py:1227-1236` | `check_user_enum` 门槛 2 之后插入**检测层闸**：三个响应任一命中非业务码即 `continue`，不产 finding |
| `core/verify.py:1188-1207` | `verify_account_enum` 内**核验层独立闸**：延迟导入 `_is_non_business as _is_nb`（失败降级 `lambda st: False`），四响应取非业务码列表，非空即返回 `UNKNOWN` + `detail` 带 `non_business_status`，绝不写 `Verified: yes` |

**403 / WAF 特意未进白名单**：403 仍由既有 FIX-6 / FIX-12 通道自证（拦截墙识别、通道自证），避免「一刀切死」把真实拦截场景也判死。

---

## 3. 诉求二：模型选择弹窗滑不动、点不到按钮

### 3.1 改造内容（`ui/web.py`，全部用模块级 `_PAGE` 实测命中）

| 选择器 | 改动 |
|---|---|
| `.mask` | `align-items:flex-start` + `overflow:auto` + `-webkit-overflow-scrolling:touch` + `padding:3vh 0` |
| `.modal` | `max-height:94vh; min-height:0; margin:0 auto` |
| `.mlist` | `flex:1 1 auto; min-height:88px; overscroll-behavior:contain` |
| `.mbar` | **新增**，`position:sticky; bottom:0`（按钮条永远可见，不再被长列表顶出屏幕） |
| `.mfind` | **新增**，全宽过滤框 |

`showModelPicker`（`ui/web.py:1098` 起）重写为：过滤框 + 实时 `render()` + 计数「已选 X / 共 Y，当前显示 Z」+ 按钮「全选当前 / 清空当前 / 清空全部 / 确定 / 取消」，全选/清空**只作用于过滤后的可见项**。

### 3.2 回归抓出的真实兼容缺陷（已修）

`lab/verify_round66.py` 的 D9/D11 首跑 FAIL：jsdom 测试直接 `cbs[0].checked = true` 后点「确定」，**不派发 `change` 事件**，而 `cur` 只靠 `onchange` 维护 → 写回 `#ai-model` 为空。

修法：`showModelPicker` 内新增 `const sync = function(){ visible().forEach(...) }`，在「确定」写回 `#ai-model` 之前调用 `sync()`，把 DOM 勾选状态回灌 `cur`。注释写明原因：脚本化/无障碍点击、部分移动端 WebView 直接改 `checked` 不触发 `onchange`。同时去掉「全选当前」处理器里多余的 `cnt.textContent=...`（`render()` 已统一刷新计数）。

---

## 4. 断言资产（本轮新增，已挂 `lab/regall.sh`）

| 脚本 | 项数 | 覆盖 |
|---|---|---|
| `lab/verify_round89_fix14.py` | 33 | A：先证明「padding 0 vs 4 条原始 ratio 确实 < 0.9」复现误判前提，再证白化后 `=1.0`；B：状态码白名单（404/405/501/505 命中，200/201/302/400/401/403/500/502 不命中，`None`/`'x'` 不抛异常）；C：monkey-patch `_enum_call` 造 405/501 + padding 抖动 → **0 finding**，200 可区分仍命中 5 条（正反对照）；D：405/501 核验 → `inconclusive` 且 detail 带 `non_business_status`，200 可区分 → `confirmed`；E：源码守卫 |
| `lab/verify_round89_ui.py` | 18 | A：弹窗结构/文案 13 项（限定在 `showModelPicker` 函数体内判，避免撞 round70 列表页同名按钮）；B：**活体复现** —— 真起 `ThreadingTCPServer` 的「nginx 式」服务（`bt-nonexist` → 真 404，其余 → 405 + 循环 padding），用真实 `HttpClient` 跑 `check_user_enum` / `verify_account_enum`，断言 0 finding、环境中确有 405、核验 `inconclusive`、evidence 含 405、不再 `confirmed` |

---

## 5. 本轮顺带修掉的两处历史红灯

| 脚本 | 症状 | 根因 | 修法 |
|---|---|---|---|
| `lab/verify_round66.py` | `PASS=69 FAIL=2`（D9 单选回填、D11 多选逗号拼接） | 见 §3.2，我新写 JS 的真实缺陷 | 加 `sync()` → `PASS=71 FAIL=0` |
| `lab/verify_round31.py` | `PASS=25 FAIL=4`（C2/C3/E2/F1） | 本机网络 v4-only：`v6=[]`、`v6_hits=0/20`、`/proc/net/if_inet6: Permission denied` | 新增 `SKIPS` + `skip(name, why)` + 启动探测 `_V6_ENV`，IPv6 用例「有环境硬判、无环境 SKIP」；F2/F3 静态守卫照旧硬判 → `PASS=25 FAIL=0 SKIP=4` |

**计数对账**：3927（上轮基线）+ 33（fix14）+ 18（ui）= 3978，减 4（round31 转 SKIP）= **3974**，与实测一致。

---

## 6. 最终验收数字

```
REGALL TOTAL PASS=3974 FAIL=0 SCRIPTS_FAILED=0
lab/check_exe_r82.py   BAD=0  TOTAL PASS=175 FAIL=0
```

EXE 内容核对（7z 从 `dist-win/CardinalSRCHunter.exe` 解出全量）：`app/进度.md` **与源码逐字节一致（`diff -q` + md5 双证，不写死行数以免文档自指）**；`app/mcp/` 为空占位；`r66mcp*` / `r84mcp*` / `r85probe` / `r85e2e` / `reports/` / `findings.db` / `ai_key.txt` **stray 零命中**。

源码 zip：`files=205`（较上轮 203 增加 2，正是新增的两个 lab 脚本），`BAK_LEAK bad=0`、`VERIFY bad=0`；zip 内 `进度.md` 与源码一致。

---

## 7. 遗留（本轮未动，需人工/定向确认）

- `www` 目标上的 **24 条 403** 仍未定向确认（老遗留，不属本轮 FIX-14 命中的 405 类别；403 按设计不进非业务白名单，仍走 FIX-6/FIX-12 拦截墙通道）。
- 用户需实机跑一次新 EXE：①Web 控制台弹窗能滑到底、能点「全选当前 / 确定」；②对 `lanli.cc` 重扫，账号枚举类应归零。

---

## 8. 本轮新增工艺坑（累计 18 条，追加 ⑲）

⑲ **`check_exe_r82.py` 依赖先手工解包到 `/tmp/verify82`**（脚本头注释即写明）。若跳过解包直接跑，脚本会拿「上一轮的旧提取目录」比对，报出一批 `BAD`；若解包时加了 `'app/*'` 这类子集过滤，又会因缺少 `python/` 等目录产生假红（实测 15 BAD）。**正确姿势：`rm -rf /tmp/verify82 && mkdir -p /tmp/verify82 && 7z x -y -o/tmp/verify82 dist-win/CardinalSRCHunter.exe`（不加过滤），再跑脚本。**
