# 交接文档 · round61

> 生成时间：2026-10-12 10:36
> 代码版本：round61（round60 取消"未授权域名"概念 + 交付基线去运行期回写段）
> 前置文档：`交接文档_round60.md`（round60 主体改动说明）
> 本文档只覆盖 round61 增量 + 当前权威状态，接手请先读本文档，再看 round60。

---

## §0 一句话结论

round60 交付物（EXE / zip / report）曾在打包后被程序自测运行**回写污染**：源 `config/config.json` 多出 `ai_ui` 段，
导致 zip/EXE 内嵌的 config 与源码基线不一致。round61 删掉了这个"每次运行都会回写"的 `ai_ui` 默认段（全工程零消费方），
归一了源 config，迁出工程根下 7 个目录式备份，重跑全量回归（`PASS=2184 FAIL=0 SCRIPTS_FAILED=0`）并重建全部交付物。

---

## §1 本轮改了什么

| 文件 | 改动 | 前 → 后 |
|---|---|---|
| `core/config.py` | ① 删除 `DEFAULT_CONFIG` 的 `ai_ui` 顶层段（含 3 个字段）② `save()` 补末尾换行使写回幂等 | 373 行 → **367 行** |
| `config/config.json` | 删 `ai_ui` 段，并重写为 `save()` 规范形态（`indent=2` + 末尾换行），与 dist 副本一致 | 125 行 → **120 行** |
| 工程根 | 7 个目录式备份迁出 | 见 §3 |

改动副本：`core/config.py.bak_r61`、`config/config.json.bak_r61_aiui`（均在原位置，后缀式，不参与 `os.walk` 污染）。

---

## §2 为什么必须删 `ai_ui`（根因，非一次性污染）

`core/config.py::Config.load()` 的实现是：

```python
self.data = _deep_merge(DEFAULT_CONFIG, user)
```

即"默认配置深合并磁盘上的用户配置"。只要 `DEFAULT_CONFIG` 里有 `ai_ui` 段，**每次程序启动都会把该段补进内存并回写落盘**。
round60 打包时源 config 是干净的，但程序自测一跑（工作区附件显示 `config/config.json` 被修改），`ai_ui` 段就被写回来了——
于是"源 config"与"EXE/zip 内嵌 config"永久漂移，每重建一次就再脏一次。

**第二个根因（本轮一并根治）**：`Config.save()` 用 `json.dump(indent=2)` 重序列化整个配置，且**不写末尾换行**。
回归脚本 `lab/verify_round34.py` 的 E 组会真实调用 `web.save_config()` 写回源 `config/config.json`
（其 `finally` 只把备份 copy 回去，而备份本身也已被重写），于是每跑一次回归就把 `mcp` 段从单行展开成多行、并丢掉末尾换行。
故 round61 除删段外，还给 `save()` 补 `f.write("\n")`，并把源 config 与 dist 副本统一重写为 `save()` 的规范形态——
现在 `save()` 是幂等的：跑完全量回归后 `diff` 仍返回 `IDENTICAL`。

全工程检索确认 `ai_ui` **没有任何消费方**：

```
grep -rn 'ai_ui' ui/ tools/ core/ main.py
→ core/config.py:85（仅默认段定义本身）
```

故删除是零风险的，且是唯一根治手段（否则只能每次打包前手动清、下次运行再脏）。

---

## §3 备份目录离场清单

迁出目标：`/storage/emulated/0/Audiobooks/bak_offsite_round60/`

- `.bak_r26`、`.bak_r27`、`.bak_r28`、`.bak_r30`、`.bak_r31`、`.bak_r32`
- `templates.bak_r43`

共 **7 个目录**。迁出后 `ls -d /sdcard/Audiobooks/src/bt-src-hunter/.bak_*` 与 `*.bak_r*`（目录）均为空。

**为什么必须迁**：回归脚本用 `os.walk(ROOT)` 扫工程根，目录式备份会被扫到。
round60 首轮回归失败（`verify_round39.py` D5，`.draft` 字面量"仅出现在契约处"断言）就是 `.bak_round60/` 被扫到所致。
铁律：**备份一律后缀式（`foo.py.bak_rNN`），不要目录式（`.bak_rNN/`）**；后缀式文件不被 `os.walk` 当敏感产物扫。

---

## §4 当前权威状态

| 项 | 值 |
|---|---|
| 全量回归 | `REGALL TOTAL PASS=2184 FAIL=0 SCRIPTS_FAILED=0`（54 脚本） |
| 回归日志 | `/tmp/regall_r61.txt`（本轮权威；`/tmp/regall_r60b.txt` 为 round60 权威；`/tmp/regall_r60_final.txt` 已弃用，截断无汇总行） |
| 源 config 行数 | 120 行（与 dist 副本 `IDENTICAL`；回归跑完仍 `IDENTICAL`） |
| `core/config.py` | 367 行，`ast.parse` 通过 |
| 工程根备份目录 | 0 个 |
| 靶场进程 | 已 `kill`，零残留 |

---

## §5 交付物

重建顺序（**必须按此顺序**，EXE 内嵌代码副本）：

```sh
python3 build/make_src_zip.py        # 出 PACK + BAK_LEAK bad=0 + VERIFY bad=0
python3 build/make_sfx_exe.py pack   # 出 [verify] MZ=True PE=True
python3 build/make_src_zip.py        # 再跑一次刷新 MD5SUMS.txt
```

权威 MD5 见 `dist-win/MD5SUMS.txt`（以文件内容为准，勿从旧文档抄）。

---

## §6 下一轮方向

1. round60 交接文档 §6.1 的三项检测器扩展（账号枚举 / 硬编码 RSA 公钥 / token 跨主机复用）仍可做；
2. `www.langhanyun.cn` 报告的组件版本漂移说明；
3. `tools/scope_sync.py --fetch` 改造为「指定目标域 + 相关性过滤」；
4. round59 的 `takeover` 段（默认全关）可做一次 `mode=advisory` 真实联调。

---

## §7 环境硬约束（继续有效）

- `read_file` 直读 `/storage/emulated/0/...` 会报 `File does not exist`，走 terminal 或 `repo:Audiobooks`；
- 禁止 `set -e`（会卡死终端会话）；
- **含中文 + 复杂引号的批量替换，一律写成 `.py` 落 `/sdcard/` 再执行，不要 heredoc 内联**（PTY 会改写中文引号致 `SyntaxError`）；
- 长命令必须拆短 + 显式传 `timeoutMs`；全量回归耗时 > 5 分钟，用 `setsid nohup ... &` 后台跑再轮询 `grep -c '^===== '`；
- `edit_file` 改文件尾部会追加重复碎片——改完必须 `ast.parse` 体检；
- `kill` 靶场：跑完回归必查 `vuln_server.py` 残留。

---

*本文档随 round61 交付生成，与 `dist-win/CardinalSRCHunter-src.zip` 内源码一致。*