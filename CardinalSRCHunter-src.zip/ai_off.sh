#!/usr/bin/env bash
# 一键关 AI：确认当前是零网络状态
set -u
cd "$(cd "$(dirname "$0")" && pwd)"
unset BTSRHUNTER_AI_ENABLED BTSRHUNTER_AI_ONLINE BTSRHUNTER_AI_BASE BTSRHUNTER_AI_MODEL BTSRHUNTER_AI_KEY 2>/dev/null || true
echo "[-] 已清除 AI 环境变量（磁盘 config 本来就是关的）"
python3 -c "from core.config import Config;a=Config().ai();print('enabled=%s online=%s review=%s poc=%s'%(a['enabled'],a['online'],a['review_required'],a['allow_poc_suggestion']))"
