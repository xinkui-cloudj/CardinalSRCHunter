@echo off
setlocal
title Cardinal-SRC-Hunter builder
rem ============================================================
rem  Developer helper: build the project into a single-file
rem  CardinalSRCHunter.exe via PyInstaller.  Output: dist\CardinalSRCHunter.exe
rem  Not needed for end users - the shipped Setup.exe is already
rem  self-contained.
rem ============================================================

cd /d "%~dp0"
echo.
echo ============================================================
echo   Cardinal-SRC-Hunter - build Windows EXE
echo ============================================================
echo.

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo [ERROR] Python 3.9+ not found. Install it first.
  pause
  exit /b 1
)

echo [1/3] Ensuring PyInstaller is installed ...
%PY% -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo [WARN] PyInstaller install may have failed, continuing ...
)

echo.
echo [2/3] Installing runtime dependencies (bundled into the exe) ...
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo [WARN] Some dependencies failed to install; the build may lack modules.
)

echo.
echo [3/3] Building (single file, may take several minutes) ...
%PY% build\build_exe.py --clean

if errorlevel 1 (
  echo.
  echo [FAIL] Build did not complete. You can try:
  echo   - temporarily disable antivirus and retry
  echo   - use the onedir variant: %PY% build\build_exe.py --clean --onedir
  pause
  exit /b 1
)

echo.
echo ============================================================
echo   Done. Output: dist\CardinalSRCHunter.exe
echo   Double-click to run; first launch sets up prerequisites.
echo ============================================================
echo.
if exist "dist" explorer "dist"
pause
endlocal