# 交接文档 · round71
> 生成时间：2026-10-16 05:35
> 代码版本：round71（round70 基线 + B 方案体验层提示落地 + 版本戳升 r71）
> 前置文档：`交接文档_round70.md`、`项目总结报告.md` 第十节（round70 详情）
> 接手请先读本文档 §0/§1，再看 `项目总结报告.md` 第十/十一节。

---

## §0 一句话结论
round70 遗留的**需求④「无插件状态下扫不出东西」本轮闭环**。
定性结论：**不是程序缺陷** —— 实测该现象是「AI 增强默认关闭 + 未安装 SKILL/MCP」下的**必然结果**：
确定性扫描（URL 探测 / 指纹 / 弱口令）照常产出，只是**漏洞检测环节没有任何 AI 产出**，
而此前**界面与 CLI 完全没有给过任何提示**，用户无从判断"是不是坏了"。
本轮按用户拍板的 **B 方案**只补体验层：在 Web 控制台启动横幅与 CLI 扫描入口显式提示，
不触碰任何 AI 判定核心逻辑。改动已落源码、`verify_round71.py` 20/20 全绿、交付物已重建。

---

## §1 本轮改了什么
| 文件 | 改动 |
|---|---|
| `tools/capability.py` | **新增** `scan_note(engine)`（96 行起，文件 115 行）：判定 + 文案**单点收敛**，异常一律退化为空串 |
| `ui/web.py` | 新增 `_ai_banner_notes()`（43 行起，伪 engine= `cfg.Config()`）；启动横幅打印（1577 行）；`_APP_VER` → `r71` |
| `ui/cli.py` | `cmd_scan` 内 `eng = Engine(...)` 之后插入 12 行同款提示（163-167 行）；文件 409 → 421 行 |
| `build/make_sfx_exe.py` | `BUILD_ID` → `r71-` |
| `lab/verify_round71.py` | **新增**（172 行，A 层 11 项 + B 层四象限 + B5 + C 层 2 项，共 20 断言） |
| `lab/regall.sh` | 收录 `verify_round71.py`（脚本数 60 → 61） |
| `lab/verify_round66.py` `verify_round67.py` | 版本字面量 `r70` → `r71`（r66 1 处 / r67 30 处），否则 A1/D2/D3/D4 会 FAIL |
| `项目总结报告.md` | 版本行更新 + 新增第十一节（连尾注版本行一并 → r71） |

**B 方案核心资产（单点维护）**：`tools/capability.py::scan_note(engine)`
```python
try:    ai_ok = bool(engine.config.ai_ready())
except: ai_ok = False
c = list_capabilities(engine)
has_cap = bool(c.get("skills") or c.get("mcp_servers"))
if ai_ok and has_cap: return ""
return "  当前仅确定性扫描，漏洞环节无 AI 产出\n  如需漏洞检测请启用 AI 并安装 SKILL/MCP"
```
判定为 **AND**：AI 未就绪**或** SKILL/MCP 清单全空 → 出提示；最外层 `except Exception: return ""`，
**绝不阻断启动或扫描**。web（伪 engine）/ cli（真实 Engine）共用同一份文案，UI 层不复制判定逻辑。

---

## §2 需求④闭环说明
| 项 | 内容 |
|---|---|
| 用户原始反馈（录屏） | 无插件状态下点扫描，界面「扫不出东西」 |
| 实测定性 | 确定性扫描正常；**漏洞环节无 AI 产出**是 AI 增强关闭 + 无 SKILL/MCP 的必然结果 |
| 唯一真缺陷 | 体验层**零提示**，用户无法区分「没结果」与「功能异常」 |
| 本轮处置 | B 方案：Web 控制台启动横幅 + CLI 扫描入口显式提示（不改判定逻辑） |
| 状态 | ✅ 已闭环（round70 文档中该行「⏸ 待用户补」已作废） |

---

## §3 当前权威状态
| 项 | 值 |
|---|---|
| 全量回归 | `REGALL TOTAL PASS=2609 FAIL=0 SCRIPTS_FAILED=0`（61 脚本，日志 `/tmp/regall_r71f.log`） |
| 首跑（未同步 r66/r67 版本字面量） | `PASS=2600 FAIL=9 SCRIPTS_FAILED=2`（r66 A1 + r67 A1/D2/D3/D4）→ 修正后复跑全绿 |
| 本轮定向验证 | `python3 lab/verify_round71.py` → `round71 PASS=20 FAIL=0` |
| `ui/web.py` | 1608 行，`_APP_VER = "r71"`，`ast.parse` 通过 |
| `ui/cli.py` | 421 行，`ast.parse` 通过 |
| `tools/capability.py` | 115 行 |
| 冒烟证据 | 伪/真 engine 双路径 note 均为两行提示；`ai_ready=False`；`caps={'skills':2,'mcp_servers':0,...}` 仍出提示（证明 AND 判定） |
| 靶场进程 | 跑完必 `pkill -9 -f vuln_server.py`，零残留 |

---

## §4 交付物（`dist-win/MD5SUMS.txt` 为权威）
见 `dist-win/MD5SUMS.txt`（本轮重建后以该文件为准；重建顺序与 round70 一致）：
```sh
python3 build/make_src_zip.py        # 出 PACK + BAK_LEAK bad=0 + VERIFY bad=0
python3 build/make_sfx_exe.py pack   # 出 [verify] MZ=True PE=True
python3 build/make_src_zip.py        # 再跑一次刷新 MD5SUMS.txt
```
（对 round70 的 hash 变化是预期结果：源码与版本戳均已变。）

---

## §5 事故记录（本轮唯一一次险情，已闭环）
| 项 | 内容 |
|---|---|
| 现象 | `ui/cli.py` **本体消失**，仅剩 `ui/cli.py.bak_r71`（17951 B，04:47，409 行） |
| 排查 | `ls -la ui/` + `find . -name 'cli.py*'` → 确认只有备份；`head -25` / `wc -l` / `grep capability\|scan_note` 确认该备份即未含 B 代码的原版 |
| 排除 | `grep -n 'bak_r\|rename\|os.replace\|shutil.move' build/*.py` → 构建脚本只做「排除 .bak」，非改名元凶 |
| 恢复 | `cp -p ui/cli.py.bak_r71 ui/cli.py`（保留时间戳）+ `ast.parse` → `cli.py RESTORED OK` |
| 风险根因 | 项目**不是 git 仓库**（`fatal: not a git repository`），`.bak_rNN` 副本是**唯一回滚手段** |
| 纪律 | **备份必须 `cp` 复制，绝不能 `mv`/改名源文件**；改任何文件前先确认本体存在 |

---

## §6 下一轮方向
1. **遗留缺陷（round70 已登记，本轮未动）**：`core/engine.py` 两处 `ThreadPoolExecutor` + `as_completed(futs)` 未传 `timeout=`（`_check_url` 并发 URL 检查、`scan_target` 并发主机扫描），是「完整回归偶发卡住」的候选根因；
2. 可加 `check_exe_r71.py` 进 `regall.sh`（当前 EXE 解包复核需手工到 `/tmp` 再跑）；
3. round60 交接文档 §6.1 的三项检测器扩展仍可做；
4. 备份命名历史不统一（`.r62bak`/`.r63bak` 与 `.bak_rNN` 并存），交付前一律靠 `BAK_LEAK bad=0` 兜底。

---

## §7 环境硬约束（继续有效）
- `read_file` 直读 `/storage/emulated/0/...` 可能报 `File does not exist`，走 terminal 或 `repo:Audiobooks`；
- 禁止 `set -e`（会卡死终端会话）；
- **含中文 + 复杂引号的批量替换，一律写成 `.py` 落 `/tmp/` 再执行**（PTY 会改写中文引号致 `SyntaxError`）；
- `_PAGE` 内联 JS 拼 `onclick="fn(\'x\',true)"` 需**四重**反斜杠；改完必须 `node --check` 抽 `<script>` 校验；
- jsdom 子进程要 `cwd=/tmp/jsdomtest`；脚本末尾必须 `process.exit(0)`；
- 长命令必须拆短 + 显式传 `timeoutMs`；全量回归 > 5 分钟，用 `setsid nohup ... &` 后台跑再轮询 `grep -c '^===== '`；
- 跑完回归必查 `vuln_server.py` 残留（`pkill -9 -f vuln_server.py`）；
- 备份一律后缀式（`foo.py.bak_rNN`），不要目录式（`os.walk` 会扫到）。

---
*本文档随 round71 交付生成，与 `dist-win/CardinalSRCHunter-src.zip` 内源码一致。*
