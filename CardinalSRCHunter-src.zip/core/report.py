# -*- coding: utf-8 -*-
"""报告生成：补天（butian）风格三段式漏洞报告。

产出结构：
    reports/<target>-<YYYYmmdd-HHMMSS>/
        report.md            # Markdown 版（可直接粘贴到补天）
        report.html          # HTML 版（带样式，方便截图/存档）
        evidence/<n>_<类型>.txt   # 每个漏洞的请求/响应原文
        summary.json         # 机器可读汇总

补天提交要素：标题 / 漏洞类型 / 危害等级 / 复现步骤 / 请求包 / 响应包 /
影响范围 / 修复建议 / 复现证据。
"""
import csv
import datetime
import html as _html
import io
import json
import os
import re
from urllib.parse import urlsplit
from . import __version__
from . import config as cfg
from . import logger

log = logger.get("bt.report")

SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
SEV_CN = {"critical": "严重", "high": "高危", "medium": "中危",
          "low": "低危", "info": "信息"}
# 缺陷 E 修复：置信度分档。原来 confidence 只作为普通字段渲染，
# 大量 low 置信度疑似项照样按 severity 排进「严重/高危」，报告看着
# 一堆高危实则未复现，提交补天会被判误报。这里给置信度建独立分档，
# 排序键纳入置信度作次级，并把未复现的低置信度项显式标注「待人工确认」。
CONF_ORDER = {"high": 0, "medium": 1, "low": 2, "unknown": 3}
CONF_CN = {"high": "高", "medium": "中", "low": "低"}
# 未复现且低置信度的分档键，报告层统一按此判定「待人工确认」
CONF_PENDING = ("low", "unknown")
SEV_COLOR = {"critical": "#b71c1c", "high": "#e64a19", "medium": "#f9a825",
             "low": "#2e7d32", "info": "#546e7a"}
PLATFORM_NAME = {"butian": "(请填写你的平台)", "edu": "教育行业SRC",
                 "cnvd": "CNVD", "generic": "通用"}


def _safe_name(s):
    """把任意字符串压成文件名安全片段。

    只剔除路径分隔符 / 引号 / 控制符等危险字符，保留中文（\\w 在
    Python3 str 模式下默认匹配 Unicode 字母）。原来用 [^A-Za-z0-9_.-]
    会把中文漏洞类型整体吃成下划线，evidence 文件名退化成 "02__.txt"，
    提交补天时无法辨认，这里放开 CJK。
    """
    s = re.sub(r"[^\w.\-]+", "_", (s or "target").strip(), flags=re.UNICODE)
    s = s.strip("._") or "target"
    return s[:60] or "target"


def _conf_of(f):
    """归一化置信度：返回 (档位, 中文, 是否待人工确认)。

    缺陷 E 修复配套。待人工确认 = 未复现 且 置信度低/缺失。
    已复现项无论置信度如何都不再标"待确认"（PoC 已实证）。
    """
    raw = str(f.get("confidence") or "").strip().lower()
    tier = raw if raw in CONF_ORDER else "unknown"
    verified = bool((f.get("extra") or {}).get("verified")) \
        if isinstance(f.get("extra"), dict) else False
    pending = (not verified) and (tier in CONF_PENDING)
    return tier, CONF_CN.get(tier, raw or "-"), pending


def _verify_of(f):
    """读取核验层的三档结论，返回 (verdict, 中文, 证据说明)。

    核验结论由 core/verify.py 经 db.set_verdict 写进
    findings.extra["verify_verdict"]。报告层据此：
      - refuted      → 从主报告剔除（误报不提交）
      - confirmed    → 状态列标"已证实"
      - inconclusive → 状态列标"无法判定"，保留但提示人工复核
    未核验过的行返回 ("", "", "")，行为与改造前完全一致。
    """
    ex = f.get("extra")
    if not isinstance(ex, dict):
        return "", "", ""
    v = ex.get("verify_verdict") or ""
    if v not in ("confirmed", "refuted", "inconclusive"):
        return "", "", ""
    cn = {"confirmed": "已证实", "refuted": "已证伪",
          "inconclusive": "无法判定"}.get(v, v)
    return v, cn, str(ex.get("verify_evidence") or "")

def _sort_key(f):
    """报告排序键：severity 主序、confidence 次序、已复现优先。

    缺陷 E：原来只按 severity 排，导致 low 置信度的疑似项和已复现的
    确认项混排在一起，读者无法一眼分辨哪些是实证、哪些是待核。
    """
    sev = SEV_ORDER.get(f.get("severity", "info"), 9)
    tier = _conf_of(f)[0]
    conf = CONF_ORDER.get(tier, 9)
    verified = bool((f.get("extra") or {}).get("verified")) \
        if isinstance(f.get("extra"), dict) else False
    # 核验已证伪的排最后（通常在 generate() 里已被剔除，此处兜底：
    # 单独消费 all_findings 的调用方仍能得到"证伪沉底"的稳定顺序）
    refuted = 1 if _verify_of(f)[0] == "refuted" else 0
    return (sev, 0 if verified else 1, refuted, conf)


def _meta_of(f):
    """从 finding 的 extra 字段取出攻击面元信息。

    findings 行的 extra 由 db._hydrate 还原成 dict。GET 面与 POST 面
    在库里是两条独立记录（去重键含 method），如果报告不渲染 method/
    param/body_keys，同一 URL 的两条 finding 在报告里会长得一模一样，
    提交到补天时无法区分是 query 注入还是表单注入。

    返回 (method, param, body_keys, verified)：
        method    —— 大写 HTTP 方法，缺省 "GET"
        param     —— 命中的参数名（POST 面即表单字段名）
        body_keys —— POST 表单的字段名列表（GET 面为空）
        verified  —— 是否已被 PoC 层复现
    """
    ex = f.get("extra")
    if not isinstance(ex, dict):
        ex = {}
    method = str(ex.get("method") or f.get("method") or "GET").upper()
    param = ex.get("param") or f.get("payload_param") or ""
    body_keys = ex.get("body_keys") or []
    if not isinstance(body_keys, (list, tuple)):
        body_keys = []
    return method, str(param or ""), [str(x) for x in body_keys], bool(ex.get("verified"))


def _host_key(netloc):
    """把主机名归一化成资产键：去端口、去大小写、去 www. 前缀。

    缺陷 D 修复配套。实测 181 条系统性重复里，同一路径在
    www.hupowl.com(82) / hupowl.com(82) / mail.hupowl.com(17) 上各计一次，
    本质是同一资产的别名被当成不同主机。报告层按归一化主机 + 归一化
    路径归并，避免同一漏洞重复占版面、重复计数。
    """
    h = (netloc or "").strip().lower()
    # 增强 D-2：IPv6 字面量 [::1]:8080 —— 先取方括号内容，
    # 否则下面的 ":" 切分会把 ::1 切成空串，同一主机的 v6 与 v4
    # 记录被拆成不同资产键。
    if h.startswith("["):
        end = h.find("]")
        h = h[1:end] if end != -1 else h[1:]
    elif ":" in h:
        h = h.split(":", 1)[0]
    # 增强 D-2：FQDN 绝对域名尾点（hupowl.com. 与 hupowl.com 是同一资产，
    # DNS 解析完全等价），去尾点后再去 www. 前缀，避免别名漏归并。
    if h.endswith("."):
        h = h.rstrip(".")
    if h.startswith("www."):
        h = h[4:]
    return h


def _norm_path(path):
    """归一化路径：折叠重复斜杠、解析 . 与 .. 段、去尾部斜杠（根除外）。

    增强 D-2：真实爬取会带出 /a/./b、/x/../y 这类等价写法，不做段解析
    就会把同一资源拆成多个资产键，归并失效。
    """
    p = (path or "/").strip()
    p = re.sub(r"/{2,}", "/", p)
    _segs = p.split("/")
    if "." in _segs or ".." in _segs:
        segs = []
        for seg in p.split("/"):
            if seg == ".":
                continue
            if seg == "..":
                if len(segs) > 1:
                    segs.pop()
                continue
            segs.append(seg)
        p = "/".join(segs) or "/"
        p = re.sub(r"/{2,}", "/", p)
    if len(p) > 1 and p.endswith("/"):
        p = p.rstrip("/")
    return p or "/"


# ------------------------------------------------------------
# 漏洞类型族（跨来源归并）
# ------------------------------------------------------------
# 同一条真实缺陷会被两条产线各记一条、各起一个名字：
#   · 内置检测器（core/dicts.SENSITIVE_PATHS）—— 如 ".git 源码泄露"
#   · 模板引擎（templates/*.yaml 的 info.name）—— 如 "Git 配置泄露"
# 二者落在同一 host + 同一 path 上。旧 _dedup_key 把 vuln_type 当首元素，
# 名字不同就归并不了，报告里同一处缺陷重复占版面、重复计数（实测
# /.git/config 同时存在 high 与 critical 两档就是这来的）。
# 这里把 vtype 先投影到「族」：**同族 + 同 host + 同 path + 同方法 + 同参数**
# 才归并——比"同族即并"严格得多，绝不会把 /a 的 XSS 与 /b 的 XSS 并掉，
# 也不会把 反射型XSS 与 开放重定向 并掉（二者都无规则命中，原样返回）。
# 规则按顺序匹配、先命中先返回；未命中的类型原样返回，保持天然隔离。
_FAMILY_RULES = (
    ("druid",           ("druid",)),
    ("jenkins",         ("jenkins",)),
    ("spring-actuator", ("actuator",)),
    ("api-doc",         ("swagger", "api-docs", "openapi", "knife4j", "api 文档")),
    ("apache-status",   ("server-status", "server_status")),
    ("nginx-status",    ("nginx_status", "stub_status", "nginx status")),
    ("db-admin",        ("phpmyadmin", "pma", "adminer")),
    ("web-xml",         ("web.xml",)),
    ("web-config",      ("web.config",)),
    ("git-leak",        ("git",)),
    ("svn-leak",        ("svn",)),
    ("hg-leak",         ("mercurial", ".hg", "hg 元数据")),
    ("env-leak",        (".env", "环境变量", "env 配置", "env 环境")),
    ("dir-index",       (".ds_store", "目录索引")),
    ("ide-leak",        ("idea", ".idea", "工程配置", "模块配置")),
    ("docker-leak",     ("dockerfile", "docker-compose", "docker")),
    ("deps-leak",       ("composer.lock", "package.json", "npmrc", "gitlab-ci")),
    ("sql-inject",      ("sql",)),
    ("backup-leak",     ("备份", "源码包", "源码文件", "backup", "数据库备份")),
)


def _vtype_family(vt):
    """把漏洞类型名投影到「族」；未识别的类型原样返回（保持隔离）。"""
    s = str(vt or "").strip()
    if not s:
        return ""
    low = s.lower()
    for fam, keys in _FAMILY_RULES:
        for k in keys:
            if k in low:
                return fam
    return s


def _dedup_key(f):
    """跨主机 + 跨来源去重键：(漏洞类型族, 归一化主机, 归一化路径, 方法, 参数)。

    缺陷 D 修复 + 族归并增强。只在报告层归并，不改动落库数据——db 里仍是
    逐条原始记录（审计需要），报告里同一资产的同一漏洞只出现一次。参数
    纳入键，避免把 /a?x= 与 /a?y= 两条不同注入点误合并；类型先投影到族，
    避免内置检测器与模板引擎对同一路径的两种叫法各占一行。
    """
    url = f.get("url") or ""
    try:
        sp = urlsplit(url)
        host = _host_key(sp.netloc)
        path = _norm_path(sp.path)
    except Exception:
        host, path = "", _norm_path(url)
    method, param, _bk, _v = _meta_of(f)
    return (_vtype_family(f.get("vuln_type")), host, path, method, str(param or ""))


def _dedup_findings(findings):
    """按 _dedup_key 归并跨主机重复项，保留信息量更大的一条。

    合并策略：同一键下若存在已复现项，则保留已复现项（实证优先）；
    否则保留置信度更高的一条；完全同级时保留先出现的一条。被合并掉
    的重复主机名记进保留项的 extra["merged_hosts"]，报告可展示。
    """
    groups = {}
    order = []
    for f in findings:
        k = _dedup_key(f)
        if k not in groups:
            groups[k] = []
            order.append(k)
        groups[k].append(f)
    out = []
    for k in order:
        g = groups[k]
        if len(g) == 1:
            out.append(g[0])
            continue
        best = min(g, key=_sort_key)
        hosts = []
        for f in g:
            if f is best:
                continue
            try:
                hh = _host_key(urlsplit(f.get("url") or "").netloc)
            except Exception:
                hh = ""
            if hh and hh not in hosts:
                hosts.append(hh)
        if hosts:
            ex = best.get("extra")
            if not isinstance(ex, dict):
                ex = {}
                best["extra"] = ex
            prev = ex.get("merged_hosts")
            merged = list(prev) if isinstance(prev, list) else []
            for hh in hosts:
                if hh not in merged:
                    merged.append(hh)
            ex["merged_hosts"] = merged
            ex["merged_count"] = len(g)
        out.append(best)
    return out


# ------------------------------------------------------------
# 需求 PENDING-1：AI 输出日志随报告一起落地（reports/<dir>/ai_log.txt）
# ------------------------------------------------------------
# 分流口径与界面完全一致：**只按 logger 名判定，绝不做正文关键字匹配**
# ——正文匹配会被用户自己填的目标串、被扫到的 URL 误伤。ui/gui.py 的
# _AI_LOG_PREFIXES 与本元组必须逐项相同，由 lab/verify_round91_ailog.py 锁死。
AI_LOG_PREFIXES = ("bt.agent", "bt.skill", "bt.mcp", "bt.ai")
AI_LOG_NAME = "ai_log.txt"
_LINE_TS_RE = re.compile(
    r"^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})[,.](\d{1,6})\]")
_LINE_NAME_RE = re.compile(r"^\[[^\]]*\]\s+\w+\s+\[[^\]]*\]\s+([\w.]+):")


def is_ai_log_name(name):
    """logger 名是否属于「AI 输出」，与 ui/gui.py 同口径。"""
    n = str(name or "")
    for _p in AI_LOG_PREFIXES:
        if n == _p or n.startswith(_p + "."):
            return True
    return False


def _line_epoch(line):
    """解析行首 [%Y-%m-%d %H:%M:%S,mmm] 为 epoch 秒；解析不了返回 None。"""
    m = _LINE_TS_RE.match(line)
    if not m:
        return None
    try:
        dt = datetime.datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")
        return dt.timestamp() + float("0." + m.group(2).ljust(6, "0")[:6])
    except Exception:
        return None


def _ai_log_files(log_dir, since_ts=None):
    """列出与本次扫描时间窗相交的 bt-*.log（含 .1/.2 轮转档），按时间升序。

    轮转档命名是 .log 最新、.log.1 次之，所以同一天内按轮转号倒序排，
    保证导出的行是「旧 → 新」的自然顺序。
    """
    out = []
    try:
        names = os.listdir(log_dir)
    except Exception:
        return out
    _sd = None
    if since_ts:
        try:
            _sd = datetime.datetime.fromtimestamp(float(since_ts)).date()
        except Exception:
            _sd = None
    for fn in names:
        m = re.match(r"^bt-(\d{8})\.log(?:\.(\d+))?$", fn)
        if not m:
            continue
        try:
            fdate = datetime.datetime.strptime(m.group(1), "%Y%m%d").date()
        except Exception:
            continue
        # 扫描开始日之前的日志整份跳过（不读历史日的 AI 行）
        if _sd is not None and fdate < _sd:
            continue
        out.append((fdate, -int(m.group(2) or 0), os.path.join(log_dir, fn)))
    out.sort()
    return [p for _a, _b, p in out]


def export_ai_log(report_dir, target=None, since_ts=None, until_ts=None,
                  log_dir=None):
    """把本次扫描期间的 AI 输出日志导出到报告目录的 ai_log.txt。

    since_ts：扫描开始时刻（epoch 秒）。None 表示不做时间过滤——手动
        `report` 命令没有扫描时点，此时导出当天全部 AI 行，仍然可用。
    until_ts：扫描结束时刻，默认由调用方传，None 表示不设上界。
    没有任何 AI 行时不建文件、返回 None：空文件会被误当成「AI 没跑」
    的证据，比没有文件更容易误导。
    返回写入路径，或 None。
    """
    try:
        d = report_dir or ""
        if not d or not os.path.isdir(d):
            return None
        log_dir = log_dir or cfg.LOG_DIR
        since = float(since_ts) if since_ts else None
        until = float(until_ts) if until_ts else None
        keep = []
        for path in _ai_log_files(log_dir, since):
            try:
                fp = open(path, "r", encoding="utf-8", errors="replace")
            except Exception:
                continue
            with fp:
                carry = False
                for line in fp:
                    ts = _line_epoch(line)
                    nm = _LINE_NAME_RE.match(line)
                    if ts is None and nm is None:
                        # 续行（traceback / 多行响应）：跟随上一行的判定
                        if carry:
                            keep.append(line.rstrip("\n"))
                        continue
                    ai = bool(nm) and is_ai_log_name(nm.group(1))
                    carry = ai
                    if not ai:
                        continue
                    if since is not None and ts is not None and ts < since:
                        continue
                    if until is not None and ts is not None and ts > until:
                        continue
                    keep.append(line.rstrip("\n"))
        if not keep:
            return None

        def _fmt(t):
            return datetime.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S")

        head = [
            "# AI 输出日志（本次扫描）",
            "# 目标：%s" % (target or "-"),
            "# 时间窗：%s ~ %s" % (_fmt(since) if since else "（不限起点）",
                                  _fmt(until) if until else "（不设上界）"),
            "# 来源：%s" % log_dir,
            "# 口径：logger 名前缀 %s（与界面 AI 日志框同一分派规则，不做正文匹配）"
            % " / ".join(AI_LOG_PREFIXES),
            "# 行数：%d" % len(keep),
        ]
        out_path = os.path.join(d, AI_LOG_NAME)
        with open(out_path, "w", encoding="utf-8") as fp:
            fp.write("\n".join(head) + "\n\n")
            fp.write("\n".join(keep) + "\n")
        return out_path
    except Exception as e:  # 导出失败绝不能影响主报告产出
        log.warning("AI 日志导出失败：%s", e)
        return None


_REPORT_SEQ = [0]

def new_report_dir(target, want_evidence=True):
    """为一次报告生成唯一目录。

    缺陷 Q 修复：目录名原来只带秒级时间戳，同一秒内连续两次 generate
    （或同秒并发多 worker）会算出同一个目录名，第二次生成把证据文件
    直接写进第一次的 evidence/ 里，旧报告证据被静默污染——实测表现是
    「2 条确认项的目录里出现 3 个 Verified: yes」。这里在时间戳后追加
    pid + 进程内自增序号，并在极端撞名时退避重试，保证绝不复用目录。

    增强 U-4：want_evidence=False 时（`report --format md` 之类）不再预建
    evidence/ 子目录，避免产出空目录让人误以为证据丢失。
    """
    cfg.ensure_dirs()
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    _REPORT_SEQ[0] += 1
    base = os.path.join(cfg.REPORT_DIR, "%s-%s-%d-%d" % (
        _safe_name(target), ts, os.getpid(), _REPORT_SEQ[0]))
    d = base
    n = 0
    while os.path.exists(d):
        n += 1
        d = "%s_%d" % (base, n)
    if want_evidence:
        os.makedirs(os.path.join(d, "evidence"), exist_ok=True)
    else:
        os.makedirs(d, exist_ok=True)
    return d


# ------------------------------------------------------------
# 单个漏洞 → Markdown 段
# ------------------------------------------------------------
def _md_finding(idx, f, include_evidence=True):
    sev = f.get("severity", "info")
    method, param, body_keys, verified = _meta_of(f)
    lines = []
    lines.append("### %d. %s" % (idx, f.get("title") or f.get("vuln_type", "漏洞")))
    lines.append("")
    lines.append("| 项 | 内容 |")
    lines.append("| --- | --- |")
    lines.append("| 漏洞类型 | %s |" % (f.get("vuln_type") or "-"))
    lines.append("| 危害等级 | **%s**（%s） |" % (SEV_CN.get(sev, sev), sev))
    _ctier, _ccn, _cpending = _conf_of(f)
    _conf_cell = "%s（%s）" % (_ccn, _ctier)
    if _cpending:
        _conf_cell += " ⚠ **待人工确认**"
    lines.append("| 置信度 | %s |" % _conf_cell)
    lines.append("| 请求方法 | `%s` |" % method)
    if param:
        lines.append("| 注入参数 | `%s` |" % str(param).replace("|", "\\|"))
    if method == "POST" and body_keys:
        lines.append("| 表单字段 | `%s` |" % ", ".join(body_keys))
    if verified:
        lines.append("| PoC 复现 | 已复现 |")
    lines.append("| 影响地址 | `%s` |" % (f.get("url") or "-"))
    if f.get("payload"):
        lines.append("| 验证载荷 | `%s` |" % str(f["payload"]).replace("|", "\\|"))
    if f.get("cvss"):
        lines.append("| CVSS 4.0 | `%s` |" % f["cvss"])
    lines.append("")

    lines.append("**漏洞描述**")
    lines.append("")
    lines.append(f.get("description") or "（无）")
    lines.append("")

    if f.get("evidence"):
        lines.append("**验证证据**")
        lines.append("")
        lines.append("```")
        lines.append(str(f["evidence"])[:2000])
        lines.append("```")
        lines.append("")

    if include_evidence:
        if f.get("request"):
            lines.append("**复现请求包**")
            lines.append("")
            lines.append("```http")
            lines.append(str(f["request"])[:4000])
            lines.append("```")
            lines.append("")
        if f.get("response"):
            lines.append("**响应包（截断）**")
            lines.append("")
            lines.append("```http")
            lines.append(str(f["response"])[:4000])
            lines.append("```")
            lines.append("")

    if f.get("fix"):
        lines.append("**修复建议**")
        lines.append("")
        lines.append(f["fix"])
        lines.append("")
    lines.append("---")
    lines.append("")
    return "\n".join(lines)


# ------------------------------------------------------------
# Markdown 报告
# ------------------------------------------------------------
def _unreach_rows(meta):
    """把失败明细规整为 [(主机, 原因, 建议, IP, TCP, 替代形态)]，无明细时返回空表。"""
    det = meta.get("unreachable_detail")
    rows = []
    if isinstance(det, list):
        for d in det:
            if not isinstance(d, dict):
                continue
            var = d.get("variants")
            vtxt = "、".join(str(v) for v in var[:3]) if isinstance(var, list) and var else "-"
            rows.append((str(d.get("host") or ""),
                         str(d.get("reason") or "未知错误"),
                         str(d.get("hint") or ""),
                         str(d.get("ip") or "-"),
                         str(d.get("tcp") or "-"),
                         vtxt))
    return rows


def _md_unreach_table(meta):
    """不可达主机明细表（Markdown）。按原因归并一行摘要 + 逐主机明细。"""
    out = []
    rows = _unreach_rows(meta)
    by_reason = meta.get("unreachable_by_reason") or {}
    if isinstance(by_reason, dict) and by_reason:
        parts = ["**%s** × %d" % (k, int(v)) for k, v in
                 sorted(by_reason.items(), key=lambda kv: -int(kv[1] or 0))]
        out.append("原因归并：" + "；".join(parts))
        out.append("")
    if not rows:
        return out
    out.append("| 主机 | 失败原因 | 解析 IP | TCP 结论 | 可解析的替代形态 | 排查建议 |")
    out.append("| --- | --- | --- | --- | --- | --- |")
    for h, r, hint, ip, tcp, var in rows:
        out.append("| `%s` | %s | `%s` | `%s` | `%s` | %s |"
                   % (h, r, ip, tcp, var, hint))
    out.append("")
    return out


def _asset_rows(meta):
    """把 meta["assets"]（db assets 行）规整成
    [(主机, 地址, 标题, 服务器, 组件指纹, 识别版本), ...]。

    指纹库扩充（round51）：assets.tech 落库时以逗号 join，形如
    "nginx,nginx/1.18.0,PHP"；这里把带 / 的 token 拆成「组件 / 版本」，
    让报告直接展示识别到的组件与版本，与 core/verify.py 的 CVE 区间
    比对共用同一份指纹来源，避免两处口径漂移。
    """
    rows = []
    for a in (meta.get("assets") or []):
        if not isinstance(a, dict):
            continue
        _raw = a.get("tech") or ""
        if isinstance(_raw, (list, tuple)):
            _toks = [str(t).strip() for t in _raw]
        else:
            _toks = [t.strip() for t in str(_raw).split(",")]
        comps = []
        vers = []
        for t in _toks:
            if not t:
                continue
            if "/" in t:
                _c, _v = t.split("/", 1)
                _c = _c.strip()
                _v = _v.strip()
                if _c and _c not in comps:
                    comps.append(_c)
                if _v:
                    vers.append("%s %s" % (_c, _v))
            elif t not in comps:
                comps.append(t)
        rows.append((a.get("host") or "", a.get("url") or "",
                     a.get("title") or "", a.get("server") or "",
                     "、".join(comps), "；".join(vers)))
    return rows


def _md_asset_table(meta):
    """资产指纹与版本表（Markdown）。无资产数据时返回空列表。"""
    rows = _asset_rows(meta)
    if not rows:
        return []
    out = ["**资产指纹与版本（探测阶段识别，供 CVE 比对参考）**", "",
           "| 主机 | 地址 | 标题 | 服务器 | 组件指纹 | 识别版本 |",
           "| --- | --- | --- | --- | --- | --- |"]
    for _h, _u, _t, _s, _c, _v in rows:
        out.append("| %s | `%s` | %s | %s | %s | %s |" % (
            str(_h).replace("|", "\\|"), str(_u).replace("|", "\\|"),
            str(_t).replace("|", "\\|"), str(_s).replace("|", "\\|"),
            str(_c).replace("|", "\\|"), str(_v).replace("|", "\\|")))
    out.append("")
    return out


def _html_asset_table(meta):
    """资产指纹与版本表（HTML）。无资产数据时返回空列表。"""
    rows = _asset_rows(meta)
    if not rows:
        return []
    h = ["<h3>资产指纹与版本</h3>",
         "<table><tr><th>主机</th><th>地址</th><th>标题</th>"
         "<th>服务器</th><th>组件指纹</th><th>识别版本</th></tr>"]
    for _h, _u, _t, _s, _c, _v in rows:
        h.append("<tr><td>%s</td><td><code>%s</code></td><td>%s</td>"
                 "<td>%s</td><td>%s</td><td>%s</td></tr>"
                 % (_esc(_h), _esc(_u), _esc(_t), _esc(_s), _esc(_c), _esc(_v)))
    h.append("</table>")
    return h


def build_markdown(target, findings, stats=None, meta=None, include_evidence=True):
    meta = meta or {}
    stats = stats or {}
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    platform = PLATFORM_NAME.get(meta.get("src_platform", "butian"),
                                meta.get("src_platform", ""))

    out = []
    out.append("# %s 漏洞挖掘报告" % (meta.get("program") or target))
    out.append("")
    out.append("- **目标**：`%s`" % target)
    out.append("- **提交平台**：%s" % platform)
    out.append("- **测试作者**：%s" % (meta.get("author") or "（请填写你的平台ID）"))
    out.append("- **生成时间**：%s" % now)
    out.append("- **测试强度**：%s" % (meta.get("intensity") or "safe"))
    # 授权状态标注（round60）：只做"已授权/已拒绝"的显示，
    # 绝不参与扫描强度决策。强度同档由 Engine.auth_scan_profile() 保证。
    _acn = meta.get("auth_cn") or "未判定"
    _are = meta.get("auth_reason") or ""
    out.append("- **授权状态**：%s%s（与扫描强度无关，所有目标同档）"
               % (_acn, ("（%s）" % _are) if _are else ""))
    out.append("- **CVSS 版本**：%s" % meta.get("cvss_version", "4.0"))
    # 4-1：报告头补"工具版本"行，引用 core.__version__ 单一来源，
    # 不硬编码字面量（避免版本号双源漂移）。允许 meta 覆盖以便回归用例
    # 固定版本串；缺省即取包版本。
    out.append("- **工具版本**：v%s" % (meta.get("tool_version") or __version__))
    out.append("")

    out.append("## 一、漏洞汇总")
    out.append("")
    out.append("| 危害等级 | 数量 |")
    out.append("| --- | --- |")
    for k in ("critical", "high", "medium", "low", "info"):
        if stats.get(k):
            out.append("| %s | %d |" % (SEV_CN[k], stats[k]))
    out.append("| **合计** | **%d** |" % stats.get("total", len(findings)))
    out.append("")

    # 增强 U-1：漏洞类型分布 + 涉及主机。181 条级别的报告里，按等级看
    # 不出一共打到了几类问题、覆盖几台资产，这里补两张聚合视图，
    # 提交前能一眼判断产出结构、有没有把同一类问题刷屏。
    _by_type = {}
    for f in findings:
        vt = f.get("vuln_type") or "未分类"
        _by_type[vt] = _by_type.get(vt, 0) + 1
    if _by_type:
        out.append("**漏洞类型分布**")
        out.append("")
        out.append("| 漏洞类型 | 数量 |")
        out.append("| --- | --- |")
        for vt, _n in sorted(_by_type.items(), key=lambda kv: (-kv[1], str(kv[0]))):
            out.append("| %s | %d |" % (str(vt).replace("|", "\\|"), _n))
        out.append("")
    _hosts = []
    for f in findings:
        try:
            _hh = _host_key(urlsplit(f.get("url") or "").netloc) or "-"
        except Exception:
            _hh = "-"
        if _hh not in _hosts:
            _hosts.append(_hh)
    if len(_hosts) > 1:
        out.append("**涉及主机（已按别名归并）**：%s"
                   % "、".join("`%s`" % x for x in _hosts))
        out.append("")
    out.extend(_md_asset_table(meta))

    _n_pending = sum(1 for f in findings if _conf_of(f)[2])
    _n_ver = sum(1 for f in findings
                 if isinstance(f.get("extra"), dict)
                 and (f.get("extra") or {}).get("verified"))
    if findings:
        out.append("| # | 方法 | 标题 | 等级 | 置信度 | 状态 | 地址 |")
        out.append("| --- | --- | --- | --- | --- | --- | --- |")
        for i, f in enumerate(findings, 1):
            m = _meta_of(f)[0]
            _t, _cn, _p = _conf_of(f)
            _verified = isinstance(f.get("extra"), dict) \
                and (f.get("extra") or {}).get("verified")
            _state = "已复现" if _verified else ("待人工确认" if _p else "疑似")
            out.append("| %d | %s | %s | %s | %s | %s | `%s` |"
                       % (i, m,
                          (f.get("title") or f.get("vuln_type", "")).replace("|", "\\|"),
                          SEV_CN.get(f.get("severity", "info"), ""), _cn,
                          _state, f.get("url", "")))
        out.append("")
        if _n_pending:
            out.append("> ⚠ 其中 **%d** 条为低置信度疑似项（未复现），"
                       "已在详情中标「待人工确认」，提交前请优先人工复核；"
                       "已复现 **%d** 条。" % (_n_pending, _n_ver))
            out.append("")
    _n_dedup = int(meta.get("deduped_count") or 0)
    if _n_dedup:
        out.append("> ℹ 已按主机别名归并 **%d** 条跨主机重复项"
                   "（如 `www.x.com` 与 `x.com` 视为同一资产），"
                   "避免同一漏洞重复计数。" % _n_dedup)
        out.append("")

    out.append("## 二、漏洞详情")
    out.append("")
    _n_unreach = int(meta.get("unreachable_count") or 0)
    if not findings:
        if _n_unreach:
            out.append("> ⚠ **目标不可达**：本次共有 **%d** 个主机在探测阶段无任何 HTTP "
                       "响应，**这不是「扫了没漏洞」**。原因分类见下表，"
                       "请按「排查建议」列处理后重测。" % _n_unreach)
            out.append("")
            out.extend(_md_unreach_table(meta))
            # 3-1 回退链可观测：紧跟不可达表列出试过的端口，再给自愈计划。
            out.extend(_md_port_probe_table(meta))
            # 自愈计划：在不可达表之后追加"程序打算怎么自救"，
            # 让用户看到的不只是"失败了"，还有确定性的下一步与代价。
            out.extend(_md_selfheal_table(meta))
            out.extend(_md_switched_table(meta))
        else:
            out.append("本次扫描未发现可确认的漏洞。建议扩大范围或提高扫描强度后重测。")
            out.append("")
    for i, f in enumerate(findings, 1):
        out.append(_md_finding(i, f, include_evidence))

    out.append("## 三、测试说明")
    out.append("")
    out.append("1. 所有测试均在授权范围内进行，未越界请求；")
    out.append("2. 全程遵守无危害验证原则：SQL 注入仅用时间盲注/报错证明，"
               "未拖取任何数据；XSS 仅验证反射与上下文；SSRF 仅回连自有探针；")
    _wp_cfg = cfg.Config()
    if _wp_cfg.get("scan.weak_password", False):
        _wp_try = int(_wp_cfg.get("scan.weak_password_max_try", 24) or 24)
        _wp_tgt = int(_wp_cfg.get("scan.weak_password_max_targets", 5) or 5)
        out.append("3. 弱口令仅在识别到的登录入口上做少量默认凭据尝试"
                   "（入口上限 %d 个 / 单入口上限 %d 次），未进行字典轰炸，"
                   "避免锁号与 DoS；" % (_wp_tgt, _wp_try))
    else:
        out.append("3. 弱口令检测默认关闭，本次未发起任何凭据尝试，"
                   "不存在锁号与 DoS 风险；")
    out.append("4. 敏感信息在采集阶段已脱敏，报告不包含完整个人信息；")
    out.append("5. 请求频率受全局限速约束，未对目标造成可用性影响。")
    out.append("")
    out.append("> 本报告由 bt-src-hunter 自动生成，提交前请人工复核置信度较低项。")
    out.append("")
    return "\n".join(out)


# ------------------------------------------------------------
# HTML 报告
# ------------------------------------------------------------
_HTML_CSS = """
body{font-family:-apple-system,'Segoe UI','Microsoft YaHei',sans-serif;
 margin:0;padding:32px;background:#f5f6f8;color:#222;line-height:1.6}
.wrap{max-width:960px;margin:0 auto;background:#fff;border-radius:10px;
 padding:32px;box-shadow:0 2px 12px rgba(0,0,0,.08)}
h1{font-size:24px;border-bottom:3px solid #1a73e8;padding-bottom:12px}
h2{font-size:19px;margin-top:32px;color:#1a73e8}
h3{font-size:16px;margin-top:24px}
table{border-collapse:collapse;width:100%;margin:12px 0;font-size:13px}
th,td{border:1px solid #e0e0e0;padding:8px 10px;text-align:left}
th{background:#fafafa}
pre{background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:6px;
 overflow-x:auto;font-size:12px;white-space:pre-wrap;word-break:break-all}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;
 font-size:12px;font-weight:600}
.meta{color:#666;font-size:13px}
hr{border:none;border-top:1px dashed #ddd;margin:24px 0}
"""


def _esc(s):
    return _html.escape(str(s or ""))


def _html_unreach_table(meta):
    """不可达主机明细表（HTML）。"""
    h = []
    rows = _unreach_rows(meta)
    by_reason = meta.get("unreachable_by_reason") or {}
    if isinstance(by_reason, dict) and by_reason:
        parts = ["<b>%s</b> × %d" % (_esc(k), int(v)) for k, v in
                 sorted(by_reason.items(), key=lambda kv: -int(kv[1] or 0))]
        h.append('<p>原因归并：' + "；".join(parts) + "</p>")
    if not rows:
        return h
    h.append("<table>")
    h.append("<tr><th>主机</th><th>失败原因</th><th>解析 IP</th>"
             "<th>TCP 结论</th><th>可解析的替代形态</th><th>排查建议</th></tr>")
    for host, r, hint, ip, tcp, var in rows:
        h.append("<tr><td><code>%s</code></td><td>%s</td><td><code>%s</code></td>"
                 "<td><code>%s</code></td><td><code>%s</code></td><td>%s</td></tr>"
                 % (_esc(host), _esc(r), _esc(ip), _esc(tcp), _esc(var), _esc(hint)))
    h.append("</table>")
    return h


def _port_probe_rows(meta):
    """端口补测行：[(主机, 端口, TCP 结论, 详情), ...]，无数据时返回空表。
    3-1 回退链可观测：与 _unreach_rows / _selfheal_rows 分开，单独新增，
    不动既有六元组契约（round26/30/33 锁死了它）。
    """
    rows = []
    for d in (meta.get("unreachable_detail") or []):
        if not isinstance(d, dict):
            continue
        host = d.get("host") or ""
        for r in (d.get("port_probe") or []):
            if not isinstance(r, dict):
                continue
            ok = bool(r.get("ok"))
            verdict = "开放" if ok else (r.get("code") or "unknown")
            rows.append((host, r.get("port"), verdict, r.get("detail") or ""))
    return rows


def _md_port_probe_table(meta):
    """端口补测表（Markdown）：不可达主机的回退链到底试过哪些端口。"""
    rows = _port_probe_rows(meta)
    if not rows:
        return []
    out = ["| 主机 | 端口 | TCP 结论 | 详情 |", "| --- | --- | --- | --- |"]
    for host, port, verdict, detail in rows:
        out.append("| %s | %s | %s | %s |" % (host, port, verdict, detail))
    out.append("")
    return out


def _html_port_probe_table(meta):
    """端口补测表（HTML）：与 Markdown 版同语义。"""
    rows = _port_probe_rows(meta)
    if not rows:
        return []
    h = ["<table>", "<tr><th>主机</th><th>端口</th><th>TCP 结论</th>"
         "<th>详情</th></tr>"]
    for host, port, verdict, detail in rows:
        h.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                 % (_esc(host), _esc(port), _esc(verdict), _esc(detail)))
    h.append("</table>")
    return h


def _switched_rows(meta):
    """round57：变体接管行：[(原主机, 已改用形态), ...]，无接管时返回空表。

    单独新增，不扩既有 _unreach_rows 六元组契约（round26/30/33 锁死了它）。
    """
    det = meta.get("unreachable_detail")
    rows = []
    if isinstance(det, list):
        for d in det:
            if not isinstance(d, dict):
                continue
            sw = d.get("switched_to")
            if sw:
                rows.append((str(d.get("host") or "-"), str(sw)))
    return rows


def _md_switched_table(meta):
    """变体接管表（Markdown）。"""
    rows = _switched_rows(meta)
    if not rows:
        return []
    out = []
    out.append("**变体接管**：以下主机原形态不可达，已自动改用可解析形态继续扫描。")
    out.append("")
    out.append("| 原主机 | 已改用形态 |")
    out.append("| --- | --- |")
    for host, sw in rows:
        out.append("| `%s` | `%s` |" % (host, sw))
    out.append("")
    return out


def _html_switched_table(meta):
    """变体接管表（HTML）。"""
    rows = _switched_rows(meta)
    if not rows:
        return []
    h = []
    h.append("<p><b>变体接管</b>：以下主机原形态不可达，"
             "已自动改用可解析形态继续扫描。</p>")
    h.append("<table><tr><th>原主机</th><th>已改用形态</th></tr>")
    for host, sw in rows:
        h.append("<tr><td>%s</td><td>%s</td></tr>" % (_esc(host), _esc(sw)))
    h.append("</table>")
    return h


def _selfheal_rows(meta):
    """自愈计划行：[(动作, 涉及台数, 是否发请求), ...]，无计划时返回空表。

    与 _unreach_rows 分开是为了不破坏既有六元组契约（round30 C 组锁死了它）。
    """
    acts = meta.get("unreachable_actions")
    rows = []
    if isinstance(acts, dict):
        for name, n in sorted(acts.items(), key=lambda kv: -int(kv[1] or 0)):
            rows.append((str(name), int(n or 0),
                         str(name) in ("try_www", "port_retry", "switch_variant",
                                       "scheme_retry", "rotate_ua")))
    return rows


def _md_selfheal_table(meta):
    """自愈计划表（Markdown）：失败后程序打算怎么自救，以及代价。"""
    rows = _selfheal_rows(meta)
    if not rows:
        return []
    out = []
    _stop = int(meta.get("unreachable_stop") or 0)
    _cost = int(meta.get("unreachable_request_cost") or 0)
    out.append("**自愈计划**（确定性规则，非模型决策）：预计额外请求 %d 次，"
               "确定性放弃 %d 台。" % (_cost, _stop))
    out.append("")
    out.append("| 自愈动作 | 涉及主机数 | 是否产生请求 |")
    out.append("| --- | --- | --- |")
    for name, n, sending in rows:
        out.append("| `%s` | %d | %s |" % (name, n, "是" if sending else "否"))
    out.append("")
    return out


def _html_selfheal_table(meta):
    """自愈计划表（HTML）。"""
    rows = _selfheal_rows(meta)
    if not rows:
        return []
    h = []
    _stop = int(meta.get("unreachable_stop") or 0)
    _cost = int(meta.get("unreachable_request_cost") or 0)
    h.append("<p><b>自愈计划</b>（确定性规则，非模型决策）：预计额外请求 %d 次，"
             "确定性放弃 %d 台。</p>" % (_cost, _stop))
    h.append("<table><tr><th>自愈动作</th><th>涉及主机数</th>"
             "<th>是否产生请求</th></tr>")
    for name, n, sending in rows:
        h.append("<tr><td><code>%s</code></td><td>%d</td><td>%s</td></tr>"
                 % (_esc(name), n, "是" if sending else "否"))
    h.append("</table>")
    return h


def build_html(target, findings, stats=None, meta=None, include_evidence=True):
    meta = meta or {}
    stats = stats or {}
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    platform = PLATFORM_NAME.get(meta.get("src_platform", "butian"),
                                meta.get("src_platform", ""))

    h = ['<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">',
         '<title>%s 漏洞报告</title><style>%s</style></head><body><div class="wrap">'
         % (_esc(target), _HTML_CSS)]
    h.append("<h1>%s 漏洞挖掘报告</h1>" % _esc(meta.get("program") or target))
    _acn_h = meta.get("auth_cn") or "未判定"
    _are_h = meta.get("auth_reason") or ""
    h.append('<p class="meta">目标：<code>%s</code>　平台：%s　作者：%s　'
             '生成时间：%s　强度：%s　授权状态：%s%s</p>'
             % (_esc(target), _esc(platform),
                _esc(meta.get("author") or "（请填写你的平台ID）"), now,
                _esc(meta.get("intensity") or "safe"),
                _esc(_acn_h),
                _esc(("（%s）" % _are_h) if _are_h else "")))

    h.append("<h2>一、漏洞汇总</h2>")
    h.append("<table><tr><th>危害等级</th><th>数量</th></tr>")
    for k in ("critical", "high", "medium", "low", "info"):
        if stats.get(k):
            h.append('<tr><td><span class="badge" style="background:%s">%s</span></td>'
                     '<td>%d</td></tr>' % (SEV_COLOR[k], SEV_CN[k], stats[k]))
    h.append('<tr><td><b>合计</b></td><td><b>%d</b></td></tr></table>'
             % stats.get("total", len(findings)))
    h.extend(_html_asset_table(meta))

    _n_pending = sum(1 for f in findings if _conf_of(f)[2])
    _n_ver = sum(1 for f in findings
                 if isinstance(f.get("extra"), dict)
                 and (f.get("extra") or {}).get("verified"))
    if findings:
        h.append("<table><tr><th>#</th><th>方法</th><th>标题</th><th>等级</th>"
                 "<th>置信度</th><th>状态</th><th>地址</th></tr>")
        for i, f in enumerate(findings, 1):
            sev = f.get("severity", "info")
            _t, _cn, _p = _conf_of(f)
            _verified = isinstance(f.get("extra"), dict) \
                and (f.get("extra") or {}).get("verified")
            _state = "已复现" if _verified else ("待人工确认" if _p else "疑似")
            _scolor = "#1a7f37" if _verified else ("#b26a00" if _p else "#666")
            h.append('<tr><td>%d</td><td><code>%s</code></td><td>%s</td>'
                     '<td><span class="badge" style="background:%s">%s</span></td>'
                     '<td>%s</td><td><span style="color:%s">%s</span></td>'
                     '<td><code>%s</code></td></tr>'
                     % (i, _esc(_meta_of(f)[0]),
                        _esc(f.get("title") or f.get("vuln_type", "")),
                        SEV_COLOR.get(sev, "#999"), SEV_CN.get(sev, sev),
                        _esc(_cn), _scolor, _esc(_state),
                        _esc(f.get("url", ""))))
        h.append("</table>")
        if _n_pending:
            h.append('<p style="color:#b26a00">⚠ 其中 <b>%d</b> 条为低置信度疑似项'
                     '（未复现），已在详情中标「待人工确认」，提交前请优先人工复核；'
                     '已复现 <b>%d</b> 条。</p>' % (_n_pending, _n_ver))
    _n_dedup = int(meta.get("deduped_count") or 0)
    if _n_dedup:
        h.append('<p style="color:#1a73e8">ℹ 已按主机别名归并 <b>%d</b> 条跨主机重复项'
                 '（如 <code>www.x.com</code> 与 <code>x.com</code> 视为同一资产），'
                 '避免同一漏洞重复计数。</p>' % _n_dedup)

    h.append("<h2>二、漏洞详情</h2>")
    _n_unreach = int(meta.get("unreachable_count") or 0)
    if not findings:
        if _n_unreach:
            h.append('<p style="color:#c62828"><b>⚠ 目标不可达</b>：本次共有 '
                     '<b>%d</b> 个主机在探测阶段无任何 HTTP 响应，'
                     '<b>这不是「扫了没漏洞」</b>。原因分类见下表，'
                     '请按「排查建议」列处理后重测。</p>' % _n_unreach)
            h.extend(_html_unreach_table(meta))
            # 3-1 回退链可观测：与 Markdown 版同位置。
            h.extend(_html_port_probe_table(meta))
            # 自愈计划：与 Markdown 版同语义，紧跟不可达表。
            h.extend(_html_selfheal_table(meta))
            h.extend(_html_switched_table(meta))
        else:
            h.append("<p>本次扫描未发现可确认的漏洞。</p>")
    for i, f in enumerate(findings, 1):
        sev = f.get("severity", "info")
        h.append("<h3>%d. %s <span class='badge' style='background:%s'>%s</span></h3>"
                 % (i, _esc(f.get("title") or f.get("vuln_type", "")),
                    SEV_COLOR.get(sev, "#999"), SEV_CN.get(sev, sev)))
        h.append("<table>")
        h.append("<tr><th>漏洞类型</th><td>%s</td></tr>" % _esc(f.get("vuln_type")))
        h.append("<tr><th>影响地址</th><td><code>%s</code></td></tr>" % _esc(f.get("url")))
        h.append("<tr><th>请求方法</th><td><code>%s</code></td></tr>"
                 % _esc(_meta_of(f)[0]))
        _hp = _meta_of(f)
        if _hp[1]:
            h.append("<tr><th>注入参数</th><td><code>%s</code></td></tr>" % _esc(_hp[1]))
        if _hp[0] == "POST" and _hp[2]:
            h.append("<tr><th>表单字段</th><td><code>%s</code></td></tr>"
                     % _esc(", ".join(_hp[2])))
        if _hp[3]:
            h.append("<tr><th>PoC 复现</th><td>已复现</td></tr>")
        _ctier, _ccn, _cpending = _conf_of(f)
        _ccell = _esc(_ccn)
        if _cpending:
            _ccell += ' <span style="color:#b26a00">⚠ 待人工确认</span>'
        h.append("<tr><th>置信度</th><td>%s</td></tr>" % _ccell)
        if f.get("payload"):
            h.append("<tr><th>验证载荷</th><td><code>%s</code></td></tr>"
                     % _esc(f.get("payload")))
        if f.get("cvss"):
            h.append("<tr><th>CVSS 4.0</th><td><code>%s</code></td></tr>"
                     % _esc(f.get("cvss")))
        h.append("</table>")
        h.append("<p><b>漏洞描述</b><br>%s</p>" % _esc(f.get("description")))
        if f.get("evidence"):
            h.append("<p><b>验证证据</b></p><pre>%s</pre>" % _esc(f.get("evidence")))
        if include_evidence:
            if f.get("request"):
                h.append("<p><b>复现请求包</b></p><pre>%s</pre>" % _esc(f.get("request")))
            if f.get("response"):
                h.append("<p><b>响应包（截断）</b></p><pre>%s</pre>" % _esc(f.get("response")))
        if f.get("fix"):
            h.append("<p><b>修复建议</b><br>%s</p>" % _esc(f.get("fix")))
        h.append("<hr>")

    h.append("</div></body></html>")
    return "".join(h)


# ------------------------------------------------------------
# CSV 导出（增强 U-2）
# ------------------------------------------------------------
def build_csv(findings, meta=None):
    """导出可直接导入表格/平台的 CSV 文本。

    增强 U-2：补天等平台提交前常要一份可筛选的表格（按等级/类型/主机
    排序、批量核对），md/html 不便机读。这里用标准库 csv 生成，
    始终带 UTF-8 BOM，避免 Excel 打开中文乱码。
    """
    meta = meta or {}
    buf = io.StringIO()
    writer = csv.writer(buf)
    # 报告级授权状态行（本轮新增）：机读时能直接知道本次扫描对象的授权档位。
    writer.writerow(["报告授权状态", meta.get("auth_cn") or "未判定",
                     meta.get("auth_reason") or "",
                     "扫描强度=%s" % (meta.get("intensity") or "safe"),
                     "强度与授权状态无关", "", "", "", "", "", ""])
    writer.writerow(["序号", "漏洞类型", "危害等级", "置信度", "状态",
                     "方法", "参数", "主机", "URL", "CVSS"])
    for i, f in enumerate(findings, 1):
        m, p, _bk, v = _meta_of(f)
        _t, _cn, _pend = _conf_of(f)
        _state = "已复现" if v else ("待人工确认" if _pend else "疑似")
        try:
            host = _host_key(urlsplit(f.get("url") or "").netloc) or "-"
        except Exception:
            host = "-"
        writer.writerow([
            i, f.get("vuln_type") or "", SEV_CN.get(f.get("severity", "info"),
                                                    f.get("severity", "")),
            _cn, _state, m, p, host, f.get("url") or "", f.get("cvss") or "",
        ])
    return "\ufeff" + buf.getvalue()


def build_json(findings, meta=None):
    """导出机器可读的漏洞清单 JSON 文本（主动增强 U-4）。

    背景（为什么要做）：
        summary.json 是"报告摘要"（含 stats/meta），字段是给汇总看的；
        CSV 便于人看表格但不便于程序消费嵌套字段（payload、cvss、
        conf_tier、pending、host）。第三方平台 / CI 往往要一份
        "纯清单" JSON 直接 `json.load` 后逐条处理。
        这里补一份 findings.json：数组结构，每条含检测与证据元信息。

    设计：字段与 CSV 列对齐并补上机读字段，便于两种导出互相核对。
    """
    meta = meta or {}
    out = []
    for i, f in enumerate(findings or [], 1):
        m, p, bk, v = _meta_of(f)
        _t, cn, pend = _conf_of(f)
        try:
            host = _host_key(urlsplit(f.get("url") or "").netloc) or ""
        except Exception:
            host = ""
        out.append({
            "index": i,
            "vuln_type": f.get("vuln_type") or "",
            "severity": f.get("severity") or "info",
            "severity_cn": SEV_CN.get(f.get("severity", "info"),
                                      f.get("severity", "")),
            "confidence": f.get("confidence") or "",
            "confidence_cn": cn,
            "conf_tier": _t,
            "pending": bool(pend),
            "verified": bool(v),
            "method": m,
            "param": p,
            "body_keys": bk,
            "host": host,
            "url": f.get("url") or "",
            "title": f.get("title") or "",
            "cvss": f.get("cvss") or "",
            "description": f.get("description") or "",
            "fix": f.get("fix") or "",
            "payload": f.get("payload") or "",
        })
    _auth_obj = {
        "level": meta.get("auth_level") or "",
        "cn": meta.get("auth_cn") or "",
        "reason": meta.get("auth_reason") or "",
        "rule": meta.get("auth_rule") or "",
        "scan_active": bool(meta.get("scan_active")),
        "scan_poc": bool(meta.get("scan_poc")),
        "note": "扫描强度与授权状态无关：所有目标同档",
    }
    return json.dumps({"meta": meta, "auth": _auth_obj,
                       "total": len(out), "findings": out},
                      ensure_ascii=False, indent=2)


# ------------------------------------------------------------
# 主入口
# ------------------------------------------------------------
def generate(target, findings=None, db=None, config=None, meta=None,
             include_evidence=None, formats=None, out_dir=None, finding_ids=None):
    """生成报告目录，返回文件路径字典。

    findings 为 None 时按以下优先级取数据（r88 缺陷 #6 收紧）：
      1) finding_ids 非 None → 只取这批 id（= 本轮 scan 真正落库/升级的行）；
      2) finding_ids 为 None  → 回退 db.all_findings(target)（手动 report 命令，
         用户要的本来就是该目标的历史全量）；
      3) 两者都没给且 db 为空 → 空报告。
    原来只有第 2 条，于是 scan 后自动出报告时会把历史 finding 一并输出：
    修好检测规则重跑，旧误报仍原样出现（实测 scan5 把 scan3 的 5 条
    时间盲注带了出来），修复效果无法验收。
    """
    config = config or cfg.Config()
    if include_evidence is None:
        include_evidence = bool(config.get("report.include_evidence", True))
    # 主动增强 U-4：按需输出（CLI `report --format` / config 传入）。
    # formats 为空 → 全量输出（保持既有行为）；否则只落盘被点名的产物。
    _fmts = None
    if formats:
        _seq = (formats if isinstance(formats, (list, tuple, set))
                else str(formats).split(","))
        # 容错：列表元素本身也可能含逗号（如 ["md,json"]），统一摊平后再归一，
        # 并 strip + lower，容忍 " MD " / "JSON" 之类写法。
        _flat = []
        for _x in _seq:
            _flat.extend(str(_x).split(","))
        _fmts = set(t.strip().lower() for t in _flat if t.strip())
        if "all" in _fmts or not _fmts:
            _fmts = None

    def _want(name):
        return _fmts is None or name in _fmts

    if findings is None and finding_ids is not None:
        # 本轮口径：只认 scan 期间落库/升级的 id，不拉历史。
        findings = db.findings_by_ids(finding_ids) if db is not None else []
    elif findings is None and db is not None:
        findings = db.all_findings(target)

    findings = list(findings or [])
    # 缺陷 D：报告层跨主机别名归并（www.x.com / x.com 视为同一资产）。
    # 默认开启，可经 config report.dedup_hosts=false 关闭以保留全量逐条。
    _n_raw = len(findings)
    if config.get("report.dedup_hosts", True):
        findings = _dedup_findings(findings)
    _n_dedup = _n_raw - len(findings)
    # 核验层联动：被独立证据通道「已证伪」的项不进主报告（误报不提交），
    # 其原始记录仍完整保留在 db.verifications 与独立核验报告里，可追溯。
    # 未核验（verify_verdict 缺失）与无法判定（inconclusive）的项一律保留。
    _refuted = [f for f in findings if _verify_of(f)[0] == "refuted"]
    _n_refuted = len(_refuted)
    if _n_refuted:
        findings = [f for f in findings if _verify_of(f)[0] != "refuted"]
    findings.sort(key=_sort_key)

    stats = {"total": len(findings)}
    for f in findings:
        s = f.get("severity", "info")
        stats[s] = stats.get(s, 0) + 1

    meta = dict(meta or {})
    meta.setdefault("author", config.get("report.author", ""))
    meta.setdefault("src_platform", config.get("report.src_platform", "butian"))
    meta.setdefault("cvss_version", config.get("report.cvss_version", "4.0"))
    # 强度从配置读（scan.mode 的真实来源）；db 上没有 scope 属性，
    # 原来的 getattr(getattr(db,"scope",None),"intensity","safe") 恒为 "safe"，是死兜底。
    meta.setdefault("intensity", config.get("scan.mode", "safe") or "safe")
    # 可达性诊断：把上一次扫描记录的「不可达主机数」带进报告。
    # 只有当 last_scan 记录的目标与本次一致时才采信，避免张冠李戴；
    # 有该字段时报告空漏洞分支会改说「目标不可达」而非「未发现漏洞」。
    if "unreachable_count" not in meta:
        _ur = 0
        _ur_det = []
        _ur_by = {}
        _ur_acts = {}
        _ur_stop = 0
        _ur_cost = 0
        if db is not None:
            try:
                _ls = db.get_progress("last_scan") or {}
                if isinstance(_ls, dict) and _ls.get("target") == target:
                    _ur = int(_ls.get("unreachable") or 0)
                    # 失败明细随计数一起带出，让报告正文能列出每台主机的原因。
                    if isinstance(_ls.get("unreachable_detail"), list):
                        _ur_det = _ls.get("unreachable_detail")
                    if isinstance(_ls.get("unreachable_by_reason"), dict):
                        _ur_by = _ls.get("unreachable_by_reason")
                    # 自愈计划：与不可达明细同源（last_scan），一并带出，
                    # 使报告在没有 scan_summary 的独立生成路径下也能渲染自愈表。
                    if isinstance(_ls.get("unreachable_actions"), dict):
                        _ur_acts = _ls.get("unreachable_actions")
                    _ur_stop = int(_ls.get("unreachable_stop") or 0)
                    _ur_cost = int(_ls.get("unreachable_request_cost") or 0)
            except Exception:
                _ur = 0
        meta["unreachable_count"] = _ur
        if _ur_det:
            meta["unreachable_detail"] = _ur_det
        if _ur_by:
            meta["unreachable_by_reason"] = _ur_by
        if _ur_acts:
            meta["unreachable_actions"] = _ur_acts
        meta["unreachable_stop"] = _ur_stop
        meta["unreachable_request_cost"] = _ur_cost
    # 缺陷 D：把跨主机归并数量透出到报告头部与 summary
    meta["deduped_count"] = _n_dedup
    # 指纹库扩充（round51）：把探测阶段落库的资产指纹/版本带进报告，
    # 让「识别到什么组件、什么版本」可提交、可核对，供 CVE 比对参考。
    if "assets" not in meta and db is not None:
        try:
            _tk = ""
            try:
                _tk = _host_key(urlsplit(target).netloc) or str(target).lower()
            except Exception:
                _tk = str(target).lower()
            _arows = []
            for _a in (db.all_assets() or []):
                _ah = str(_a.get("host") or "")
                try:
                    _ahk = _host_key(_ah) or _ah.lower()
                except Exception:
                    _ahk = _ah.lower()
                if _tk and not (_ahk == _tk or _ahk.endswith("." + _tk)
                                or _tk.endswith("." + _ahk)):
                    continue
                _arows.append(_a)
            if _arows:
                meta["assets"] = _arows
        except Exception:
            pass

    # 需求 2：允许调用方传入已有目录（核验报告与主报告放同一目录）。
    if out_dir:
        d = out_dir
        os.makedirs(d, exist_ok=True)
        if _want("evidence"):
            os.makedirs(os.path.join(d, "evidence"), exist_ok=True)
    else:
        d = new_report_dir(target, want_evidence=_want("evidence"))
    paths = {"dir": d}

    if _want("md") or _want("markdown"):
        md = build_markdown(target, findings, stats, meta, include_evidence)
        paths["markdown"] = os.path.join(d, "report.md")
        with open(paths["markdown"], "w", encoding="utf-8") as fp:
            fp.write(md)
    if _want("html"):
        html_doc = build_html(target, findings, stats, meta, include_evidence)
        paths["html"] = os.path.join(d, "report.html")
        with open(paths["html"], "w", encoding="utf-8") as fp:
            fp.write(html_doc)
    # 证据文件
    ev_dir = os.path.join(d, "evidence")
    if _want("evidence"):
        for i, f in enumerate(findings, 1):
            name = "%02d_%s.txt" % (i, _safe_name(f.get("vuln_type", "finding")))
            with open(os.path.join(ev_dir, name), "w", encoding="utf-8") as fp:
                fp.write("URL: %s\n" % f.get("url", ""))
                fp.write("Type: %s\nSeverity: %s\n" % (f.get("vuln_type", ""),
                                                       f.get("severity", "")))
                _em, _ep, _ebk, _ev = _meta_of(f)
                fp.write("Method: %s\n" % _em)
                if _ep:
                    fp.write("Param: %s\n" % _ep)
                if _em == "POST" and _ebk:
                    fp.write("Body keys: %s\n" % ", ".join(_ebk))
                fp.write("Verified: %s\n" % ("yes" if _ev else "no"))
                if f.get("payload"):
                    fp.write("Payload: %s\n" % f.get("payload"))
                if f.get("evidence"):
                    fp.write("\n--- Evidence ---\n%s\n" % f.get("evidence"))
                if f.get("request"):
                    fp.write("\n--- Request ---\n%s\n" % f.get("request"))
                if f.get("response"):
                    fp.write("\n--- Response ---\n%s\n" % f.get("response"))
        paths["evidence_dir"] = ev_dir

    summary = {"target": target, "generated_at": datetime.datetime.now().isoformat(),
               "stats": stats, "meta": meta,
               "findings": [dict(
                   {k: f.get(k) for k in
                    ("vuln_type", "severity", "confidence", "url",
                     "title", "cvss")},
                   method=_meta_of(f)[0],
                   param=_meta_of(f)[1],
                   body_keys=_meta_of(f)[2],
                   verified=_meta_of(f)[3],
                   # 缺陷 E：summary 里也带出归一化置信度档位与待确认标记，
                   # 便于下游程序化消费（如按档位过滤、统计误报率）。
                   conf_tier=_conf_of(f)[0],
                   pending=_conf_of(f)[2]) for f in findings]}
    summary["pending_count"] = sum(1 for f in findings if _conf_of(f)[2])
    summary["verified_count"] = sum(1 for f in findings if _meta_of(f)[3])
    # 缺陷 D：归并统计，便于下游核对原始条数与展示条数
    summary["deduped_count"] = _n_dedup
    # 可达性诊断：显式透出本次不可达主机数，供下游程序化判断「全空报告」成因
    summary["unreachable_count"] = int(meta.get("unreachable_count") or 0)
    # 失败归因明细：下游可直接读取「哪台主机为什么连不上」
    summary["unreachable_detail"] = meta.get("unreachable_detail") or []
    summary["unreachable_by_reason"] = meta.get("unreachable_by_reason") or {}
    # 自愈计划：把"失败后程序打算怎么自救"也透出给下游程序化消费
    summary["unreachable_actions"] = meta.get("unreachable_actions") or {}
    summary["unreachable_stop"] = int(meta.get("unreachable_stop") or 0)
    summary["unreachable_request_cost"] = int(
        meta.get("unreachable_request_cost") or 0)
    summary["unreachable_switched"] = len(_switched_rows(meta))
    summary["raw_count"] = _n_raw
    summary["assets"] = meta.get("assets") or []
    # 核验层联动：主报告已剔除的证伪项数 + 三档核验分布，便于下游对账
    summary["refuted_count"] = _n_refuted
    summary["verify_stats"] = {
        "confirmed": sum(1 for f in findings if _verify_of(f)[0] == "confirmed"),
        "inconclusive": sum(1 for f in findings
                            if _verify_of(f)[0] == "inconclusive"),
        "refuted": _n_refuted,
        "unverified": sum(1 for f in findings if not _verify_of(f)[0]),
    }
    paths["summary"] = os.path.join(d, "summary.json")
    with open(paths["summary"], "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)

    # 增强 U-2：附带一份 CSV 明细，便于导入表格/平台批量核对
    # 增强 U-4：纳入按需输出（--format json 时不应再无条件落 CSV）
    if _want("csv"):
        try:
            paths["csv"] = os.path.join(d, "findings.csv")
            with open(paths["csv"], "w", encoding="utf-8", newline="") as fp:
                fp.write(build_csv(findings, meta))
        except Exception as _e:  # 导出失败不应影响主报告产出
            log.warning("CSV 导出失败：%s", _e)

    # 增强 U-4：机读清单 JSON（第三方平台 / CI 可直接 json.load 消费）
    if _want("json"):
        try:
            paths["json"] = os.path.join(d, "findings.json")
            with open(paths["json"], "w", encoding="utf-8") as fp:
                fp.write(build_json(findings, meta))
        except Exception as _e:  # 导出失败不应影响主报告产出
            log.warning("JSON 导出失败：%s", _e)

    logger.audit("report_generated", target=target, dir=d, total=len(findings))
    log.info("报告已生成：%s（%d 条漏洞）", d, len(findings))
    # 需求 PENDING-1：AI 输出日志与报告同目录落地（不进发布包）。
    # 时间窗取扫描起止（由 engine.make_report 经 meta 透传）；手动 report
    # 命令没有扫描时点，此时退化为当天全部 AI 行，仍然可用。
    # 放在最后一步：即使导出失败也只留一条 warning，绝不影响上面的四件套。
    _ai = export_ai_log(
        d, target=target,
        since_ts=(meta or {}).get("scan_started_at"),
        until_ts=(meta or {}).get("scan_ended_at"))
    if _ai:
        paths["ai_log"] = _ai
        log.info("AI 日志已随报告导出：%s", _ai)
    return paths
