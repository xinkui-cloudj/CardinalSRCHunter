# -*- coding: utf-8 -*-
"""bt-src-hunter core package."""
__version__ = "1.0.0"