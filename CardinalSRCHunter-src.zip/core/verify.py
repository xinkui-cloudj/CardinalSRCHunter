# -*- coding: utf-8 -*-
"""漏洞真实性核验层（独立证据通道）。

为什么必须独立于检测层？
    检测层（modules/vulnchecks）的判定是"命中特征即报"：看到 SQL 错误签名
    就报注入、看到 marker 反射就报 XSS、看到 AKIA 前缀就报密钥泄露。
    如果"核验"只是把同一套检测逻辑重跑一遍，那它确认的是自己，不是漏洞——
    同一个误报会稳定地确认自己（实测：base64 串里的巧合 AKIA 骗过了大小写
    不敏感的匹配，见 probe.scan_secrets 的三重降误报注释）。所以核验层
    必须走**与检测层不同的证据通道**：

        检测层问："有没有命中特征？"
        核验层问："这个行为是不是由注入引起的？"

    每类漏洞的独立通道：
      - 时间盲注：延迟必须随 SLEEP 参数**线性增长**（SLEEP(2)≈2s、
        SLEEP(4)≈4s），单次超阈值不算数（网络抖动也会超阈值）；
      - 报错注入：要求"正常值不报错、注入值报错、语法配平后不报错"三段因果，
        排除站点固有错误页与中间件统一报错；
      - XSS：要求反射落在 HTML **可执行上下文**（非 JSON、非实体编码、
        非 <script> 字符串内）；
      - 开放重定向：用**两个不同的外部域**分别注入，Location 必须随输入变化，
        排除"站点固定跳 CDN"；
      - 备份/源码：内容必须命中**文件魔数/源码特征**，且与软 404 基线不同质；
      - 密钥：必须通过**格式自校验**（长度/字符集/结构）与香农熵评估；
      - CORS：要求 ACAO 回显**任意** Origin 且 ACAC=true。

三档结论：
    confirmed    已证实——独立通道复现，可提交
    refuted      已证伪——独立通道明确否定，落误报样本、不进主报告
    inconclusive 无法判定——证据不足或该类型无独立通道，保留原结论待人核

红线：核验层只读、无危害。复用 poc._safe_payload 拒绝破坏性载荷，
      每类核验请求数受控（单类 <= 8 次），全量核验另有单目标请求上限。
"""
import base64
import datetime
import json
import math
import os
import re
import statistics
import time
from urllib.parse import urlparse

from core import config as cfg
from core import dicts, logger
from modules import probe

log = logger.get("bt.verify")

CONFIRMED = "confirmed"
REFUTED = "refuted"
UNKNOWN = "inconclusive"
# round78 ④：「未核验」独立成档。它与「无法判定」是两件事——
#   not_verified = 一次请求都没发（无对应核验器 / 前置条件不足，缺核验通道）
#   inconclusive  = 核验器跑了、发了请求，但证据不足以定论
# 旧版把两者都塞进 inconclusive，报告上就出现「核验过但没结论」的假象。
NOT_VERIFIED = "not_verified"
UNKNOWN_METHODS = ("无对应核验器", "核验前置条件不足")
VERDICT_CN = {CONFIRMED: "已证实", REFUTED: "已证伪", UNKNOWN: "无法判定",
              NOT_VERIFIED: "未核验"}


def _is_unverified(res):
    """该结论是否属于「一次请求都没发」的未核验档。

    判定只收紧在最安全的口径上：
      - 已经是 not_verified → 是；
      - 非 inconclusive（已证实/已证伪）→ 否，那是核验器给的实质结论，
        例如密钥格式自校验 0 请求也能证伪，绝不改档；
      - inconclusive 且请求数 0 → 是（无核验器命中，或缺 url 等前置条件）。
    """
    if not isinstance(res, dict):
        return False
    v = res.get("verdict")
    if v == NOT_VERIFIED:
        return True
    if v != UNKNOWN:
        return False
    if (res.get("method") or "") in UNKNOWN_METHODS:
        return True
    return int(res.get("requests") or 0) == 0


def _demote_unverified(res):
    """把「0 请求的 inconclusive」降档为 not_verified（保留原核验方法名）。"""
    if _is_unverified(res) and res.get("verdict") != NOT_VERIFIED:
        res = dict(res)
        res["verdict"] = NOT_VERIFIED
        if not res.get("evidence"):
            res["evidence"] = "未发起核验请求（缺核验通道），保留原结论"
    return res


# ------------------------------------------------------------
# 通用工具
# ------------------------------------------------------------
def _verdict(v, method, requests=0, evidence="", confidence="", detail=None):
    return {"verdict": v, "method": method, "requests": int(requests or 0),
            "evidence": evidence, "confidence": confidence, "detail": detail or {}}


def _param_of(f):
    ex = f.get("extra") if isinstance(f.get("extra"), dict) else {}
    return f.get("payload_param") or ex.get("param") or f.get("param") or ""


def _method_of(f):
    ex = f.get("extra") if isinstance(f.get("extra"), dict) else {}
    return str(ex.get("method") or f.get("method") or "GET").upper()


def _body_of(f):
    b = f.get("body")
    return b if isinstance(b, dict) and b else None


def _base_of(url):
    try:
        p = urlparse(url or "")
        if not p.scheme or not p.netloc:
            return ""
        return "%s://%s/" % (p.scheme, p.netloc)
    except Exception:
        return ""


def _channel_clean(client, base_url, resp, tag):
    """round89 FIX-12: 核验前置自证——本次响应是不是站点统一拦截页。
    判据与 FIX-6 完全一致（复用 probe.blocking_wall），抽成公共函数，
    避免第三个核验器各写一遍导致同一证据结论互相矛盾。
    返回 (is_wall, evidence)；is_wall=True 时调用方必须返回 UNKNOWN，
    不能判 REFUTED——拦截页既不能证明存在也不能证明不存在。
    """
    if resp is None or not getattr(resp, "status", 0) or not base_url:
        return False, ""
    try:
        if probe.blocking_wall(resp, base_url, client, tag=tag):
            return True, ("与站点统一拦截页同质（HTTP %d / %dB），"
                          "该响应不代表路径真实存在，无法判定"
                          % (resp.status, resp.length or 0))
    except Exception:
        pass
    return False, ""

def _timed_send(client, url, param, method, body, payload, purpose):
    """按检测层记录的请求语义（GET query / POST form）注入 payload 并计时。"""
    from modules.vulnchecks import _inject_query, _inject_form
    t0 = time.time()
    r = None
    try:
        if method == "GET":
            r = client.get(_inject_query(url, param, payload), purpose=purpose)
        else:
            r = client.post(url, data=_inject_form(body or {}, param, payload),
                            purpose=purpose)
    except Exception as e:
        log.debug("核验请求异常 %s: %s", purpose, e)
    return r, time.time() - t0


def _median(xs):
    return statistics.median(xs) if xs else 0.0


def _shannon_entropy(s):
    """香农熵：用于判断随机串是否为"像密钥"的高熵串。"""
    if not s:
        return 0.0
    freq = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    try:
        return -sum((v / n) * math.log2(v / n) for v in freq.values())
    except Exception:
        return 0.0


def _jwt_payload_ok(tok):
    try:
        parts = tok.split(".")
        if len(parts) != 3:
            return False
        for p in parts[:2]:
            pad = "=" * (-len(p) % 4)
            base64.urlsafe_b64decode(p + pad)
        return True
    except Exception:
        return False


# ------------------------------------------------------------
# 1) SQL 时间盲注：延迟线性因果
# ------------------------------------------------------------
def verify_sqli_time(f, client, config=None):
    """真核验：延迟必须随 SLEEP 参数**线性增长**，且显著高于无害对照。
    检测层只看"单次是否超阈值"——网络抖动、服务端慢查询都会超阈值；
    核验层看"延迟与注入参数是否成因果关系"：SLEEP(2) 与 SLEEP(4) 的
    延迟若按 1:2 增长，才说明延迟由注入驱动。
    """
    url = f.get("url") or ""
    param = _param_of(f)
    method = _method_of(f)
    body = _body_of(f)
    if not url or not param:
        return _verdict(UNKNOWN, "时间盲注·延迟线性因果", 0, "缺少 url/param，无法复现")
    from modules.poc import _safe_payload
    ctrl_payload = "btverify1337"
    sleep_tpl = "' AND SLEEP(%d)-- -"
    if not _safe_payload(ctrl_payload) or not _safe_payload(sleep_tpl % 2):
        return _verdict(UNKNOWN, "时间盲注·延迟线性因果", 0, "载荷被安全红线拒绝")

    n = 0
    ctrl, s2, s4 = [], [], []
    _r, t = _timed_send(client, url, param, method, body, ctrl_payload, "verify:sqli:ctrl")
    ctrl.append(t); n += 1
    _r, t = _timed_send(client, url, param, method, body, ctrl_payload + "x", "verify:sqli:ctrl")
    ctrl.append(t); n += 1
    for _i in range(3):
        _r, t = _timed_send(client, url, param, method, body, sleep_tpl % 2, "verify:sqli:s2")
        s2.append(t); n += 1
    for _i in range(2):
        _r, t = _timed_send(client, url, param, method, body, sleep_tpl % 4, "verify:sqli:s4")
        s4.append(t); n += 1

    c, m2, m4 = _median(ctrl), _median(s2), _median(s4)
    ev = ("对照中位 %.2fs / SLEEP(2) 中位 %.2fs / SLEEP(4) 中位 %.2fs" % (c, m2, m4))
    detail = {"ctrl": round(c, 3), "sleep2": round(m2, 3), "sleep4": round(m4, 3),
              "samples": {"ctrl": [round(x, 3) for x in ctrl],
                          "sleep2": [round(x, 3) for x in s2],
                          "sleep4": [round(x, 3) for x in s4]}}
    if m2 >= 2 * 0.7 and m4 >= 4 * 0.6 and m4 >= m2 * 1.4 and m2 >= max(c * 2.0, 1.0):
        return _verdict(CONFIRMED, "时间盲注·延迟线性因果", n,
                        ev + "；延迟随 SLEEP 参数线性增长，构成因果证据", "high", detail)
    if m2 >= 2 * 0.6 and m2 >= max(c * 2.0, 1.0):
        return _verdict(UNKNOWN, "时间盲注·延迟线性因果", n,
                        ev + "；存在延迟但未随参数线性增长，疑网络抖动/服务端慢查询",
                        "low", detail)
    return _verdict(REFUTED, "时间盲注·延迟线性因果", n,
                    ev + "；无稳定延迟，注入未生效", "medium", detail)


# ------------------------------------------------------------
# 2) SQL 报错注入：三段因果
# ------------------------------------------------------------
def verify_sqli_error(f, client, config=None):
    """真核验：正常值不报错 + 注入值报错 + 语法配平后不报错。
    检测层只看"响应里有没有 SQL 错误签名"，会把站点固有错误页/中间件
    统一报错页误判为注入；核验层用配平载荷（' AND '1'='1）反证——
    若配平后仍报错，说明报错与该参数无关，不能归因于注入。
    """
    url = f.get("url") or ""
    param = _param_of(f)
    method = _method_of(f)
    body = _body_of(f)
    if not url or not param:
        return _verdict(UNKNOWN, "报错注入·三段因果", 0, "缺少 url/param")

    def _send(payload):
        r, _t = _timed_send(client, url, param, method, body, payload, "verify:sqli:err")
        return r

    def _signs(text):
        t = text or ""
        hits = []
        for sig in dicts.SQLI_ERROR_SIGNS:
            try:
                if re.search(sig, t, re.I):
                    hits.append(sig)
            except re.error:
                continue
        return hits

    n = 0
    r_norm = _send("btverify1337"); n += 1
    norm_hits = _signs(r_norm.text if r_norm else "")
    r_inj = _send("'"); n += 1
    inj_hits = _signs(r_inj.text if r_inj else "")
    r_bal = _send("' AND '1'='1"); n += 1
    bal_hits = _signs(r_bal.text if r_bal else "")
    ev = ("正常值错误签名=%d / 注入(单引号)错误签名=%d / 配平后错误签名=%d"
          % (len(norm_hits), len(inj_hits), len(bal_hits)))
    detail = {"normal": norm_hits, "injected": inj_hits, "balanced": bal_hits}
    if inj_hits and not norm_hits and not bal_hits:
        return _verdict(CONFIRMED, "报错注入·三段因果", n,
                        ev + "；错误由引号未配平引起，非通用错误页", "high", detail)
    if inj_hits and not norm_hits:
        return _verdict(UNKNOWN, "报错注入·三段因果", n,
                        ev + "；注入报错但配平后仍报错，无法排除中间件统一报错",
                        "low", detail)
    if norm_hits:
        return _verdict(REFUTED, "报错注入·三段因果", n,
                        ev + "；正常请求即含 SQL 错误签名，属站点固有错误页", "medium", detail)
    return _verdict(REFUTED, "报错注入·三段因果", n,
                    ev + "；注入未触发任何数据库错误签名", "medium", detail)


# ------------------------------------------------------------
# 3) 反射型 XSS：HTML 可执行上下文
# ------------------------------------------------------------
def verify_xss_reflect(f, client, config=None):
    """真核验：反射内容必须落在 HTML **可执行上下文**。
    检测层只看"marker 是否出现在响应里"，JSON 响应里出现也判 XSS（典型
    误报）；核验层要求 Content-Type 为 HTML、marker 未被实体编码、
    且不在 <script> 字符串上下文中。
    """
    url = f.get("url") or ""
    param = _param_of(f)
    method = _method_of(f)
    body = _body_of(f)
    if not url or not param:
        return _verdict(UNKNOWN, "XSS·HTML 上下文验证", 0, "缺少 url/param")
    from modules.vulnchecks import _inject_query, _inject_form
    marker = dicts.XSS_MARKER
    payload = '"><script>alert("%s")</script>' % marker
    try:
        if method == "GET":
            r = client.get(_inject_query(url, param, payload), purpose="verify:xss")
        else:
            r = client.post(url, data=_inject_form(body or {}, param, payload),
                            purpose="verify:xss")
    except Exception as e:
        return _verdict(UNKNOWN, "XSS·HTML 上下文验证", 1, "请求异常：%s" % e)
    n = 1
    if not r or not r.status:
        return _verdict(UNKNOWN, "XSS·HTML 上下文验证", n, "目标不可达")
    text = r.text or ""
    ct = (r.content_type or "").lower()
    idx = text.find(marker)
    if idx < 0:
        return _verdict(REFUTED, "XSS·HTML 上下文验证", n,
                        "重新注入后 marker 未反射，无法复现", "high",
                        {"content_type": ct})
    pre = text[max(0, idx - 80):idx]
    ctx = text[max(0, idx - 80):idx + 80]
    encoded = ("&lt;" in pre and "&gt;" in pre) or ("&#" in pre[-24:])
    is_html = ("html" in ct) or ("<html" in text[:600].lower())
    in_script = bool(re.search(r"<script[^>]*>[^<]*$", pre, re.I))
    detail = {"content_type": ct or "-", "context": ctx.replace("\n", " "),
              "encoded": encoded, "in_script": in_script}
    if not is_html:
        return _verdict(REFUTED, "XSS·HTML 上下文验证", n,
                        "响应 Content-Type=%s，非 HTML，浏览器不会执行" % (ct or "-"),
                        "high", detail)
    if encoded:
        return _verdict(REFUTED, "XSS·HTML 上下文验证", n,
                        "注入内容被 HTML 实体编码，无法逃逸", "high", detail)
    if in_script:
        return _verdict(UNKNOWN, "XSS·HTML 上下文验证", n,
                        "反射落在 <script> 上下文，需闭合/转义链配合，未证实可执行",
                        "medium", detail)
    return _verdict(CONFIRMED, "XSS·HTML 上下文验证", n,
                    "注入内容未编码地反射进 HTML 上下文，构成可执行条件", "high", detail)


# ------------------------------------------------------------
# 4) 开放重定向：双域对照
# ------------------------------------------------------------
def verify_open_redirect(f, client, config=None):
    """真核验：用**两个不同的外部域**分别注入，Location 必须随输入变化。
    检测层只看单次 30x + "evil.com" 子串，会把"站点固定跳某个 CDN/门户"
    误判为开放重定向；核验层要求跳转目标与输入一一对应。
    """
    url = f.get("url") or ""
    param = _param_of(f)
    method = _method_of(f)
    body = _body_of(f)
    if not url or not param:
        return _verdict(UNKNOWN, "开放重定向·双域对照", 0, "缺少 url/param")
    from modules.vulnchecks import _inject_query, _inject_form

    def _send(payload):
        try:
            if method == "GET":
                return client.get(_inject_query(url, param, payload),
                                  purpose="verify:redirect", allow_redirects=False)
            return client.post(url, data=_inject_form(body or {}, param, payload),
                               purpose="verify:redirect", allow_redirects=False)
        except Exception:
            return None

    n = 0
    locs = {}
    _resps = []
    for tag in ("btv-a.example", "btv-b.example"):
        r = _send("https://" + tag + "/")
        n += 1
        _resps.append(r)
        locs[tag] = {"status": (r.status if r else 0),
                     "location": (r.header("Location") if r else "") or ""}
    ev = "；".join("%s → %s %s" % (k, v["status"], v["location"] or "-")
                   for k, v in locs.items())
    detail = {"probes": locs}
    a, b = locs["btv-a.example"], locs["btv-b.example"]
    # round89 FIX-12b: 与 verify_unauth 同理——先自证通道干净。
    # 实测 my.ztgame.com 对任意路径均回 403 WAF 页，旧逻辑落到末尾直接判
    # REFUTED（未返回 3xx）。但拦截页根本没走到业务代码，既不能证明也
    # 不能否认开放重定向，只能判 UNKNOWN。
    for _r in _resps:
        _w, _wev = _channel_clean(client, _base_of(url), _r, "verify:redirect")
        if _w:
            detail["wall"] = True
            return _verdict(UNKNOWN, "开放重定向·双域对照", n, _wev, "high", detail)
    if a["location"] and b["location"] \
            and "btv-a.example" in a["location"] and "btv-b.example" in b["location"]:
        return _verdict(CONFIRMED, "开放重定向·双域对照", n,
                        ev + "；跳转目标随输入变化，构成开放重定向", "high", detail)
    if a["status"] in (301, 302, 303, 307, 308) or b["status"] in (301, 302, 303, 307, 308):
        if a["location"] and a["location"] == b["location"]:
            return _verdict(REFUTED, "开放重定向·双域对照", n,
                            ev + "；两次跳转目标相同，属固定跳转而非可控重定向",
                            "medium", detail)
        return _verdict(UNKNOWN, "开放重定向·双域对照", n,
                        ev + "；有跳转但目标与输入无稳定对应", "low", detail)
    return _verdict(REFUTED, "开放重定向·双域对照", n,
                    ev + "；未返回 3xx 跳转", "high", detail)


# ------------------------------------------------------------
# 5) 备份 / 源码泄露：内容特征 + 软 404 对照
# ------------------------------------------------------------
_FILE_SIGNATURES = [
    ("zip/jar 压缩包", lambda b: b[:4] == b"PK\x03\x04"),
    ("gzip 压缩包", lambda b: b[:2] == b"\x1f\x8b"),
    ("bzip2 压缩包", lambda b: b[:3] == b"BZh"),
    ("tar 归档", lambda b: len(b) > 265 and b[257:262] == b"ustar"),
    ("SQL 转储", lambda b: bool(re.search(
        rb"(INSERT INTO|CREATE TABLE|-- MySQL dump|-- Dumped by)", b, re.I))),
    ("PHP 源码", lambda b: b"<?php" in b),
    ("Python 源码", lambda b: bool(re.search(
        rb"^\s*(import |from \S+ import |def |class )", b, re.M))),
    ("env 配置", lambda b: bool(re.search(rb"^[A-Z][A-Z0-9_]{2,}=.+$", b, re.M))),
    ("Git 仓库", lambda b: b"[core]" in b or b"ref: refs/" in b),
    ("私钥/证书", lambda b: b"-----BEGIN" in b and b"KEY-----" in b),
    ("Shell 脚本", lambda b: b[:2] == b"#!"),
    ("Java class", lambda b: b[:4] == b"\xca\xfe\xba\xbe"),
]


def verify_backup_file(f, client, config=None):
    """真核验：响应必须是**真实文件内容**，而非软 404 / WAF 兜底页。
    独立通道：文件魔数/源码特征 + 软 404 基线比对 + 换 UA 复现稳定性。
    """
    url = f.get("url") or ""
    if not url:
        return _verdict(UNKNOWN, "备份/源码·内容特征+软404对照", 0, "缺少 url")
    base_url = _base_of(url)
    n = 0
    base = {}
    if base_url:
        try:
            base = probe.soft404_baseline(base_url, client)
            # round21 基线降级保护：主基线失败时改用首页备用基线，
            # 避免 is_soft404 恒 False 导致核验层无法识别兜底页。
            if not probe.baseline_usable(base):
                base = probe.home_baseline(base_url, client)
        except Exception:
            base = {}
    try:
        r = client.get(url, purpose="verify:backup")
    except Exception as e:
        return _verdict(UNKNOWN, "备份/源码·内容特征+软404对照", 1, "请求异常：%s" % e)
    n += 1
    if not r or not r.status:
        return _verdict(REFUTED, "备份/源码·内容特征+软404对照", n,
                        "目标不可达（status=%s）" % (getattr(r, "status", 0) or 0),
                        "medium")
    if probe.is_soft404(r, base):
        return _verdict(REFUTED, "备份/源码·内容特征+软404对照", n,
                        "响应与软 404 基线同质，该文件实际不存在", "high",
                        {"baseline_status": base.get("status")})
    raw = (r.text or "").encode("utf-8", "ignore")
    hit = []
    for name, fn in _FILE_SIGNATURES:
        try:
            if fn(raw):
                hit.append(name)
        except Exception:
            continue
    stable = False
    try:
        r2 = client.get(url, purpose="verify:backup:ua",
                        headers={"User-Agent": "BTVerify/1.0"})
        n += 1
        if r2 and r2.status:
            l1, l2 = (r.length or 0), (r2.length or 0)
            stable = abs(l2 - l1) <= max(32, l1 * 0.05)
    except Exception:
        stable = False
    detail = {"signatures": hit, "status": r.status, "length": r.length,
              "stable": stable, "ctype": r.content_type or "-"}
    if hit:
        return _verdict(CONFIRMED, "备份/源码·内容特征+软404对照", n,
                        "命中文件特征：%s；响应稳定=%s，非软 404"
                        % ("、".join(hit), "是" if stable else "否"),
                        "high", detail)
    if r.status == 200 and stable:
        return _verdict(UNKNOWN, "备份/源码·内容特征+软404对照", n,
                        "可稳定访问但未命中文件特征，需人工确认是否为真实文件",
                        "low", detail)
    return _verdict(REFUTED, "备份/源码·内容特征+软404对照", n,
                    "无文件特征且响应不稳定，疑似 WAF/兜底页", "medium", detail)


# ------------------------------------------------------------
# 6) 目录列表：自动索引特征
# ------------------------------------------------------------
def verify_dirlist(f, client, config=None):
    """真核验：目录列表页必须含 'Index of' 标记或成规模条目 + 父目录链接。"""
    url = f.get("url") or ""
    if not url:
        return _verdict(UNKNOWN, "目录列表·自动索引特征", 0, "缺少 url")
    base_url = _base_of(url)
    n = 0
    base = {}
    if base_url:
        try:
            base = probe.soft404_baseline(base_url, client)
            # round21 基线降级保护：主基线失败时改用首页备用基线，
            # 避免 is_soft404 恒 False 导致核验层无法识别兜底页。
            if not probe.baseline_usable(base):
                base = probe.home_baseline(base_url, client)
        except Exception:
            base = {}
    try:
        r = client.get(url, purpose="verify:dirlist")
    except Exception as e:
        return _verdict(UNKNOWN, "目录列表·自动索引特征", 1, "请求异常：%s" % e)
    n += 1
    if not r or not r.status:
        return _verdict(REFUTED, "目录列表·自动索引特征", n, "目标不可达", "medium")
    if probe.is_soft404(r, base):
        return _verdict(REFUTED, "目录列表·自动索引特征", n,
                        "与软 404 基线同质，非真实目录列表", "high")
    t = r.text or ""
    idx = bool(re.search(r"<title>\s*Index of|<h1>\s*Index of|Index of /", t, re.I))
    links = len(re.findall(r'<a\s+href="[^"]+"', t, re.I))
    parent = bool(re.search(r'href="\.\./?"', t))
    detail = {"index_of": idx, "link_count": links, "parent_link": parent,
              "status": r.status}
    if idx and links >= 3:
        return _verdict(CONFIRMED, "目录列表·自动索引特征", n,
                        "页面含 Index of 标记且列出 %d 个条目，确认目录遍历" % links,
                        "high", detail)
    if links >= 5 and parent:
        return _verdict(UNKNOWN, "目录列表·自动索引特征", n,
                        "含父目录链接与 %d 个条目，但无 Index of 标记" % links,
                        "medium", detail)
    return _verdict(REFUTED, "目录列表·自动索引特征", n,
                    "无自动索引特征（Index of=%s，条目=%d）" % (idx, links),
                    "medium", detail)


# ------------------------------------------------------------
# 7) 密钥 / 敏感信息：格式自校验
# ------------------------------------------------------------
def _secret_selfcheck(raw):
    raw = (raw or "").strip()
    if not raw:
        return False, "空值"
    if re.fullmatch(r"AKIA[0-9A-Z]{16}", raw):
        return True, "AWS AK 格式合法（AKIA + 16 位大写）"
    if re.fullmatch(r"LTAI[0-9A-Za-z]{12,24}", raw):
        return True, "阿里云 AK 格式合法（LTAI 前缀）"
    if re.fullmatch(r"AIza[0-9A-Za-z\-_]{35}", raw):
        return True, "Google API Key 格式合法"
    if raw.startswith("-----BEGIN") and "PRIVATE KEY-----" in raw:
        return True, "PEM 私钥结构合法"
    if raw.count(".") == 2 and _jwt_payload_ok(raw):
        return True, "JWT 三段结构可解"
    ent = _shannon_entropy(raw)
    if len(raw) >= 24 and ent >= 3.5:
        return True, "高熵长串（熵=%.2f）" % ent
    return False, "格式不符且熵不足（熵=%.2f）" % ent


def verify_secret(f, client, config=None):
    """真核验：重新从目标采集 + 密钥格式自校验。
    不信任落库的脱敏串（形如 AKIA12***ABCD 无法判长度），而是重新请求
    该 URL 并重扫，取原始命中串做格式/熵校验——这才是独立通道。
    邮箱/手机号/内网 IP 属信息类，不参与漏洞真实性判定。
    """
    url = f.get("url") or ""
    vtype = f.get("vuln_type") or ""
    if any(k in vtype for k in ("邮箱", "手机号", "身份证", "内网 IP", "内网IP")):
        return _verdict(UNKNOWN, "信息类·不作真实性判定", 0,
                        "联系信息/内网地址属情报参考，不作为漏洞真实性结论")
    if not url:
        return _verdict(UNKNOWN, "密钥·格式自校验", 0, "缺少 url")
    try:
        r = client.get(url, purpose="verify:secret")
    except Exception as e:
        return _verdict(UNKNOWN, "密钥·格式自校验", 1, "请求异常：%s" % e)
    if not r or not r.status:
        return _verdict(UNKNOWN, "密钥·格式自校验", 1, "目标不可达，无法复核")
    try:
        hits = probe.scan_secrets(url, r.text or "")
    except Exception as e:
        return _verdict(UNKNOWN, "密钥·格式自校验", 1, "重扫异常：%s" % e)
    if not hits:
        return _verdict(REFUTED, "密钥·格式自校验", 1,
                        "重新采集未再匹配到该敏感串，无法复现", "medium")
    types = [h.get("type") for h in hits]
    best_type, why = "", ""
    for h in hits:
        ok, w = _secret_selfcheck(h.get("raw"))
        if ok:
            return _verdict(CONFIRMED, "密钥·格式自校验", 1,
                            "%s 通过格式自校验：%s" % (h.get("type"), w), "high",
                            {"types": types})
        best_type, why = h.get("type"), w
    return _verdict(REFUTED, "密钥·格式自校验", 1,
                    "命中串未通过格式自校验：%s（%s）" % (why, best_type), "medium",
                    {"types": types})


# ------------------------------------------------------------
# 8) CORS：恶意 Origin 回显
# ------------------------------------------------------------
def verify_cors(f, client, config=None):
    """真核验：带任意 Origin 请求，看 ACAO 是否回显该 Origin 且允许凭据。
    检测层可能只看"存在 ACAO 头"；核验层要求回显**任意** Origin +
    ACAC=true，才能跨域窃取带凭据数据。
    """
    url = f.get("url") or ""
    if not url:
        return _verdict(UNKNOWN, "CORS·恶意 Origin 回显", 0, "缺少 url")
    probe_origin = "https://bt-verify.evil.example"
    try:
        r = client.get(url, headers={"Origin": probe_origin}, purpose="verify:cors")
    except Exception as e:
        return _verdict(UNKNOWN, "CORS·恶意 Origin 回显", 1, "请求异常：%s" % e)
    if not r or not r.status:
        return _verdict(UNKNOWN, "CORS·恶意 Origin 回显", 1, "目标不可达")
    acao = (r.header("Access-Control-Allow-Origin") or "").strip()
    acac = (r.header("Access-Control-Allow-Credentials") or "").strip().lower()
    detail = {"acao": acao or "-", "acac": acac or "-"}
    if acao == probe_origin and acac == "true":
        return _verdict(CONFIRMED, "CORS·恶意 Origin 回显", 1,
                        "ACAO 回显任意 Origin 且允许携带凭据，可跨域窃取数据",
                        "high", detail)
    if acao == probe_origin:
        return _verdict(UNKNOWN, "CORS·恶意 Origin 回显", 1,
                        "ACAO 回显任意 Origin 但未允许凭据，危害受限", "medium", detail)
    if acao in ("*", ""):
        return _verdict(REFUTED, "CORS·恶意 Origin 回显", 1,
                        "ACAO=%s，未回显任意 Origin" % (acao or "无"), "medium", detail)
    return _verdict(UNKNOWN, "CORS·恶意 Origin 回显", 1,
                    "ACAO=%s，与探测 Origin 不一致，未证实可控" % acao, "low", detail)


# ------------------------------------------------------------
# 9) 未授权访问：匿名可达性
# ------------------------------------------------------------
_LOGIN_HINTS_RE = re.compile(
    r"(name=[\"']?(password|passwd|pwd)|<form[^>]*login|请登录|用户登录|sign\s*in)",
    re.I)


def verify_unauth(f, client, config=None):
    """真核验：匿名请求能否直接拿到受保护的业务数据。
    关键是否定证据：401/403、跳登录、返回登录页 → 证伪。
    """
    url = f.get("url") or ""
    if not url:
        return _verdict(UNKNOWN, "未授权访问·匿名可达性", 0, "缺少 url")
    try:
        r = client.get(url, purpose="verify:unauth")
    except Exception as e:
        return _verdict(UNKNOWN, "未授权访问·匿名可达性", 1, "请求异常：%s" % e)
    if not r or not r.status:
        return _verdict(REFUTED, "未授权访问·匿名可达性", 1, "匿名请求不可达", "medium")
    t = r.text or ""
    ct = (r.content_type or "").lower()
    detail = {"status": r.status, "ctype": ct or "-", "length": r.length}
    # round89 FIX-12: 先自证通道干净。拦截页可能是 403，也可能是 200+JSON。
    _wall, _wev = _channel_clean(client, _base_of(url), r, "verify:unauth")
    if _wall:
        detail["wall"] = True
        return _verdict(UNKNOWN, "未授权访问·匿名可达性", 1, _wev, "high", detail)
    if r.status in (401, 403):
        return _verdict(REFUTED, "未授权访问·匿名可达性", 1,
                        "匿名请求返回 %d，访问已被拒绝" % r.status, "high", detail)
    if r.status in (301, 302, 303, 307, 308):
        return _verdict(REFUTED, "未授权访问·匿名可达性", 1,
                        "匿名请求被重定向（%d → %s），需鉴权"
                        % (r.status, r.header("Location") or "-"), "high", detail)
    if _LOGIN_HINTS_RE.search(t[:4000]):
        return _verdict(REFUTED, "未授权访问·匿名可达性", 1,
                        "匿名响应为登录页，未获得受保护数据", "high", detail)
    if "json" in ct and re.search(r"[\{\[].+[\}\]]", t, re.S):
        # round89 FIX-12: “是 JSON” 离 “是业务数据” 还差一步。实测大量站点
        # 对匿名请求回 {"code":401,"msg":"未登录"} 这类鉴权拒绝信封，旧逻辑
        # 当成业务数据 → 直接判证实（最危险的一类误报）。这里加信封识别：
        # 顶层没有任何 list/dict 型数据字段时，只能判 UNKNOWN。
        _env = None
        try:
            _env = json.loads(t)
        except Exception:
            _env = None
        _dk = []
        if isinstance(_env, dict):
            _dk = [k for k in _env.keys() if isinstance(_env.get(k), (list, dict))]
        if _dk:
            return _verdict(CONFIRMED, "未授权访问·匿名可达性", 1,
                            "匿名请求返回 JSON 业务数据（%d 字节，含数据字段 %s）"
                            % (r.length or 0, ",".join(_dk[:3])),
                            "high", detail)
        return _verdict(UNKNOWN, "未授权访问·匿名可达性", 1,
                        "匿名响应为 JSON 信封（无 list/dict 数据字段），"
                        "疑似鉴权拒绝，不能判定为未授权访问", "medium", detail)
    return _verdict(UNKNOWN, "未授权访问·匿名可达性", 1,
                    "匿名可达但响应不含明确业务数据特征，需人工核", "low", detail)


# ------------------------------------------------------------
# 9.5) 组件版本 → CVE 影响区间比对（独立证据通道）
# ------------------------------------------------------------
# 为什么这一层算"独立通道"？检测层（vulnchecks.check_cn_components /
# template_engine）判定组件存在的依据是"特征路径可访问 + 特征串命中"；
# 核验层不复用那个结论，而是**重新请求并解析出具体版本号**，再拿
# CVE_MAP 的公开影响区间做区间判定。"存在"与"有可利用漏洞"是两件事——
# 装了 nginx 1.18 和装了 nginx 1.16 的风险等级完全不同，只看指纹
# 命中就报"高危组件漏洞"正是这类扫描器的头号误报来源。
_COMPONENT_ALIASES = (
    ('apache tomcat', 'tomcat'), ('apache httpd', 'apache'), ('spring boot', 'spring'), ('microsoft sql server', 'mssql'),
    ('sql server', 'mssql'), ('sqlserver', 'mssql'), ('shardingsphere', 'shardingsphere'), ('phpmyadmin', 'phpmyadmin'),
    ('pma', 'phpmyadmin'), ('elasticsearch', 'elasticsearch'), ('elastic', 'elasticsearch'), ('kubernetes', 'k8s'),
    ('k8s', 'k8s'), ('xxl-job', 'xxljob'), ('xxljob', 'xxljob'), ('nginx', 'nginx'),
    ('openresty', 'openresty'), ('tengine', 'tengine'), ('caddy', 'caddy'), ('litespeed', 'litespeed'),
    ('apache', 'apache'), ('tomcat', 'tomcat'), ('jetty', 'jetty'), ('jboss', 'jboss'),
    ('wildfly', 'wildfly'), ('undertow', 'undertow'), ('resin', 'resin'), ('weblogic', 'weblogic'),
    ('websphere', 'websphere'), ('iis', 'iis'), ('spring', 'spring'), ('fastjson', 'fastjson'),
    ('thinkphp', 'thinkphp'), ('laravel', 'laravel'), ('django', 'django'), ('werkzeug', 'flask'),
    ('flask', 'flask'), ('php', 'php'), ('asp.net', 'aspnet'), ('aspnet', 'aspnet'),
    ('openssh', 'openssh'), ('nacos', 'nacos'), ('jenkins', 'jenkins'), ('gitlab', 'gitlab'),
    ('gitea', 'gitea'), ('grafana', 'grafana'), ('prometheus', 'prometheus'), ('zabbix', 'zabbix'),
    ('kibana', 'kibana'), ('skywalking', 'skywalking'), ('sentry', 'sentry'), ('redis', 'redis'),
    ('druid', 'druid'), ('harbor', 'harbor'), ('solr', 'solr'), ('consul', 'consul'),
    ('wordpress', 'wordpress'), ('minio', 'minio'), ('nexus', 'nexus'), ('sonarqube', 'sonarqube'),
    ('jolokia', 'jolokia'), ('verdaccio', 'verdaccio'), ('postgresql', 'postgresql'), ('postgres', 'postgresql'),
    ('mysql', 'mysql'), ('mariadb', 'mysql'), ('clickhouse', 'clickhouse'), ('influxdb', 'influxdb'),
    ('cassandra', 'cassandra'), ('couchdb', 'couchdb'), ('memcached', 'memcached'), ('etcd', 'etcd'),
    ('kafka', 'kafka'), ('rocketmq', 'rocketmq'), ('activemq', 'activemq'), ('rabbitmq', 'rabbitmq'),
    ('pulsar', 'pulsar'), ('neo4j', 'neo4j'), ('jira', 'jira'), ('confluence', 'confluence'),
    ('teamcity', 'teamcity'), ('kong', 'kong'), ('apisix', 'apisix'), ('portainer', 'portainer'),
    ('discuz', 'discuz'), ('joomla', 'joomla'), ('magento', 'magento'), ('airflow', 'airflow'),
    ('drupal', 'drupal'), ('adminer', 'adminer'),
)

# 国产 OA / 协同 / 面板：CVE_MAP 无对应键，走"特征路径可达性复核"通道。
_CN_COMPONENT_WORDS = ('致远', '泛微', '通达', '万户', '蓝凌', '华天动力', '帆软', '润乾', '金和', '红帆', '用友', '金蝶', '若依', 'RuoYi', 'JEECG', 'SpringBlade', 'Guns', '宝塔', 'Discuz', 'DedeCMS')


def _ver_tuple(v):
    """版本串 → 数字元组。'1.17.6' → (1,17,6)；
    'RELEASE.2023-03-20' → (2023,3,20)（取全部数字段，保序）。"""
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(v or "")))
    except Exception:
        return ()


def _ver_pad(a, b):
    n = max(len(a), len(b))
    return (tuple(list(a) + [0] * (n - len(a))),
            tuple(list(b) + [0] * (n - len(b))))


def _ver_cmp(a, b):
    """a>b → 1，a<b → -1，相等 → 0；短串按位补 0 后比较。
    无法解析（任一侧无数字段）返回 None，调用方按"不可判定"处理。"""
    ta, tb = _ver_tuple(a), _ver_tuple(b)
    if not ta or not tb:
        return None
    pa, pb = _ver_pad(ta, tb)
    return (pa > pb) - (pa < pb)


def _ver_in_range(ver, rng):
    """版本是否落在 (min, max) 闭区间内；None 表示该侧无界。"""
    try:
        lo, hi = rng
    except Exception:
        return False
    if lo is not None:
        c = _ver_cmp(ver, lo)
        if c is None or c < 0:
            return False
    if hi is not None:
        c = _ver_cmp(ver, hi)
        if c is None or c > 0:
            return False
    return True


def _component_key_of(vtype):
    """finding 的 vuln_type → CVE_MAP 组件键；未命中返回空串。"""
    t = (vtype or "").lower()
    if not t:
        return ""
    for alias, key in _COMPONENT_ALIASES:
        if alias in t:
            return key
    return ""


def verify_component(f, client, config=None):
    """组件类核验：重抓目标 → 版本指纹 → CVE 影响区间比对。

    三条通道按优先级：
      1) 解析到版本 + CVE_MAP 有该组件规则 → 区间比对（可 confirmed/refuted）
      2) 解析到版本但无规则 / 无版本 → 保留 inconclusive，不猜
      3) 国产组件（CVE_MAP 无键）→ 特征路径可达性复核（二次请求 + 软 404 基线）
    """
    url = f.get("url") or ""
    vtype = f.get("vuln_type") or ""
    key = _component_key_of(vtype)
    base = _base_of(url) or url
    if not base:
        return _verdict(UNKNOWN, "组件漏洞·版本比对", 0, "缺少 url")
    detail = {"component_key": key}
    resp = None
    try:
        resp = client.get(base, purpose="verify:component")
    except Exception as e:
        return _verdict(UNKNOWN, "组件漏洞·版本比对", 1,
                        "请求异常：%s" % e, "", detail)
    requests = 1
    vers = []
    if resp and resp.status:
        try:
            vers = probe.fingerprint_versions(resp)
        except Exception:
            vers = []
    # 站点根常被重定向/精简，补一次特征路径本身（组件类 finding 的 url）
    if not vers and url and url != base:
        try:
            r2 = client.get(url, purpose="verify:component")
            requests += 1
            if r2 and r2.status:
                vers = probe.fingerprint_versions(r2)
        except Exception:
            pass
    detail["versions"] = [{"name": n, "version": v, "key": k}
                          for n, v, k in (vers or [])]
    hit_key = key
    if not hit_key and vers:
        hit_key = vers[0][2]

    if not hit_key:
        # ---- 通道 3：国产组件特征路径可达性复核 ----
        if any(w in vtype for w in _CN_COMPONENT_WORDS):
            if not url:
                return _verdict(UNKNOWN, "组件漏洞·路径复核", requests,
                                "缺少 url", "", detail)
            try:
                base404 = probe.soft404_baseline(base, client)
                requests += 2   # 基线为多请求采样，此处按 2 保守计
            except Exception:
                base404 = None
            if not probe.baseline_usable(base404):
                return _verdict(UNKNOWN, "组件漏洞·路径复核", requests,
                                "软 404 基线不可用，无法复核路径真实性", "", detail)
            try:
                r = client.get(url, purpose="verify:component")
                requests += 1
            except Exception as e:
                return _verdict(UNKNOWN, "组件漏洞·路径复核", requests,
                                "请求异常：%s" % e, "", detail)
            if not r or not r.status:
                return _verdict(REFUTED, "组件漏洞·路径复核", requests,
                                "特征路径二次请求不可达，原结论不成立",
                                "medium", detail)
            if r.status in (404, 410):
                return _verdict(REFUTED, "组件漏洞·路径复核", requests,
                                "特征路径返回 %d，该路径并不存在" % r.status,
                                "high", detail)
            if probe.is_soft404(r, base404):
                return _verdict(REFUTED, "组件漏洞·路径复核", requests,
                                "响应与随机路径软 404 同质，属兜底页而非组件特征页",
                                "high", detail)
            return _verdict(CONFIRMED, "组件漏洞·路径复核", requests,
                            "特征路径二次可达（HTTP %d，%d 字节）且与软 404 基线不同质"
                            % (r.status, r.length or 0), "medium", detail)
        return _verdict(UNKNOWN, "组件漏洞·版本比对", requests,
                        "未能从响应解析出可判定的组件版本，需人工确认", "", detail)

    ver = ""
    for n, v, k in vers:
        if k == hit_key:
            ver = v
            break
    detail["component_key"] = hit_key
    detail["version"] = ver
    rules = dicts.CVE_MAP.get(hit_key) or []
    if not rules:
        return _verdict(UNKNOWN, "组件漏洞·版本比对", requests,
                        "组件 %s 无可用 CVE 影响区间规则，保留原结论" % hit_key,
                        "", detail)
    if not ver:
        return _verdict(UNKNOWN, "组件漏洞·版本比对", requests,
                        "组件 %s 存在但未解析到版本号，无法做区间比对" % hit_key,
                        "", detail)
    hits = []
    for cve, rng, desc, cvss in rules:
        if _ver_in_range(ver, rng):
            hits.append({"cve": cve, "range": list(rng),
                         "desc": desc, "cvss": cvss})
    detail["matched"] = hits
    if hits:
        names = ", ".join(h["cve"] for h in hits)
        return _verdict(CONFIRMED, "组件漏洞·版本比对", requests,
                        "解析到 %s %s，落入 %d 条公开影响区间：%s"
                        % (hit_key, ver, len(hits), names), "high", detail)
    return _verdict(REFUTED, "组件漏洞·版本比对", requests,
                    "解析到 %s %s，未落入任何已知 CVE 影响区间" % (hit_key, ver),
                    "medium", detail)


# ------------------------------------------------------------
# 10) 无法自动证实的类型（保留原结论，不误判）
# ------------------------------------------------------------
def verify_ssrf(f, client, config=None):
    return _verdict(UNKNOWN, "SSRF·带外通道缺失", 0,
                    "SSRF 真伪需 DNSLog/回连平台确认；无带外通道时不可证实，"
                    "本工具不自动外联，保留原结论待人工验证")


def _wp_creds_of(f):
    """从 finding 还原 (user_field, user, pass_field, pwd)。

    检测层写入的 payload 形如 'username=admin&password=admin123'，且**可能
    含空口令**（DEFAULT_CREDS 里有 ("sa","")，payload 为 'username=sa&password='）。
    所以这里不能用 parse_qs（会丢弃空值），必须手动切分并保留空串。
    """
    uf = (_param_of(f) or "username") or "username"
    pf = "password"
    user = pwd = ""
    parts = []
    for seg in str(f.get("payload") or "").split("&"):
        if not seg:
            continue
        if "=" in seg:
            k, v = seg.split("=", 1)
        else:
            k, v = seg, ""
        parts.append((k.strip(), v))
    if parts:
        uf = parts[0][0] or uf
        user = parts[0][1]
    if len(parts) >= 2:
        pf = parts[1][0] or pf
        pwd = parts[1][1]
    if not parts:
        # payload 缺失时的兜底：extra.param 做用户字段，其余无从还原
        ex = f.get("extra") if isinstance(f.get("extra"), dict) else {}
        uf = str(ex.get("param") or f.get("param") or uf)
    return uf, user, pf, pwd


def verify_weakpass(f, client, config=None):
    """真核验：用 finding 记录的凭据做一次真实登录，再看**会话是否真的生效**。

    为什么这是独立证据通道？
        检测层的判定依据是同一响应内的静态特征（成功关键词 / 响应长度变化），
        这类特征会被欢迎语、模板文字、随机广告位骗过；核验层不复用它，而是
        要求一个**行为层面的因果**：

            登录前：匿名访问 base → 是登录页 / 无会话
            登录后：拿到会话凭据（Set-Cookie / JWT）→ 复访 base → 内容变了

        静态特征伪造不了"会话状态变更"，所以这条通道的误报率远低于检测层。

    三档结论：
        confirmed    登录后取得会话凭据，且复访页面与匿名态不同
        refuted      出现明确失败文案 / 登录后拿不到任何会话凭据
        inconclusive 目标不可达、凭据无法还原、或拿到会话但复访无差异

    请求数 <= 4，全部经 client 统一 scope 校验与全局限速。
    """
    url = f.get("url") or ""
    if not url:
        return _verdict(UNKNOWN, "弱口令·凭据登录验证", 0, "缺少 url")
    uf, user, pf, pwd = _wp_creds_of(f)
    if not user and not pwd:
        return _verdict(UNKNOWN, "弱口令·凭据登录验证", 0,
                        "payload 中无法还原凭据，保留原结论待人工核")
    try:
        from modules.vulnchecks import _WEAK_FAIL_WORDS, _weak_evidence, _JWT_RE
    except Exception:
        _WEAK_FAIL_WORDS, _weak_evidence = (), None
        _JWT_RE = re.compile(r"eyJ[A-Za-z0-9_\-]{6,}")
    base = _base_of(url) or url
    n = 0

    # 1) 匿名基线：登录页长什么样，供后面比对"会话是否真的改变了页面"
    anon_text, anon_len = "", 0
    try:
        ra = client.get(base, purpose="verify:weakpass")
        n += 1
        if ra and ra.status:
            anon_text = ra.text or ""
            anon_len = ra.length
    except Exception:
        pass

    # 2) 错误口令基线：给证据强弱做参照（与检测层同源，保证口径一致）
    base_len, base_body = anon_len, anon_text.lower()
    try:
        rb = client.post(url, data={uf: "bt_verify_no_such_%d" % int(time.time()),
                                    pf: "wrong_pass_xyz"},
                         purpose="verify:weakpass")
        n += 1
        if rb and rb.status:
            base_len = rb.length
            base_body = (rb.text or "").lower()
    except Exception:
        pass

    # 3) 真实登录（凭据来自检测层 finding，不是新造的爆破）
    try:
        r = client.post(url, data={uf: user, pf: pwd}, purpose="verify:weakpass")
        n += 1
    except Exception as e:
        return _verdict(UNKNOWN, "弱口令·凭据登录验证", n, "登录请求异常：%s" % e)
    if not r or not r.status:
        return _verdict(UNKNOWN, "弱口令·凭据登录验证", n, "目标不可达，无法验证")

    body_low = (r.text or "").lower()
    detail = {"status": r.status, "length": r.length, "baseline": base_len,
              "field": "%s/%s" % (uf, pf)}
    # 负证据优先：明确"凭据错误"文案 → 直接证伪，绝不把误报确认成漏洞
    if _WEAK_FAIL_WORDS and any(w in body_low for w in _WEAK_FAIL_WORDS):
        detail["fail_hit"] = [w for w in _WEAK_FAIL_WORDS if w in body_low][:3]
        return _verdict(REFUTED, "弱口令·凭据登录验证", n,
                        "登录响应出现明确失败文案（%s），该凭据无效"
                        % "、".join(detail["fail_hit"]), "high", detail)

    ev = _weak_evidence(r, body_low, base_len, base_body) if _weak_evidence else []
    strong = [e for e in ev if not e.startswith("长度变化")]
    # 会话凭据：核验层的硬门槛，没有它就不算"登录成功"
    sess = []
    if (r.header("Set-Cookie") or ""):
        sess.append("Set-Cookie")
    if _JWT_RE.search(r.text or ""):
        sess.append("JWT")
    detail["evidence"] = ev
    detail["session"] = sess or ["-"]

    if r.status in (200, 302, 303) and sess:
        # 4) 复访：会话是否真的打开了"匿名态打不开"的内容
        try:
            rv = client.get(base, purpose="verify:weakpass")
            n += 1
            if rv and rv.status:
                anon_login = bool(_LOGIN_HINTS_RE.search(anon_text[:4000]))
                now_login = bool(_LOGIN_HINTS_RE.search((rv.text or "")[:4000]))
                detail["revisit_status"] = rv.status
                detail["revisit_length"] = rv.length
                changed = bool(anon_text) and abs(rv.length - anon_len) > max(64, int(anon_len * 0.1))
                if (anon_login and not now_login) or changed:
                    return _verdict(CONFIRMED, "弱口令·凭据登录验证", n,
                                    "凭据 %s/%s 登录后取得有效会话（%s），复访页面与匿名态不同"
                                    "（匿名态%s登录页、已登录态%s登录页，长度 %d→%d）"
                                    % (user, pwd, "、".join(sess),
                                       "是" if anon_login else "非",
                                       "是" if now_login else "非", anon_len, rv.length),
                                    "high", detail)
        except Exception:
            pass
        if strong:
            return _verdict(CONFIRMED, "弱口令·凭据登录验证", n,
                            "登录返回有效会话凭据（%s）且命中成功证据：%s"
                            % ("、".join(sess), "、".join(strong)), "high", detail)
        return _verdict(UNKNOWN, "弱口令·凭据登录验证", n,
                        "登录返回会话凭据但复访未观察到权限差异，需人工核",
                        "medium", detail)
    if strong:
        return _verdict(UNKNOWN, "弱口令·凭据登录验证", n,
                        "命中成功证据（%s）但未取得会话凭据，需人工核"
                        % "、".join(strong), "medium", detail)
    return _verdict(REFUTED, "弱口令·凭据登录验证", n,
                    "登录后未取得会话凭据、亦无成功证据，判定该凭据无效",
                    "high", detail)


# ------------------------------------------------------------
# 账号枚举核验（round78 ③）
# ------------------------------------------------------------
# 检测层只采样一轮（不存在名 a/b + 对照名），一次网络抖动或动态内容就会
# 造成单轮误判；核验层不看单轮结果，而是把同一因果条件**连测两轮**并
# 比对相似度矩阵，只有「两轮都稳定复现差异」才确认。相似度阈值直接复用
# 检测层的 _body_similarity / _USER_ENUM_SIM，不新造口径。
_ENUM_SIM_SAME = 0.9


def _enum_active_ok(config):
    """主动核验门槛：safe 强度下只降「未核验」，不发探测流量。

    round78 决策点 A：账号枚举核验会真发请求，仅在 aggressive 强度
    （或显式开了主动检测）时执行；判定失败一律回落 not_verified，
    绝不因为「没跑」而误标成「已证伪」。
    """
    def _g(k):
        try:
            if config is not None and hasattr(config, "get"):
                return config.get(k)
        except Exception:
            pass
        return None

    if str(_g("scan.intensity") or "").lower() in ("aggressive", "active"):
        return True
    for key in ("scan.enable_active", "enable_active", "allow_active"):
        if _g(key):
            return True
    try:
        fn = getattr(config, "scan_profile", None)
        if callable(fn):
            active, _poc = fn()
            return bool(active)
    except Exception:
        pass
    return False


def _enum_sim(a, b):
    """两段响应体的相似度（复用检测层实现，口径不新造）。"""
    try:
        from modules.vulnchecks import _body_similarity as _bs
        return float(_bs(a, b))
    except Exception:
        import difflib
        return float(difflib.SequenceMatcher(
            None, (a or "")[:4000], (b or "")[:4000]).ratio())


def verify_account_enum(f, client, config=None):
    """真核验：同一端点再做一轮「双名对照」，要求**两轮结论一致**。

    判定：
        confirmed    不存在名两轮互相同质(>=0.9)，且与对照名两轮均可区分(<0.9)
        refuted      不存在名与对照名两轮均同质（端点一视同仁，无存在性泄露）
        inconclusive 两轮结论不一致（不稳定）、目标不可达或基线不可用
        not_verified 缺 url / safe 强度（不主动发流量）
    请求数 <= 6，全部经 client 统一 scope 校验与全局限速，只读无副作用。
    """
    url = f.get("url") or ""
    if not url:
        return _verdict(NOT_VERIFIED, "账号枚举·双轮对照", 0,
                        "缺少 url，核验前置条件不足")
    if not _enum_active_ok(config):
        return _verdict(NOT_VERIFIED, "账号枚举·双轮对照", 0,
                        "safe 强度下不主动复现账号枚举（需核验请切 aggressive）")
    base_url = _base_of(url)
    if not base_url:
        return _verdict(NOT_VERIFIED, "账号枚举·双轮对照", 0,
                        "URL 无法解析出站点根，核验前置条件不足")
    uf = _param_of(f) or "username"
    method = _method_of(f)
    n = 0
    base = probe.soft404_baseline(base_url, client)
    n += 1
    if not probe.baseline_usable(base):
        return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                        "软 404 基线不可用，无法判定")
    try:
        from modules import vulnchecks as _vc
        control = getattr(dicts, "USER_ENUM_CONTROL", "admin")
        rounds = []
        for tag in ("a", "b"):
            nm = _vc._enum_probe_name(url, tag)
            rs = _vc._enum_call(client, url, method, uf, nm)
            rc = _vc._enum_call(client, url, method, uf, control)
            n += 2
            if not rs or not rs.status or not rc or not rc.status:
                return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                                "目标不可达（探测请求无响应），无法判定")
            rounds.append((nm, rs, rc))
    except Exception as e:
        return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                        "核验请求异常：%s" % e)

    (n1, s1, c1), (n2, s2, c2) = rounds
    # round89 FIX-14：错误页不携带业务判定。检测层已加状态码闸，但真实
    # 报告里的历史发现（lanli.cc 31 条，100% HTTP 405）仍会被拿来回放核
    # 验，所以核验侧必须独立再判一次，否则报告还会继续出现
    # 「Verified: yes + HTTP 405 nginx 默认错误页」这种自相矛盾的结论。
    try:
        from modules.vulnchecks import _is_non_business as _is_nb
    except Exception:
        _is_nb = lambda st: False
    _nb = [x for x in (s1.status, s2.status, c1.status, c2.status) if _is_nb(x)]
    if _nb:
        return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                        "端点返回非业务状态码 HTTP %s（端点不接受该请求方法或未"
                        "实现），服务端未执行用户名判定，无法判定" % _nb[0],
                        "high",
                        {"field": uf, "param": uf,
                         "non_business_status": _nb[0],
                         "r1": {"name": n1, "status": s1.status,
                                "length": s1.length, "hash": s1.body_hash},
                         "r2": {"name": n2, "status": s2.status,
                                "length": s2.length, "hash": s2.body_hash}})
    # round89 FIX-6：检测阶段会把「站点统一拦截页」当成端点存在（实测
    # zt.bbs.ztgame.com/api/user/exist 返回的是 <title>WAF 的 403/2785，
    # 而不存在的路径走 nginx 真 404）。若核验器只看软 404 基线，就会把
    # WAF 页当成「账号枚举已证实」。核验必须先自证通道干净：
    # 两个不同的不存在名若返回同质响应，说明端点只回拦截页，无法判定。
    # round89 FIX-15：对照名（admin 等常见名）落到 403/429/5xx 时，差异来自
    # 「被拒 / 被限流 / 后端故障」，不是「这个用户名存在」。检测层已加同名闸门，
    # 核验层必须独立再判一次：否则历史发现回放核验时，一个 WAF 403 就会被
    # 算成 d1<0.9 → CONFIRMED，报告继续出现「Verified: yes + 对照名 403」。
    try:
        from modules.vulnchecks import _is_control_unreliable as _is_cu
    except Exception:
        _is_cu = lambda st: False
    _cu = [x for x in (c1.status, c2.status) if _is_cu(x)]
    if _cu:
        return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                        "对照名返回 HTTP %s（被拒绝 / 被限流 / 服务端故障），差异来自"
                        "基础设施而非用户名存在性，无法判定" % _cu[0],
                        "high",
                        {"field": uf, "param": uf, "control": control,
                         "unreliable_control_status": _cu[0],
                         "r1": {"name": n1, "status": s1.status,
                                "length": s1.length, "hash": s1.body_hash},
                         "r2": {"name": n2, "status": s2.status,
                                "length": s2.length, "hash": s2.body_hash},
                         "ctrl": {"status": c1.status, "length": c1.length,
                                  "hash": c1.body_hash}})
    if s1.status in (401, 403, 412, 429, 503) and s2.status == s1.status:
        _wsim = _enum_sim(s1.text, s2.text)
        if _wsim >= _ENUM_SIM_SAME:
            return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                            "端点对任意不存在名均返回同一响应（HTTP %d，相似度 %.2f），"
                            "疑似统一拦截页，非账号枚举" % (s1.status, _wsim),
                            "high",
                            {"field": uf, "param": uf,
                             "r1": {"name": n1, "status": s1.status,
                                    "length": s1.length, "hash": s1.body_hash},
                             "r2": {"name": n2, "status": s2.status,
                                    "length": s2.length, "hash": s2.body_hash},
                             "sim_self": round(_wsim, 4)})
    if probe.is_soft404(s1, base) or probe.is_soft404(s2, base):
        return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                        "不存在名响应与软 404 基线同质（路径未被单独处理），无法判定")
    self_sim = _enum_sim(s1.text, s2.text)      # 不存在名：两轮应同质
    ctrl_sim = _enum_sim(c1.text, c2.text)      # 对照名：两轮应同质
    d1 = _enum_sim(s1.text, c1.text)            # 轮1：不存在名 vs 对照名
    d2 = _enum_sim(s2.text, c2.text)            # 轮2：同上
    det = {"field": uf, "param": uf, "control": control,
           "r1": {"name": n1, "status": s1.status, "length": s1.length,
                  "hash": s1.body_hash},
           "r2": {"name": n2, "status": s2.status, "length": s2.length,
                  "hash": s2.body_hash},
           "ctrl": {"status": c1.status, "length": c1.length,
                    "hash": c1.body_hash},
           "sim_self": round(self_sim, 4), "sim_ctrl": round(ctrl_sim, 4),
           "sim_round1": round(d1, 4), "sim_round2": round(d2, 4)}
    stable_self = self_sim >= _ENUM_SIM_SAME
    if not stable_self:
        return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                        "两轮对同一不存在名返回不一致（相似度 %.2f），端点响应不稳定"
                        % self_sim, "medium", det)
    if d1 < _ENUM_SIM_SAME and d2 < _ENUM_SIM_SAME:
        return _verdict(CONFIRMED, "账号枚举·双轮对照", n,
                        "两轮均复现「不存在名 / 对照名」响应差异（不存在名两轮相似度 %.2f，"
                        "与对照名相似度 %.2f、%.2f；HTTP %d vs %d），可据此批量判断账号是否存在"
                        % (self_sim, d1, d2, s1.status, c1.status), "high", det)
    if ctrl_sim >= _ENUM_SIM_SAME:
        return _verdict(REFUTED, "账号枚举·双轮对照", n,
                        "两轮均未复现差异：不存在名与对照名响应同质（%.2f / %.2f），"
                        "端点未泄露用户名存在性" % (d1, d2), "high", det)
    return _verdict(UNKNOWN, "账号枚举·双轮对照", n,
                    "对照名两轮响应不稳定（相似度 %.2f），不足以定论" % ctrl_sim,
                    "medium", det)


# ------------------------------------------------------------
# 分派表（关键字按"先具体后泛化"排列）
# ------------------------------------------------------------
_VERIFIERS = [
    ("账号枚举", verify_account_enum),
    ("时间盲注", verify_sqli_time),
    ("报错注入", verify_sqli_error),
    ("XSS", verify_xss_reflect),
    ("重定向", verify_open_redirect),
    ("SSRF", verify_ssrf),
    ("备份", verify_backup_file),
    ("源码", verify_backup_file),
    # round89 FIX-3：真实扫描的 pay.ztgame.com 报了「FTP 配置文件泄露」
    # （ftp-config.json / .ftpconfig），字串里没有一个能命中上表的
    # 「备份/源码」关键词，于是被打成「无对应核验器 / not_verified」，
    # 一次请求都不发。这类凭据文件与备份文件是同一套判据（魔数+软404
    # +换UA稳定性），没理由不核。补进去，并把「配置/凭据」类词一并纳入。
    ("配置文件", verify_backup_file),
    ("凭据", verify_backup_file),
    ("凭证", verify_backup_file),
    ("私钥", verify_backup_file),
    ("密钥文件", verify_backup_file),
    ("证书", verify_backup_file),
    ("目录列表", verify_dirlist),
    ("敏感信息", verify_secret),
    ("密钥", verify_secret),
    ("CORS", verify_cors),
    ("未授权", verify_unauth),
    ("弱口令", verify_weakpass),
    ("组件", verify_component),
]

# 组件类 finding 的 vuln_type 是具体组件名（如“致远OA 任意文件上传”“Spring Actuator 环境信息泄露”），
# 不含“组件”二字，故上表的子串匹配命中不了。此处按“能否映射到组件键”补一层路由。
def _is_component_finding(vtype):
    """能映射到 CVE_MAP 组件键，或命中国产组件词，则归组件类。"""
    if not vtype:
        return False
    if _component_key_of(vtype):
        return True
    if any(w in vtype for w in _CN_COMPONENT_WORDS):
        return True
    t = vtype.lower()
    return any(k and k in t for k in dicts.CVE_MAP.keys())



def verify_finding(f, client, config=None):
    """对单条 finding 做真实性核验，返回带 url/vuln_type/param/method 的结论。"""
    vtype = f.get("vuln_type") or f.get("type") or ""
    # 组件类先行匹配：其 vuln_type 为具体组件名，不含“组件”字样
    if _is_component_finding(vtype):
        try:
            res = verify_component(f, client, config)
        except Exception as e:
            log.warning("核验异常 %s %s: %s", vtype, f.get("url"), e)
            res = _verdict(UNKNOWN, "核验异常", 0, "核验器异常：%s" % e)
        res["verifier"] = res.get("method") or ""
        res["vuln_type"] = vtype
        res["url"] = f.get("url") or ""
        res["param"] = _param_of(f)
        res["method"] = _method_of(f)
        res["finding_id"] = f.get("id")
        return res
    for kw, fn in _VERIFIERS:
        if kw in vtype:
            try:
                res = fn(f, client, config)
            except Exception as e:
                log.warning("核验异常 %s %s: %s", vtype, f.get("url"), e)
                res = _verdict(UNKNOWN, "核验异常", 0, "核验器异常：%s" % e)
            res["verifier"] = res.get("method") or ""
            res["vuln_type"] = vtype
            res["url"] = f.get("url") or ""
            res["param"] = _param_of(f)
            res["method"] = _method_of(f)
            res["finding_id"] = f.get("id")
            return res
    return {"verdict": NOT_VERIFIED, "method": "无对应核验器", "requests": 0,
            "verifier": "无对应核验器",
            "evidence": "该漏洞类型无独立核验通道（一次请求都未发起），保留原结论",
            "confidence": "", "detail": {}, "vuln_type": vtype,
            "url": f.get("url") or "", "param": _param_of(f),
            "http_method": _method_of(f), "finding_id": f.get("id")}


def verify_target(db, target, client, config=None, limit=None, max_requests=400,
                  only_ids=None):
    """对某目标已落库的全部 finding 做真实性核验，回写 DB 并返回结果列表。

    回写规则（与 engine._persist 的去重语义一致，绝不新 INSERT）：
      - confirmed    → db.mark_verified（原地升级为"已复现"）
      - refuted      → db.set_verdict（标 verify_verdict=refuted，主报告据此剔除）
      - inconclusive → db.set_verdict（标 verify_verdict=inconclusive，保留但标注）
    所有结论同时落 verifications 表，供误报率统计与检测规则收紧。
    """
    # r88 缺陷 #6 联动：scan 后自动核验只核「本轮」的 finding。
    # 否则历史行会一直占 max_requests 预算，本轮新项反而轮不上，
    # 且旧误报被反复核验、报告口径混乱。only_ids 为 None 时保持原全量语义
    # （手动 verify 命令仍可核历史）。
    if only_ids is not None:
        rows = db.findings_by_ids(only_ids)
        _ords = {int(i): _k for _k, i in enumerate(only_ids)}
        rows.sort(key=lambda r: _ords.get(int(r.get("id") or 0), 10 ** 9))
    else:
        rows = db.all_findings(target)
    if limit:
        rows = rows[:int(limit)]
    results = []
    spent = 0
    for f in rows:
        if spent >= max_requests:
            log.warning("[核验] 已达单目标请求上限 %d，剩余 %d 条跳过",
                        max_requests, len(rows) - len(results))
            break
        # round78 ④：0 请求的 inconclusive 一律降档 not_verified，
        # 避免把「没核验过」混进「核验过但判不出来」。
        res = _demote_unverified(verify_finding(f, client, config))
        spent += res.get("requests", 0)
        fid = f.get("id")
        try:
            if res["verdict"] == CONFIRMED:
                db.mark_verified(
                    fid, confidence=res.get("confidence") or None,
                    evidence="[核验] %s：%s" % (res["method"], res["evidence"]))
            db.set_verdict(fid, res["verdict"], method=res.get("method", ""),
                           evidence=res.get("evidence", ""),
                           confidence=res.get("confidence", ""))
            db.add_verification(
                finding_id=fid, target=target, host=f.get("host", ""),
                url=f.get("url", ""), vuln_type=res.get("vuln_type", ""),
                param=res.get("param", ""), method=res.get("method", ""),
                verdict=res["verdict"], confidence=res.get("confidence", ""),
                method_used=res.get("verifier") or res.get("method", ""),
                requests=res.get("requests", 0),
                evidence=res.get("evidence", ""), detail=res.get("detail", {}))
        except Exception as e:
            log.warning("核验结果回写失败 fid=%s: %s", fid, e)
        results.append(res)
        logger.audit("verify_done", target=target, url=res.get("url"),
                     type=res.get("vuln_type"), verdict=res["verdict"],
                     method=res.get("method"))
        log.info("[核验] %s · %s · %s", VERDICT_CN.get(res["verdict"], res["verdict"]),
                 res.get("vuln_type"), res.get("url"))
    return results


# ------------------------------------------------------------
# 独立核验报告（与主报告分离，用户明确要求不同文件）
# ------------------------------------------------------------
def _by_type(results):
    agg = {}
    for r in results:
        t = r.get("vuln_type") or "未知"
        d = agg.setdefault(t, {"total": 0, CONFIRMED: 0, REFUTED: 0,
                               UNKNOWN: 0, NOT_VERIFIED: 0})
        d["total"] += 1
        d[r["verdict"]] = d.get(r["verdict"], 0) + 1
    return agg


def _safe(target):
    try:
        from core.report import _safe_name
        return _safe_name(target)
    except Exception:
        return re.sub(r"[^\w.\-]+", "_", (target or "target"))[:60] or "target"


def write_verify_report(target, results, meta=None, out_dir=None,
                        ai_stat=None):
    """产出独立核验报告：verify_report.md + verify.json，返回路径字典。

    ``ai_stat`` 为 round89 的 AI 分层复核统计（可为 None）；传了就额外产出一节
    「AI 复核旁证」，并给每条 inconclusive 标注 AI 怎么看。**AI 结论不参与**
    三档计数与误报率计算，只做旁证展示——规则口径不许被模型漂移。
    """
    cfg.ensure_dirs()
    meta = dict(meta or {})
    if out_dir is None:
        ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        out_dir = os.path.join(cfg.REPORT_DIR, "%s-verify-%s" % (_safe(target), ts))
    os.makedirs(out_dir, exist_ok=True)

    total = len(results)
    n_ok = sum(1 for r in results if r["verdict"] == CONFIRMED)
    n_no = sum(1 for r in results if r["verdict"] == REFUTED)
    # round78 ④：「未核验」单列一档——它表示一次请求都没发（缺核验通道），
    # 与「核验器跑了但证据不足」不是同一件事；两者都不进误报率分母。
    n_nv = sum(1 for r in results if r["verdict"] == NOT_VERIFIED)
    n_un = total - n_ok - n_no - n_nv
    # 误报率口径与 db.verify_stats / Engine.verify / cmd_verify 三处保持一致：
    # refuted / (confirmed + refuted)，即**在能判定的样本里**有多少是误报。
    # inconclusive（无法判定）既非误报也非真实漏洞，不进分母，否则会把
    # 误报率稀释成好看但无意义的数字。
    decidable = n_ok + n_no
    # round78 ⑤：分母为 0 时不能当成「误报率 0%」——那是「无样本可算」。
    # 数值字段仍保持 0.0（不破下游契约），另出 decidable
    # 供消费方判断能不能算；人看的文本直接写明。
    fp_rate = (n_no / float(decidable)) if decidable else 0.0
    agg = _by_type(results)
    now = datetime.datetime.now().isoformat()

    lines = []
    lines.append("# 漏洞真实性核验报告")
    lines.append("")
    lines.append("> 本报告由**独立核验层**产出，与扫描报告分离。核验走的是与检测层")
    lines.append("> 不同的证据通道（延迟因果 / 三段因果 / HTML 上下文 / 双域对照 /")
    lines.append("> 文件魔数 / 格式自校验），用于剔除误报、只保留可提交项。")
    lines.append("")
    lines.append("| 项 | 值 |")
    lines.append("| --- | --- |")
    lines.append("| 目标 | %s |" % target)
    lines.append("| 生成时间 | %s |" % now)
    lines.append("| 核验总数 | %d |" % total)
    lines.append("| 已证实 | **%d** |" % n_ok)
    lines.append("| 已证伪 | **%d** |" % n_no)
    lines.append("| 无法判定 | **%d** |" % n_un)
    lines.append("| 未核验（缺核验通道） | **%d** |" % n_nv)
    if decidable:
        lines.append("| 误报率 | **%.1f%%**（证伪 %d / 可判定 %d） |"
                     % (fp_rate * 100, n_no, decidable))
    else:
        lines.append("| 误报率 | —（无可判定样本：证实 0 / 证伪 0） |")
    for k in ("program", "author", "src_platform", "intensity"):
        if meta.get(k):
            lines.append("| %s | %s |" % (k, meta[k]))
    lines.append("")

    lines.append("## 一、按类型统计（含误报率）")
    lines.append("")
    lines.append("| 漏洞类型 | 总数 | 已证实 | 已证伪 | 无法判定 | 未核验 | 误报率 | 建议 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |")
    for t, d in sorted(agg.items(), key=lambda kv: -kv[1]["total"]):
        # 同口径：单类型也只在「能判定」的样本里算误报率。
        _dec = d[CONFIRMED] + d[REFUTED]
        rate = (d[REFUTED] / float(_dec)) if _dec else 0.0
        if _dec >= 3 and rate >= 0.5:
            adv = "误报率偏高，建议收紧该规则判定阈值"
        elif rate > 0:
            adv = "存在误报，复核规则"
        else:
            adv = "未见误报"
        _rate_cell = ("%.1f%%" % (rate * 100)) if _dec else "—"
        lines.append("| %s | %d | %d | %d | %d | %d | %s | %s |"
                     % (t, d["total"], d[CONFIRMED], d[REFUTED], d[UNKNOWN],
                        d.get(NOT_VERIFIED, 0), _rate_cell, adv))
    lines.append("")

    _ai = ai_stat if isinstance(ai_stat, dict) else {}
    if _ai.get("enabled"):
        lines.append("## 一之二、AI 分层复核（只复核 inconclusive，不改判）")
        lines.append("")
        lines.append("| 项 | 值 |")
        lines.append("| --- | --- |")
        lines.append("| 复核条数 | %d |" % int(_ai.get("reviewed", 0)))
        lines.append("| 疑似真实（likely_true） | %d |" % int(_ai.get("likely_true", 0)))
        lines.append("| 疑似误报（likely_false） | %d |" % int(_ai.get("likely_false", 0)))
        lines.append("| 也判不准（uncertain） | %d |" % int(_ai.get("uncertain", 0)))
        lines.append("| 跳过（超上限） | %d |" % int(_ai.get("skipped", 0)))
        lines.append("| 调用失败 | %d |" % int(_ai.get("failed", 0)))
        lines.append("| 模型 | %s |" % (_ai.get("model") or "-"))
        lines.append("")
        lines.append("> AI 只对规则**无法判定**的样本作旁证，**不覆盖**规则结论，")
        lines.append("> 也不计入上面的三档计数与误报率。提交前仍以人工复核为准。")
        lines.append("")
        _case = [(i, r) for i, r in enumerate(results, 1)
                 if isinstance(r.get("ai_review"), dict)]
        if _case:
            lines.append("| # | 漏洞类型 | URL | 规则结论 | AI 旁证 | 理由 | 置信 |")
            lines.append("| ---: | --- | --- | --- | --- | --- | ---: |")
            for i, r in _case:
                _r2 = r["ai_review"]
                lines.append("| %d | %s | %s | %s | %s | %s | %.2f |"
                             % (i, r.get("vuln_type", ""), r.get("url", ""),
                                VERDICT_CN.get(r["verdict"], r["verdict"]),
                                AI_REVIEW_CN.get(_r2.get("verdict"),
                                                  _r2.get("verdict") or "-"),
                                (_r2.get("reason") or "-")[:80],
                                float(_r2.get("confidence") or 0)))
            lines.append("")
    lines.append("## 二、核验明细")
    lines.append("")
    lines.append("| # | 结论 | 漏洞类型 | URL | 参数 | 核验方法 | 请求数 |")
    lines.append("| ---: | --- | --- | --- | --- | --- | ---: |")
    for i, r in enumerate(results, 1):
        lines.append("| %d | %s | %s | %s | %s | %s | %d |"
                     % (i, VERDICT_CN.get(r["verdict"], r["verdict"]),
                        r.get("vuln_type", ""), r.get("url", ""),
                        r.get("param", "") or "-", r.get("method", ""),
                        r.get("requests", 0)))
    lines.append("")

    lines.append("## 三、证据链")
    lines.append("")
    for i, r in enumerate(results, 1):
        lines.append("### %d. [%s] %s" % (
            i, VERDICT_CN.get(r["verdict"], r["verdict"]), r.get("vuln_type", "")))
        lines.append("")
        lines.append("- URL：%s" % r.get("url", ""))
        lines.append("- 请求语义：%s %s" % (r.get("method", "GET"),
                                       ("参数 " + r["param"]) if r.get("param") else ""))
        lines.append("- 核验方法：%s" % r.get("method", ""))
        lines.append("- 核验请求数：%d" % r.get("requests", 0))
        lines.append("- 结论证据：%s" % (r.get("evidence") or "-"))
        det = r.get("detail") or {}
        if det:
            try:
                lines.append("- 关键数据：`%s`"
                             % json.dumps(det, ensure_ascii=False)[:600])
            except Exception:
                pass
        lines.append("")

    nv = [r for r in results if r["verdict"] == NOT_VERIFIED]
    if nv:
        lines.append("## 四、未核验清单（缺核验通道，不计入误报率分母）")
        lines.append("")
        lines.append("以下 %d 条**一次请求都未发起**：该漏洞类型尚无独立核验通道，"
                     "或核验前置条件不足。它们**不是“核验过但判不出”**，"
                     "也不进误报率分母，需要人工或新增核验器后再判。" % len(nv))
        lines.append("")
        for r in nv:
            lines.append("- `%s` %s —— %s"
                         % (r.get("vuln_type", ""), r.get("url", ""),
                            r.get("evidence", "") or "无核验通道"))
        lines.append("")

    refuted = [r for r in results if r["verdict"] == REFUTED]
    if refuted:
        lines.append("## 五、误报样本（已证伪，已从主报告剔除）")
        lines.append("")
        for r in refuted:
            lines.append("- `%s` %s —— %s"
                         % (r.get("vuln_type", ""), r.get("url", ""),
                            r.get("evidence", "")))
        lines.append("")

    md_path = os.path.join(out_dir, "verify_report.md")
    with open(md_path, "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines))

    payload = {
        "meta": dict(meta, target=target, generated_at=now),
        "total": total,
        "confirmed": n_ok, "refuted": n_no, "inconclusive": n_un,
        "not_verified": n_nv,
        # decidable=0 时 false_positive_rate 的 0.0 表示「无样本」
        "decidable": decidable,
        "false_positive_rate": round(fp_rate, 4),
        "by_type": agg,
        "ai_review": (_ai if isinstance(_ai, dict) else {}),
        "results": results,
    }
    json_path = os.path.join(out_dir, "verify.json")
    with open(json_path, "w", encoding="utf-8") as fp:
        json.dump(payload, fp, ensure_ascii=False, indent=2)

    logger.audit("verify_report_generated", target=target, dir=out_dir,
                 total=total, confirmed=n_ok, refuted=n_no)
    log.info("核验报告已生成：%s（已证实 %d / 已证伪 %d / 无法判定 %d / 未核验 %d）",
             md_path, n_ok, n_no, n_un, n_nv)
    return {"dir": out_dir, "markdown": md_path, "json": json_path,
            "total": total, "confirmed": n_ok, "refuted": n_no,
            "inconclusive": n_un, "not_verified": n_nv,
            "decidable": decidable,
            "false_positive_rate": round(fp_rate, 4)}
# ------------------------------------------------------------
# AI 分层复核（round89 新增）
# ------------------------------------------------------------
# 设计红线（必须逐条守住）：
#   1) 只复核 verdict == UNKNOWN（inconclusive）。confirmed/refuted 是规则引擎
#      已经能定论的，AI 不碰；not_verified 是「一次请求都没发」（缺核验通道），
#      交给 AI 也没有证据可读，同样不碰。
#   2) AI 结论写成**新增字段** ai_review，绝不覆盖 verdict。规则结论是审计
#      基线，AI 只是旁证；两者分列，报告里能看出「规则怎么说、AI 怎么说」。
#   3) AI 不可用（未配置 / 双开关关 / 端点不通 / 返回非 JSON）时，本函数必须
#      静默返回空统计，让调用方完全保持原行为——不崩、不阻塞、不写半截字段。
#   4) AI 不得自己发请求：只读已有证据（URL / 参数 / 核验方法 / 证据串 /
#      关键数据），因此本层天然只读、无危害，也不会扩大攻击面。
AI_REVIEW_VERDICTS = ("likely_true", "likely_false", "uncertain")
AI_REVIEW_CN = {"likely_true": "AI 倾向真实",
                "likely_false": "AI 倾向误报",
                "uncertain": "AI 也判不准"}
# 单次核验里最多复核多少条（控 token；超出部分保持原样，只记 skipped）
AI_REVIEW_MAX = 40
# 每条送给模型的证据截断长度（避免长响应体把 token 打爆）
_AI_EV_MAX = 400

def _ai_review_system():
    return ("你是 Web 漏洞验证工程师，只做判断题，只输出 JSON，不写任何解释。\n"
            "输入是一条扫描器找到、但规则核验器**无法判定**（inconclusive）的疑似漏洞。\n"
            "请你根据给出的证据链判断它更像真实漏洞还是误报。\n"
            "三个可选结论：\n"
            "  likely_true  —— 证据能支撑该漏洞真实存在\n"
            "  likely_false —— 证据更像巧合/正常行为（如报错来自通用错误页、\n"
            "                  反射落在 JSON 或已实体编码、延迟与载荷无关）\n"
            "  uncertain    —— 证据不足以判断\n"
            "只输出 JSON：{\"verdict\":\"likely_true|likely_false|uncertain\","
            "\"reason\":\"一句话理由\",\"confidence\":0.0~1.0}")

def _ai_case_prompt(res, idx):
    det = res.get("detail") or {}
    try:
        det_s = json.dumps(det, ensure_ascii=False)[:_AI_EV_MAX]
    except Exception:
        det_s = ""
    return ("案件编号：%d\n"
            "漏洞类型：%s\n"
            "URL：%s\n"
            "参数：%s\n"
            "请求方法：%s\n"
            "规则核验方法：%s\n"
            "规则核验请求数：%d\n"
            "规则结论：%s（证据不足）\n"
            "规则证据：%s\n"
            "关键数据：%s"
            % (idx, res.get("vuln_type") or "未知", res.get("url") or "",
               res.get("param") or "-", res.get("http_method") or "GET",
               res.get("method") or "-", int(res.get("requests") or 0),
               VERDICT_CN.get(res.get("verdict"), res.get("verdict")),
               (res.get("evidence") or "-")[:_AI_EV_MAX], det_s or "-"))

def _ai_parse(obj):
    """把模型返回钳成约定形状；不合格返回 None（调用方按「AI 没给结论」处理）。"""
    if not isinstance(obj, dict):
        return None
    v = str(obj.get("verdict") or "").strip().lower()
    if v not in AI_REVIEW_VERDICTS:
        return None
    reason = str(obj.get("reason") or "").strip()[:200]
    try:
        conf = float(obj.get("confidence"))
    except Exception:
        conf = 0.0
    if conf < 0:
        conf = 0.0
    if conf > 1:
        conf = 1.0
    return {"verdict": v, "reason": reason, "confidence": round(conf, 2)}

def ai_review_inconclusive(results, client_mod=None, config=None, limit=None):
    """对 inconclusive 结果做 AI 复核，返回 ``(results, stat)``。

    ``results`` 是 verify_target 的返回值（list of dict），本函数**原地**给每条
    被判为 inconclusive 的项加 ``ai_review`` 字段后返回同一个 list；其它档位
    一律不动。``stat`` 只做统计，供报告与日志使用：
        {"enabled": bool, "reviewed": n, "skipped": n,
         "likely_true": n, "likely_false": n, "uncertain": n,
         "failed": n, "model": "..."}
    ``client_mod`` 允许注入（测试用）；默认动态加载 ``tools/ai_client.py``，
    与 ai_enhance 同款动态加载，避免把 tools 拉进 core 的静态导入链。
    任何异常都在本函数内吞掉并标记 failed，绝不向上抛。
    """
    stat = {"enabled": False, "reviewed": 0, "skipped": 0,
            "likely_true": 0, "likely_false": 0, "uncertain": 0,
            "failed": 0, "model": ""}
    targets = [r for r in (results or []) if r.get("verdict") == UNKNOWN]
    # round89 FIX-2：`enabled` 语义必须是「模型可用与否」，不能混入
    # 「本轮有没有 inconclusive 可交给 AI」。原实现先判 targets 再判
    # available()，于是「本该复核但零样本」与「模型没配」在调用方完全
    # 无法区分，engine.verify 一律打印「AI 复核未启用（未配置或调用不通）」
    # ——这是错误日志：实测自动核验阶段模型明明是通的，独立 verify 跑
    # 同一条日得出了 AI 结论。现先把 enabled/model 算出来，再看有无样本。
    cm = client_mod
    if cm is None:
        try:
            import importlib.util
            _p = os.path.join(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))), "tools", "ai_client.py")
            _spec = importlib.util.spec_from_file_location("bt_ai_client_r89", _p)
            _mod = importlib.util.module_from_spec(_spec)
            _spec.loader.exec_module(_mod)
            cm = _mod
        except Exception:
            cm = None
    if cm is None:
        return results, stat
    try:
        if not cm.available():
            return results, stat
    except Exception:
        return results, stat
    stat["enabled"] = True
    try:
        stat["model"] = str((cm.settings() or {}).get("model") or "")
    except Exception:
        stat["model"] = ""
    # round89 FIX-2：模型可用但一条 inconclusive 都没有 -> reviewed=0，
    # 由调用方根据 enabled=True/reviewed=0 打印「本轮无待复核样本」。
    if not targets:
        return results, stat
    cap = AI_REVIEW_MAX if limit is None else max(0, min(int(limit), AI_REVIEW_MAX))
    system = _ai_review_system()
    for i, res in enumerate(targets, 1):
        if i > cap:
            stat["skipped"] += 1
            continue
        obj = None
        try:
            obj = cm.ask_json(_ai_case_prompt(res, i), system=system,
                              max_tokens=300)
        except Exception as e:
            log.warning("[AI复核] 调用失败 fid=%s: %s", res.get("finding_id"), e)
        parsed = _ai_parse(obj)
        if parsed is None:
            stat["failed"] += 1
            continue
        parsed["model"] = stat["model"]
        res["ai_review"] = parsed
        stat["reviewed"] += 1
        stat[parsed["verdict"]] = stat.get(parsed["verdict"], 0) + 1
        log.info("[AI复核] %s · %s · %s（置信 %.2f）",
                 AI_REVIEW_CN.get(parsed["verdict"], parsed["verdict"]),
                 res.get("vuln_type"), res.get("url"), parsed["confidence"])
    return results, stat

