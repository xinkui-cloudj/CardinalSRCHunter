# -*- coding: utf-8 -*-
"""DNS 解析增强：多源解析 / 变体推断 / 精确归因 / 全局注入。

真实报告实测（ahqt.com.cn、www.yqhbl.com）：summary.json 里
stats.total=0、unreachable_by_reason={"DNS 解析失败":1}。根因三层：

  1) 解析只有 socket.getaddrinfo 一条路，/etc/resolv.conf 首选 8.8.8.8，
     该服务器一旦 NXDOMAIN / 超时，整条链路直接失败，没有任何回退；
  2) 「域名不存在(NXDOMAIN)」与「域名存在但无 A/AAAA 记录(NOERROR 空答案)」
     被混成同一句「DNS 解析失败」——前者该改拼写，后者该找域名管理员，
     混在一起用户没法判断；
  3) 用户给的是带 www 的形态，而解析记录只配在裸域（或反之）时，
     工具直接判死，不做一次变体推断就放弃。

本模块提供：
  · resolve_ex(host)       —— 多源并发解析，返回 (ips, code, detail)
  · resolve(host)          —— 只要 IP 列表（兼容旧调用）
  · suggest_variants(host) —— 常见主机名变体（www 有无 / m / oa / ...）
  · install_hook()         —— 把 socket.getaddrinfo 换成「本模块优先、系统兜底」，
                              让 requests / urllib3 无感获得多源解析能力
仅做本地 DNS 查询，不发 HTTP；所有调用点仍在 scope 校验之后。
"""
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import dns.resolver
except Exception:  # pragma: no cover
    dns = None
else:
    dns = dns.resolver

# 解析服务器池：国内公共 DNS 优先（对国内域名正确率最高），
# 再挂国际 DNS 兜底。顺序即优先级，但实际是并发查询、取最先成功的。
DEFAULT_SERVERS = ("223.5.5.5", "119.29.29.29", "180.76.76.76",
                   "114.114.114.114", "223.6.6.6",
                   "8.8.8.8", "1.1.1.1")

# 查询预算：单个服务器单次超时（秒）。宁可快速失败换下一个服务器，
# 也不要让一个卡住的 DNS 拖垮整轮——实测 4s 超时会让失败域名总耗时 20s+。
_QUERY_TIMEOUT = 2.0

# 多数票早退阈值：同一结论拿到这么多台服务器即可下结论，不再等慢服务器。
# 实测本机 1.1.1.1 不可达（单查 2.6s），没有早退时每个失败域名都要白等它。
_QUORUM = 3

# 服务器健康度：连续 N 次拿不到有效结论（ok/nxdomain/nodata）就熔断跳过，
# 避免每次解析都为一个不可达的 DNS 反复付超时代价。
_SRV_BAD = {}
_SRV_BAD_LOCK = threading.Lock()
_SRV_BAD_THRESHOLD = 2
_VALID_STATES = ("ok", "nxdomain", "nodata")

# 双栈宽限：拿到 IPv4 后，为「已在路上」的 AAAA 多等这一小段时间（秒）。
# 双栈域名下 A/AAAA 是并发投出的，谁先回不确定；若一拿到 v4 就 break，
# IPv6 地址会按返回顺序被概率性丢弃，hook 下 requests 便只剩 v4 可走。
# 取 0.6s：远小于单次查询超时（2.0s），拿不到就照旧早退，不拖慢扫描。
#
# 注意（实测修正）：此窗口不是丢 v6 的根因。曾把 0.35s 上调到 0.6s，
# 双栈率不变（两次均 19/20 只回 v4 1 次）；真正原因是宽限循环里对
# 已完成 future 用 `if _fu.done(): continue` 跳过 + `except: break`
# 提前放弃在途查询 —— 已修（见 resolve_ex 内两步收口）。修复后 60/60
# 全双栈，本常量只作「在途查询再收一轮」的兜底预算。
_AAAA_GRACE = 0.6


def _srv_mark(server, state):
    """记录一台服务器的健康度；有效结论清零，无效结论累加。"""
    with _SRV_BAD_LOCK:
        if state in _VALID_STATES:
            _SRV_BAD.pop(server, None)
        else:
            _SRV_BAD[server] = _SRV_BAD.get(server, 0) + 1


def _srv_healthy(server):
    with _SRV_BAD_LOCK:
        return _SRV_BAD.get(server, 0) < _SRV_BAD_THRESHOLD


def server_health():
    """当前熔断状态，供自检/日志。"""
    with _SRV_BAD_LOCK:
        return dict(_SRV_BAD)

# 变体推断用的常见主机名前缀
_VARIANT_PREFIXES = ("www", "m", "wap", "oa", "erp", "crm", "mail",
                     "portal", "home", "app", "admin", "web", "shop",
                     "mall", "bbs", "blog", "api", "sso", "hr", "test",
                     "dev", "vpn", "git", "jenkins")
# 域名级联想用的跨 TLD 候选后缀（同主体换后缀：langhanyun.com -> langhanyun.cn）
_TLD_SWAP = ("cn", "com", "net", "com.cn", "org", "top", "vip")
# 近音 / 近形替换对（同 TLD 换主体：langhanyun -> linghanyun）。
# 只做子串替换，命中即生成一个候选；总量由 suggest_domain_variants 封顶。
_CONFUSE = (("lang", "ling"), ("ling", "lang"), ("han", "hen"), ("hen", "han"),
            ("nan", "lan"), ("lan", "nan"), ("hanyun", "hanyu"),
            ("sh", "s"), ("zh", "z"), ("ang", "an"), ("ing", "in"),
            ("yun", "yuan"), ("u", "v"), ("y", "i"), ("h", "n"))

_ORIG_GETADDRINFO = socket.getaddrinfo
_CACHE = {}
_CACHE_LOCK = threading.Lock()
_CACHE_TTL = 600.0            # 正向结果缓存 10 分钟
_NEG_TTL = 60.0               # 负向结果缓存 1 分钟（避免反复打 DNS）
_hook_installed = [False]
_hook_depth = threading.local()

# 归因 code -> (中文标签, 排查建议)
DNS_REASONS = {
    "nxdomain": ("域名不存在（NXDOMAIN）",
                 "该域名未注册或已被删除：核对拼写、确认是否为未注册的近似域名"),
    "nodata":   ("域名存在但无 A/AAAA 记录",
                 "域名已注册但没有 Web 解析记录（可能只配了 CNAME 且目标失效，"
                 "或只配了 MX/TXT）：请向域名管理员确认解析配置，或改用带 www 的形态"),
    "dns":      ("DNS 解析失败",
                 "所有公共 DNS 均未返回结果：检查本机网络 / 是否需代理，或稍后重试"),
}


def _is_ip(s):
    """判断是否为 IP 字面量（v4 / v6）。"""
    try:
        socket.inet_aton(s)
        return True
    except Exception:
        pass
    try:
        socket.inet_pton(socket.AF_INET6, s)
        return True
    except Exception:
        return False


def _servers():
    """取解析服务器池：优先读 config，读不到用内置默认。"""
    try:
        from . import config as cfg
        s = cfg.Config().get("dns.servers")
        if s:
            if isinstance(s, str):
                s = [x.strip() for x in s.split(",") if x.strip()]
            if s:
                return list(s)
    except Exception:
        pass
    return list(DEFAULT_SERVERS)


def _cache_get(host):
    with _CACHE_LOCK:
        it = _CACHE.get(host)
    if not it:
        return None
    ips, code, detail, ts = it
    ttl = _CACHE_TTL if ips else _NEG_TTL
    if time.time() - ts > ttl:
        with _CACHE_LOCK:
            _CACHE.pop(host, None)
        return None
    return ips, code, detail


def _cache_put(host, val):
    with _CACHE_LOCK:
        _CACHE[host] = (val[0], val[1], val[2], time.time())


def clear_cache():
    """清空解析缓存（换目标 / 单测隔离时调用）。"""
    with _CACHE_LOCK:
        _CACHE.clear()


def _query_one(server, host, rtype, lifetime):
    """向单个服务器查一种记录，返回 (状态, 记录列表)。"""
    r = dns.Resolver(configure=False)
    r.nameservers = [server]
    r.lifetime = lifetime
    r.timeout = min(lifetime, 3.0)
    try:
        ans = r.resolve(host, rtype, raise_on_no_answer=False)
        if getattr(ans, "rrset", None) is None:
            st, recs = "nodata", []
        else:
            st, recs = "ok", [x.to_text().strip('"') for x in ans]
    except dns.NXDOMAIN:
        st, recs = "nxdomain", []
    except dns.NoAnswer:
        st, recs = "nodata", []
    except dns.NoNameservers:
        st, recs = "nns", []
    except dns.LifetimeTimeout:
        st, recs = "timeout", []
    except Exception:
        st, recs = "err", []
    _srv_mark(server, st)
    return st, recs


def _socket_fallback(host):
    """无 dnspython 时退化为系统解析（用原始 getaddrinfo，防重入）。"""
    try:
        infos = _ORIG_GETADDRINFO(host, None)
        ips = []
        for it in infos:
            ip = it[4][0]
            if ip and ip not in ips:
                ips.append(ip)
        if ips:
            return ips, "", "socket"
        return [], "nodata", "socket: empty"
    except socket.gaierror as e:
        msg = str(e).lower()
        if "name or service not known" in msg or "nodomain" in msg:
            return [], "nxdomain", "socket: %s" % e
        return [], "dns", "socket: %s" % e
    except Exception as e:
        return [], "dns", "socket: %s" % e


def resolve_ex(host, servers=None, lifetime=None):
    """多源并发解析 host 的 A/AAAA，返回 (ips, code, detail)。

    code：""（成功）/ "nxdomain" / "nodata" / "dns"（超时或全部失败）

    性能策略（实测优化）：
      · 所有服务器 × A/AAAA 一次性并发投出；
      · 用 as_completed 收结果，**拿到 IPv4 就立即收工**，并且
        executor 用 shutdown(wait=False) 而非 with（with 退出会 join 所有
        线程，早退形同虚设——这正是首版失败域名仍要 2.6s 的真凶）；
      · 同结论（nxdomain/nodata）拿到 _QUORUM 台即下结论，不等慢服务器；
      · 连续超时的服务器自动熔断跳过（实测 1.1.1.1 不可达）；
      · 结果 IPv4 优先排序：本机无 IPv6 路由时，v6 优先会直接连不上。
    """
    h = (host or "").strip().rstrip(".")
    if not h:
        return [], "dns", "空主机名"
    if _is_ip(h):
        return [h], "", "ip-literal"
    hit = _cache_get(h)
    if hit is not None:
        return hit
    if dns is None:
        res = _socket_fallback(h)
        _cache_put(h, res)
        return res

    life = float(lifetime or _QUERY_TIMEOUT)
    srv_all = list(servers or _servers())
    srv = [s for s in srv_all if _srv_healthy(s)]
    if not srv:                      # 全部被熔断：退化为原始池，别把功能关死
        srv = srv_all
    ips, seen_code = [], {}
    verdict = [None]                 # 已可下结论的状态（多数票）
    _grace_done = [False]            # 双栈宽限只做一次，避免重复等待

    def _note(st):
        if st in _VALID_STATES:
            seen_code[st] = seen_code.get(st, 0) + 1
            if seen_code[st] >= _QUORUM:
                verdict[0] = st
        else:
            seen_code[st] = seen_code.get(st, 0) + 1

    try:
        ex = ThreadPoolExecutor(max_workers=min(12, max(2, len(srv) * 2)))
        futs = {}
        for s in srv:
            for rt in ("A", "AAAA"):
                futs[ex.submit(_query_one, s, h, rt, life)] = (s, rt)
        deadline = time.time() + life + 1.0
        try:
            for fu in as_completed(list(futs), timeout=life + 1.5):
                try:
                    st, recs = fu.result()
                except Exception:
                    st, recs = "err", []
                _note(st)
                if st == "ok":
                    for ip in recs:
                        if ip and ip not in ips:
                            ips.append(ip)
                    if any(":" not in ip for ip in ips):
                        # 拿到可用 IPv4 即认定可用。但双栈域名下 AAAA 与 A 是
                        # 并发投出的，此刻直接 break 会按返回顺序「概率性」丢掉
                        # IPv6 地址：hook 下 requests 就只拿到 v4，一旦 v4 不可
                        # 达便无法回退 v6（纯 v6 目标不受影响，因为那时 ips 里
                        # 没有 v4，不会走到这个 break）。宽限收口分两步：
                        #   ① 已完成但尚未被 as_completed 消费的 future，无条件
                        #      先取结果（不设时间预算）—— 并发中先跑完的 AAAA
                        #      常落在这里，被 done() 跳过就会整族丢失（实测约
                        #      5% 的解析只回 v4 的真因）；
                        #   ② 其余「仍在路上」的查询，在 _AAAA_GRACE 内再收一轮。
                        # 两步都不退化成首版那种全量等待。
                        if not _grace_done[0]:
                            _grace_done[0] = True
                            _futs_left = list(futs)
                            # ① 先清空所有已完成的（无论 A/AAAA，与族无关）
                            for _fu in list(_futs_left):
                                if not _fu.done():
                                    continue
                                _futs_left.remove(_fu)
                                try:
                                    _st2, _recs2 = _fu.result()
                                except Exception:
                                    continue
                                if _st2 == "ok":
                                    for _ip in _recs2:
                                        if _ip and _ip not in ips:
                                            ips.append(_ip)
                            # ② 剩余在途查询在宽限窗口内再收一轮
                            _t_end = time.time() + _AAAA_GRACE
                            for _fu in _futs_left:
                                _remain = _t_end - time.time()
                                if _remain <= 0:
                                    break
                                try:
                                    _st2, _recs2 = _fu.result(timeout=_remain)
                                except Exception:
                                    continue   # 单台超时不该放弃其余在途查询
                                if _st2 == "ok":
                                    for _ip in _recs2:
                                        if _ip and _ip not in ips:
                                            ips.append(_ip)
                        break
                if verdict[0]:           # 多数票已出（nxdomain/nodata），收工
                    break
                if time.time() > deadline and ips:
                    break
        except Exception:
            pass            # 预算内未全部回：按已到的状态码继续归因，不丢信息
        ex.shutdown(wait=False)      # 关键：不 join，早退立即生效
    except Exception as e:
        if not ips:
            return [], "dns", str(e)[:120]

    codes = set(seen_code)
    if ips:
        ips = [ip for ip in ips if ":" not in ip] + [ip for ip in ips if ":" in ip]
        res = (ips, "", "multi")
    elif verdict[0] == "nxdomain" or (
            "nxdomain" in codes and codes <= {"nxdomain", "err", "timeout", "nns"}):
        res = ([], "nxdomain", "all servers: NXDOMAIN")
    elif "nodata" in codes:
        res = ([], "nodata", "NOERROR without answer")
    else:
        res = ([], "dns", "servers=%s" % ",".join(sorted(codes)))
    # round86 D2: dnspython 死路时先试系统解析，别把能通的网络判死。
    # Windows 上 8.8.8.8/1.1.1.1 常被屏蔽 -> 全服务器 LifetimeTimeout
    # -> 旧逻辑直接得出 code=dns，而系统解析（本地运营商 DNS）明明可用。
    # 只在 dns/timeout 这类"无结论"失败上兜底：nxdomain/nodata 是权威
    # 答案，不能拿系统解析去覆盖，否则会把不存在的域名硬解析成假 IP。
    if res[1] in ("dns", "timeout"):
        sys_res = _socket_fallback(h)
        if sys_res[0]:
            r86_ips = [ip for ip in sys_res[0] if ":" not in ip] + \
                      [ip for ip in sys_res[0] if ":" in ip]
            res = (r86_ips, "", "sysdns(%s)" % sys_res[2])
    _cache_put(h, res)
    return res



def resolve(host):
    """只要 IP 列表（失败返回空列表），兼容旧调用点。"""
    return resolve_ex(host)[0]


# 常见二级后缀（用于粗抽可注册域，不引 PSL：判错只影响候选质量，不影响解析）。
_2LD = ("com.cn", "net.cn", "org.cn", "gov.cn", "edu.cn", "ac.cn",
        "com.hk", "com.tw", "co.jp", "co.uk", "com.au", "com.sg")


def _registrable(host):
    """粗抽可注册域（apex）：按常见二级后缀与末两段规则近似，不引 PSL。"""
    h = (host or "").strip().lower().rstrip(".")
    labels = [x for x in h.split(".") if x]
    if len(labels) < 2:
        return ""
    if len(labels) >= 3 and ".".join(labels[-2:]) in _2LD:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def suggest_domain_variants(host):
    """域名级联想：跨 TLD（langhanyun.com -> langhanyun.cn）+ 近音近形
    （langhanyun -> linghanyun）。与 suggest_variants 的"同主体换前缀"互补——
    那是在同一主体下换主机名，这里换的是**主体 / 后缀本身**。

    保序去重，硬上限 12 个候选；只生成名字，不发任何请求（探测由
    probe_variants 负责，且只走 DNS）。
    """
    h = (host or "").strip().lower().rstrip(".")
    if not h or _is_ip(h):
        return []
    apex = _registrable(h)
    if not apex or "." not in apex:
        return []
    core = apex.split(".")[0]
    tld = ".".join(apex.split(".")[1:])
    bases = []
    # 1) 跨 TLD：同主体换后缀，取前 3 个（cn 优先）。
    for t in _TLD_SWAP:
        if t != tld:
            bases.append("%s.%s" % (core, t))
        if len(bases) >= 3:
            break
    # 2) 近音 / 近形：同 TLD 换主体，取前 3 个不同结果。
    confs = []
    for a, b in _CONFUSE:
        if a in core:
            c = core.replace(a, b)
            if c != core and c not in confs:
                confs.append(c)
        if len(confs) >= 3:
            break
    for c in confs:
        bases.append("%s.%s" % (c, tld))
    out = []
    for b in bases:
        if b != h and "." in b and not _is_ip(b) and b not in out:
            out.append(b)
    for b in bases:                      # 交替补 www 形态（两类命中都能进前 12）
        w = "www." + b
        if w != h and w not in out:
            out.append(w)
    return out[:12]


def suggest_variants(host):
    """生成常见主机名变体，供「原域名无解析」时自动兜底。

    覆盖两类最常见的错配：
      · 用户给 www.x.com，但记录只配在 x.com（去 www）
      · 用户给 x.com，但站点只在 www.x.com（加 www）
    再补一批常见服务前缀（m / oa / erp / mail / portal ...）。
    """
    h = (host or "").strip().lower().rstrip(".")
    if not h or _is_ip(h):
        return []
    labels = h.split(".")
    out = []
    if h.startswith("www.") and len(labels) > 2:
        out.append(h[4:])
    else:
        out.append("www." + h)
    base = h[4:] if (h.startswith("www.") and len(labels) > 2) else h
    for p in _VARIANT_PREFIXES:
        cand = "%s.%s" % (p, base)
        if cand != h and cand not in out:
            out.append(cand)
    # 域名级联想（近音/近形/跨 TLD）：与上面的"同主体换前缀"互补。
    # 只在末尾追加、不删不改既有候选，老断言（裸域补 www / www 去 www）仍成立。
    try:
        for d in suggest_domain_variants(h):
            if d != h and d not in out:
                out.append(d)
    except Exception:
        pass
    return out


def probe_variants(host, limit=6, lifetime=None):
    """并发探测变体，返回 [(候选主机, [ips]), ...]（只含解析成功的）。"""
    _cands = []
    # 域名级候选（换主体 / 换 TLD）优先：nxdomain 场景下"同主体换前缀"几乎必然
    # 也 nxdomain，先探它们等于浪费额度。只发 DNS，不发 HTTP，不占请求预算。
    for _c in suggest_domain_variants(host):
        if _c not in _cands:
            _cands.append(_c)
    for _c in suggest_variants(host):
        if _c not in _cands:
            _cands.append(_c)
    cands = _cands[:limit]
    if not cands:
        return []
    out = []
    try:
        ex = ThreadPoolExecutor(max_workers=min(8, len(cands)))
        futs = {ex.submit(resolve_ex, c, None, lifetime): c for c in cands}
        try:
            for fu in as_completed(list(futs), timeout=(lifetime or _QUERY_TIMEOUT) + 2.0):
                c = futs[fu]
                try:
                    ips = fu.result()[0]
                except Exception:
                    ips = []
                if ips:
                    out.append((c, ips))
        except Exception:
            pass
        ex.shutdown(wait=False)
    except Exception:
        pass
    return out


def _hooked_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    """替换版 getaddrinfo：域名走多源解析，失败/异常回退系统实现。"""
    if getattr(_hook_depth, "busy", False):
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)
    try:
        if host and not _is_ip(host) and host.lower() not in ("localhost", ""):
            _hook_depth.busy = True
            try:
                ips, _code, _ = resolve_ex(host)
            finally:
                _hook_depth.busy = False
            # round86 D3: resolve_ex 已经会兜底系统 DNS，但仍存在两侧都空
            # 的情形。此时直接把 socket 交给系统实现，比让 urllib3 先报
            # 一次 "getaddrinfo failed" 更省事，也避免上层把瞬时网络抖
            # 动误报成"目标不可达"。仅在没有任何 IP 时生效，有 IP 不走这里。
            if not ips and _code in ("dns", "timeout"):
                return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)
            if ips:
                res = []
                for ip in ips:
                    if ":" in ip:
                        if family in (0, socket.AF_INET6):
                            res.append((socket.AF_INET6, socket.SOCK_STREAM, 6, "",
                                        (ip, port or 0, 0, 0)))
                    else:
                        if family in (0, socket.AF_INET):
                            res.append((socket.AF_INET, socket.SOCK_STREAM, 6, "",
                                        (ip, port or 0)))
                if res:
                    return res
    except Exception:
        pass
    return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)


def install_hook():
    """全局安装解析钩子（幂等）。让 requests/urllib3 无感用上多源解析。"""
    if _hook_installed[0]:
        return False
    socket.getaddrinfo = _hooked_getaddrinfo
    _hook_installed[0] = True
    return True


def uninstall_hook():
    """还原系统 getaddrinfo（单测用）。"""
    if _hook_installed[0]:
        socket.getaddrinfo = _ORIG_GETADDRINFO
        _hook_installed[0] = False
        return True
    return False


def stats():
    """缓存规模，供自检/日志。"""
    with _CACHE_LOCK:
        return {"cache": len(_CACHE), "hook": _hook_installed[0],
                "servers": len(_servers())}