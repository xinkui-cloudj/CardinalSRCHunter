# -*- coding: utf-8 -*-
"""难例队列落盘（阶段 5-1）。

背景
----
扫描器对每个接口跑完五个参数级检测（sqli / xss / open_redirect / ssrf / cors）
后，绝大多数响应能归到"有命中"或"参数无效"两类。但总有一批接口：

    真有可测参数、五个检测全跑完，却一条都没命中。

这类样本恰恰最有信息量——它们代表"程序还没见过的新响应模式"，是 AI 旁路
分析器（阶段 5-2）最该吃进去的原料。因此这里做一件很小的事：**把难例原样
落盘**（url / method / param / 响应片段），交给离线工具联网查该组件/报错、
产出"候选 payload + 触发条件"草稿。扫描本身不看、不用、不依赖它。

红线遵守（三条）
----------------
1. AI 永不进扫描热路径做决策 —— 本模块只写文件，不做任何判定；
2. 产物是落盘静态数据，人工审核后才生效 —— 本模块只产出
   ``data/hunt_queue.jsonl``，5-3 人工改名生效后才可能进模板；
3. 扫描热路径不 import 学习器 —— 反向也成立：本模块不被任何判定逻辑 import，
   engine 只在收尾处调用 ``record_many`` 批量落盘。

与 unknowns 的关系
------------------
本模块与 ``core/unknowns.py``（阶段 1-2）结构同构：都是"热路径 O(1) 写一行 +
指纹去重 + 容量上限 + 进程内缓存 + 批量入口 + 只写文件不判定"。区别仅在
字段名（host/code/err → url/param/snippet）与判定条件（is_unknown → is_huntable）。

性能
----
``record()`` 单次成本 = 一次 set 查重 + 一次 append 写行，O(1)，不阻塞扫描。
进程内 ``_SEEN`` 缓存指纹，重复样本不重复落盘。
"""
import hashlib
import json
import os
import threading
import time

from core import config as cfg

# 落盘路径：data/hunt_queue.jsonl（追加写，一行一样本）
HUNT_PATH = os.path.join(cfg.DATA_DIR, "hunt_queue.jsonl")

# 容量上限：超过就保留最近 MAX_LINES 行（防止长期运行无限膨胀）
MAX_LINES = 2000

# 响应片段最大字符数（落盘前截断，避免单条样本撑爆文件）
SNIPPET_MAX = 600

# 归入"难例"的 kind 集合（目前只有一种：响应不匹配任何已知规则）
HUNT_KINDS = ("no_match",)

_LOCK = threading.Lock()
_SEEN = set()          # 进程内指纹缓存
_LOADED = [False]      # 是否已从磁盘加载过指纹


def normalize(sample):
    """把一条样本规范化成"落盘形状"（阶段 5-3 统一口径）。

    关键不变量：**算指纹用的字段 == 落盘用的字段**。历史 bug —— ``record``
    先用原始 sample 算指纹（缺 method 时按 ""），落盘却把 method 规范成
    "GET"；重启 ``_load_seen`` 用落盘行重算得不同指纹 → 进程内去重缓存失效，
    同一难例被重复落盘（实测：缺 method 的样本重启后落 2 行）。
    现在统一：先 normalize，再用规范化后的 dict 算指纹，最后落盘。
    """
    s = sample or {}
    return {
        "url": str(s.get("url") or ""),
        "method": str(s.get("method") or "GET").upper(),
        "param": str(s.get("param") or ""),
        "kind": str(s.get("kind") or "no_match"),
        "snippet": str(s.get("snippet") or "")[:SNIPPET_MAX],
    }

def fingerprint(sample):
    """指纹 = url + method + param + kind 的 sha1（**公开契约，单一来源**）。

    字段口径（5-3 起固定，改动即破坏跨模块一致性）：
        url    = 原样（不 strip，避免与落盘行不一致）
        method = 大写，缺省 ``"GET"``
        param  = 原样
        kind   = 缺省 ``"no_match"``
    编码用 ``encode("utf-8", "replace")``：代理对/非法码点不抛异常
    （扫描热路径容错优先，与 ``core/unknowns`` 同款）。
    ``tools/hunt_assist._fp_of`` 直接委托本函数，不再本地复制。
    """
    s = sample or {}
    url = str(s.get("url") or "")
    method = str(s.get("method") or "GET").upper()
    param = str(s.get("param") or "")
    kind = str(s.get("kind") or "no_match")
    raw = "\x1f".join((url, method, param, kind))
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()

# 私有别名：保持既有调用点（_load_seen / record / lab 断言）零改动。
_fingerprint = fingerprint


def _load_seen():
    """首次调用时把磁盘已有样本的指纹读进内存（只读一遍）。"""
    if _LOADED[0]:
        return
    _LOADED[0] = True
    try:
        if not os.path.exists(HUNT_PATH):
            return
        with open(HUNT_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                _SEEN.add(_fingerprint(obj))
    except Exception:
        pass


def is_huntable(sample):
    """判断一条样本是否属于"难例"类。

    条件：kind 在 HUNT_KINDS 内，且 url 非空（url 是样本的唯一标识，
    空 url 的样本没有任何分析价值，直接拒收）。
    """
    s = sample or {}
    kind = str(s.get("kind") or "").strip().lower()
    url = str(s.get("url") or "").strip()
    return kind in HUNT_KINDS and bool(url)


def record(sample, target=""):
    """把一条难例样本追加到 hunt_queue.jsonl。

    返回 True 表示真的写入了新样本（去重后），False 表示跳过。
    sample: engine 里采集的单项（含 url/method/param/kind/snippet）。
    """
    if not is_huntable(sample):
        return False
    row = normalize(sample)
    fp = fingerprint(row)          # 与落盘字段同源（修复重启去重失效）
    with _LOCK:
        _load_seen()
        if fp in _SEEN:
            return False
        _SEEN.add(fp)
        obj = {
            "fp": fp,
            "at": round(time.time(), 3),
            "target": str(target or ""),
            "url": row["url"],
            "method": row["method"],
            "param": row["param"],
            "kind": row["kind"],
            "snippet": row["snippet"],
        }
        if isinstance(sample.get("extra"), dict) and sample["extra"]:
            obj["extra"] = sample["extra"]
        try:
            os.makedirs(os.path.dirname(HUNT_PATH), exist_ok=True)
            with open(HUNT_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(obj, ensure_ascii=False) + "\n")
        except Exception:
            return False
        _trim()
        return True


def _trim():
    """超限则保留最近 MAX_LINES 行，并同步内存去重集。调用方已持锁。

    关键点：文件被裁掉的那些样本，必须同时从 ``_SEEN`` 里移除，
    否则它们会被内存永久判为"已见过"，再也无法重新落盘（去重集与
    磁盘内容必须始终一致）。
    """
    try:
        # 快速路径：内存去重集未超限，文件必然也未超限（两者同步）
        if len(_SEEN) <= MAX_LINES:
            return
        if not os.path.exists(HUNT_PATH):
            return
        with open(HUNT_PATH, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]
        if len(lines) <= MAX_LINES:
            return
        keep = lines[-MAX_LINES:]
        tmp = HUNT_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.writelines(keep)
        os.replace(tmp, HUNT_PATH)
        # 重建去重集：只保留仍在文件里的指纹
        _SEEN.clear()
        for line in keep:
            try:
                _SEEN.add(_fingerprint(json.loads(line)))
            except Exception:
                continue
    except Exception:
        pass


def record_many(samples, target=""):
    """批量落盘，返回新增条数。扫描收尾时调用一次。"""
    n = 0
    for s in (samples or []):
        try:
            if record(s, target=target):
                n += 1
        except Exception:
            continue
    return n


def count():
    """当前已落盘的难例样本数。"""
    try:
        if not os.path.exists(HUNT_PATH):
            return 0
        n = 0
        with open(HUNT_PATH, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    n += 1
        return n
    except Exception:
        return 0


def tail(limit=50):
    """取最近 limit 条样本（供 CLI / 5-2 旁路分析器读取）。"""
    try:
        if not os.path.exists(HUNT_PATH):
            return []
        with open(HUNT_PATH, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]
        out = []
        for line in lines[-int(limit):]:
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        return out
    except Exception:
        return []


def clear():
    """清空样本文件（测试 / 手动重置用）。"""
    with _LOCK:
        _SEEN.clear()
        _LOADED[0] = True
        try:
            if os.path.exists(HUNT_PATH):
                os.remove(HUNT_PATH)
        except Exception:
            pass
