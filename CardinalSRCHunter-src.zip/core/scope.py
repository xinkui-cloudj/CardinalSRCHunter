# -*- coding: utf-8 -*-
"""授权范围守卫。

设计原则：**默认拒绝**。只有明确命中 in_scope 且未命中 out_of_scope 的目标才放行。
例外：用户在界面 / 命令行里**显式填写**的目标，由 Scope.authorize() 自动并入
in_scope（仍受 out_of_scope 排除规则约束），无需每次手改 scope.yaml。
所有判定结果都写审计日志，便于事后回溯。
"""
import fnmatch
import ipaddress
import os
import re
import socket

from . import config as cfg
from . import logger

log = logger.get("bt.scope")

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None


class ScopeError(Exception):
    pass


# 授权等级（授权状态自动分辨的产物）。
# 只用于日志 / 报告标注，**绝不参与扫描强度决策**——所有目标
# 一律使用同一份强度配置，见 Engine.auth_scan_profile()。
# round60：取消“白名单外目标需确认”档位——填入的目标一律视为已授权。
AUTH_AUTHORIZED = "authorized"   # 命中白名单，或用户填入的目标（默认视为已授权）
AUTH_DENIED = "denied"           # 被 out_of_scope 排除，或严格模式下不在范围
AUTH_CN = {AUTH_AUTHORIZED: "已授权", AUTH_DENIED: "已拒绝"}


def _norm_host(host):
    if not host:
        return ""
    host = host.strip().lower()
    host = re.sub(r"^https?://", "", host)
    host = host.split("/")[0]
    host = host.split("@")[-1]
    if host.startswith("[") and "]" in host:          # IPv6
        host = host[1:host.index("]")]
    elif host.count(":") == 1:                        # host:port
        host = host.split(":")[0]
    return host.rstrip(".")


def _match_any(host, patterns):
    for p in patterns or []:
        p = str(p).strip().lower()
        if not p:
            continue
        if fnmatch.fnmatch(host, p):
            return p
        # 裸域名同时匹配其子域
        if not any(ch in p for ch in "*?[") and (host == p or host.endswith("." + p)):
            return p
    return None


def _ip_in_cidrs(host, cidrs):
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return None
    for c in cidrs or []:
        try:
            if ip in ipaddress.ip_network(str(c), strict=False):
                return c
        except ValueError:
            continue
    return None


class Scope(object):
    def __init__(self, scope_path=None, config=None):
        self.config = config or cfg.Config()
        self.path = scope_path or cfg.SCOPE_PATH
        self.program = ""
        self.in_scope = []
        self.out_of_scope = []
        self.test_headers = {}
        self.oob_domain = ""
        self._extra_in = []
        # round60：取消白名单外目标的“放行开关”。用户填入的目标一律视为
        # 已授权（仅受 out_of_scope 排除规则约束），不再有“白名单外 →
        # 需确认 / 可拒绝”的档位。
        self._load()

    @property
    def intensity(self):
        """scope.yaml 里的 intensity 字段已废弃，不再作为强度来源。

        历史上它写死为 safe，与真正决定行为的 scan.mode / enable_active
        / enable_poc 毫无关联，报告和摘要照着它输出就会撒谎。现在改为
        从配置的 scan.mode 派生真值；scope.yaml 里若仍残留该键，一律忽略。
        """
        try:
            if hasattr(self.config, "scan_profile"):
                active, poc = self.config.scan_profile()
                if active and poc:
                    return "aggressive"
                if active or poc:
                    return "normal"
                return "safe"
            return str(self.config.get("scan.mode", "safe") or "safe").lower()
        except Exception:
            return "safe"

    # ---------- 载入 ----------
    def _load(self):
        data = {}
        if os.path.isfile(self.path) and yaml is not None:
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
            except Exception as e:
                raise ScopeError("scope.yaml 解析失败: %s" % e)
        self.program = data.get("program", "")
        self.in_scope = list(data.get("in_scope") or [])
        self.out_of_scope = list(data.get("out_of_scope") or [])
        self.test_headers = dict(data.get("test_headers") or {})
        self.oob_domain = data.get("oob_domain") or ""
        # 注意：data.get("intensity") 已废弃——它曾被写死为 safe 并让
        # 报告撒谎。强度真值统一由 Scope.intensity property 从配置派生。

        # 与 config.json 里的 domains/ips/cidrs 合并
        self.in_scope += list(self.config.get("target.domains") or [])
        self.in_scope += list(self.config.get("target.ips") or [])
        self.in_scope += list(self.config.get("target.cidrs") or [])
        self.out_of_scope += list(self.config.get("target.exclude") or [])

    def add_in_scope(self, target):
        t = _norm_host(target)
        if t and t not in self.in_scope:
            self.in_scope.append(t)

    def authorize(self, target):
        """把用户在界面/命令行里显式填写的目标并入 in_scope。

        与 add_in_scope 的差别：这里会先尊重 out_of_scope —— 用户明确排除的目标
        不会被重新放行（排除优先），并把结果写审计日志。
        返回 True 表示该目标可用。
        """
        raw = (target or "").strip()
        host = _norm_host(raw)
        if not host:
            return False
        if _match_any(host, self.out_of_scope):
            logger.audit("scope_authorize", host=host, allowed=False,
                         reason="out_of_scope")
            return False
        if host not in self.in_scope:
            self.in_scope.append(host)
        logger.audit("scope_authorize", host=host, allowed=True,
                     reason="user_supplied")
        return True

    # ---------- 判定 ----------
    def _classify(self, host_or_url):
        """内部纯判定：不写审计，返回 (level, reason, rule)。

        level 两档：
            authorized  命中 in_scope / config.target.* / CIDR，或用户填入的目标
                        （round60 起默认视为已授权）—— 白名单授权
            denied      被 out_of_scope 排除，或空目标

        round60：取消白名单外目标单独成档的做法。用户填进程序的目标一律
        视为已授权，不再存在“未命中白名单 → 需人工确认”的分支。

        本方法**只判定授权状态，不参与任何强度决策**：所有目标
        走完全相同的扫描强度（见 Engine.auth_scan_profile），level 仅
        用于标注与审计，绝不允许拿去分流扫描能力。
        """
        host = _norm_host(host_or_url)
        if not host:
            return AUTH_DENIED, "空目标", ""
        denied = _match_any(host, self.out_of_scope)
        if denied:
            return AUTH_DENIED, "命中排除规则 %s" % denied, str(denied)
        hit = _match_any(host, self.in_scope)
        if hit:
            return AUTH_AUTHORIZED, "命中授权规则 %s" % hit, str(hit)
        # 可能是 IP，检查 CIDR
        cid = _ip_in_cidrs(host, self.config.get("target.cidrs") or [])
        if cid:
            return AUTH_AUTHORIZED, "命中授权网段 %s" % cid, "cidr:%s" % cid
        # round60：未命中白名单且未被 out_of_scope 排除的目标，一律视为已授权
        # （用户填进程序的目标即已授权）。不再有“白名单外 → 需确认”的档位，
        # 也不再读已废弃的放行开关配置项。
        return AUTH_AUTHORIZED, "用户填入目标，默认视为已授权", "user_supplied"

    def classify(self, host_or_url):
        """对外暴露的授权等级判定（不写审计，供报告 / 界面 / 日志标注）。

        返回 (level, reason, rule)：
            level  ∈ authorized / denied
            reason 中文说明，可直接展示
            rule   命中的规则（白名单条目 / cidr:xx / user_supplied）
        """
        return self._classify(host_or_url)

    def check(self, host_or_url, purpose=""):
        """返回 (allowed: bool, reason: str)。判定结果写审计日志。"""
        host = _norm_host(host_or_url)
        level, reason, rule = self._classify(host_or_url)
        if level == AUTH_DENIED:
            if not host:
                logger.audit("scope_deny", host=host_or_url, reason="empty")
            elif rule and reason.startswith("命中排除规则"):
                logger.audit("scope_deny", host=host, reason="out_of_scope:%s" % rule)
            else:
                logger.audit("scope_deny", host=host, reason="not_in_scope")
            return False, reason
        logger.audit("scope_allow", host=host, rule=rule, purpose=purpose)
        return True, reason

    def is_allowed(self, host_or_url, purpose=""):
        return self.check(host_or_url, purpose)[0]

    def assert_allowed(self, host_or_url, purpose=""):
        ok, reason = self.check(host_or_url, purpose)
        if not ok:
            raise ScopeError("拒绝访问 %s：%s（请在界面/命令行直接填写该目标，"
                             "或把目标加入 config/scope.yaml 的 in_scope）"
                             % (host_or_url, reason))
        return True

    def resolve_ips(self, host):
        """解析域名到 IP，用于展示；失败返回空列表。

        优先走 core.dnsx 的多源并发解析（IPv4 优先、单台 DNS 失效自动跳过）：
        真实报告里正是 /etc/resolv.conf 首选 8.8.8.8 一挂，整条链路直接全失败。
        dnsx 不可用时退回系统 getaddrinfo，保证功能不关死。
        """
        h = _norm_host(host) if host else ""
        if not h:
            return []
        try:
            from . import dnsx
            ips = dnsx.resolve(h)
            if ips:
                return ips
        except Exception:
            pass
        try:
            infos = socket.getaddrinfo(h, None)
            return sorted({i[4][0] for i in infos})
        except Exception:
            return []

    def summary(self):
        return {
            "program": self.program,
            "in_scope": self.in_scope,
            "out_of_scope": self.out_of_scope,
            "intensity": self.intensity,
            "oob_domain": self.oob_domain,
        }
