# -*- coding: utf-8 -*-
"""扫描编排层：把 recon → probe → vulnchecks → poc → report 串成一条链。

职责边界：
- 只做"调度与状态"，不重复实现任何检测逻辑（检测在 modules/，出网在 httpclient）；
- 每一处出网都经过 HttpClient，因此 scope 守卫在代码层面不可绕过；
- 所有疑似项先进 DB（未复现），poc.upgrade() 复现成功后原地升级为"已确认"；
- 支持断点续扫：已扫描 URL 记在 db.scanned，重跑时跳过。

产物：
    data/findings.db      资产 + 漏洞 + 进度
    reports/<target>-<ts>/  report.md / report.html / evidence/ / summary.json
"""
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FuturesTimeout
from urllib.parse import urlparse

from core import config as cfg
from core import dicts, logger, netdiag, selfheal, unknowns, hunt_queue
from core import report as report_mod   # 静态导入：PyInstaller 才能把 core.report 打进包
from core import verify as verify_mod   # 同上：核验层须静态导入才能被打包
from core.db import DB
from core.httpclient import HttpClient
from core.scope import (Scope, ScopeError, _norm_host,
                        AUTH_AUTHORIZED, AUTH_DENIED, AUTH_CN)
from modules import poc, probe, recon, template_engine, vulnchecks

log = logger.get("bt.engine")

# round83 A2：AI 黑框通道。能力清单以前只打 bt.engine（进左框），
# 被海量常规日志冲走后用户看不到，误判成「没识别到工具」。
# 现在双通道：左框留汇总，黑框留完整清单并常驻顶部。
_ailog = logger.get("bt.ai")

# 从 HTML 里抽同域链接，用于浅爬
# 注意：**必须保留 query（?）**。旧版把 "?" 排除在字符类外，导致
# `/search?q=x` 这类带参链接被整段丢弃，而参数级检测只处理含 "?" 的 URL
# ——结果是真实站点上 XSS/SQLi/重定向/SSRF 全部静默漏检（缺陷 I）。
LINK_RE = re.compile(r"""(?:href|src|action)\s*=\s*["']([^"'#]{2,300})["']""", re.I)
# 可能是登录入口的特征
LOGIN_HINTS = ("login", "signin", "sign-in", "admin", "manage", "auth",
               "user/login", "console", "passport")
# 弱口令表单字段名猜测顺序
USER_FIELDS = ("username", "user", "name", "account", "email", "login")
PASS_FIELDS = ("password", "passwd", "pwd", "pass", "passcode")

# 表单解析（缺陷 O：POST 检测面从未打开）
# 旧版 LINK_RE 已经抓到 <form action="..."> 的提交地址，但**只抓 URL**：
# 既不知道 method="post"，也不知道 <input name=...> 有哪些字段，因此永远
# 构造不出请求体 —— 结果是所有 POST 型 SQLi/XSS/重定向/SSRF 一律静默漏检
# （AA 补丁把 poc 的 method/body 透传通道修通了，但上游从不产生 POST 项，
#  通道一直空转）。下面三个正则把表单的 method / action / 字段名补齐。
FORM_RE = re.compile(r"<form\b.*?</form>", re.I | re.S)
TAG_ATTR_RE = re.compile(r"""([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*["']([^"']*)["']""")
FIELD_TAG_RE = re.compile(r"<(input|textarea|select)\b([^>]*)>", re.I)
# 这些 type 不是业务字段，注入它们没有意义
NON_FIELD_TYPES = ("submit", "button", "reset", "image", "file")


def _host_of(url):
    """纯主机名（不带端口）——仅用于同域比较。"""
    try:
        return (urlparse(url).hostname or "").lower()
    except Exception:
        return ""


def _in_scope_for_persist(url, target):
    """FIX-31：判定某条漏洞项是否属于本次授权目标。

    与 tools.hunt_consumer.in_target_scope 同口径但独立实现，避免 engine 与
    hunt_consumer 产生循环依赖。异常一律不放行（宁可丢、不可污）。
    """
    # 归一：target 常是裸域名（mendunerhr.com:443），_host_of 依赖 urlparse，
    # 无 scheme 时 hostname 为空 —— 必须补 '//' 再解析，否则一律误判为不放行。
    def _hp(s):
        t = str(s or "").strip()
        if not t:
            return ""
        if "://" not in t:
            t = "//" + t.lstrip("/")
        return _host_of(t)
    th = _hp(target)
    if not th:
        return False
    uh = _hp(url)
    if not uh:
        return False
    def _loc(h):
        if h in ("localhost", "::1", "0.0.0.0"):
            return True
        try:
            import ipaddress as _ip
            a = _ip.ip_address(h)
            return bool(a.is_loopback or a.is_private or a.is_link_local)
        except ValueError:
            return h.endswith(".local")
    if _loc(uh) or _loc(th):
        return uh == th
    return uh == th or uh.endswith("." + th)




def _hostport_of(url):
    """主机名[:端口]——用于出网、落库与报告展示。幂等：可接受 host、host:port、scheme://host:port。"""
    s = (url or "").strip()
    if not s:
        return ""
    try:
        p = urlparse(s) if "://" in s else urlparse("//" + s.lstrip("/"))
        h = (p.hostname or "").lower()
        if not h:
            return ""
        if p.port:
            return "%s:%d" % (h, p.port)
        return h
    except Exception:
        return ""
def _norm_target(target):
    """把用户输入归一为 host[:port]，保留显式端口（8080/8443 这类）。"""
    t = (target or "").strip()
    if not t:
        return ""
    hp = _hostport_of(t)
    return hp or _norm_host(target)


class Engine(object):
    """一次会话 = 一份配置 + 一份 scope + 一个 DB + 一个 HTTP 客户端。"""

    def __init__(self, config=None, scope=None, db=None, verbose=False):
        cfg.ensure_dirs()
        self.config = config or cfg.Config()
        self.scope = scope or Scope(config=self.config)
        self.db = db or DB()
        # db 是外部注入还是自己建的：close() 只关自己建的那个，
        # 否则会把调用方仍在用的连接一起关掉。
        self._own_db = db is None
        self.client = HttpClient(self.scope, self.config)
        self.verbose = verbose

        self.max_per_host = int(self.config.get("scan.max_requests_per_host", 3000) or 3000)
        self.concurrency = max(1, min(int(self.config.get("http.concurrency", 10) or 10), 8))
        # 3-3：并发上限可配（http.concurrency_max，默认 8）。只允许往低钳，
        # 硬顶仍是上面那个 8——配置项与真实行为一致，不撒谎。
        try:
            _cmax = max(1, min(int(self.config.get("http.concurrency_max", 8) or 8), 8))
            self.concurrency = max(1, min(self.concurrency, _cmax))
        except Exception:
            pass
        self.depth = max(0, int(self.config.get("scan.crawl_depth", 2) or 0))
        # 强度由 scan.mode 预设解析而来（safe/normal/aggressive）；
        # 显式设置的 scan.enable_active / enable_poc 优先。
        _active, _poc = (self.config.scan_profile()
                         if hasattr(self.config, "scan_profile")
                         else (bool(self.config.get("scan.enable_active", True)),
                               bool(self.config.get("scan.enable_poc", True))))
        self.enable_active = _active
        self.enable_poc = _poc
        # scan.mode 只是"初始档位"，真正决定行为的是 enable_active /
        # enable_poc（CLI 的 --full / --no-poc、GUI 的勾选都会在构造后
        # 直接覆盖它们）。所以强度标签不能照抄配置，而是用下面的
        # intensity property 从"实际生效的开关"反推。
        self.mode = str(self.config.get("scan.mode", "safe") or "safe").lower()
        self.resume = bool(self.config.get("scan.resume", True))
        self.weak_password = bool(self.config.get("scan.weak_password", False))
        self.poc_limit = int(self.config.get("scan.poc_limit", 6) or 6)
        # round57：目标域名 NXDOMAIN 但 probe 层联想出可解析形态时，自动改用该形态接管扫描。
        self.auto_variant = bool(self.config.get("scan.auto_variant", True))
        self._variant_depth = 0         # 变体接管递归深度（防环）
        self._variant_seen = set()      # 已触发过接管的主机，防重复接管
        self._weak_tried = set()        # 弱口令已试入口（敏感路径/目录爆破跨阶段去重）

        self._hits = {}                 # host -> 出网计数
        self._token_map = {}            # 凭据值 -> {host: [路径]}（跨主机复用汇总）
        self._seen = set()              # (vuln_type, url, param, method) 去重
        self._seen_fid = {}             # 去重键 -> 已落库 finding id（供 PoC 原地升级）
        self._verified = set()          # 已升级为"已复现"的去重键，防止重复升级
        # r88 缺陷 #6：本轮真正落库/升级过的 finding id（按目标）。
        # 报告若从 db.all_findings(target) 取值，会把历史 finding 一并输出，
        # 修好规则后重跑仍看到旧误报、修复效果无法验收。这里记 id，
        # 报告只消费这些 id 对应的行。
        self._run_fids = {}             # target -> [finding id, ...]
        self._lock = threading.Lock()
        self._stop = False

        # round73 B3：暂停闸门（与 _stop 并列的第二个人工闸门）。
        # 只置标志位、不打断在跑的请求；各阶段检查点统一走 wait_if_paused()，
        # 所以"暂停"的粒度天然是"当前批次/小循环跑完再停"，不会留半截状态。
        self._pause = threading.Event()   # set=暂停中，clear=放行
        self._beat = 0                    # 检查点心跳：供 wait_idle 判"已停稳"
        # round75 会话存档状态。初值 None = "本 Engine 从未开跑过会话"，
        # 是 _session_pause 的天然哨兵：没跑过就不该写档（否则只启动界面
        # 什么都没扫也会留下一份空会话，下次开窗白弹一次提示）。
        self._sess_targets = None         # 本次 run() 的完整目标列表
        self._sess_done = None            # 已完成目标（顺序即完成顺序）
        self._sess_started = 0.0          # 本次 run() 开始时间
        self._sess_last = ""              # 最近一次收尾的目标（提示用）
        self._sess_saved_at = 0.0         # 上次落盘时刻（暂停期周期兜底用）
        # 兜底策略（不新增 import、不挂钩 atexit/signal）：
        # ① 每个目标收尾即时落盘（_session_mark）；② 暂停等待期间在
        # wait_if_paused() 里周期落盘，保证窗口被强杀也不会退回旧快照。
        # 阶段 5-1 难例采集：把"有可测参数但五类检测零命中"的接口攒在内存里，
        # scan_target 收尾统一落盘。只采集不判定、零额外网络请求，不参与任何
        # 扫描决策（落盘在收尾处，失败也不影响扫描结果）。
        self._hunt_samples = []
        self._hunt_lock = threading.Lock()
        # round81 B6/B7: long-silence heartbeat (log only).
        # _hb_t: last time we said 'still running'. _host_prog: set by
        # run() when scanning many hosts, used to report i/N per host.
        self._hb_t = 0.0
        self._host_prog = None
        # 授权状态自动分辨结果（target -> (level, reason, rule)）。
        # 在 run() 里于 authorize() 之前定格，记录目标的真实来源
        # （白名单命中 / 用户填入默认视为已授权）。只用于标注/审计，
        # 不参与强度决策。
        self._auth_levels = {}
        # round59：MCP 子进程句柄（未启用时恒为空列表，close() 统一收口）。
        self._mcp_clients = []
        self._mcp_loaded = False

    # ------------------------------------------------------------
    # 强度标签
    # ------------------------------------------------------------
    @property
    def intensity(self):
        """强度标签由"实际生效的开关"反推，而不是照抄配置里的 scan.mode。

        CLI 的 --full / --no-poc、GUI 的勾选都会在 Engine 构造之后直接
        改写 enable_active / enable_poc；若标签仍读配置文件，就会出现
        行为已全开、报告与日志却写"强度=safe"的撒谎现象。反推规则与
        config.MODE_PRESETS 一一对应：
            (active, poc) = (True, True)   -> aggressive
            (True, False) / (False, True)  -> normal
            (False, False)                 -> safe
        """
        if self.enable_active and self.enable_poc:
            return "aggressive"
        if self.enable_active or self.enable_poc:
            return "normal"
        return "safe"

    def auth_scan_profile(self, level=None):
        """所有目标统一使用的扫描强度 (enable_active, enable_poc)。

        硬约定（与用户口径一致）：授权状态不影响强度。无论目标是命中白名单
        的已授权域名（authorized），还是用户直接填入、默认视为已授权的目标
        （user_supplied），一律返回当前引擎实际生效的开关组合——即
        “所有目标扫描强度一样好一样高，不会一个牛逼一个是垃圾”。

        level 形参仅为调用方兼容保留，任何取值都不会改变返回值；
        若未来有人试图按 level 分流强度，请先看这条约定。
        """
        return bool(self.enable_active), bool(self.enable_poc)

    def _auth_of(self, target, host=None):
        """取目标的授权等级。优先用 run() 里预先定格的记录，
        未记录时现算（用于直接调 scan_target 的场景）。
        返回 (level, reason, rule)。"""
        t = (target or "").strip()
        rec = self._auth_levels.get(t)
        if rec:
            return rec
        try:
            return self.scope.classify(_norm_host(host or t))
        except Exception:
            return AUTH_AUTHORIZED, "未判定", ""

    # ------------------------------------------------------------
    # 出网预算
    # ------------------------------------------------------------
    def _budget_ok(self, host):
        with self._lock:
            n = self._hits.get(host, 0) + 1
            self._hits[host] = n
            if n > self.max_per_host:
                if n == self.max_per_host + 1:
                    log.warning("[预算] %s 已达单主机上限 %d，后续请求跳过",
                                host, self.max_per_host)
                    logger.audit("host_budget_exceeded", host=host, limit=self.max_per_host)
                return False
            return True

    # ------------------------------------------------------------
    # 落库（统一两种来源：vulnchecks 疑似项 / poc 已确认项）
    # ------------------------------------------------------------
    def _note_fid(self, target, fid):
        """登记本轮落库/升级/命中的 finding id（r88 缺陷 #6）。

        计入三种情形：本轮新增落库、本轮原地升级为已复现、
        本轮命中了「历史已有」的同一去重键（URL 完全相同的复扫）。
        三者合起来才是「本轮结果」的正确口径：报告与核验都只消费它，
        历史里没被本轮命中的旧行（正是被修掉的误报）不会混进新报告。
        """
        try:
            _fid = int(fid)
        except Exception:
            return
        with self._lock:
            self._note_fid_locked(target, _fid)
    def _note_fid_locked(self, target, fid):
        """_note_fid 的「已持锁」版：调用方必须已持有 self._lock。

        拆出来是为了避免 _persist 在 with self._lock 里再调 _note_fid
        造成 Lock 重入（threading.Lock 不可重入，会直接把扫描线程吊死）。
        """
        _lst = self._run_fids.setdefault(str(target).strip(), [])
        if fid not in _lst:
            _lst.append(fid)
    def _fids_of(self, target):
        """取某目标本轮落库的 finding id 列表（未扫过则为空）。"""
        with self._lock:
            return list(self._run_fids.get(str(target).strip()) or [])
    def _persist(self, f, target, verified=False):
        url = f.get("url") or ""
        host = _host_of(url)
        vtype = f.get("vuln_type") or f.get("type") or "未知"
        param = f.get("payload_param") or f.get("param") or ""
        method = (f.get("method") or "GET").upper()
        # 去重键含 method：同一 URL 的 GET 面与 POST 面是两条独立攻击面，
        # 只按 (type,url,param) 去重会让后出现的形态被前一个静默吞掉
        # （典型：/login 的 GET 与 POST 都带 user 参数，POST 面永远出不来）。
        key = (vtype, url, param, method)
        # 缺陷 P 修复：原实现见重复键即 return None，于是 PoC 升级项
        # （verified=True）被自己先前落下的"疑似"行挡住——实测 e2e 中 PoC
        # 明明打印了 3 条"[已复现]"，落库 12 条的 verified 却全是 False，
        # 报告永远显示不出"已复现"。现改为：命中已有行时，若本次是 PoC 确认项
        # 且该键尚未升级过，则把原行"原地升级"为已复现（不新增条目、不丢确认）。
        # 注意：db 调用必须在锁外执行，DB._exec/query 自己会取锁，重入会死锁。
        upgrade_fid = None
        with self._lock:
            prev_fid = self._seen_fid.get(key)
            if prev_fid is not None:
                if verified and key not in self._verified:
                    self._verified.add(key)
                    upgrade_fid = prev_fid
                else:
                    # r88 缺陷 #6 补丁：本轮命中的已存在项也要登记。
                    # 否则「本轮命中集与历史完全相同」时（实测 activiti
                    # 复扫的 22 条 URL 全是老行，全被去重挡掉），本轮 fid
                    # 列表为空，核验就退回全量、把历史误报当本轮项核验，
                    # 报告口径再次混乱。这里只登记 id，不重复 INSERT。
                    self._note_fid_locked(target, int(prev_fid))
                    return None
            else:
                self._seen.add(key)
        if upgrade_fid is not None:
            self.db.mark_verified(
                upgrade_fid,
                severity=f.get("severity"),
                confidence=f.get("confidence"),
                description=f.get("description") or f.get("evidence", ""),
                request=f.get("request", ""), response=f.get("response", ""),
                payload=f.get("payload", ""), cvss=f.get("cvss", ""),
                fix=f.get("fix", ""), evidence=f.get("evidence", ""),
                timing=({"baseline": f.get("baseline"), "control": f.get("control"),
                         "elapsed": f.get("elapsed")}
                        if f.get("baseline") is not None else None))
            logger.audit("finding_verified", target=target, url=url,
                         type=vtype, severity=f.get("severity"), id=upgrade_fid)
            self._note_fid(target, upgrade_fid)
            return upgrade_fid

        extra = {
            "verified": bool(verified),
            "param": param,
            "method": method,
            "evidence": f.get("evidence", ""),
        }
        # POST 型 finding 留档请求体键名（值统一为占位，避免把注入 payload
        # 当成"原始请求"写进库），供报告层复现与人工核验。
        body = f.get("body")
        if isinstance(body, dict) and body:
            extra["body_keys"] = sorted(body.keys())
        if f.get("baseline") is not None:
            extra["timing"] = {"baseline": f.get("baseline"),
                               "control": f.get("control"),
                               "elapsed": f.get("elapsed")}
        fid = self.db.add_finding(
            target=target, host=host, url=url, vuln_type=vtype,
            severity=f.get("severity", "info"), confidence=f.get("confidence", "medium"),
            title=f.get("title") or "%s @ %s" % (vtype, url),
            description=f.get("description") or f.get("evidence", ""),
            request=f.get("request", ""), response=f.get("response", ""),
            payload=f.get("payload", ""), cvss=f.get("cvss", ""),
            fix=f.get("fix", ""), extra=extra)
        # 登记去重键 -> fid，供后续 PoC 确认项"原地升级"该行（缺陷 P 修复）。
        if fid is not None:
            with self._lock:
                self._seen_fid[key] = fid
                if verified:
                    self._verified.add(key)
            self._note_fid(target, fid)
        if verified:
            logger.audit("finding_verified", target=target, url=url,
                         type=vtype, severity=f.get("severity"), id=fid)
        return fid

    def _fut_timeout(self):
        """round71：并发等待的兜底超时（秒）。

        as_completed 默认无限期等待，只要有一个 future 卡在 socket 上
        不返回，整轮扫描/整轮回归就会一起挂住（round70 登记的"偶发卡住"
        就是这个形态）。这里给一个"整批最坏耗时"上限：超时即放弃剩余
        future，已完成的照常入库，不把整轮判死。
        """
        try:
            per = float(self.config.get("http.timeout", 12) or 12)
        except Exception:
            per = 12.0
        try:
            retries = int(self.config.get("http.retries", 2) or 2)
        except Exception:
            retries = 2
        # r88: 旧值是「单请求最坏 × 4」≈144s，与每台 240s 的扫描预算严重不匹配：
        # 实测 392 台在第 144s 被整批放弃，只落了 10.7 个请求/台，扫描被压成形式化。
        # 现按「单台预算 × 主机数 ÷ 并发」估算整轮最坏耗时（1.5 倍余量），
        # 再用 scan.max_wait_sec 兜底，避免真的卡死时无限期等待。
        _budget = 0.0
        try:
            _budget = float(self.config.get("scan.stage_budget_total_sec", 600) or 600)
        except Exception:
            _budget = 600.0
        _n = max(1, int(getattr(self, "_n_hosts", 0) or 0))
        # r88: concurrency 在少数调用路径（桩对象 / 早期构造）可能尚未就位，
        # 用 getattr 取默认值，避免 _fut_timeout 直接 AttributeError 把整轮打断。
        try:
            _conc = max(1, int(getattr(self, "concurrency", 1) or 1))
        except Exception:
            _conc = 1
        _rounds = (_n + _conc - 1) // _conc
        _est = max(per * (retries + 1), 240.0) * _rounds * 1.5
        try:
            _cap = float(self.config.get("scan.max_wait_sec", 1800) or 1800)
        except Exception:
            _cap = 1800.0
        return max(60.0, min(_cap, max(_est, _budget * 1.2)))

    def _log_pending_futures(self, futs, tag):
        """round72：并发等待超时后，把"仍未返回"的线程打成可判读的日志。

        round71b 已给 as_completed 补上 timeout=，超时后不再无限期等待；但被
        放弃的那批 future 当时是静默 cancel —— cancel 对**已在运行**的线程
        无效，它们会继续跑到底，日志里不留痕迹。于是"回归偶发卡住"到底卡在
        哪个阶段、超时后还剩几个线程在跑，事后无法判读（遗留①的观测缺口）。

        这里只补观测，不改控制流：超时语义、结果丢弃规则、命中落库范围全部
        不变，也不新增任何出网请求。
        """
        try:
            pend = [fu for fu in futs if not fu.done()]
        except Exception:
            pend = []
        if not pend:
            log.debug("[%s] 并发超时后无未完成线程", tag)
            return
        log.warning("[%s] 并发超时后仍有 %d/%d 个线程未返回"
                    "（已放弃等待；未写入 checked 的任务下轮重扫，不会漏报）",
                    tag, len(pend), len(futs))
        for _fu in pend:
            try:
                _fu.cancel()
            except Exception:
                pass


    # ------------------------------------------------------------
    # 单主机完整流程
    # ------------------------------------------------------------
    def _hb(self):
        # round81 B6/B7: long-silence heartbeat gate (log only, no behavior
        # change). 'no log' and 'dead' look identical in the UI, so every
        # loop that may stay quiet for a long time goes through here:
        # say 'still running' at least once every 30s. True = print now.
        _now = time.time()
        if (_now - getattr(self, '_hb_t', 0.0)) < 30.0:
            return False
        self._hb_t = _now
        return True

    def scan_host(self, host, target):
        """对单主机做：存活探测 → 浅爬 → 路径/目录 → 九类检测。返回该主机结果摘要。"""
        out = {"host": host, "alive": False, "url": "", "findings": 0,
               "confirmed": 0, "secrets": 0, "error": ""}
        # round81 B5: one host runs 7 serial stages. Say which host starts.
        _hs = time.time()
        log.info("[主机] 开始 %s（本机跑 7 个阶段：敏感路径→目录→组件→…→落库/PoC）",
                 host)
        if self.wait_if_paused():
            return out

        ok, reason = self.scope.check(_norm_host(host), purpose="engine:host")
        if not ok:
            log.warning("[跳过] %s（%s）", host, reason)
            out["error"] = reason
            return out
        # 授权状态标注（仅标注，不改变任何扫描行为）。
        # 优先继承父目标已定格的等级：子域是父目标枚举/派生出来的，
        # 应跟父目标同档（round60 起未命中白名单也默认视为已授权）。
        _pt = self._auth_levels.get(str(target).strip())
        if _pt:
            _hl, _hr = _pt[0], _pt[1]
        else:
            try:
                _hl, _hr, _ = self.scope.classify(_norm_host(host))
            except Exception:
                _hl, _hr = AUTH_AUTHORIZED, ""
        out["auth_level"] = _hl
        out["auth_cn"] = AUTH_CN.get(_hl, _hl)
        out["auth_reason"] = _hr

        _diag = {}
        try:
            info = probe.probe_host(host, self.client, db=self.db, diag=_diag)
        except Exception as e:
            out["error"] = "probe_host: %s" % e
            log.warning("探测异常 %s: %s", host, e)
            return out
        if not info or not info.get("url"):
            # 失败归因：不再只留一句笼统的"连不上"，而是带上分类原因 + 排查建议，
            # 并保留 unreachable: 前缀以兼容既有过滤逻辑（scan_target）。
            _reason = _diag.get("reason") or "目标无 HTTP 响应"
            _hint = _diag.get("hint") or "连接超时 / 被拒绝 / 端口未开放"
            out["error"] = "unreachable: %s（%s）" % (_reason, _hint)
            # 自愈动作：把归因 code 映射为确定性的下一步动作（见 core/selfheal.py）。
            # 这里只做"计划"不做"执行"——动作是否真发请求由调用方按
            # scan.max_requests_per_host 预算决定，避免自愈把预算打穿。
            _diag_full = {"code": _diag.get("code") or "unknown",
                          # 域名级联想结果回填：probe_host 已把可解析候选写进
                          # _diag["variants"] 并置 variants_probed=True。
                          # should_stop 据此判断"联想后仍无解才停"。
                          "variants": list(_diag.get("variants") or []),
                          "variants_probed": bool(_diag.get("variants_probed"))}
            try:
                _acts = selfheal.plan(_diag_full)
                _cost = selfheal.request_cost(_acts)
            except Exception:
                _acts, _cost = [], 0
            # 3-1 回退链可观测：把"试过的端口"记进报告。
            # 只做 TCP 探活（不出网 HTTP，不占 requests 计数），且仅对端口相关的
            # 归因补测：DNS 类失败（域名都解析不了）探端口毫无意义，不做。
            # refused/connect 走完整默认端口组（与 selfheal 的 port_retry 同源），
            # 其余端口类失败只复测当前端口，避免无谓放大出网动作。
            _ports = []
            try:
                _c0 = _diag.get("code") or "unknown"
                if _c0 in ("refused", "connect"):
                    _ports = netdiag.probe_ports(host)
                elif _c0 in ("timeout", "reset", "http", "tls", "noroute"):
                    _ports = netdiag.probe_ports(
                        host, [netdiag.port_of(host, 443)])
            except Exception:
                _ports = []
            out["unreachable"] = {
                "host": host, "code": _diag.get("code") or "unknown",
                "reason": _reason, "hint": _hint,
                "ip": _diag.get("ip", ""), "tcp": _diag.get("tcp", ""),
                "err": _diag.get("err", ""),
                "variants": _diag.get("variants") or [],
                "next_steps": [a["action"] for a in _acts],
                "next_actions": _acts,
                "request_cost": _cost,
                "stop": selfheal.should_stop(_diag_full),
                # 3-1 回退链可观测：把"试过的端口"与一行摘要记进报告。
                # 纯 TCP 探活、不占 requests 计数，异常已在上面吞掉。
                "port_probe": _ports,
                "ports_text": netdiag.ports_text(_ports),
            }
            log.warning("[不可达] %-40s %s | %s | 自愈：%s", host, _reason, _hint,
                        selfheal.describe(_acts))
            # round57：自愈层 plan() 已产出 switch_variant（域名 NXDOMAIN 但联想出可解析
            # 形态）。此处消费该动作：把变体主机交给 scan_host 接管扫描，并把"已改用变体
            # X"写进报告。受 scan.auto_variant、递归深度(<=1)与去重表三重约束；任何异常
            # 都吞掉，绝不影响既有不可达结果字段与语义（round26 A14-A26/C/D 组）。
            if self.auto_variant:
                try:
                    _sv = [a for a in _acts
                           if isinstance(a, dict) and a.get("action") == "switch_variant"]
                    if _sv and self._variant_depth < 1:
                        _cand = [str(h) for h in
                                 ((_sv[0].get("params") or {}).get("hosts") or [])
                                 if str(h).strip()]
                        _takeover = False
                        with self._lock:
                            if host not in self._variant_seen:
                                self._variant_seen.add(host)
                                self._variant_depth += 1
                                _takeover = True
                        if _takeover and _cand:
                            _tried = []
                            try:
                                for _vh in _cand[:3]:
                                    if not self._budget_ok(_vh):
                                        continue
                                    _tried.append(_vh)
                                    _r = self.scan_host(_vh, target)
                                    if _r.get("alive"):
                                        out["unreachable"]["switched_to"] = _vh
                                        log.warning("[变体接管] %s -> %s 可探测，改用该形态继续",
                                                    host, _vh)
                                        break
                            finally:
                                with self._lock:
                                    self._variant_depth -= 1
                            if _tried:
                                out["unreachable"]["variant_tried"] = _tried
                except Exception as e:
                    log.debug("变体接管跳过：%s", e)
            return out

        out["alive"] = True
        base_url = info["url"]
        out["url"] = base_url
        out["title"] = info.get("title", "")
        out["tech"] = info.get("tech", [])
        if info.get("waf"):
            logger.audit("waf_detected", host=host, waf=info["waf"])

        pending = []   # 疑似项，最后统一升级
        hosts_cfg = host
        _t0 = time.time()

        # round87e: budget was a flat 120s per host, so with 13 siblings
        # nearly every host blew it and fell into 50-word lite mode --
        # which is exactly why the scan output looked stripped down.
        # Spread a run-wide total across the host list instead.
        try:
            _nhost87 = max(1, int(getattr(self, '_n_hosts', 0) or 0))
        except Exception:
            _nhost87 = 1
        _tot87 = float(self.config.get('scan.stage_budget_total_sec', 600) or 600)
        _per87 = _tot87 / float(_nhost87)
        # single-host runs keep the explicit per-host knob (r87 behaviour);
        # multi-host runs spread the total so no host is starved.
        _hard87 = float(self.config.get('scan.stage_budget_sec', 0) or 0)
        if _hard87 > 0 and _nhost87 <= 1:
            _per87 = _hard87
        # r88: 旧下限 60s。392 台时每台 60~180s 连阶段1敏感路径都跑不完，
        # 实测 4216 请求 / 392 主机 = 每台 10.7 个请求，等于只做了形式化检查。
        # 单台最低给 240s，上限抬到 600s；总预算仍由 stage_budget_total_sec 约束。
        _per87 = max(240.0, min(600.0, _per87))
        _stage_t = {'v': 0.0, 'tag': '', 'host_t0': time.time(),
                    'deadline': time.time() + _per87,
                    'budget87': _per87, 'lite87': False}

        def _stage(tag, note=""):
            """阶段进度日志：串行阶段请求量大（数百条）+ 全局限速，
            单阶段动辄十几秒，没没有日志用户会误判为卡死。
            round83 B1：记下进入时间，配合 _stage_done() 打出本阶段耗时+产出。"""
            # round87 A1: stage time budget. Before this, one stage could
            # eat 505s (user report) because nothing capped it. Track a
            # per-host soft deadline; once blown, later stages run in
            # lite mode instead of running the full word lists again.
            _now87 = time.time()
            if _stage_t.get('deadline') and _now87 > _stage_t['deadline'] and not _stage_t.get('lite87'):
                _stage_t['lite87'] = True
                log.warning("[%s] 阶段预算已尽（%.0fs），后续阶段切精简模式",
                            host, _now87 - _stage_t['host_t0'])
            _stage_t['prev87'] = _stage_t.get('v', _now87)
            _stage_t['v'] = _now87
            # r88: 旧写法取 prev87 默认值 _t0，首阶段算出 +1792479419.3s 这类 epoch 差值。
            # 统一用本机 scan_host 起点 host_t0 做基准，异常时也不出现天文数字。
            _prev87 = _stage_t.get('prev87') or _stage_t.get('host_t0') or _now87
            _delta87 = max(0.0, _now87 - _prev87)
            log.info("[%s] %-34s +%.1fs（累计 %.0fs） %s",
                     host, tag, _delta87, _now87 - (_stage_t.get('host_t0') or _now87), note)
            _stage_t['tag'] = tag
            if not _stage_t.get('lite87') and _stage_t.get('budget87'):
                _left87 = _stage_t['deadline'] - _now87
                if _left87 < 20:
                    log.info("[%s] 本台预算剩余 %.0fs（共 %.0fs），"
                             "接近后转精简", host, max(0.0, _left87),
                             _stage_t['budget87'])

        def _stage_done(prod):
            """round83 B1：阶段退出时打一行「耗时 + 产出」，
            让用户能看出每个阶段真正干了什么、花了多久。"""
            try:
                _d = time.time() - float(_stage_t['v'] or time.time())
                log.info("[%s] %-34s 完成 %.1fs -> %s",
                         host, (_stage_t['tag'] or '') + ' 完成', _d, prod)
            except Exception:
                pass

        # ---- 1) 敏感路径 ----
        _stage("阶段1/7 敏感路径", "字典 %d 条" % len(dicts.SENSITIVE_PATHS))
        path_hits = []
        if self._budget_ok(host):
            try:
                path_hits = probe.probe_sensitive_paths(base_url, self.client,
                                                        db=self.db, host=hosts_cfg)
            except Exception as e:
                log.warning("敏感路径异常 %s: %s", host, e)
            _stage_done("命中路径 %d 条，待判定 %d 条" % (len(path_hits), len(pending)))
            if path_hits:
                pending += vulnchecks.check_unauthorized(path_hits, self.client, db=self.db)
                # 登录入口 → 弱口令（默认关闭，避免锁号）
                if self.weak_password:
                    pending += self._weak_password(base_url, path_hits)

        # ---- 2) 目录爆破 ----
        _stage("阶段2/7 目录爆破", "字典 %d 条 / 并发 %d" % (len(dicts.DIR_WORDS), self.concurrency))
        dirs = []
        if self.enable_active and self.config.get("scan.dir_bruteforce", True) and self._budget_ok(host):
            try:
                # round87 A1: once the host budget is blown, brute force
                # only the first slice of the word list. Full 190-word runs
                # on 13 sibling subdomains is what made the run feel hung.
                _words87 = None
                _lite87_on = bool(_stage_t.get('lite87'))
                # round87e: _lite_run was computed but NEVER read, so the
                # sub-domain lite mode did nothing. Actually use it.
                _sub87 = bool(getattr(self, '_lite_run', False))
                if _lite87_on or _sub87:
                    _n87 = int(self.config.get('scan.lite_words', 50) or 50)
                    if _sub87 and not _lite87_on:
                        _n87 = int(self.config.get('scan.sub_lite_words', 180) or 180)
                    _words87 = list(dicts.DIR_WORDS)[:_n87]
                    log.info("[%s] 精简模式（%s）：目录字典 %d -> %d 条",
                             host, '预算耗尽' if _lite87_on else '子域较多',
                             len(dicts.DIR_WORDS), len(_words87))
                dirs = probe.dir_bruteforce(base_url, self.client, db=self.db,
                                            workers=self.concurrency, words=_words87)
            except Exception as e:
                log.warning("目录爆破异常 %s: %s", host, e)
            out["dirs"] = [d["url"] for d in dirs[:50]]
            _stage_done("目录命中 %d 条" % len(dirs))

        # ---- 2.5) 目录爆破命中的登录入口 -> 弱口令（默认关闭）----
        # SENSITIVE_PATHS 里没有 login 类路径，真实站点最常见的 /login、
        # /signin 只能靠目录爆破发现。把目录爆破结果里带登录线索的入口
        # 补喂给弱口令通道，消除有登录页却永远不测的结构性漏检。
        if self.weak_password and dirs and self._budget_ok(host):
            try:
                _dh = [{"url": d.get("url") or "", "title": ""} for d in dirs]
                pending += self._weak_password(base_url, _dh, tag="目录爆破")
            except Exception as e:
                log.warning("弱口令（目录入口）异常 %s: %s", host, e)
        # ---- 3) 备份文件 / 国产组件 ----
        _stage("阶段3/7 备份·目录列表·组件", "串行 %d+%d+%d 项"
               % (30, 40, len(dicts.CN_COMPONENT_CHECKS)))
        if self.enable_active and self._budget_ok(host):
            try:
                pending += vulnchecks.check_backup_files(
                    base_url, self.client, found_dirs=[d["url"] for d in dirs])
            except Exception as e:
                log.warning("备份文件检测异常 %s: %s", host, e)
        # 主动增强 U-6：目录列表泄露（与备份检测共用 found_dirs，两者互为线索）
        if self.enable_active and self._budget_ok(host):
            try:
                pending += vulnchecks.check_directory_listing(
                    base_url, self.client, found_dirs=[d["url"] for d in dirs])
            except Exception as e:
                log.warning("目录列表检测异常 %s: %s", host, e)
        if self.enable_active and self._budget_ok(host):
            try:
                pending += vulnchecks.check_cn_components(base_url, self.client)
            except Exception as e:
                log.warning("组件检测异常 %s: %s", host, e)
        # ---- 3.5) 声明式模板引擎（templates/*.yaml）----
        # 模板请求同样走 client.send()，受 scope 闸与限速约束；命中输出走
        # vulnchecks._finding 契约，故与内置检测器在后续流程（poc 升级、
        # 去重落库、报告分档）中完全等价。上限可配 scan.template_max_requests。
        if self.enable_active and self._budget_ok(host):
            try:
                tpl_limit = int(self.config.get("scan.template_max_requests", 120) or 120)
                _stage("阶段3.5/7 模板引擎", "上限 %d 请求" % tpl_limit)
                pending += template_engine.run_templates(
                    base_url, self.client, host=host, max_requests=tpl_limit)
            except Exception as e:
                log.warning("模板引擎异常 %s: %s", host, e)
        # ---- 3.6) 开放 API 注册端点（未鉴权 + 直接下发会话凭据）----
        # round58 新增：round57 基线高危 #1（匿名注册即回会话 token）此前
        # 全项目零覆盖。只做一次匿名注册调用，看回包是否直接吐出会话凭据，
        # 不做任何爆破/重复提交；命中输出走 vulnchecks._finding 契约，故与
        # 内置检测器在后续流程（去重落库、报告分档）中完全等价。
        if (self.enable_active and self.config.get("scan.open_api_probe", True)
                and self._budget_ok(host)):
            try:
                _stage("阶段3.6/7 开放 API 注册面", "端点 %d 个"
                       % len(dicts.OPEN_API_PROBES))
                pending += vulnchecks.check_open_api_auth(base_url, self.client)
            except Exception as e:
                log.warning("开放 API 检测异常 %s: %s", host, e)
        # ---- 3.7) 账号枚举（用户名存在性泄露）----
        # round71c 遗留③-1。与参数级检测的区别：这里做的是**语义型**判定
        # （同一字段喂不同取值、比对响应差异），而参数级只注入 payload 看回显。
        # 只读、每端点 3 次请求、无字典，命中输出走同一 _finding 契约。
        if (self.enable_active and self.config.get("scan.user_enum_probe", True)
                and self._budget_ok(host)):
            try:
                _stage("阶段3.7/7 账号枚举", "端点 %d 个"
                       % len(dicts.USER_ENUM_PROBES))
                pending += vulnchecks.check_user_enum(base_url, self.client)
            except Exception as e:
                log.warning("账号枚举检测异常 %s: %s", host, e)
        # ---- 3.8) 硬编码公钥（前端可读位置的密钥材料）----
        # round71c 遗留③-2。与 SECRET_PATTERNS 的「私钥」互补：私钥只抓
        # PRIVATE KEY，这里专抓随前端下发的公钥/证书材料。只读 GET。
        if (self.enable_active
                and self.config.get("scan.hardcoded_key_probe", True)
                and self._budget_ok(host)):
            try:
                _stage("阶段3.8/7 硬编码公钥", "路径 %d 条"
                       % len(dicts.HARDCODED_KEY_PATHS))
                pending += vulnchecks.check_hardcoded_key(base_url, self.client)
            except Exception as e:
                log.warning("硬编码公钥检测异常 %s: %s", host, e)
        # ---- 3.9) token 跨端点复用（单主机侧）----
        # round71c 遗留③-3。跨主机汇总在 scan_target 收尾做（见 4.9）。
        if (self.enable_active and self.config.get("scan.token_reuse_probe", True)
                and self._budget_ok(host)):
            try:
                _stage("阶段3.9/7 token 复用", "路径 %d 条"
                       % len(dicts.TOKEN_REUSE_PATHS))
                _tmap = vulnchecks.collect_token_map(base_url, self.client)
                if _tmap:
                    # 暂存供 scan_target 跨主机汇总；单主机命中同样上报。
                    with self._lock:
                        for _v, _ps in _tmap.items():
                            self._token_map.setdefault(_v, {})
                            self._token_map[_v][host] = list(_ps)
                    pending += vulnchecks.token_reuse_findings(base_url, _tmap)
            except Exception as e:
                log.warning("token 复用检测异常 %s: %s", host, e)

        # ---- 4) 浅爬取待测 URL（含首页自身）+ POST 表单面 ----
        _stage("阶段4/7 浅爬 + 参数面")
        urls, form_tasks = self._collect_urls(base_url, host)
        for d in dirs[:40]:
            urls.append(d["url"])
        for h in path_hits[:40]:
            urls.append(h["url"])
        urls = self._dedup_urls(urls)

        # ---- 4.5) 参数面扩展 ----
        # 真实入口常是 POST 表单或无参路由，只测"URL 已带 ?"会大面积漏检。
        # 这里给无参 URL 低频补上常见参数名，把候选注入面打开；是否成漏洞
        # 仍由各检测函数自己的判定口径决定。
        if self.config.get("scan.param_seed", True) and self._budget_ok(host):
            try:
                seeded = self._seed_param_urls(urls)
                if seeded:
                    urls = self._dedup_urls(urls + seeded)
                    log.info("[参数面] %s 新增 %d 个候选参数 URL", host, len(seeded))
            except Exception as e:
                log.warning("参数面扩展异常 %s: %s", host, e)

        # ---- 4.6) 组装检测任务表（GET 面 + POST 表单面） ----
        # 缺陷 O 修复：原实现直接遍历 urls，POST 表单面无法进入检测链路。
        # 现在统一成 (url, method, body) 三元组，POST 任务单独排队；
        # 表单面按主机限额，避免一个页面几十个表单吃光请求预算。
        tasks = [(u, "GET", None) for u in urls]
        for t in form_tasks[:20]:
            tasks.append(t)
        if form_tasks:
            log.info("[POST 面] %s 解析出 %d 个表单提交面", host, len(form_tasks))

        # ---- 5) 参数级检测（每任务，并发） ----
        # 单主机串行跑上百个参数级任务时，2 req/s x 数百请求 = 十几分钟，
        # 且循环内无日志，用户会误以为卡死。这里改为线程池并发（上限
        # concurrency），并每 10 个任务打一条进度，保证过程可见。
        _stage("阶段5/7 参数级检测", "任务 %d 个" % len(tasks))
        checked = []   # 真正处理过的 URL：只有这些才允许标记为"已扫描"
        todo = []
        for (u, m, b) in tasks:
            if self.wait_if_paused() or not self._budget_ok(host):
                break
            # 断点续扫只对 GET 面生效：POST 任务无稳定 URL 标识，
            # 且 mark_scanned 以 URL 为键，混用会把 GET 面误标成已扫。
            if m == "GET" and self.resume and self.db.is_scanned(u):
                continue
            todo.append((u, m, b))
        total_todo = len(todo)
        if total_todo > 1 and self.concurrency > 1:
            with ThreadPoolExecutor(max_workers=min(self.concurrency, total_todo)) as ex:
                futs = {ex.submit(self._check_url, u, m, b): (u, m, b)
                        for (u, m, b) in todo}
                done_n = 0
                _tt = time.time()
                try:
                    for fu in as_completed(futs, timeout=self._fut_timeout()):
                        u, m, b = futs[fu]
                        try:
                            pending += fu.result() or []
                        except Exception as e:
                            log.warning("检测异常 %s: %s", u, e)
                        checked.append(u)
                        done_n += 1
                        # round81 B6: previously only every 10th task printed;
                        # one task can take ~10s+, hence the 144s of silence
                        # seen on the device. Add a 30s/90s gate and print the
                        # wait cap so 'not stuck' is provable.
                        if done_n % 10 == 0 or done_n == total_todo:
                            log.info("[检测] %s 进度 %d/%d", host, done_n, total_todo)
                        elif self._hb() or (time.time() - _tt) >= 90.0:
                            log.info("[检测] %s 进行中 %d/%d（已 %.0fs，未卡死；"
                                     "本机参数级等待上限 %.0fs）",
                                     host, done_n, total_todo, time.time() - _tt,
                                     self._fut_timeout())
                except FuturesTimeout:
                    # 放弃剩余任务：未写入 checked 的 URL 下轮会重扫，不会漏
                    self._log_pending_futures(futs, "检测")
                    log.warning("[检测] %s 并发等待超时（%.0fs），已放弃剩余 %d 个任务",
                                host, self._fut_timeout(), len(futs) - done_n)
        else:
            for (u, m, b) in todo:
                pending += self._check_url(u, method=m, body=b)
                checked.append(u)
        _stage_done("已检测~%d 个 URL，待判定累计 %d 条" % (len(checked), len(pending)))

        # ---- 6) 敏感信息（首页 + 已爬页面） ----
        # 优先扫 HTML 页（真配置多在此），静态资源排后面，避免 20 个名额被
        # jquery/bootstrap 之类占满而漏掉真正的动态页。
        # 缺陷 C 修复：原实现把每个 URL 的命中都无条件追加，导致同一封底
        # 邮箱/同一个内网 IP 在几十个 URL 上被重复计（实测大报告 40 条
        # "敏感信息泄露（邮箱）"全部来自同一封底邮箱）。现在：
        #   1) 软 404 兜底页不扫——WAF/兜底首页的响应体不是该路径的真实内容；
        #   2) 按 (类型, 原始匹配值) 全局去重，同一敏感值只报一次。
        secret_urls = sorted(
            urls, key=lambda x: 1 if probe.STATIC_ASSET_RE.search(x or "") else 0)[:20]
        _stage("阶段6/7 敏感信息", "候选 %d 个" % len(secret_urls))
        secret_base = probe.soft404_baseline(base_url, self.client)
        # round21 基线降级保护：基线不可用时 is_soft404 恒 False，
        # 会把兜底首页的封底邮箱/内网 IP 当成本页泄露内容。
        # 此处直接清空待扫 URL 列表，宁可漏扫，也不产出全站伪泄露。
        if not probe.baseline_usable(secret_base):
            log.warning("软 404 基线不可用，跳过敏感信息扫描 %s", host)
            secret_urls = []
        seen_secret = set()
        for u in secret_urls:
            if self.wait_if_paused() or not self._budget_ok(host):
                break
            r = self.client.get(u, purpose="engine:secret")
            if not r.status or not r.text:
                continue
            checked.append(u)
            # 兜底页 / WAF 统一响应：内容与随机路径同质，不代表该 URL 的真实内容
            if probe.is_soft404(r, secret_base):
                continue
            for h in probe.scan_secrets(u, r.text):
                key = (h["type"], h.get("raw", ""))
                if key in seen_secret:
                    continue
                seen_secret.add(key)
                out["secrets"] += 1
                pending.append({
                    "vuln_type": "敏感信息泄露（%s）" % h["type"],
                    "severity": h.get("severity", "low"),
                    "confidence": "medium", "url": h["url"],
                    "description": "响应体中匹配到 %s：%s（已脱敏）"
                                   % (h["type"], h.get("match", "")),
                    "payload": "", "cvss": "", "request": "",
                    "response": "", "evidence": "匹配项：%s" % h.get("match", ""),
                    "fix": "移除前端可见的密钥/内网信息；敏感配置改为服务端注入。",
                })

        # ---- 7) 落库（疑似） ----
        _stage("阶段7/7 落库 + PoC 复现", "疑似 %d 条" % len(pending))
        if len(pending) == 0:
            # round83 B2：五类检测零命中时必须说清楚原因，避免用户误以为程序坏了。
            _rs = []
            if not out.get("alive"):
                _rs.append("主机不存活，未进入检测")
            if not self.enable_active:
                _rs.append("主动检测关闭（enable_active=false，只跑基础派生）")
            if not self.enable_poc:
                _rs.append("PoC 复现关闭（不影响疑似判定）")
            if not checked:
                _rs.append("本机未检测到任何 URL（目录/爬取无产出）")
            if not path_hits and not dirs:
                _rs.append("敏感路径与目录字典均无命中（疑似停放页/默认页）")
            if not _rs:
                _rs.append("已检测 %d 个 URL、五类检测均未命中（目标没有对应露洞，属正常结果）" % len(checked))
            log.info("[%s] 疑似 0 条，原因：%s", host, "；".join(_rs))
        # 计数以"真正落库成功"为准：_persist 内部按 (type,url,param) 去重，
        # 重复项返回 None 被静默丢弃；直接 len(pending) 会让摘要数字虚高。
        saved = 0
        for f in pending:
            if self._persist(f, target, verified=False) is not None:
                saved += 1
        out["findings"] = saved

        # ---- 8) PoC 复现（只对可复现类型） ----
        confirmed = []
        if self.enable_poc and pending:
            try:
                confirmed = poc.upgrade(pending, self.client, limit=self.poc_limit)
            except Exception as e:
                confirmed = []
                log.warning("PoC 复现异常 %s: %s", host, e)
            for c in confirmed:
                self._persist(c, target, verified=True)
            out["confirmed"] = len(confirmed)

        # 记录已扫描 URL，供断点续扫。
        # 只标 checked（真正处理过、未因预算耗尽/停机而 break 掉）的 URL；
        # 原实现对 urls 全量标记，会把从未检测的 URL 也写成"已扫描"，
        # 续扫时被 is_scanned 跳过 -> 永久漏扫。
        for u in checked:
            self.db.mark_scanned(u, 0, 0, "", "")
        log.info("[主机] 完成 %s：耗时 %.1fs｜存活=%s｜漏洞=%d｜已复现=%d%s",
                 host, time.time() - _hs, "是" if out.get("alive") else "否",
                 int(out.get("findings", 0) or 0), int(out.get("confirmed", 0) or 0),
                 ("｜错误：%s" % out.get("error")) if out.get("error") else "")
        # round83 B3：单主机收尾汇总块（逐项列出本机真实产出，不再只给一个数字）
        try:
            log.info("[%s] ── 本机汇总 ── 耗时 %.1fs｜存活=%s｜目录命中=%d｜检测 URL=%d｜待判定=%d｜落库=%d｜已复现=%d｜敏感=%d",
                     host, time.time() - _hs, "是" if out.get("alive") else "否",
                     len(dirs), len(checked), len(pending),
                     int(out.get("findings", 0) or 0), int(out.get("confirmed", 0) or 0),
                     int(out.get("secrets", 0) or 0))
        except Exception:
            pass
        _hp = getattr(self, "_host_prog", None)
        if callable(_hp):
            try:
                _hp(host, "存活" if out.get("alive") else "不可达")
            except Exception:
                pass
        return out

    # ------------------------------------------------------------
    # 单 URL 参数级检测
    # ------------------------------------------------------------
    def _check_url(self, url, method="GET", body=None):
        """对单个 (url, method, body) 任务跑参数级检测。

        缺陷 O 修复：原签名只接收 url，四个检测函数调用时一律不传 method/body，
        于是 POST 表单面即使被解析出来也无处可测。现在按任务形态下发：
        - GET  : params 从 query string 取，检测函数内部拼 `?k=payload`
        - POST : params 从请求体键名取，检测函数内部拼 `k=payload` 表单体
        """
        findings = []
        method = (method or "GET").upper()
        is_post = method == "POST"
        if not is_post and "?" not in url:
            # 无参 GET URL 只做 CORS / 组件类检测
            if self.enable_active:
                try:
                    findings += vulnchecks.check_cors(url, self.client)
                except Exception:
                    pass
            return findings

        params = vulnchecks._param_candidates(url, body)
        if not params:
            # POST 表单没有具名字段（纯按钮表单）时退化为 CORS 检查，不空转请求
            if self.enable_active:
                try:
                    findings += vulnchecks.check_cors(url, self.client)
                except Exception:
                    pass
            return findings

        def _safe(fn, *a, **kw):
            try:
                return fn(*a, **kw) or []
            except Exception as e:
                log.warning("检测异常 %s: %s", fn.__name__, e)
                return []

        findings += _safe(vulnchecks.check_sqli, url, self.client, params=params,
                          method=method, body=body)
        findings += _safe(vulnchecks.check_xss, url, self.client, params=params,
                          method=method, body=body)
        findings += _safe(vulnchecks.check_open_redirect, url, self.client, params=params,
                          method=method, body=body)
        findings += _safe(vulnchecks.check_ssrf, url, self.client, params=params,
                          oob_domain=self.scope.oob_domain, method=method, body=body)
        if self.enable_active:
            findings += _safe(vulnchecks.check_cors, url, self.client)
        # 阶段 5-1 难例采集：走到这里说明"确实有可测参数（params 非空）且
        # 五类检测全部零命中"——即现有规则覆盖不到的接口。只写内存、不发
        # 任何额外请求、不做任何判定；真正落盘在 scan_target 收尾统一完成。
        # 注意：上面两处退化分支（无参 GET / 无具名字段 POST）已提前 return，
        # 不会走到这里，因此"无参 URL 灌满队列"的误采被结构性排除。
        if not findings:
            try:
                with self._hunt_lock:
                    self._hunt_samples.append({
                        "url": url,
                        "method": method,
                        "param": params[0] if params else "",
                        "kind": "no_match",
                        "snippet": "params=%s" % ",".join(params),
                    })
            except Exception:
                pass
        return findings

    # ------------------------------------------------------------
    # 弱口令（默认关闭）
    # ------------------------------------------------------------
    def _weak_password(self, base_url, path_hits, tag="敏感路径"):
        """弱口令检测（默认关闭）。

        去重候选登录入口：同一 URL 只测一次，且跨阶段共享 self._weak_tried，
        避免敏感路径与目录爆破两次命中同一入口时重复试凭据；入口数 /
        单入口尝试次数
        均取自配置（scan.weak_password_max_targets / max_try），
        且所有出网由 HttpClient.rate_limit 统一限速。
        """
        out = []
        candidates = []
        seen = set()
        for h in path_hits:
            u = h.get("url") or ""
            low = u.lower()
            if not u or u in seen or u in self._weak_tried:
                continue
            # 既看路径，也看标题/正文里的登录线索（表单型入口常不带 login 字样）
            hint = (any(k in low for k in LOGIN_HINTS) or
                    any(k in (h.get("title") or "").lower() for k in LOGIN_HINTS))
            if hint:
                seen.add(u)
                candidates.append(u)
        if not candidates:
            return out
        try:
            max_targets = max(1, int(self.config.get("scan.weak_password_max_targets", 5)))
        except Exception:
            max_targets = 5
        try:
            max_try = max(1, int(self.config.get("scan.weak_password_max_try", 24)))
        except Exception:
            max_try = 24
        # 3-2：连续失败熔断阈值（默认 3）。配置缺失/非法时退回默认值，
        # 与 max_targets / max_try 同风格，绝不因配置写错而中断扫描。
        try:
            max_fail = max(1, int(self.config.get("scan.weak_password_max_fail", 3)))
        except Exception:
            max_fail = 3
        _consec_fail = 0
        for i, u in enumerate(candidates[:max_targets]):
            self._weak_tried.add(u)
            try:
                _hit = vulnchecks.check_weak_password(
                    u, self.client, user_field=USER_FIELDS[0],
                    pass_field=PASS_FIELDS[0], max_try=max_try,
                    user_fields=list(USER_FIELDS), pass_fields=list(PASS_FIELDS)) or []
                out += _hit
                # 3-2：连续失败熔断。命中即清零；连续 max_fail 个入口零命中
                # 就提前收手，避免对"本来就没弱口令"的资产持续试凭据。
                # 只做计数与提前退出，不新增 kind="weakpass" 判定点。
                if _hit:
                    _consec_fail = 0
                else:
                    _consec_fail += 1
                    if _consec_fail >= max_fail:
                        log.info("弱口令熔断：连续 %d 个入口零命中，"
                                 "提前收手（已测 %d 个）", _consec_fail, i + 1)
                        break
            except Exception as e:
                log.warning("弱口令检测异常 %s: %s", u, e)
        return out

    # ------------------------------------------------------------
    # 浅爬
    # ------------------------------------------------------------
    def _collect_urls(self, base_url, host):
        """从首页出发，按 crawl_depth 抽取同域链接（不跟进外域）。

        返回 (urls, form_tasks)：
        - urls      : 普通链接（GET 面，含首页自身）
        - form_tasks: POST 表单三元组 (action_url, "POST", {字段名: "bt"})

        缺陷 O 修复：原实现只返回 urls，`<form method="post">` 的提交面被
        LINK_RE 当普通 GET 链接测，POST 面从未打开。现在在同一遍爬取里
        顺带解析表单，避免二次抓取浪费请求预算。
        """
        seen = [base_url]
        forms, form_seen = [], set()
        frontier = [base_url]
        for _d in range(self.depth):
            nxt = []
            _cn = 0
            for u in frontier:
                if self.wait_if_paused() or not self._budget_ok(host):
                    break
                _cn += 1
                # round81 B6: the crawl loop had no per-page log, so a slow
                # batch here looked identical to a hang. Round start plus
                # 10-page / 30s heartbeat; single page worst case is
                # timeout x (retries + 1), printed so it stays provable.
                if _cn == 1 or _cn % 10 == 0 or self._hb():
                    log.info("[浅爬] %s 第 %d/%d 轮：%d/%d 个页面（单页最坏 %.0fs，"
                             "未卡死）", host, _d + 1, self.depth, _cn,
                             len(frontier),
                             float(self.config.get("http.timeout", 12) or 12) * 3.0)
                r = self.client.get(u, purpose="engine:crawl")

                if not r.status or not r.text:
                    continue
                text = r.text[:200000]
                for m in LINK_RE.finditer(text):
                    link = m.group(1).strip()
                    if not link or link.startswith(("mailto:", "javascript:", "tel:")):
                        continue
                    full = self._absolutize(base_url, link)
                    if full and _host_of(full) == _norm_host(host) and full not in seen:
                        seen.append(full)
                        nxt.append(full)
                for t in self._extract_forms(u, text):
                    if _host_of(t[0]) != _norm_host(host):
                        continue
                    k = (t[0], tuple(sorted(t[2])))
                    if k in form_seen:
                        continue
                    form_seen.add(k)
                    forms.append(t)
            frontier = nxt[:30]
            if not frontier:
                break
        return seen, forms

    # ------------------------------------------------------------
    # POST 表单面解析（缺陷 O 配套）
    # ------------------------------------------------------------
    def _extract_forms(self, base_url, text):
        """从 HTML 抽取 POST 表单提交面，产出 (action_url, "POST", {字段: "bt"})。

        解析口径（保守，避免造出假面）：
        - 只认 `method="post"`（含大小写混写）的表单；缺省 method 按 GET，
          不产生 POST 任务——HTML 规范默认就是 GET。
        - action 缺省时回落到所在页面 URL（规范行为）。
        - 跳过 submit/button/reset/image/file 等非注入字段。
        - 字段值统一填 "bt" 占位，真正 payload 由各检测函数按字段名注入。
        """
        out = []
        if not text:
            return out
        for fm in FORM_RE.finditer(text):
            block = fm.group(0)
            head = block[:block.find(">") + 1] if ">" in block else block
            attrs = dict(TAG_ATTR_RE.findall(head))
            method = (attrs.get("method") or "GET").strip().upper()
            if method != "POST":
                continue
            action = (attrs.get("action") or "").strip()
            target = self._absolutize(base_url, action) if action else base_url
            if not target or not target.startswith(("http://", "https://")):
                continue
            fields = {}
            for _tag, rest in FIELD_TAG_RE.findall(block):
                fattrs = dict(TAG_ATTR_RE.findall(rest))
                name = (fattrs.get("name") or "").strip()
                if not name:
                    continue
                if (fattrs.get("type") or "").strip().lower() in NON_FIELD_TYPES:
                    continue
                fields[name] = "bt"
            if not fields:
                # 无具名字段的表单（纯按钮）用常见参数名兜底，保持 POST 面可测
                fields = {dicts.COMMON_PARAMS[0]: "bt"}
            out.append((target, "POST", fields))
        return out

    @staticmethod
    def _absolutize(base_url, link):
        from urllib.parse import urljoin
        try:
            return urljoin(base_url, link)
        except Exception:
            return ""

    # ------------------------------------------------------------
    # 参数面扩展（缺陷 I 配套）
    # ------------------------------------------------------------
    def _seed_param_urls(self, urls, limit=2):
        """给无参 URL 补上常见参数名，打开候选注入面。

        背景：真实入口大量是 `/search`、`/user`、`/detail` 这类无参路由，
        仅测"URL 自带 ?"会大面积漏检。这里只做**候选面扩展**（生成 URL 不发
        请求），命中与否仍由各检测函数的判定口径决定。
        为控制请求预算，每主机最多扩 `limit` 个 URL、每 URL 取 2 个参数名。
        """
        from urllib.parse import urlparse, urlunparse, urlencode
        out = []
        for u in urls:
            if len(out) >= limit:
                break
            if "?" in u or not u.startswith(("http://", "https://")):
                continue
            p = urlparse(u)
            base = (p.path or "/").rsplit("/", 1)[-1]
            # 跳过静态资源：带扩展名且不是动态脚本后缀的，基本不是注入入口
            if "." in base and not base.lower().endswith(
                    (".html", ".htm", ".php", ".asp", ".aspx", ".jsp", ".do", ".action")):
                continue
            for name in dicts.COMMON_PARAMS[:2]:
                if len(out) >= limit:
                    break
                out.append(urlunparse((p.scheme, p.netloc, p.path, p.params,
                                       urlencode({name: "bt"}), "")))
        return out

    @staticmethod
    def _dedup_urls(urls):
        out, seen = [], set()
        for u in urls:
            u = (u or "").split("#")[0]
            if u and u not in seen:
                seen.add(u)
                out.append(u)
        return out

    # ------------------------------------------------------------
    # 目标级
    # ------------------------------------------------------------
    def _load_mcp_tools(self):
        """按配置拉起 MCP server 并注册其工具（幂等，失败静默）。

        只有 ``takeover.mcp.enabled`` 为真时才动作；任何异常都吞掉，
        绝不影响扫描主流程。注册进 tool_registry 的工具同样走四道校验。
        """
        if self._mcp_loaded:
            return
        self._mcp_loaded = True
        try:
            from tools import mcp_client, tool_registry
            clients, names = mcp_client.load_from_config(self.config,
                                                         tool_registry)
            self._mcp_clients = list(clients or [])
            if names:
                log.info("已接入 MCP 工具 %d 个：%s", len(names),
                         ",".join(names[:6]))
        except Exception as e:
            log.debug("MCP 接入跳过：%s", e)
        # round84 S 组：SKILL 包里的脚本也注册成可调用工具。
        # 与 MCP 并列：同样幂等、同样静默，不影响扫描主流程。
        try:
            from tools import skill_exec, tool_registry as _tr2
            _snames = skill_exec.load_from_config(self.config, _tr2)
            if _snames:
                log.info("已接入 SKILL 可执行工具 %d 个：%s",
                         len(_snames), ",".join(_snames[:6]))
        except Exception as e:
            log.debug("SKILL 可执行工具接入跳过：%s", e)

    def scan_target(self, target):
        """target 可以是域名、IP、或带 scheme 的 URL。"""
        target = (target or "").strip()
        if not target:
            return {"target": target, "hosts": [], "error": "空目标"}

        host = _norm_target(target)
        # 授权状态自动分辨：在 scope.check/authorize 之前先定格，
        # 记录目标来源（白名单命中 / 用户填入默认视为已授权）。
        _tkey = target.strip()
        if _tkey in self._auth_levels:
            # run() 已在 authorize() 之前定格过：必须沿用，不得重新判定。
            _lvl, _lre, _lrule = self._auth_levels[_tkey]
        else:
            try:
                _lvl, _lre, _lrule = self.scope.classify(_norm_host(host))
            except Exception:
                _lvl, _lre, _lrule = AUTH_AUTHORIZED, "未判定", ""
            self._auth_levels[_tkey] = (_lvl, _lre, _lrule)
        ok, reason = self.scope.check(_norm_host(host), purpose="engine:target")
        if not ok:
            raise ScopeError("目标 %s 不在授权范围：%s（请在界面/命令行直接填写该目标，"
                             "或加入 config/scope.yaml 的 in_scope）"
                             % (target, reason))

        t0 = time.time()
        # 多目标复用同一 Engine 时清空上一轮的 token 汇总，避免跨目标污染。
        try:
            self._token_map = {}
        except Exception:
            pass
        logger.audit("scan_start", target=target, host=host,
                     intensity=self.intensity, mode=self.mode,
                     auth_level=_lvl, auth_reason=_lre)
        log.info("=" * 62)
        log.info("开始扫描：%s（强度=%s｜授权状态=%s：%s）",
                 target, self.intensity, AUTH_CN.get(_lvl, _lvl), _lre)
        # 硬约定：所有目标使用同一份强度，不允许按授权状态降档。
        _pa, _pp = self.auth_scan_profile(_lvl)
        if (_pa, _pp) != (bool(self.enable_active), bool(self.enable_poc)):
            log.error("[强度不一致] 授权状态 %s 试图改变强度（active=%s poc=%s），已拒绝",
                      _lvl, _pa, _pp)
            _pa, _pp = bool(self.enable_active), bool(self.enable_poc)
        log.info("本次生效强度：主动检测=%s｜PoC 复现=%s（所有目标同档）",
                 _pa, _pp)
        # round83 B5：三个强度开关逐项显示。用户反馈「感觉工具受损，
        # 主动检测 / PoC 复现 / 弱口令到底还用不用得了」——只打一个合并字段看不出来，
        # 必须逐项列开。
        log.info("强度明细：主动检测(超出 GET 的深度检测)=%s｜PoC 复现=%s｜弱口令探测=%s",
                 "开" if self.enable_active else "关",
                 "开" if self.enable_poc else "关",
                 "开" if getattr(self, "weak_password", False) else "关")
        if not (self.enable_active or self.enable_poc):
            log.warning("三个强度开关全关：本轮只跑基础派生（敏感路径/目录/组件），"
                         "不会发漏洞检测请求——这不是程序坏了。")

        # 1) 子域枚举（仅对域名）
        hosts = [host]
        if re.match(r"^[a-z0-9.\-]+\.[a-z]{2,}$", _norm_host(host)) and not re.match(r"^[\d.]+$", _norm_host(host)):
            try:
                subs = recon.enumerate_subdomains(_norm_host(host), self.client,
                                                  db=self.db, config=self.config)
                if subs:
                    hosts = subs
            except Exception as e:
                log.warning("子域枚举异常 %s: %s", host, e)

        # 由用户显式填写的目标派生出的主机（含枚举到的子域）一并视为已授权；
        # out_of_scope 排除规则仍然优先，命中的主机直接剔除。
        kept = []
        for h in hosts:
            if self.scope.authorize(h):
                kept.append(h)
            else:
                log.warning("[跳过] %s（命中 out_of_scope 排除规则）", h)
        hosts = kept
        if not hosts:
            return {"target": target, "hosts": [], "error": "目标被 out_of_scope 排除规则拦截"}
        log.info("待探测主机：%d 个", len(hosts))
        # round87 A2: many sibling subdomains x full 7 stages is the real
        # cause of the +505s-per-host hang. Once the host count passes
        # scan.sub_lite_after, mark the run as lite so stages trim their
        # word lists instead of repeating the full pass on every sibling.
        _lite_after = int(self.config.get("scan.sub_lite_after", 3) or 3)
        # round87e: per-host stage budget is spread across this count.
        self._n_hosts = len(hosts)
        self._lite_run = len(hosts) > _lite_after
        if self._lite_run:
            log.warning("[%s] 子域 %d 个（超过 %d），转精简模式："
                        "后续主机词表降级，优先覆盖率", host, len(hosts), _lite_after)
        # round81 B4/B5: state what happens next and roughly how long.
        log.info("[队列] 本机进入扫描阶段：%d 台主机 × 每台上限 %d 请求"
                 "（并发 %d；单台走 7 个阶段，慢属正常，不是卡死）",
                 len(hosts), self.max_per_host, self.concurrency)
        self._hb_t = time.time()
        # round81 B5b: per-run hook. Engine may be reused across
        # run() calls; without this the i/N line would count
        # against the previous run's host list.
        self._host_prog = None
        if len(hosts) > 1:
            _seen = set()

            def _host_prog(h, note=""):
                _seen.add(h)
                log.info("[并发] 主机完成 %d/%d：%s %s",
                         len(_seen), len(hosts), h, note)

            self._host_prog = _host_prog

        try:
            from tools import agent_loop as _agent_loop
            _tk_on = bool(_agent_loop.takeover_conf(self).get("enabled"))
            try:
                from tools import capability as _cap
                _cl = _cap.list_capabilities(self)
                _why = _cl.get("mcp_reason") or ""
                _slines = _cap.summary_lines(self)
                _ailog.info("===== 能力清单 =====")
                for _ln in _slines[1:]:
                    _ailog.info("  %s", _ln)
                log.info("      能力清单：SKILL %d 个｜MCP 服务 %d 个｜MCP 工具 %d 个%s",
                         len(_cl["skills"]), len(_cl["mcp_servers"]),
                         len(_cl["mcp_tools"]),
                         ("（MCP 未生效：%s）" % _why) if _why else "")
                if _tk_on:
                    _ailog.info("      · AI 接管已启用：模型可见工具 %d 个",
                                len(_cl["mcp_tools"]))
                else:
                    _ailog.info("      · AI 接管未启用（takeover.enabled=false）："
                                "上面列出的能力本轮不会调用模型")
            except Exception as _ce:
                log.debug("能力清单读取跳过：%s", _ce)
            if _tk_on:
                self._load_mcp_tools()
                # round73 P0 · 难例回流：把 hunt_queue.jsonl 里“有参数但五类检测零命中”
                # 的接口读一次交给 AI 重扫：只读、不改规则主流程，异常静默。
                # 非法/空值下两个参数为空，run_agent 行为与 round72 逐字一致。
                _hunt_sys = _hunt_usr = ""
                try:
                    from tools import hunt_consumer as _hunt
                    _hunt_sys, _hunt_usr = _hunt.build_notes(self, target)
                    if _hunt_usr:
                        log.info("[难例回流] 本轮 AI 额外重扫 %d 条零命中接口",
                                 len(_hunt.LAST_PICKED))
                except Exception as _he:
                    log.debug("难例回流读取跳过：%s", _he)
                _n_out = 0
                _ai_findings = _agent_loop.run_agent(
                    self, target, hunt_system=_hunt_sys, hunt_user=_hunt_usr)
                for _af in _ai_findings or []:
                    if isinstance(_af, dict):
                        # FIX-31 作用域门禁（最后一道）：
                        # AI 可能挑中目标外地址（幻觉或上下文残留），
                        # 命中后直接落库会把假洞写进客户报告。
                        _auf = str(_af.get("url") or _af.get("target") or "")
                        if not _in_scope_for_persist(_auf, target):
                            _n_out += 1
                            continue
                        try:
                            self._persist(_af, target)
                        except Exception as _e2:
                            log.debug("AI 漏洞项落库跳过：%s", _e2)
                if _n_out:
                    log.warning("[AI 接管] 丢弃 %d 条目标外漏洞项（不属于 %s）",
                                _n_out, target)
        except Exception as _e1:
            log.debug("AI 接管跳过：%s", _e1)

        # 2) 并发探测
        results = []
        if self.concurrency > 1 and len(hosts) > 1:
            with ThreadPoolExecutor(max_workers=self.concurrency) as ex:
                futs = {ex.submit(self.scan_host, h, target): h for h in hosts}
                _qt = time.time()
                try:
                    for fu in as_completed(futs, timeout=self._fut_timeout()):
                        try:
                            results.append(fu.result())
                        except Exception as e:
                            results.append({"host": futs[fu], "error": str(e)})
                        # round81 B6: report each finished host, plus a
                        # 'still running N/M' line every 30s.
                        if self._hb():
                            log.info("[并发] 主机扫描进行中：%d/%d 已完成"
                                     "（累计 %.0fs，未卡死）",
                                     len(results), len(hosts), time.time() - _qt)
                except FuturesTimeout:
                    self._log_pending_futures(futs, "并发")
                    got = set(r.get("host") for r in results)
                    for h in hosts:
                        if h not in got:
                            results.append({"host": h, "error": "timeout"})
                    log.warning("[并发] 主机扫描等待超时（%.0fs），%d 台未完成",
                                self._fut_timeout(),
                                len([h for h in hosts if h not in got]))
        else:
            for h in hosts:
                results.append(self.scan_host(h, target))

        alive = [r for r in results if r.get("alive")]
        # r88: 存活计数回填。并发超时那条路径会把未完成主机记成 {"error":"timeout"}，
        # 里面没有 alive 字段，于是「存活 0/392」却同时报出几十条漏洞，自相矛盾。
        # 这里用落库到该主机的资产记录把 alive 补回来：只要 DB 里有该 host 的
        # status>0 资产，就说明这台其实活着（探测确实成功过）。
        if results and not alive:
            _backfill = 0
            for _r in results:
                if _r.get("alive"):
                    continue
                _h = _r.get("host") or ""
                if not _h:
                    continue
                try:
                    _a = self.db.assets_of_host(_h) or []
                except Exception:
                    _a = []
                _live = [x for x in _a if int(x.get("status") or 0) > 0]
                if not _live:
                    continue
                _r["alive"] = True
                _r["alive_backfilled"] = True
                if not _r.get("url"):
                    _r["url"] = str(_live[0].get("url") or "")
                _r.pop("error", None)
                _backfill += 1
            if _backfill:
                alive = [r for r in results if r.get("alive")]
                log.info("[存活回填] 并发超时导致 %d 台主机被误记为未存活，已按落库资产纠正（存活 %d/%d）",
                         _backfill, len(alive), len(results))
        base_url_of_first = ""
        for _r in alive:
            if _r.get("url"):
                base_url_of_first = _r["url"]
                break
        # 可达性诊断：把探测失败且原因就是连不上的主机单列出来。
        # 这类结果过去与探测了但没漏洞混在一起，用户看到 0 存活会误判
        # 程序坏了；现在显式区分，日志 / CLI / 报告三处都会提示。
        unreachable = [r for r in results
                       if (not r.get("alive"))
                       and str(r.get("error", "")).startswith("unreachable")]
        # 失败明细：每台不可达主机的 原因 code / 中文原因 / 建议 / 解析 IP / TCP 结论。
        # 写进 summary 与 last_scan 后，报告与 CLI/GUI 直接消费结构化字段，
        # 不必再去解析错误字符串。
        unreach_detail = [r.get("unreachable") for r in unreachable
                          if isinstance(r.get("unreachable"), dict)]
        unreach_by_reason = netdiag.summarize(unreach_detail)
        # 未知失败样本落盘（阶段 1-2）：归因落在 unknown 的主机说明是"程序还没见过
        # 的失败模式"，原样写进 data/unknowns.jsonl，交给离线学习器归纳新规则。
        # 只写文件、不做判定，且去重（同 host+code+err 只落一次），不影响扫描结果。
        try:
            _n_unknown = unknowns.record_many(unreach_detail, target=target)
            if _n_unknown:
                log.info("[未知失败] 新增 %d 条样本 -> %s", _n_unknown,
                         os.path.basename(unknowns.UNKNOWNS_PATH))
        except Exception as e:
            log.debug("unknowns 落盘跳过：%s", e)
        # 4.9) token 跨主机复用汇总（round71c 遗留③-3）
        # 单主机侧只证明「同一凭据在多个端点上复用」；这里再看它是否**跨主机**
        # 也一致——一致即服务端全局静态下发，泄露面从单站扩大到整个资产组。
        # 只读、无额外请求（复用 3.9 已抓到的响应），异常静默不影响主流程。
        try:
            if self.config.get("scan.token_reuse_probe", True) and self._token_map:
                for _tv, _hosts in list(self._token_map.items()):
                    if len(_hosts) < 2:
                        continue
                    _tgt = base_url_of_first or target
                    _f = vulnchecks.token_reuse_findings(
                        _tgt, {_tv: sorted(_hosts.keys())},
                        scope_word="主机", min_hits=2)
                    for _ff in _f:
                        self._persist(_ff, target, verified=False)
        except Exception as e:
            log.debug("token 跨主机汇总跳过：%s", e)
        # 难例样本落盘（阶段 5-1）：归因落在"有可测参数、五类检测全不命中"的接口，
        # 说明是现有规则覆盖不到的盲区，原样写进 data/hunt_queue.jsonl 交给离线
        # AI 旁路分析器（tools/hunt_assist.py）。只写文件、不做判定，且去重
        # （同 url+method+param+kind 只落一次），不影响扫描结果。
        # 取走即清空，避免同一 Engine 复用扫多目标时重复落盘。
        try:
            with self._hunt_lock:
                _hunt_batch = self._hunt_samples
                self._hunt_samples = []
            _n_hunt = hunt_queue.record_many(_hunt_batch, target=target)
            if _n_hunt:
                log.info("[难例] 新增 %d 条样本 -> %s", _n_hunt,
                         os.path.basename(hunt_queue.HUNT_PATH))
        except Exception as e:
            log.debug("hunt_queue 落盘跳过：%s", e)
        # 自愈汇总：把每台不可达主机的 next_steps 归并成 动作 -> 台数，
        # 让用户/报告一眼看到"这次失败程序打算怎么自救"。
        # 只统计不执行 —— 执行与否仍受 scan.max_requests_per_host 约束。
        unreach_actions = {}
        unreach_stop = 0
        unreach_cost = 0
        for _d in unreach_detail:
            if _d.get("stop"):
                unreach_stop += 1
            try:
                unreach_cost += int(_d.get("request_cost") or 0)
            except Exception:
                pass
            for _a in (_d.get("next_steps") or []):
                unreach_actions[_a] = unreach_actions.get(_a, 0) + 1
        elapsed = round(time.time() - t0, 2)
        # r88 缺陷 #6：stats 口径。原实现 self.db.stats(target) 是**该目标历史
        # 全量**统计，与「本轮」完全脱钩：实测复扫本轮只落 1 条，日志却打
        # 「漏洞 23 条」（= 23 条历史行）。修好检测规则后这个数字不会下降，
        # 用户永远无法用「条数变少了」来验收。
        # 现改为：有本轮 fid 就按本轮 id 统计，没有（未落任何库）则为 0。
        # db.stats 仍保留给「手动 report 看历史全量」的入口。
        _run_ids = self._fids_of(target)
        _run_rows = self.db.findings_by_ids(_run_ids) if _run_ids else []
        stats = {"total": len(_run_rows)}
        for _r in _run_rows:
            _sv = _r.get("severity") or "info"
            stats[_sv] = stats.get(_sv, 0) + 1
        # 本轮真正落库/复现的数量（供 CLI/GUI 直接读，不必从 stats 里猜）。
        n_findings = len(_run_rows)
        n_confirmed = sum(int(r.get("confirmed", 0) or 0) for r in results)
        # 授权状态随 summary 一起返回：三入口（CLI/GUI/Web）只读不改，
        # 与扫描强度完全解耦（强度真值仍只认 enable_active/enable_poc）。
        _sum_lvl, _sum_re, _sum_rule = self._auth_levels.get(
            str(target).strip(), (AUTH_AUTHORIZED, "未判定", ""))
        summary = {
            "target": target, "host": host, "hosts": len(hosts),
            "alive": len(alive), "elapsed": elapsed,
            "auth_level": _sum_lvl,
            "auth_cn": AUTH_CN.get(_sum_lvl, _sum_lvl),
            "auth_reason": _sum_re,
            "scan_active": bool(self.enable_active),
            "scan_poc": bool(self.enable_poc),
            "unreachable": len(unreachable),
            "unreachable_detail": unreach_detail,
            "unreachable_by_reason": unreach_by_reason,
            "unreachable_actions": unreach_actions,
            "unreachable_stop": unreach_stop,
            "unreachable_request_cost": unreach_cost,
            "requests": self.client.count(), "stats": stats,
            "findings": n_findings, "confirmed": n_confirmed,
            # PENDING-1：AI 日志导出的时间窗锚点（epoch 秒）。
            # 起点必须是扫描真正开始的时刻，而不是报告目录建立时刻——
            # 报告在扫描之后才生成，用后者当起点会把整轮 AI 输出全切掉。
            "started_at": round(t0, 3),
            "ended_at": round(t0 + elapsed, 3),
            "results": results,
        }
        self.db.set_progress("last_scan", {"target": target, "at": time.time(),
                                           "stats": stats,
                                           "hosts": len(hosts), "alive": len(alive),
                                           "unreachable": len(unreachable),
                                           "unreachable_detail": unreach_detail,
                                           "unreachable_by_reason": unreach_by_reason,
                                           "unreachable_actions": unreach_actions,
                                           "unreachable_stop": unreach_stop,
                                           "unreachable_request_cost": unreach_cost})
        logger.audit("scan_done", target=target, hosts=len(hosts), alive=len(alive),
                     unreachable=len(unreachable),
                     requests=self.client.count(), elapsed=elapsed,
                     findings=stats.get("total", 0))
        log.info("扫描完成：%d 存活 / %d 主机，漏洞 %d 条，用时 %.1fs",
                 len(alive), len(hosts), stats.get("total", 0), elapsed)
        return summary

    # ------------------------------------------------------------
    # 报告
    # ------------------------------------------------------------
    def make_report(self, target, formats=None, out_dir=None, scan_summary=None,
                    only_run=False):
        meta = {"program": self.scope.program or target,
                "author": self.config.get("report.author", ""),
                "src_platform": self.config.get("report.src_platform", "butian"),
                "cvss_version": self.config.get("report.cvss_version", "4.0"),
                # 强度取引擎真值（源自 scan.mode），不再读 scope.yaml 的
                # intensity 字段——后者与 mode 无关联，会造成报告撒谎。
                "intensity": self.intensity}
        # 授权状态标注（不改变强度，只说明目标来源）。
        _al = self._auth_levels.get(str(target).strip())
        if _al:
            meta["auth_level"] = _al[0]
            meta["auth_cn"] = AUTH_CN.get(_al[0], _al[0])
            meta["auth_reason"] = _al[1]
            meta["auth_rule"] = _al[2]
        # 强度一致性声明：本次实际生效的开关，所有目标同档。
        meta["scan_active"] = bool(self.enable_active)
        meta["scan_poc"] = bool(self.enable_poc)
        # 可达性明细：优先用「本次扫描」的内存结果，而不是 DB 里的 last_scan。
        # last_scan 只存一条记录，多目标连扫时会被最后一个目标覆盖，导致
        # 前面目标的报告拿不到明细（表现为报告空漏洞但不提"目标不可达"）。
        # scan_summary 就是 scan_target 的返回值，天然按目标隔离。
        if isinstance(scan_summary, dict):
            _n = int(scan_summary.get("unreachable") or 0)
            meta["unreachable_count"] = _n
            if _n:
                if isinstance(scan_summary.get("unreachable_detail"), list):
                    meta["unreachable_detail"] = scan_summary["unreachable_detail"]
                if isinstance(scan_summary.get("unreachable_by_reason"), dict):
                    meta["unreachable_by_reason"] = scan_summary["unreachable_by_reason"]
                # 自愈计划同样按目标隔离地从本次扫描结果带出，
                # 避免多目标连扫时被 last_scan 的最后一台覆盖。
                if isinstance(scan_summary.get("unreachable_actions"), dict):
                    meta["unreachable_actions"] = scan_summary["unreachable_actions"]
                meta["unreachable_stop"] = int(scan_summary.get("unreachable_stop") or 0)
                meta["unreachable_request_cost"] = int(
                    scan_summary.get("unreachable_request_cost") or 0)
            # PENDING-1：扫描起止时间（epoch）无条件透传，供 report.export_ai_log
            # 切出「本次扫描期间」的 AI 行。不放在上面的 `if _n:`（不可达分支）里
            # ——能不能导出日志跟目标通不通没有关系。
            for _k in ("started_at", "ended_at"):
                if scan_summary.get(_k):
                    meta["scan_" + _k] = scan_summary.get(_k)
        # r88 缺陷 #6：only_run=True 时只输出「本轮 scan 落库/升级」的行，
        # 不把该目标历史 finding 拉进新报告。拿不到本轮 id（例如直接调
        # make_report 出历史报告）则退回全量，保持 report 命令原语义。
        _fids = self._fids_of(target) if only_run else None
        if only_run and not _fids:
            # 本轮一条都没落库：给空列表（而不是 None → 拉全历史），
            # 否则“修好规则后 0 条”会被历史误报改写成“还有 N 条”。
            _fids = []
        return report_mod.generate(
            target, db=self.db, config=self.config, meta=meta, formats=formats,
            out_dir=out_dir, finding_ids=_fids)

    # ------------------------------------------------------------
    # 核验
    # ------------------------------------------------------------
    def verify(self, target, limit=None, max_requests=None, out_dir=None):
        """对某目标已落库的漏洞做真实性核验，回写 DB 并产出独立核验报告。

        核验走独立证据通道（core/verify.py），不重跑检测逻辑：
        按漏洞类型分别用时间盲注延迟线性、报错三段因果、XSS 可执行上下文、
        重定向双域对照、备份文件魔数、密钥格式自校验等判据，给出
        confirmed / refuted / inconclusive 三档结论。

        返回 dict：{target, results, total, confirmed, refuted,
                   inconclusive, false_positive_rate, report}
        """
        if max_requests is None:
            max_requests = int(self.config.get("verify.max_requests", 400) or 400)
        # r88 缺陷 #6 联动：run() 的自动核验只核「本轮」落库的 finding。
        # 判据是本轮 fid 列表非空——非空说明本次 scan 确实落了库，
        # 那就只核这些；空则退回全量（手动 verify 命令的场景，用户要核历史）。
        _fids = self._fids_of(target)
        results = verify_mod.verify_target(
            self.db, target, self.client, config=self.config,
            limit=limit, max_requests=max_requests,
            only_ids=_fids if _fids else None)
        # round89 新增：**AI 分层复核**。
        # 规则引擎能定论的（confirmed / refuted）AI 不碰；一次请求都没发的
        # （not_verified）也没什么证据可读；只有真正"核验过但判不出来"的
        # inconclusive 才交 AI 复核。AI 结论写进**新增字段** ai_review，
        # 绝不覆盖 verdict——规则结论是审计基线，AI 只是旁证。
        # AI 未配置/调用失败时 ai_stat 全零,行为与旧版完全一致。
        try:
            results, ai_stat = verify_mod.ai_review_inconclusive(
                results, config=self.config)
        except Exception as e:
            log.warning("AI 复核层异常，已跳过（不影响规则核验结果）：%s", e)
            ai_stat = {"enabled": False, "reviewed": 0}
        # 回写：只给拿到了 AI 结论的条目补写 extra['ai_review']
        if ai_stat.get("reviewed"):
            for _r in results:
                _ai = _r.get("ai_review")
                if not isinstance(_ai, dict) or not _r.get("finding_id"):
                    continue
                try:
                    self.db.set_ai_review(
                        _r["finding_id"], verdict=_ai.get("verdict", ""),
                        reason=_ai.get("reason", ""),
                        confidence=_ai.get("confidence"),
                        model=_ai.get("model", ""))
                except Exception as e:
                    log.warning("AI 复核结果回写失败 fid=%s: %s",
                                _r.get("finding_id"), e)
        # 三档统计 + 误报率（口径与 db.verify_stats 一致：
        # inconclusive 不参与分母，避免把误报率稀释成无意义的好看数字）
        n_cf = sum(1 for r in results if r.get("verdict") == verify_mod.CONFIRMED)
        n_rf = sum(1 for r in results if r.get("verdict") == verify_mod.REFUTED)
        n_uk = sum(1 for r in results if r.get("verdict") == verify_mod.UNKNOWN)
        # round78 ④：「未核验」单列（一次请求都没发），
        # 不混进「无法判定」，也不进误报率分母。
        n_nv = sum(1 for r in results
                   if r.get("verdict") == getattr(verify_mod, "NOT_VERIFIED",
                                                  "not_verified"))
        denom = n_cf + n_rf
        fpr = round(float(n_rf) / denom, 4) if denom else 0.0
        meta = {"program": self.scope.program or target,
                "author": self.config.get("report.author", ""),
                "src_platform": self.config.get("report.src_platform", "butian"),
                "intensity": self.intensity}
        try:
            rep = verify_mod.write_verify_report(target, results, meta=meta,
                                                 out_dir=out_dir,
                                                 ai_stat=ai_stat)
        except Exception as e:
            log.warning("核验报告生成失败 %s: %s", target, e)
            rep = {}
        out = {"target": target, "results": results, "total": len(results),
               "confirmed": n_cf, "refuted": n_rf, "inconclusive": n_uk,
               "not_verified": n_nv, "decidable": denom,
               "false_positive_rate": fpr, "report": rep,
               "ai_review": dict(ai_stat)}
        log.info("核验完成 %s：证实 %d / 证伪 %d / 无法判定 %d / 未核验 %d（误报率 %.1f%%）",
                 target, n_cf, n_rf, n_uk, n_nv, fpr * 100)
        # round89 FIX-2：三种状态必须分开报，不能把「没样本」说成「未启用」。
        #   模型不可用      -> AI 复核未启用（未配置或调用不通）
        #   模型可用·零样本 -> AI 复核就绪，本轮无待复核样本（不改判）
        #   模型可用·有样本 -> 正常统计
        if not ai_stat.get("enabled"):
            log.info("AI 复核未启用（未配置或调用不通），%s 保持纯规则结论", target)
        elif not ai_stat.get("reviewed") and not ai_stat.get("failed"):
            log.info("AI 复核就绪（模型 %s）：%s 本轮无 inconclusive 样本，"
                     "无需复核，规则结论不变",
                     ai_stat.get("model", "") or "-", target)
        else:
            log.info("AI 复核 %s：复核 %d 条（倾向真实 %d / 倾向误报 %d / 也不准 %d），"
                     "跳过 %d，失败 %d，模型 %s",
                     target, ai_stat.get("reviewed", 0),
                     ai_stat.get("likely_true", 0),
                     ai_stat.get("likely_false", 0),
                     ai_stat.get("uncertain", 0), ai_stat.get("skipped", 0),
                     ai_stat.get("failed", 0), ai_stat.get("model", ""))
        return out


    # ------------------------------------------------------------
    # 总入口
    # ------------------------------------------------------------
    def run(self, targets=None, report=True, verify=False, formats=None):
        """targets 为空时取 scope.in_scope（去掉通配符项）。

        显式传入的 targets 视为已授权：逐个并入 scope（仍受 out_of_scope 排除规则
        约束），这样在界面 / 命令行里填的目标无需每次手改 config/scope.yaml。
        """
        targets = list(targets or [])
        explicit = bool(targets)
        if not targets:
            for t in self.scope.in_scope:
                t = str(t).strip()
                if t and "*" not in t and "?" not in t:
                    targets.append(t)
        if not targets:
            raise ScopeError("没有可用目标：请在界面填写授权目标，"
                             "或在 config/scope.yaml 的 in_scope 里填写授权域名。")

        if explicit:
            # 先一次性定格所有显式目标的授权状态，避免"先 authorize 后
            # 判定"把后一个同名目标误标（authorize 会写 in_scope）。
            for t in targets:
                _ts = str(t).strip()
                if not _ts:
                    continue
                try:
                    self._auth_levels[_ts] = self.scope.classify(
                        _norm_host(_norm_target(_ts)))
                except Exception:
                    self._auth_levels[_ts] = (AUTH_AUTHORIZED, "未判定", "")
            allowed = []
            for t in targets:
                if self.scope.authorize(t):
                    allowed.append(t)
                else:
                    log.error("目标 %s 命中 out_of_scope 排除规则，已跳过。", t)
            if not allowed:
                raise ScopeError("所有目标都命中 out_of_scope 排除规则，无可用目标。")
            targets = allowed

        # 授权状态概览：让用户一眼看到本次各目标命中的授权来源。
        _auth_cnt = {}
        for t in targets:
            _r = self._auth_levels.get(str(t).strip())
            if _r:
                _auth_cnt[_r[0]] = _auth_cnt.get(_r[0], 0) + 1
        if _auth_cnt:
            log.info("授权状态分辨：%s", "，".join(
                "%s %d 个" % (AUTH_CN.get(k, k), v)
                for k, v in sorted(_auth_cnt.items())))
            logger.audit("auth_classify_summary",
                         **{k: v for k, v in _auth_cnt.items()})
        self._session_start(targets)
        summaries = []
        for t in targets:
            if self.wait_if_paused():
                break
            try:
                summaries.append(self.scan_target(t))
            except ScopeError as e:
                log.error("%s", e)
                summaries.append({"target": t, "error": str(e)})
            self._session_mark(t)
        out = {"summaries": summaries, "requests": self.client.count()}
        # 需求 2：核验报告与扫描报告放同一目录。
        # 先为每个目标预建一次报告目录，核验(out_dir=该目录)与主报告共用它；
        # 目录名仍由 new_report_dir 生成（含时间戳/pid/序号，不会撞名）。
        _dirs = {}
        if verify or report:
            for t in targets:
                try:
                    _dirs[t] = report_mod.new_report_dir(t, want_evidence=True)
                except Exception as e:
                    log.warning("报告目录预建失败 %s: %s", t, e)
        # round89 FIX-10：这里原有一段「提前算 ai_ok 为核验日志装饰」的代码，
        # 直接调 self.config.ai_ready()，而 run() 是扫描热路径，违反
        # lab/verify_round38 H1 红线①（AI 永不进扫描热路径）。且它本来就冗余：
        # FIX-2c 已在每个目标核验完后打「未启用 / 就绪零样本 / 有样本」
        # 三态文案，比这里的二分预判更准。所以直接删掉预判，
        # 日志只保留「核验开始」事实，AI 结论交给每目标那行。
        # 自动核验：在生成主报告之前先跑核验，把已证伪项从主报告剔除。
        # 顺序很重要——generate() 会读 extra["verify_verdict"] 过滤，
        # 若先出报告再核验，本次报告仍会带上误报。
        if verify:
            ver = []
            log.info("=" * 62)
            log.info("开始核验：%d 个目标（独立证据通道，不重跑检测；"
                     "AI 分层复核状态逐目标否面见下）",
                     len(targets))
            for _vi, t in enumerate(targets, 1):
                if self.wait_if_paused():
                    break
                log.info("核验进度 %d/%d：%s", _vi, len(targets), t)
                try:
                    ver.append(self.verify(t, out_dir=_dirs.get(t)))
                except Exception as e:
                    log.warning("核验失败 %s: %s", t, e)
                    ver.append({"target": t, "error": str(e)})
            out["verifications"] = ver
        if report:
            paths = []
            _sum_by_target = {}
            for s in summaries:
                if isinstance(s, dict) and s.get("target"):
                    _sum_by_target[s.get("target")] = s
            for t in targets:
                try:
                    paths.append(self.make_report(
                        t, formats=formats, out_dir=_dirs.get(t),
                        scan_summary=_sum_by_target.get(t), only_run=True))
                except Exception as e:
                    log.warning("报告生成失败 %s: %s", t, e)
            out["reports"] = paths
        # 全部 target 跑完 -> 清会话档（"完成的不用"）。
        # 注意：只有真跑到底才清；中途 break（暂停/停止）会走到 stop()
        # 或前端软停，那时保留 paused 档供下次续跑。
        if not self._stop and not self._pause.is_set():
            self._session_finish()
        return out

    # ---------- 扫描会话存档（round73 起"暂停"只停线程，round75 补齐"存档"） ----------
    # 分工：任务层进度（还剩哪些目标没跑）走 db.progress 的 scan_session 键，
    # URL 层进度（已扫 URL 不重扫）继续由 scanned 表承担。两者都落 data/，都不进发布包。
    # 这里刻意用"只写不读"的风格：写盘失败绝不影响扫描，最多丢一次续跑机会。
    def _session_start(self, targets):
        try:
            self._sess_targets = [str(t) for t in (targets or [])]
            self._sess_done = []
            self._sess_started = time.time()
            self._sess_last = ""
            self._sess_saved_at = time.time()
            self.db.save_session({
                "targets": list(self._sess_targets),
                "done": [], "status": "running",
                "started_at": time.time(), "updated_at": time.time(),
                "last": "",
            })
        except Exception:
            pass

    def _session_mark(self, target):
        """某个目标跑完 -> 追加 done 并落盘。

        run() 在**每个目标收尾后**调用（含异常分支），所以中途关窗时
        已完成的都记着，下次只续跑剩下的；全部跑完由 _session_finish 清档。
        """
        try:
            if self._stop:
                # 已请求停止：后面的目标只是被"跳过"，不能记成"已完成"，
                # 否则停止一回就把剩余目标从续跑清单里抹掉了
                # （stop 后 scan_target 立刻返回，循环会把它们逐个走一遍）。
                return False
            self._sess_done.append(str(target))
            self.db.save_session({
                "targets": [str(t) for t in (self._sess_targets or [])],
                "done": list(self._sess_done), "status": "running",
                "started_at": self._sess_started,
                "updated_at": time.time(), "last": str(target),
            })
        except Exception:
            pass

    def _session_pause(self, status="paused"):
        """把当前进度立刻落到盘上（关窗/停止/被信号打断时调用）。

        必须在 wait_idle() 之前调用：进程可能马上被冻结，先写盘再等停稳。
        """
        try:
            if self._sess_done is None:
                return False
            self.db.save_session({
                "targets": [str(t) for t in (self._sess_targets or [])],
                "done": list(self._sess_done), "status": str(status or "paused"),
                "started_at": self._sess_started,
                "updated_at": time.time(), "last": str(self._sess_last or ""),
            })
            self._sess_saved_at = time.time()
            return True
        except Exception:
            return False

    def _session_finish(self):
        """全部目标跑完 -> 清档。已完成的任务不该在下次开窗时被提示续跑。"""
        try:
            self._sess_done = None
            self.db.save_session(None)
            return True
        except Exception:
            return False

    @staticmethod
    def session_pending(sess):
        """从会话快照算出"还没跑的目标"（顺序保持原样）。纯函数，零依赖。"""
        if not isinstance(sess, dict):
            return []
        tg = [str(t) for t in (sess.get("targets") or [])]
        dn = set(str(t) for t in (sess.get("done") or []))
        return [t for t in tg if t not in dn]

    def stop(self):
        self._stop = True
        self._session_pause("stopped")

    def pause(self):
        """请求暂停：立即置位，扫描线程在下一个检查点挂起。非阻塞、幂等。"""
        self._pause.set()
        log.info("[暂停] 已收到暂停请求，将在当前批次收尾后停下")

    def unpause(self):
        """解除暂停：闸门放开，扫描线程从检查点继续。（不叫 resume：self.resume 是断点续扫开关，会遮蔽同名方法）"""
        self._pause.clear()
        log.info("[继续] 已恢复扫描")

    @property
    def paused(self):
        return self._pause.is_set()

    def wait_if_paused(self):
        """暂停闸门检查点：返回 True = 调用方应收尾退出（已停机）。

        未暂停时只做一次 Event.is_set()，无锁、无 I/O，对原性能零影响。
        暂停时在此原地等待，直到 resume() 或 stop()；因此在检查点之间的
        "当前批次/当前小循环"一定会跑完，不会有半截状态留在库里。
        """
        if self._stop:
            return True
        if self._pause.is_set():
            log.info("[暂停] 扫描已挂在检查点，等待继续…")
            while self._pause.is_set():
                if self._stop:
                    return True
                time.sleep(0.2)
                # round75：暂停期间每 2s 兜底落盘一次，窗口被强杀时磁盘上
                # 永远是最新快照，不会退回"上一个目标跑完"的旧档。
                if time.time() - self._sess_saved_at >= 2.0:
                    self._session_pause("paused")
            log.info("[继续] 已从检查点恢复")
        self._beat += 1
        return self._stop

    def wait_idle(self, timeout=5.0):
        """等待引擎停在暂停检查点（以心跳 _beat 连续不再增长为准）。

        用途：关窗时先 pause() 再 wait_idle()，确认扫描真的停稳在安全点
        （而不是停在某个请求中间），再销毁窗口。_beat 由多个工作线程并发
        自增，非原子，但这里只做"是否还在动"的活性判据，精度足够。
        """
        if not self._pause.is_set():
            return False
        deadline = time.time() + float(timeout or 5.0)
        last = self._beat
        while time.time() < deadline:
            time.sleep(0.5)
            if self._beat == last:
                return True
            last = self._beat
        return False

    def close(self):
        """释放会话级资源：HTTP 连接池 + 自建 DB 连接。

        HttpClient 现在按线程各建一个 requests.Session（见 httpclient
        的线程本地 Session），不显式关闭的话这些连接池会一直挂到进程
        退出——命令行长跑 / GUI 反复点扫描时句柄会持续累积。
        原实现里 HttpClient.close() 是个没有任何调用者的死方法，
        所以资源从来没人回收，这里由 Engine 统一收口。
        幂等：重复调用安全。
        """
        try:
            self.client.close()
        except Exception as e:
            log.warning("关闭 HTTP 客户端失败：%s", e)
        if getattr(self, "_own_db", False):
            try:
                self.db.close()
            except Exception as e:
                log.warning("关闭数据库连接失败：%s", e)
        # round59：MCP 子进程随引擎统一收口（未启用时是空列表，零影响）。
        for _c in list(getattr(self, "_mcp_clients", []) or []):
            try:
                _c.close()
            except Exception:
                pass
        self._mcp_clients = []
