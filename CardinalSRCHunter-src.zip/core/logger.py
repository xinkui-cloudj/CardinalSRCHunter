# -*- coding: utf-8 -*-
"""日志：控制台 + 轮转文件 + JSONL 审计日志。

审计日志记录每一次出网请求（含被 scope 拦截的），用于事后自证合规。
"""
import datetime
import json
import logging
import os
import threading
from logging.handlers import RotatingFileHandler

from . import config as cfg

_audit_lock = threading.Lock()
_audit_path = None

LEVEL_COLORS = {
    "DEBUG": "\033[36m", "INFO": "\033[32m", "WARNING": "\033[33m",
    "ERROR": "\033[31m", "CRITICAL": "\033[41m", "RESET": "\033[0m",
}


class _ColorFormatter(logging.Formatter):
    def format(self, record):
        msg = super(_ColorFormatter, self).format(record)
        color = LEVEL_COLORS.get(record.levelname, "")
        if color and os.name != "nt":
            return "%s%s%s" % (color, msg, LEVEL_COLORS["RESET"])
        return msg


def init(verbose=False, log_dir=None):
    cfg.ensure_dirs()
    log_dir = log_dir or cfg.LOG_DIR
    os.makedirs(log_dir, exist_ok=True)

    global _audit_path
    _audit_path = os.path.join(log_dir, "audit.jsonl")

    root = logging.getLogger("bt")
    if root.handlers:
        return root
    root.setLevel(logging.DEBUG if verbose else logging.INFO)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG if verbose else logging.INFO)
    ch.setFormatter(_ColorFormatter("[%(asctime)s] %(levelname)-7s %(message)s", "%H:%M:%S"))
    root.addHandler(ch)

    fname = "bt-%s.log" % datetime.datetime.now().strftime("%Y%m%d")
    fh = RotatingFileHandler(os.path.join(log_dir, fname), maxBytes=8 * 1024 * 1024,
                             backupCount=5, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        "[%(asctime)s] %(levelname)-7s [%(threadName)s] %(name)s: %(message)s"))
    root.addHandler(fh)
    return root


def get(name="bt"):
    return logging.getLogger(name)


def audit(event, **fields):
    """写一条审计记录（JSONL，追加安全）。"""
    if _audit_path is None:
        init()
    rec = {"ts": datetime.datetime.now().isoformat(timespec="milliseconds"),
           "event": event}
    rec.update(fields)
    try:
        with _audit_lock:
            with open(_audit_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def banner():
    return r"""
  ____ _______   ____   ____    _   _             _
 | __ )_   _\ \ / /  _ \ / ___|  | | | |_   _ _ __ | |_ ___ _ __
 |  _ \ | |  \ V /| |_) | |      | |_| | | | | '_ \| __/ _ \ '__|
 | |_) || |   | | |  _ <| |___   |  _  | |_| | | | | ||  __/ |
 |____/ |_|   |_| |_| \_\\____|  |_| |_|\__,_|_| |_|\__\___|_|
        补天 / SRC 授权漏洞挖掘套件   v1.0
"""
