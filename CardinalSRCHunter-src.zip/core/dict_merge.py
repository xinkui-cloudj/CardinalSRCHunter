# -*- coding: utf-8 -*-
"""AI 字典的人审并入层（阶段 3-4 / 3-5 的消费侧）。

职责边界（与三条核心红线对齐）：
  · 只读、只合并、不决策 —— 把「人工审核通过的」离线字典产物
    （data/dicts_ai.json / data/hosts_ai.json）与内置字典表合并，
    供扫描热路径取用；命中与否仍由检测层独立判定。
  · 草稿（未审）一律不加载 —— 显式拒稿，而不是依赖「路径恰好不同」。
  · 任何异常静默降级为内置表 —— 文件缺失 / 损坏 / 结构非法时，
    行为与「该文件不存在」逐元素一致。
  · 本模块不做网络 / 随机 / 子进程动作，纯本地只读。

契约（字面一致，改一处必须同步另一处）：
  · DICT_LIVE_NAME / HOSTS_LIVE_NAME —— 与离线生成器侧同名常量一致
  · 草稿后缀复用 core.dicts.DRAFT_SUFFIX（本模块不写字面后缀）
"""
import json
import os

try:
    from core import config as cfg
    from core import dicts
except Exception:  # pragma: no cover - 极早期导入兜底
    cfg = None
    dicts = None

# 与离线生成器同名常量保持一致（改一处必须改两处）。
DICT_LIVE_NAME = "dicts_ai.json"
HOSTS_LIVE_NAME = "hosts_ai.json"

# 并入上限：只限制「额外」部分，内置表永不截断。
MAX_EXTRA_WORDS = 300
MAX_EXTRA_CREDS = 120


def _data_dir():
    try:
        return cfg.DATA_DIR
    except Exception:
        return os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "data")


def live_file(name):
    """正式位路径（人工审核通过后应使用的文件名）。"""
    return os.path.join(_data_dir(), name)


def _read_live(path):
    """读取人审正式件；草稿位 / 缺失 / 非文件 / 损坏 / 顶层非映射 -> None。

    草稿闸门：显式调用 dicts.loadable()，即使调用方把 path 误指到草稿也安全。
    """
    if not path:
        return None
    try:
        if dicts is not None and not dicts.loadable(path):
            return None
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except Exception:
        return None
    return obj if isinstance(obj, dict) else None


def _str_list(obj, key):
    """取对象里某个键的字符串列表（非 list / 含非串项一律丢弃）。"""
    if not isinstance(obj, dict):
        return []
    v = obj.get(key)
    if not isinstance(v, list):
        return []
    out = []
    for it in v:
        if isinstance(it, str) and it.strip():
            out.append(it.strip())
    return out


def _cred_list(obj, key):
    """取对象里某个键的 (user, pass) 二元组列表。"""
    if not isinstance(obj, dict):
        return []
    v = obj.get(key)
    if not isinstance(v, list):
        return []
    out = []
    for it in v:
        if isinstance(it, (list, tuple)) and len(it) == 2:
            u = str(it[0]).strip() if it[0] is not None else ""
            pw = str(it[1]).strip() if it[1] is not None else ""
            if u and pw:
                out.append((u, pw))
    return out


def _merge_str(base, extra, cap):
    """内置词在前、额外词在后，保序去重；额外词最多取 cap 个。
    无额外词时**原样返回内置表副本**（含原有重复项，保证行为逐元素一致）。
    """
    base = [w for w in (base or []) if isinstance(w, str)]
    extra = [w for w in (extra or []) if isinstance(w, str)]
    if not extra:
        return list(base)
    out = list(base)
    seen = set(out)
    n = 0
    for w in extra:
        s = w.strip()
        if not s or s in seen:
            continue
        seen.add(s)
        out.append(s)
        n += 1
        if n >= cap:
            break
    return out


def _merge_creds(base, extra, cap):
    """内置凭据在前、额外凭据在后，保序去重；额外凭据最多取 cap 个。"""
    base = [c for c in (base or [])
            if isinstance(c, (list, tuple)) and len(c) == 2]
    extra = [c for c in (extra or [])
             if isinstance(c, (list, tuple)) and len(c) == 2]
    if not extra:
        return [tuple(c) for c in base]
    out = [tuple(c) for c in base]
    seen = set(out)
    n = 0
    for c in extra:
        u = str(c[0]).strip() if c[0] is not None else ""
        pw = str(c[1]).strip() if c[1] is not None else ""
        if not u or not pw or (u, pw) in seen:
            continue
        seen.add((u, pw))
        out.append((u, pw))
        n += 1
        if n >= cap:
            break
    return out


def _base_words(name):
    try:
        return list(getattr(dicts, name) or [])
    except Exception:
        return []


def merged_subdomain_words(dict_path=None, hosts_path=None):
    """内置子域词 + 人审件子域词 + 人审解析候选词根（保序去重，额外项带上限）。"""
    base = _base_words("SUBDOMAIN_WORDS")
    extra = (_str_list(_read_live(dict_path or live_file(DICT_LIVE_NAME)),
                       "subdomain_words")
             + _str_list(_read_live(hosts_path or live_file(HOSTS_LIVE_NAME)),
                         "variant_words"))
    return _merge_str(base, extra, MAX_EXTRA_WORDS)


def merged_dir_words(dict_path=None):
    """内置目录词 + 人审件目录词（保序去重，额外项带上限）。"""
    base = _base_words("DIR_WORDS")
    extra = _str_list(_read_live(dict_path or live_file(DICT_LIVE_NAME)),
                      "dir_words")
    return _merge_str(base, extra, MAX_EXTRA_WORDS)


def merged_creds(dict_path=None):
    """内置凭据池 + 人审件凭据（(user, pass) 二元组，保序去重，额外项带上限）。"""
    base = _base_words("DEFAULT_CREDS_ALL")
    extra = _cred_list(_read_live(dict_path or live_file(DICT_LIVE_NAME)),
                       "creds")
    return _merge_creds(base, extra, MAX_EXTRA_CREDS)


def status():
    """人审件加载概况（供 CLI / 自检读取，不做任何写操作）。"""
    d = _read_live(live_file(DICT_LIVE_NAME))
    h = _read_live(live_file(HOSTS_LIVE_NAME))
    return {
        "dict_path": live_file(DICT_LIVE_NAME),
        "dict_loaded": isinstance(d, dict),
        "hosts_path": live_file(HOSTS_LIVE_NAME),
        "hosts_loaded": isinstance(h, dict),
        "extra_subdomain_words": len(_str_list(d, "subdomain_words")),
        "extra_dir_words": len(_str_list(d, "dir_words")),
        "extra_creds": len(_cred_list(d, "creds")),
        "extra_variant_words": len(_str_list(h, "variant_words")),
        "max_extra_words": MAX_EXTRA_WORDS,
        "max_extra_creds": MAX_EXTRA_CREDS,
    }
