# -*- coding: utf-8 -*-
"""配置加载与校验。"""
import copy
import json
import os
import shutil
import sys
import time

DEFAULT_CONFIG = {
    "target": {"domains": [], "ips": [], "cidrs": [], "exclude": []},
    "http": {
        "rate_limit": 12.0, "concurrency": 8, "timeout": 12, "retries": 2,
        # 3-3：并发上限可配（默认 8，与 engine 硬钳值一致）。
        # 只允许把上限往低调，engine 仍硬钳在 8 以内，配置项不撒谎。
        "concurrency_max": 8,
        "verify_tls": False, "follow_redirects": True,
        "user_agents": ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/122.0 Safari/537.36"],
        "proxy": "", "headers": {},
    },
    # 强度只由 mode 决定（safe/normal/aggressive，见 MODE_PRESETS）。
    # 不再内置 enable_active / enable_poc：这两项同时存在会让 mode 名存实亡
    # （显式键优先），是"配置项撒谎"的典型。需要精细控制时再手写这两项。
    "scan": {
        "mode": "safe", "max_requests_per_host": 3000,
        # round60：取消 scan.allow_unscoped —— 用户填入的目标一律视为已授权，
        # 不再需要“放行白名单外目标”的开关（该键已从代码与配置中移除）。
        "subdomain_bruteforce": True, "dir_bruteforce": True,
        "param_seed": True,
        "crawl_depth": 2, "resume": True,
        # round87e: `stage_budget_sec` was a flat per-host 120s, so any
        # multi-subdomain run blew it on nearly every host and silently
        # dropped to a 50-word lite pass -- the scan log looked gutted.
        # Now the budget is a run-wide total divided by host count
        # (60s..180s per host). Raise the total for deeper runs.
        "stage_budget_total_sec": 600,
        "stage_budget_sec": 120,
        # sub_lite_* : what "lite mode" actually means now that
        # engine._lite_run is honoured (it used to be computed and
        # never read). sub_lite_words is a mid tier, not a 50-word cut.
        "sub_lite_after": 3,
        "sub_lite_words": 180,
        "lite_words": 50,
        # round57：目标域名 NXDOMAIN 但联想出可解析形态时，自动接管扫描该形态（默认开）。
        "auto_variant": True,
        # 弱口令检测：默认关闭（可能触发账号锁定，且属主动凭据尝试）。
        # 开启后受三重限制：候选登录入口上限 max_targets、
        # 单入口凭据尝试上限 max_try、请求间隔由 http.rate_limit 统一限速。
        # 注：engine 读取 scan.weak_password（默认 False），两者必须一致。
        "weak_password": False,
        "weak_password_max_targets": 5,
        "weak_password_max_try": 24,
        # 3-2：连续失败熔断阈值。连续 N 个登录入口零命中即提前收手，
        # 避免对无弱口令的资产持续试凭据（可能触发账号锁定）。
        "weak_password_max_fail": 3,
        # round58：开放 API 注册端点探测（匿名注册接口是否直接下发会话
        # 凭据）。每个端点恰好 1 次匿名 POST，测试账号带 srctest_ 前缀，
        # 不做爆破；默认开，可关。engine 读取键 scan.open_api_probe。
        "open_api_probe": True,
        # round71c 遗留③：三项检测器（账号枚举 / 硬编码公钥 /
        # token 跨主机复用）。全部只读、次数固定、无危害，默认开。
        "user_enum_probe": True,
        "hardcoded_key_probe": True,
        "token_reuse_probe": True,
    },
    # AI / 联网搜索配置位（lab/plan_ai.md 阶段 2 起使用）。
    # 三条硬约定（默认值即为安全侧）：
    #   ① enabled/online 默认 False —— 不显式打开就永不联网、永不调模型；
    #   ② 数值项一律有上限（见 AI_LIMITS），越界自动钳制，防止"配置写飞"；
    #   ③ review_required 恒为 True —— AI 产物必须人工审核后才生效。
    # 注意：本段**只被离线工具（tools/*）读取**，扫描热路径永不读它做决策。
    "ai": {
        "enabled": False,
        "online": False,
        "engine": "auto",
        "search_max_results": 5,
        "search_timeout": 12,
        "max_queries_per_run": 5,
        "model": "",
        "api_base": "",
        "api_key_env": "BTSRHUNTER_AI_KEY",
        "allow_poc_suggestion": False,
        "review_required": True,
    },
    # AI 接管扫描（round59）。独立顶层段，**不并进 ai 段**——
    # round38 A3 锁死 ai 段键集合（新增键即判失败），故另开一段。
    # 默认 enabled=False：不显式打开就完全走原确定性流程，零行为差异。
    # mode: advisory（有人在环，AI 只给建议）/ auto（无人驾驶，AI 自主调工具）。
    "takeover": {
        "enabled": False,
        "mode": "advisory",
        "max_rounds": 8,
        "max_calls_per_round": 4,
        "timeout_sec": 30,
        # round93 FIX-36：这两个键曾经是**死配置**——只被赋值、全库没有
        # 任何消费点，于是「配置里写 false，AI 照样发包」成了撒谎项。现在
        # 已在 tools/tool_registry.py 的强度闸门接上唯一消费点，语义是
        # **AND**：scan 档位给能力上限，这里给 AI 侧授权，两者都为真才放行。
        # 默认 True = 不额外收紧（能不做主动检测仍由 scan.mode 档位决定）；
        # 想「AI 只出候选、不许打」时把这里关掉，就真的关得掉。
        "allow_active": True,
        "allow_poc": True,
        "mcp": {"enabled": False, "servers": []},
        # round73 D 组：SKILL 总开关。与 mcp.enabled 同源同构——页面上的
        # 「总开关」按钮直接写这一位；关闭时 skill_loader.text_for() 返回空串，
        # 于是所有技能提示词都不再注入模型，但技能文件本身保持原样（可随时再开）。
        # 默认 True：不改变既有行为（技能装了就生效），与 mcp 默认 False 不同。
        "skill": {"enabled": True},
    },
    # (round61) removed a round60-reserved GUI-state section here: it had no
    # consumer anywhere, and load() _deep_merge(DEFAULT_CONFIG, user) rewrote
    # it to disk on every run, keeping source config out of sync with baseline.
    "tools": {},
    "report": {"author": "", "src_platform": "butian", "language": "zh",
               "include_evidence": True, "cvss_version": "4.0",
               "dedup_hosts": True},
    "bootstrap": {"auto_install": True, "max_repair_rounds": 6, "mirror": "auto",
                  "python_min": "3.9", "install_dir": "%LOCALAPPDATA%\\CardinalSRCHunter"},
}


def app_root():
    """返回程序资源根目录（兼容 PyInstaller 打包后的 exe）。

    这里只放**随包只读资源**：代码、tools/、libs/、templates/。
    用户可写数据（config/、data/、logs/、reports/）见 USER_ROOT。
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _migrate_legacy_root(old, new):
    """一次性把旧产品名目录的用户数据搬到新目录。

    round96 改名（BTSRCHunter -> CardinalSRCHunter）后，已安装用户的配置、
    ai_key.txt、findings.db 仍留在旧目录里；若不搬，升级即"配置全丢"。
    规则：仅当**新目录不存在且旧目录存在**时整体搬迁；迁移失败（权限/
    占用）一律静默放行，宁可留在旧目录也绝不阻断启动。
    """
    try:
        import shutil
        if not old or not new:
            return
        if os.path.abspath(old) == os.path.abspath(new):
            return
        if os.path.isdir(new) or not os.path.isdir(old):
            return
        parent = os.path.dirname(new)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        try:
            os.rename(old, new)
        except Exception:
            shutil.copytree(old, new)
    except Exception:
        return
def _user_root():
    """返回**用户数据根目录**（配置 / 范围 / 数据 / 日志 / 报告）。

    round68 定位：EXE 场景下 run.bat 每次启动都执行
        xcopy "app" "%DEST%\\app" /E /I /Y /Q
    对 app/ 做**无条件整体覆盖**，而旧代码把 config.json 也放在
    app/config/ 里，于是用户手改的配置在下次启动时被包内出厂值整份盖回
    （即"保存后重启清空"）。修复：把用户数据移出 app/，落到
    %LOCALAPPDATA%\\CardinalSRCHunter\\userdata（与 bootstrap.install_dir
    的默认落点同级，同属"用户区"，不被 xcopy 触及）。

    开发态（非 frozen）仍与源码同目录，lab/ 断言与既有路径零变化。
    环境变量 BTSRHUNTER_USER_DIR 可强制指定（测试 / 便携场景）。
    """
    env = os.environ.get("BTSRHUNTER_USER_DIR")
    if env and str(env).strip():
        return os.path.abspath(os.path.expanduser(str(env).strip()))
    if getattr(sys, "frozen", False):
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        root = os.path.join(base, "CardinalSRCHunter")
        _migrate_legacy_root(os.path.join(base, "BTSRCHunter"), root)
        return os.path.join(root, USER_SUBDIR)
    # ---------------------------------------------------------------
    # round77：exe 版「关掉程序配置就没了 / 只有密钥幸存」的**真因修复**。
    #
    # 本项目的 exe 不是 PyInstaller 产物，而是「内嵌 python.exe + .py 脚本」，
    # 所以 **sys.frozen 恒为 False** —— 上面那条安装态分支根本进不去，
    # 用户数据全落在 %LOCALAPPDATA%\CardinalSRCHunter\app\ 里。而 run.bat 每次
    # 启动都执行 `xcopy "app" "%DEST%\app" /E /I /Y`（无条件覆盖，无版本戳
    # 闸门），于是 app\config\config.json 被包内出厂值整份盖回：
    #     · 端点 / 模型 / 三个开关 —— 在 config.json 里 -> 每次启动被清空
    #     · API 密钥 —— 在 app\data\ai_key.txt 里 -> 打包时 data\ 是**空目录**，
    #       xcopy 是「复制+覆盖」而非镜像，源端没有就不动 -> 密钥侥幸活下来
    # 这正是用户看到的「只有密钥回显、其它全没了」。
    #
    # 修复：不依赖 frozen，直接按**安装树形态**判定 —— 自己正跑在 <DEST>\app\
    # 下（目录名就叫 app 且含 main.py，父目录带 python\ 或 VERSION，即安装器
    # 释放出来的树）时，把用户数据上移到 <DEST>\userdata\，一步跳出 xcopy
    # 的覆盖范围。开发态（仓库根不叫 app、父目录无 python\）零影响。
    here = os.path.dirname(os.path.abspath(__file__))      # <DEST>\app\core
    appdir = os.path.dirname(here)                          # <DEST>\app
    parent = os.path.dirname(appdir)                        # <DEST>
    if (os.path.basename(appdir).lower() == "app"
            and os.path.isfile(os.path.join(appdir, "main.py"))
            and os.path.basename(parent).lower() != USER_SUBDIR
            and (os.path.isdir(os.path.join(parent, "python"))
                 or os.path.isfile(os.path.join(parent, "VERSION")))):
        return os.path.join(parent, USER_SUBDIR)
    return app_root()


# round77：桌面端界面偏好的出厂默认值。用户改过的值写进 config.json 的
# ``ui`` 段（随 userdata\ 一起被保留，重装也不丢）。这里刻意只收录**界面
# 上真实存在**的控件，多一个都不放，避免配置项自己长出来。
DEFAULT_UI = {
    "targets": "",                 # 上次填的授权目标（逗号分隔）
    "mode": "safe",                # 强度档：safe / normal / aggressive
    "enable_active": False,        # 主动检测
    "enable_poc": False,           # PoC 复现
    "weak_password": False,        # 弱口令探测
    "concurrency": 8,              # 并发（engine 侧仍硬钳 8）
    "max_requests_per_host": 3000,  # 单主机上限
    "report": True,                # 生成报告
    "resume": True,                # 断点续扫
    "full": False,                 # 全量放开
    "verify": True,                # 自动核验
    "report_format": "all",        # 报告格式
}

# round77：用户数据子目录名。安装树里必须落在 <DEST>\userdata\（被 run.bat
# 的 xcopy 覆盖范围之外），frozen 场景下落在 %LOCALAPPDATA%\CardinalSRCHunter\userdata\。
USER_SUBDIR = "userdata"
ROOT = app_root()
USER_ROOT = _user_root()
CONFIG_PATH = os.path.join(USER_ROOT, "config", "config.json")
SCOPE_PATH = os.path.join(USER_ROOT, "config", "scope.yaml")
DATA_DIR = os.path.join(USER_ROOT, "data")
LOG_DIR = os.path.join(USER_ROOT, "logs")
REPORT_DIR = os.path.join(USER_ROOT, "reports")
# 随包只读资源：始终跟程序走，不随用户数据外置。
TOOLS_DIR = os.path.join(ROOT, "tools")
# 打包后第三方依赖的落地目录（装在这里 frozen 应用才 import 得到）
LIBS_DIR = os.path.join(ROOT, "libs")


def user_data_external():
    """用户数据是否已与程序目录分离（frozen 场景下为 True）。"""
    return os.path.abspath(USER_ROOT) != os.path.abspath(ROOT)


def ensure_user_files():
    """首次运行把随包 config/ 释放到 USER_ROOT/config。

    只补齐**缺失**的文件，绝不覆盖已存在的用户配置 —— 这正是
    "保存后重启清空"的修复点：升级/重启只会新增出厂文件，不会回写。
    USER_ROOT == ROOT（开发态）时是恒等变换。
    """
    if not user_data_external():
        return 0
    src_dir = os.path.join(ROOT, "config")
    dst_dir = os.path.join(USER_ROOT, "config")
    if not os.path.isdir(src_dir):
        return 0
    try:
        os.makedirs(dst_dir, exist_ok=True)
    except OSError as e:
        sys.stderr.write("[userfiles] 创建 %s 失败: %s\n" % (dst_dir, e))
        return 0
    copied = 0
    for name in ("config.json", "scope.yaml"):
        src = os.path.join(src_dir, name)
        dst = os.path.join(dst_dir, name)
        if not os.path.isfile(src) or os.path.exists(dst):
            continue
        try:
            shutil.copy2(src, dst)
            copied += 1
        except Exception as e:
            sys.stderr.write("[userfiles] 释放 %s 失败: %s\n" % (name, e))
    return copied


def ensure_dirs():
    for d in (DATA_DIR, LOG_DIR, REPORT_DIR, TOOLS_DIR):
        os.makedirs(d, exist_ok=True)
    ensure_user_files()


def is_frozen():
    return bool(getattr(sys, "frozen", False))


def ensure_libs_path():
    """把 exe 同级的 libs/ 加入 sys.path。

    PyInstaller 打包后，系统 site-packages 不在 sys.path 里；
    缺的依赖必须装到 libs/ 并在此挂载，否则永远 import 不到。
    用 append 而非 insert：包内已冻结的模块优先。
    """
    if os.path.isdir(LIBS_DIR) and LIBS_DIR not in sys.path:
        sys.path.append(LIBS_DIR)
    return LIBS_DIR


def ensure_assets():
    """打包（PyInstaller onefile/onedir）后，把随包资源释放到 exe 同级。

    onefile 模式下 config/、requirements.txt 被打进 _MEIPASS 临时解包目录，
    而 app_root() 指向 exe 所在目录 —— 两者不同，首次运行会读不到 scope.yaml。
    这里把缺失的随包资源复制到 exe 同级，保证双击即用。
    """
    meipass = getattr(sys, "_MEIPASS", None)
    if not meipass:
        return 0
    copied = 0
    for rel in ("config", "requirements.txt", "README.md"):
        src = os.path.join(meipass, rel)
        dst = os.path.join(ROOT, rel)
        if not os.path.exists(src):
            continue
        try:
            if os.path.isdir(src):
                # 目标若被误建成文件（历史打包 bug），先清掉
                if os.path.isfile(dst):
                    try:
                        os.remove(dst)
                    except OSError:
                        continue
                os.makedirs(dst, exist_ok=True)
                for name in os.listdir(src):
                    s2 = os.path.join(src, name)
                    d2 = os.path.join(dst, name)
                    if os.path.isfile(s2) and not os.path.exists(d2):
                        shutil.copy2(s2, d2)
                        copied += 1
            else:
                # 源是文件：目标若被误建成目录（PyInstaller --add-data 的
                # <file>:<name> 会把 name 当目录），先清掉再复制
                if os.path.isdir(dst) and not os.path.islink(dst):
                    try:
                        shutil.rmtree(dst)
                    except OSError:
                        continue
                if not os.path.exists(dst):
                    shutil.copy2(src, dst)
                    copied += 1
        except Exception as e:
            sys.stderr.write("[assets] 释放 %s 失败: %s\n" % (rel, e))
    return copied


def _deep_merge(base, override):
    # 必须**深拷贝** base：浅拷贝（dict(base)）会让 out 里的嵌套 dict 与
    # DEFAULT_CONFIG 共享同一对象，Config.set("ai.x", ...) 一次就把模块级
    # 默认值改写掉，之后所有实例都继承污染值（round38 捕获）。
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# 扫描强度预设：scan.mode 的真实语义在此落地。
# safe       —— 只做被动面（敏感路径/组件/敏感信息），不发主动注入流量；
# normal     —— 主动面打开（目录爆破、备份文件、CORS 等），但不做 PoC 复现；
# aggressive —— 全开，含 PoC 复现。
# 说明：显式的 scan.enable_active / scan.enable_poc 优先级高于 mode，
# 用户手改这两项时仍按用户值生效（向后兼容旧配置）。
MODE_PRESETS = {
    "safe": {"enable_active": False, "enable_poc": False},
    "normal": {"enable_active": True, "enable_poc": False},
    "aggressive": {"enable_active": True, "enable_poc": True},
}


# AI 配置项的硬上限：任何来源（用户 config.json、工具命令行）写进来的值
# 都要过这一关，越界就钳到边界。目的是让"配额"不依赖调用方自觉。
# 形如 键 -> (最小值, 最大值)。布尔/字符串项不在表内（另有类型校验）。
AI_LIMITS = {
    "search_max_results": (1, 20),
    "search_timeout": (3, 60),
    "max_queries_per_run": (1, 20),
}
# 回落基准：DEFAULT_CONFIG["ai"] 的**冻结副本**。在模块 import 时生成，
# 早于任何 Config.set()，因此即使有人误改了 DEFAULT_CONFIG 也不会让
# "非法输入回落默认值"的语义跟着漂移（round38 S6/S14 的判据）。
_AI_FALLBACK = dict(DEFAULT_CONFIG["ai"])
AI_ENGINES = ("auto", "bing", "baidu", "github", "osv", "nvd")
# AI 产物只能落到这个后缀；改名成正式文件才生效（与 selfheal 的 .draft 同规矩）。
AI_DRAFT_SUFFIX = ".draft"

# 运行时环境变量覆盖（不落盘、不进发布包、不改磁盘 config.json）。
# 用途：磁盘保持默认全关，需要联网时在**当前终端**临时导出即可，
# 关掉终端或 unset 后立刻回到零网络状态。仅覆盖下列四项：
#   BTSRHUNTER_AI_ENABLED=1  -> ai.enabled = True
#   BTSRHUNTER_AI_ONLINE=1   -> ai.online  = True
#   BTSRHUNTER_AI_BASE=URL   -> ai.api_base
#   BTSRHUNTER_AI_MODEL=NAME -> ai.model
# 密钥仍只走 api_key_env 指定的环境变量（默认 BTSRHUNTER_AI_KEY），
# 与本覆盖层无关，同样不落盘。
AI_ENV_MAP = {
    "BTSRHUNTER_AI_ENABLED": ("enabled", "bool"),
    "BTSRHUNTER_AI_ONLINE": ("online", "bool"),
    "BTSRHUNTER_AI_BASE": ("api_base", "str"),
    "BTSRHUNTER_AI_MODEL": ("model", "str"),
}

# round74：AI 接管总开关的环境变量通道。
# 与 AI_ENV_MAP 分开是硬约束——round48 G5 断言 AI_ENV_MAP 恰好 4 项，
# 且 ai 段键集合被 round38 A3 锁死（新增键即判失败），故 takeover 另开一层。
#   BTSRHUNTER_TAKEOVER=1        -> takeover.enabled = True
#   BTSRHUNTER_TAKEOVER_MODE=auto -> takeover.mode
# 未设置时为零影响恒等变换；与磁盘 config.json 的 takeover 段取**或**语义
# （环境变量只能打开，不能强行关闭磁盘已开启的接管）。
TAKEOVER_ENV_MAP = {
    "BTSRHUNTER_TAKEOVER": ("enabled", "bool"),
    "BTSRHUNTER_TAKEOVER_MODE": ("mode", "str"),
}


def _takeover_env_override(raw):
    """把环境变量里的接管开关叠到 takeover 配置副本上（只读，绝不写盘）。"""
    out = dict(raw) if isinstance(raw, dict) else {}
    for env_name, (key, kind) in TAKEOVER_ENV_MAP.items():
        try:
            val = os.environ.get(env_name)
        except Exception:
            continue
        if val is None:
            continue
        if kind == "bool":
            # 只有真值才覆盖：env 未开时不得把磁盘上的 True 冲掉。
            if str(val).strip().lower() in ("1", "true", "yes", "on"):
                out[key] = True
        else:
            s = str(val).strip()
            if s:
                out[key] = s
    return out


def _ai_env_override(raw):
    """把环境变量里的运行时开关叠到 ai 配置副本上（只读，绝不写盘）。

    未设置或空串一律跳过，保证默认状态下本函数是零影响的恒等变换。
    """
    out = dict(raw) if isinstance(raw, dict) else {}
    for env_name, (key, kind) in AI_ENV_MAP.items():
        try:
            val = os.environ.get(env_name)
        except Exception:
            continue
        if val is None:
            continue
        if kind == "bool":
            out[key] = str(val).strip().lower() in ("1", "true", "yes", "on")
        else:
            s = str(val).strip()
            if s:
                out[key] = s
    return out


def ai_limits(name):
    """返回某项的 (min, max)，未知项返回 (None, None)。"""
    return AI_LIMITS.get(name, (None, None))


# round74：密钥文件落点与读写。
# 密钥仍然**不进 config.json**（round69 红线、scrub_secrets 依旧生效），
# 但允许落在「运行态用户数据目录」下，供 Web 控制台写入、由 ai_client 读取，
# 从而让「双击 GUI / 网页控制台」这条正常路径也能启用 AI。
# 落点选 DATA_DIR（= USER_ROOT/data）而非项目根，两条硬理由：
#   ① build/make_src_zip.py 的 EXC_DIRS 已排除 data/，密钥永不进发布包；
#   ② round50 P5 硬性断言「项目根下不得出现 ai_key.txt」。
# 环境变量 BTSRHUNTER_KEYFILE 仍可强制指定（与 ai_on.sh 同一变量名）。
AI_KEY_FILENAME = "ai_key.txt"


def ai_key_path():
    """返回密钥文件路径（不保证存在）。"""
    try:
        env = str(os.environ.get("BTSRHUNTER_KEYFILE") or "").strip()
    except Exception:
        env = ""
    if env:
        return os.path.abspath(os.path.expanduser(env))
    return os.path.join(DATA_DIR, AI_KEY_FILENAME)


def read_ai_key_file():
    """读密钥文件内容；不存在 / 为空 / 任何异常一律返回空串（绝不抛）。"""
    try:
        p = ai_key_path()
        if not os.path.isfile(p):
            return ""
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            # 与 ai_on.sh 同口径：去掉所有空白字符后再取单行。
            return "".join(f.read().split()).strip()
    except Exception:
        return ""


def write_ai_key_file(key):
    """把密钥写进密钥文件；传空串表示删除该文件。

    返回 (ok, msg)。文件权限尽量收到 0o600（Windows 上忽略）。
    只做这两件事，绝不把密钥写进 config.json。
    """
    p = ai_key_path()
    try:
        s = "".join(str(key or "").split()).strip()
        if not s:
            if os.path.isfile(p):
                os.remove(p)
                return True, "已清除密钥文件"
            return True, "密钥文件不存在"
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(s + "\n")
        try:
            os.chmod(p, 0o600)
        except Exception:
            pass
        return True, "已写入密钥文件"
    except Exception as e:
        return False, "写入失败: %s" % e


def clamp_ai(name, value):
    """把 AI 配置项钳到合法区间。未知项原样返回（交给上层决定）。

    非数值输入一律回落到 DEFAULT_CONFIG["ai"] 的默认值，避免 str 混进
    数值位导致后续 min()/max() 抛 TypeError。
    """
    lo, hi = AI_LIMITS.get(name, (None, None))
    if lo is None:
        return value
    base = _AI_FALLBACK.get(name)
    try:
        v = int(value)
    except (TypeError, ValueError):
        return base
    return max(lo, min(hi, v))


class Config(object):
    def __init__(self, path=None):
        self.path = path or CONFIG_PATH
        # 深拷贝：DEFAULT_CONFIG 含嵌套 dict，浅拷贝会让各实例共享子 dict，
        # set() 写入时污染模块级默认值，影响后续所有 Config 实例。
        self.data = copy.deepcopy(DEFAULT_CONFIG)
        self.load()

    def ai(self):
        """返回**已钳制**的 ai 配置副本（只读快照，改动不会写回 self.data）。

        调用方拿到的永远是安全值：数值在区间内、engine 在枚举内、
        两个开关是 bool、review_required 恒 True。
        """
        raw = self.data.get("ai")
        raw = dict(raw) if isinstance(raw, dict) else {}
        out = {}
        for k, dv in DEFAULT_CONFIG["ai"].items():
            out[k] = raw.get(k, dv)
        # 运行时环境变量覆盖（默认无 env 时为恒等变换，不影响任何断言）。
        out = _ai_env_override(out)
        for k in AI_LIMITS:
            out[k] = clamp_ai(k, out[k])
        for k in ("enabled", "online", "allow_poc_suggestion"):
            out[k] = bool(out[k])
        if str(out.get("engine", "auto")).lower() not in AI_ENGINES:
            out["engine"] = "auto"
        else:
            out["engine"] = str(out["engine"]).lower()
        # 人工审核闸门是硬约束：无论配置怎么写，这里都强制 True。
        out["review_required"] = True
        return out

    def ai_ready(self):
        """联网/模型是否真的可用：必须同时打开 enabled 与 online。"""
        c = self.ai()
        return bool(c["enabled"] and c["online"])

    def takeover(self):
        """返回**已钳制**的 takeover 配置副本（只读快照，改动不回写）。

        round74：在 tools/agent_loop.takeover_conf 之外另开这一层，是为了让
        独立的 tools 模块（tools/ai_client.py、tools/ai_enhance.py）**不 import
        ai 符号**（r38-H1 红线）也能读到接管开关，并统一承载环境变量覆盖。

        语义与 agent_loop.takeover_conf 一致：缺键回落默认值、越界钳到边界、
        非法值不误开。**enabled 只作「是否允许进入 AI 接管分支」的粗判**，
        真正的「模型是否可调用」仍由 ai_client.available() 把关。
        """
        raw = self.data.get("takeover")
        raw = dict(raw) if isinstance(raw, dict) else {}
        out = {
            "enabled": False,
            "mode": "advisory",
            "max_rounds": 8,
            "max_calls_per_round": 4,
            "timeout_sec": 30,
            "allow_active": True,
            "allow_poc": True,
        }
        # 运行时环境变量覆盖（默认无 env 时为恒等变换）。
        raw = _takeover_env_override(raw)
        out["enabled"] = bool(raw.get("enabled", False))
        mode = str(raw.get("mode") or "advisory").lower()
        out["mode"] = mode if mode in ("advisory", "auto") else "advisory"
        for k, lo, hi in (("max_rounds", 1, 32),
                          ("max_calls_per_round", 1, 16),
                          ("timeout_sec", 5, 120)):
            try:
                v = int(raw.get(k, out[k]))
            except Exception:
                v = out[k]
            out[k] = max(lo, min(hi, v))
        # round93 FIX-36：缺键回落 True —— 老 config.json 里没有这两个键时
        # 行为与升级前逐字一致，不因接线而突然收紧；显式写了 False 才真关。
        out["allow_active"] = bool(raw.get("allow_active", True))
        out["allow_poc"] = bool(raw.get("allow_poc", True))
        return out

    def scan_profile(self):
        """把 scan.mode 解析为 (enable_active, enable_poc)。

        mode 未识别时回落到 safe（默认拒绝主动流量）。显式设置过
        enable_active / enable_poc 的键以用户值为准。
        """
        scan = self.data.get("scan") or {}
        preset = MODE_PRESETS.get(str(scan.get("mode", "safe")).lower(),
                                  MODE_PRESETS["safe"])
        active = preset["enable_active"]
        poc = preset["enable_poc"]
        if "enable_active" in scan:
            active = bool(scan["enable_active"])
        if "enable_poc" in scan:
            poc = bool(scan["enable_poc"])
        return active, poc

    def load(self):
        if os.path.isfile(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    user = json.load(f)
                if not isinstance(user, dict):
                    raise ValueError("config 顶层不是对象：%s" % type(user).__name__)
                self.data = _deep_merge(DEFAULT_CONFIG, user)
                # round87 A3: lift legacy 5.0 req/s to 12.0 once.
                # Keeping the old value made every scan crawl: 190 dir
                # words can never finish under ~38s at 5 req/s no matter
                # how many threads run. Only the untouched default is
                # migrated, the user's own explicit value is respected.
                try:
                    _h = self.data.get("http") or {}
                    if float(_h.get("rate_limit") or 0) == 5.0:
                        _h["rate_limit"] = 12.0
                except Exception:
                    pass
            except Exception as e:  # 配置坏了就用默认值继续，不能因此崩
                # round77：**先留证据再回落**。旧代码只打一行 stderr 就继续，
                # 用户看到的是"保存好的配置又没了"却查不到原因；而且下一次
                # save() 会把出厂默认值写回，把损坏现场彻底抹掉。
                # 这里把坏文件改名成 config.json.corrupt_<时间戳> 再回落，
                # 现场可追溯，用户也不会丢数据（改名不是删除）。
                try:
                    bak = "%s.corrupt_%s" % (self.path, time.strftime("%Y%m%d_%H%M%S"))
                    if not os.path.exists(bak):
                        shutil.copy2(self.path, bak)
                except Exception:
                    bak = "(备份失败)"
                sys.stderr.write("[config] 解析失败，使用默认配置: %s\n"
                                 "[config] 已保留损坏现场: %s\n" % (e, bak))
        return self.data

    def save(self):
        d = os.path.dirname(self.path)
        if d:
            os.makedirs(d, exist_ok=True)
        text = json.dumps(self.data, ensure_ascii=False, indent=2) + "\n"
        # round77：原子写。旧实现直接 open(w) 截断再写，写到一半被杀进程/断电
        # 就留下半截 JSON —— 下次 load() 解析失败回落默认值，用户看到的就是
        # "配置又空了"。这里先写同目录 .tmp 再 os.replace（同分区原子替换）。
        # 末尾换行沿用 round61 约定：避免与交付基线 diff 出 "No newline"。
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        # 覆盖前留一份上一版，给"手滑改崩了想回退"留条路（只在能读出旧值时留）
        try:
            if os.path.isfile(self.path):
                shutil.copy2(self.path, self.path + ".bak")
        except Exception:
            pass
        os.replace(tmp, self.path)
        return text

    def ui_prefs(self):
        """读桌面端界面偏好（round77）。缺段/缺键一律回落内置默认，绝不抛。

        为什么单独开 ``ui`` 段而不是复用 ``scan``/``http``：
        ``scan.mode`` 是"档位预设"，而桌面那些勾选框是"我上次选了什么"，
        语义不同；混在一起会让 CLI 侧 ``--mode`` 的语义被界面偏好污染。
        而且用户明确要求"重装也保留"，所以必须进 config.json（config.json
        落在 userdata 目录下，xcopy 覆盖不到，重装不会被抹）。
        """
        raw = self.data.get("ui")
        raw = raw if isinstance(raw, dict) else {}
        out = {}
        for k, dv in DEFAULT_UI.items():
            out[k] = raw.get(k, dv)
        # 类型纠偏：坏值不误开危险项
        for k in ("enable_active", "enable_poc", "weak_password", "resume",
                  "report", "full", "verify"):
            out[k] = bool(out[k])
        if str(out.get("mode", "safe")).lower() not in ("safe", "normal", "aggressive"):
            out["mode"] = "safe"
        else:
            out["mode"] = str(out["mode"]).lower()
        for k, lo, hi, dv in (("concurrency", 1, 8, 8),
                              ("max_requests_per_host", 50, 1000000, 3000)):
            try:
                v = int(out.get(k, dv))
            except Exception:
                v = dv
            out[k] = max(lo, min(hi, v))
        if str(out.get("report_format", "all")) not in (
                "all", "md", "html", "csv", "json", "evidence"):
            out["report_format"] = "all"
        out["targets"] = str(out.get("targets") or "")
        return out

    def save_ui_prefs(self, prefs):
        """把界面偏好写进 ``ui`` 段并落盘。只动 ui 段，绝不碰 ai/takeover。"""
        if not isinstance(prefs, dict):
            return {}
        cur = self.data.get("ui")
        cur = dict(cur) if isinstance(cur, dict) else {}
        for k in DEFAULT_UI:
            if k in prefs:
                cur[k] = prefs[k]
        self.data["ui"] = cur
        self.save()
        return cur

    def scrub_secrets(self):
        """round69：抹掉不该落盘的敏感字段（密钥只从环境变量读，见 tools/ai_client.py）。

        递归遍历 self.data，删掉所有名为 api_key 的键，返回被删路径列表。
        放在 core/config.py 内，避免调用方出现 ai 符号（r38-H1 红线）。
        """
        removed = []

        def _walk(node, path):
            if isinstance(node, dict):
                for k in list(node.keys()):
                    if k == "api_key":
                        node.pop(k, None)
                        removed.append(".".join(path + [str(k)]))
                    else:
                        _walk(node[k], path + [str(k)])
            elif isinstance(node, list):
                for i, x in enumerate(node):
                    _walk(x, path + [str(i)])

        _walk(self.data, [])
        return removed

    def get(self, dotted, default=None):
        cur = self.data
        for part in dotted.split("."):
            if not isinstance(cur, dict) or part not in cur:
                return default
            cur = cur[part]
        return cur

    def set(self, dotted, value):
        parts = dotted.split(".")
        cur = self.data
        for p in parts[:-1]:
            cur = cur.setdefault(p, {})
        cur[parts[-1]] = value
        return value
