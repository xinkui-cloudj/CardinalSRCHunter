# -*- coding: utf-8 -*-
"""未知失败样本落盘（阶段 1-2）。

背景
----
扫描时遇到连不上的主机，netdiag 会给出归因 code（timeout / reset / tls / dns ...）。
但总有一批样本归不进任何已知类别，只能落到 ``unknown``。这类样本恰恰是最有
信息量的——它们代表"程序还没见过的新失败模式"，是 AI 学习器最该吃进去的原料。

因此这里做一件很小的事：**把 unknown 样本原样落盘**，交给离线学习器（阶段 2）
去聚类、归纳、产出新规则草案。扫描本身不看、不用、不依赖它。

红线遵守（三条）
----------------
1. AI 永不进扫描热路径做决策 —— 本模块只写文件，不做任何判定；
2. 产物是落盘静态数据，人工审核后才生效 —— 本模块只产出 ``data/unknowns.jsonl``；
3. 扫描热路径不 import 学习器 —— 反向也成立：本模块不被任何判定逻辑 import。

性能
----
``record()`` 单次成本 = 一次 set 查重 + 一次 append 写行，O(1)，不阻塞扫描。
进程内 ``_SEEN`` 缓存指纹，重复样本不重复落盘。
"""
import hashlib
import json
import os
import threading
import time

from core import config as cfg

# 落盘路径：data/unknowns.jsonl（追加写，一行一样本）
UNKNOWNS_PATH = os.path.join(cfg.DATA_DIR, "unknowns.jsonl")

# 容量上限：超过就保留最近 MAX_LINES 行（防止长期运行无限膨胀）
MAX_LINES = 2000

# 归入"未知"的 code 集合（空串也视为未知）
UNKNOWN_CODES = ("unknown", "")

_LOCK = threading.Lock()
_SEEN = set()          # 进程内指纹缓存
_LOADED = [False]      # 是否已从磁盘加载过指纹


def _fingerprint(detail):
    """指纹 = host + code + err 的 sha1。同源重复样本只落一次。"""
    host = str((detail or {}).get("host") or "")
    code = str((detail or {}).get("code") or "")
    err = str((detail or {}).get("err") or "")
    raw = "\x1f".join((host, code, err))
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()


def _load_seen():
    """首次调用时把磁盘已有样本的指纹读进内存（只读一遍）。"""
    if _LOADED[0]:
        return
    _LOADED[0] = True
    try:
        if not os.path.exists(UNKNOWNS_PATH):
            return
        with open(UNKNOWNS_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                _SEEN.add(_fingerprint(obj))
    except Exception:
        pass


def is_unknown(detail):
    """判断一条 unreachable 明细是否属于"未知"类。"""
    code = str((detail or {}).get("code") or "").strip().lower()
    return code in UNKNOWN_CODES


def record(detail, target="", extra=None):
    """把一条未知失败样本追加到 unknowns.jsonl。

    返回 True 表示真的写入了新样本（去重后），False 表示跳过。
    detail: engine 里 unreach_detail 的单项（含 host/code/reason/hint/ip/tcp/err）。
    """
    if not is_unknown(detail):
        return False
    fp = _fingerprint(detail)
    with _LOCK:
        _load_seen()
        if fp in _SEEN:
            return False
        _SEEN.add(fp)
        obj = {
            "fp": fp,
            "at": round(time.time(), 3),
            "target": str(target or ""),
            "host": str(detail.get("host") or ""),
            "code": str(detail.get("code") or "unknown"),
            "reason": str(detail.get("reason") or ""),
            "hint": str(detail.get("hint") or ""),
            "ip": str(detail.get("ip") or ""),
            "tcp": str(detail.get("tcp") or ""),
            "err": str(detail.get("err") or "")[:800],
        }
        if isinstance(extra, dict) and extra:
            obj["extra"] = extra
        try:
            os.makedirs(os.path.dirname(UNKNOWNS_PATH), exist_ok=True)
            with open(UNKNOWNS_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(obj, ensure_ascii=False) + "\n")
        except Exception:
            return False
        _trim()
        return True


def _trim():
    """超限则保留最近 MAX_LINES 行，并同步内存去重集。调用方已持锁。

    关键点：文件被裁掉的那些样本，必须同时从 ``_SEEN`` 里移除，
    否则它们会被内存永久判为"已见过"，再也无法重新落盘（去重集与
    磁盘内容必须始终一致）。
    """
    try:
        # 快速路径：内存去重集未超限，文件必然也未超限（两者同步）
        if len(_SEEN) <= MAX_LINES:
            return
        if not os.path.exists(UNKNOWNS_PATH):
            return
        with open(UNKNOWNS_PATH, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]
        if len(lines) <= MAX_LINES:
            return
        keep = lines[-MAX_LINES:]
        tmp = UNKNOWNS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.writelines(keep)
        os.replace(tmp, UNKNOWNS_PATH)
        # 重建去重集：只保留仍在文件里的指纹
        _SEEN.clear()
        for line in keep:
            try:
                _SEEN.add(_fingerprint(json.loads(line)))
            except Exception:
                continue
    except Exception:
        pass


def record_many(details, target=""):
    """批量落盘，返回新增条数。扫描收尾时调用一次。"""
    n = 0
    for d in (details or []):
        try:
            if record(d, target=target):
                n += 1
        except Exception:
            continue
    return n


def count():
    """当前已落盘的未知样本数。"""
    try:
        if not os.path.exists(UNKNOWNS_PATH):
            return 0
        n = 0
        with open(UNKNOWNS_PATH, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    n += 1
        return n
    except Exception:
        return 0


def tail(limit=50):
    """取最近 limit 条样本（供 CLI / 学习器读取）。"""
    try:
        if not os.path.exists(UNKNOWNS_PATH):
            return []
        with open(UNKNOWNS_PATH, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]
        out = []
        for line in lines[-int(limit):]:
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        return out
    except Exception:
        return []


def clear():
    """清空样本文件（测试 / 手动重置用）。"""
    with _LOCK:
        _SEEN.clear()
        _LOADED[0] = True
        try:
            if os.path.exists(UNKNOWNS_PATH):
                os.remove(UNKNOWNS_PATH)
        except Exception:
            pass
