# -*- coding: utf-8 -*-
"""出网失败归因：把「连不上」细分成可诊断的原因，并给出排查建议。

背景：探测阶段目标无响应时，旧实现只留下一句笼统的
"unreachable: 目标无 HTTP 响应（连接超时 / 被拒绝 / 端口未开放）"，
用户无法区分是 DNS 挂了、端口没开、被防火墙吞包，还是需要挂代理。
本模块把底层异常文本归一到固定枚举，并可选做一次 TCP 端口探活，
让日志 / CLI / 报告三处都能给出确定原因而不是猜。

说明：本模块只做本地 DNS 查询与 TCP 连接探测，不发送任何 HTTP 请求；
调用点均在 scope 校验通过之后，因此不越过授权边界。
"""
import socket

# 原因枚举：code -> (中文标签, 排查建议)
REASONS = {
    # 精确 DNS 归因（来自 core.dnsx，解决"域名不存在"与"无解析记录"混为一谈）
    "nxdomain": ("域名不存在（NXDOMAIN）",
                 "该域名未注册或已被删除：核对拼写、确认是否把未注册的近似域名当成目标"),
    "nodata":   ("域名存在但无 A/AAAA 记录",
                 "域名已注册但没有 Web 解析记录（可能只配了 CNAME 且目标失效，或只有 MX/TXT）："
                 "请向域名管理员确认解析配置，或改用带 www 的形态重试"),
    "dns":      ("DNS 解析失败", "域名无法解析：检查域名拼写 / DNS 配置，或改用公共 DNS 重试"),
    "timeout":  ("连接超时", "TCP 无响应（防火墙丢包 / 目标下线 / 需代理或 VPN）"),
    "refused":  ("连接被拒绝", "端口未开放或被安全策略拒绝（确认服务端口与协议）"),
    "reset":    ("连接被重置", "链路上存在 RST 注入（WAF / 运营商拦截），可尝试降速或换出口"),
    "tls":      ("TLS 握手失败", "证书或协议版本不兼容（可尝试 http，或指定 TLS 版本）"),
    "noroute":  ("网络不可达", "本机到该网段无路由（检查网络 / VPN 是否连通）"),
    "connect":  ("连接建立失败（重试耗尽）",
                 "TCP 连接始终未能建立：端口未开放 / 链路被拦截 / 目标仅 IPv6 可达；"
                 "已自动补做 TCP 探活以区分具体原因"),
    "http":     ("HTTP 交互失败", "TCP 已连通但 HTTP 交互异常（协议错配 / 反爬 / 重定向环）"),
    "unknown":  ("未知错误", "未能归类，请查看日志中的原始错误文本"),
}

# 子串匹配表：越靠前优先级越高（先判 DNS / TLS，再判连接类）。
# 注意 connect 必须排在 http 之前：urllib3 的 "Max retries exceeded" 只是
# 外层包装，内层常见 "NewConnectionError / Failed to establish a new
# connection"（TCP 根本没建起来）。若让 http 先命中，会把「连不上」误报成
# 「TCP 已连通但 HTTP 失败」，与 TCP 探活结果自相矛盾。
_RULES = (
    ("dns", ("name or service not known", "nodename nor servname",
             "getaddrinfo failed", "name resolution", "temporary failure in name",
             "nameresolutionerror", "gaierror", "dns")),
    ("tls", ("certificate verify failed", "sslerror", "ssl error", "sslv3",
             "tlsv1", "handshake failure", "wrong version number", "ssl:")),
    ("noroute", ("no route to host", "network is unreachable", "errno 101", "errno 113")),
    ("refused", ("connection refused", "errno 111", "actively refused")),
    ("reset", ("connection reset", "errno 104", "broken pipe", "remote end closed")),
    ("timeout", ("timed out", "timeout", "errno 110", "errno 138")),
    ("connect", ("newconnectionerror", "failed to establish a new connection",
                 "failed to establish new connection", "max retries exceeded",
                 "connectionerror")),
    ("http", ("protocolerror", "chunkedencodingerror", "too many redirects",
              "badstatusline", "incompleteread")),
)


# errno 数字映射：上游若直接把 errno（int 或纯数字串）传进来，走子串
# 匹配只会落到 unknown，这里给出确定归因（与 tcp_probe 的映射保持一致）。
_ERRNO_MAP = {
    61: "refused", 111: "refused",
    110: "timeout", 138: "timeout",
    101: "noroute", 113: "noroute",
    104: "reset",
}


def classify(err_text):
    """把底层异常文本归一为 (code, 中文标签)。

    兼容两种输入：① 底层异常原文（走子串匹配）；② core.dnsx 直接透传的
    归因 code（如 "nxdomain" / "nodata"），此时原样返回，让精确原因不被
    重新揉回笼统的「DNS 解析失败」。
    """
    if isinstance(err_text, int) and err_text in _ERRNO_MAP:
        return _ERRNO_MAP[err_text], REASONS[_ERRNO_MAP[err_text]][0]
    # err_text 可能是 int（errno）或异常对象，统一转字符串再匹配，
    # 避免上游把 errno 直接传进来时在 .strip() 处抛 AttributeError。
    t = str(err_text or "").strip().lower()
    if not t:
        return "unknown", REASONS["unknown"][0]
    if t in REASONS:
        return t, REASONS[t][0]
    if t.isdigit() and int(t) in _ERRNO_MAP:
        c = _ERRNO_MAP[int(t)]
        return c, REASONS[c][0]
    for code, keys in _RULES:
        for k in keys:
            if k in t:
                return code, REASONS[code][0]
    return "unknown", REASONS["unknown"][0]


def hint_of(code):
    """取某个原因 code 对应的排查建议。"""
    return REASONS.get(code, REASONS["unknown"])[1]


def tcp_probe(host, port, timeout=3.0):
    """对 host:port 做一次 TCP 探活，返回 (ok, code, detail)。

    用于把「超时」和「被拒」区分开——HTTP 层报超时时，TCP 直连往往能
    给出更确定的答案（RST=端口未开放，超时=链路丢包）。
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        rc = s.connect_ex((host, port))
        try:
            s.close()
        except Exception:
            pass
        if rc == 0:
            return True, "", "tcp open"
        if rc in (111, 61):
            return False, "refused", "tcp refused (errno %d)" % rc
        if rc in (110, 138):
            return False, "timeout", "tcp timeout (errno %d)" % rc
        if rc in (101, 113):
            return False, "noroute", "no route (errno %d)" % rc
        return False, "unknown", "tcp errno %d" % rc
    except socket.timeout:
        return False, "timeout", "tcp timeout"
    except socket.gaierror as e:
        return False, "dns", "tcp dns: %s" % e
    except Exception as e:
        return False, "unknown", "tcp %s" % e


def resolve(host):
    """解析 host 的 A/AAAA 记录，返回 (ips, err)。纯本地 DNS，不出网 HTTP。

    优先走 core.dnsx 的多源并发解析；解析不出来时，err 直接透传 dnsx 的
    归因 code（nxdomain / nodata / dns），让 diagnose 能用上精确原因，
    而不是把「域名不存在」和「无解析记录」都塞进同一句「DNS 解析失败」。
    """
    h = (host or "").strip().rstrip(".")
    if not h:
        return [], ""
    try:
        from . import dnsx
        ips, code, _detail = dnsx.resolve_ex(h)
        if ips:
            return ips, ""
        if code:
            return [], code
    except Exception:
        pass
    try:
        infos = socket.getaddrinfo(h, None)
        ips = []
        for it in infos:
            try:
                ip = it[4][0]
            except Exception:
                continue
            if ip and ip not in ips:
                ips.append(ip)
        return ips, ""
    except Exception as e:
        return [], str(e)[:200]


def diagnose(host, err_text="", port=0, do_tcp=True):
    """综合诊断一个主机为何不可达，返回结构化 dict。

    字段：host / ip / code / reason / err / hint / tcp
    """
    bare = (host or "").split(":")[0]
    ips, rerr = resolve(bare) if bare else ([], "")
    code, label = classify(err_text or rerr)
    # dnsx 已给出精确 DNS 归因（nxdomain / nodata）时优先采用：上层传入的
    # 笼统错误文本（如 "name or service not known"）只能归到笼统的 dns，
    # 会把「域名不存在」与「无解析记录」重新揉回同一句，必须让精确原因
    # 胜出——前提是当前分类确实是笼统的 dns / unknown。
    if rerr in ("nxdomain", "nodata") and code in ("dns", "unknown", ""):
        code, label = classify(rerr)
    d = {"host": host, "ip": (ips[0] if ips else ""),
         "code": code, "reason": label,
         "err": (err_text or rerr or "")[:200],
         "hint": hint_of(code), "tcp": ""}
    # HTTP 层报「超时 / 未知 / 连接建立失败」时，再做一次 TCP 直连，
    # 拿更确定的结论（RST=端口未开放，超时=链路丢包，连通=纯 HTTP 层问题）。
    # 关键：connect 也必须进这个门槛，否则会出现「reason=TCP 已连通」与
    # tcp 列 `-` 自相矛盾的报告（用户实测报告里就是这个形态）。
    if do_tcp and bare and code in ("timeout", "unknown", "connect", "http"):
        p = int(port) if port else 443
        ok, tcode, tdetail = tcp_probe(bare, p, timeout=3.0)
        d["tcp"] = tdetail
        if ok:
            # TCP 真的连通：才允许把结论收敛到 HTTP 层交互失败
            if code != "http":
                d["code"] = "http"
                d["reason"] = REASONS["http"][0]
                d["hint"] = hint_of("http")
        elif tcode and tcode != "unknown":
            # TCP 没连通：以探活结论为准，覆盖掉笼统的 connect / http
            d["code"] = tcode
            d["reason"] = REASONS[tcode][0]
            d["hint"] = hint_of(tcode)
    return d


def summarize(diags):
    """把多个诊断归并成 {原因: 台数}，供报告与日志一行展示。"""
    out = {}
    for d in diags or []:
        r = (d or {}).get("reason") or "未知错误"
        out[r] = out.get(r, 0) + 1
    return out


def port_of(host, default=443):
    """从 host[:port] 取端口，取不到用 default。"""
    try:
        if host and ":" in host:
            tail = host.rsplit(":", 1)[1]
            if tail.isdigit():
                return int(tail)
    except Exception:
        pass
    return default

# ---------------------------------------------------------------- 3-1 回退链
# 默认补测端口：与 core/selfheal.py 的 refused 动作 port_retry 保持一致
# （443/80/8080/8443），保证「报告里列出的端口」与「自愈打算重试的端口」
# 是同一组，用户不会看到两套互相打架的数字。
FALLBACK_PORTS = (443, 80, 8080, 8443)

def probe_ports(host, ports=None, timeout=2.0):
    """对同一主机按顺序做多端口 TCP 探活，返回逐端口结论列表。

    只做 TCP 连接、不出网 HTTP，用于把「连接被拒绝/超时」时的回退链
    显式记进报告：到底试过哪些端口、每个端口分别是什么结论。
    返回 [{"port": 443, "ok": False, "code": "refused", "detail": "..."}]。
    无主机名时返回空表；任何异常都被吞掉，绝不打断扫描主流程。
    """
    out = []
    if not host:
        return out
    _ports = list(ports) if ports else list(FALLBACK_PORTS)
    for p in _ports:
        try:
            pn = int(p)
        except Exception:
            continue
        try:
            ok, code, detail = tcp_probe(host, pn, timeout=timeout)
        except Exception as e:
            ok, code, detail = False, "unknown", "tcp %s" % e
        out.append({"port": pn, "ok": bool(ok),
                    "code": code or "", "detail": detail or ""})
    return out

def ports_text(rows):
    """把 probe_ports 的结果压成一行可读文本，如 "443 refused / 80 open"。"""
    parts = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        p = r.get("port")
        c = "open" if r.get("ok") else (r.get("code") or "unknown")
        parts.append("%s %s" % (p, c))
    return " / ".join(parts)
