# -*- coding: utf-8 -*-
"""HTTP 客户端：限速 / 重试 / UA 轮换 / 代理 / WAF 识别 / scope 强制。

所有请求都必须经过这里，scope 守卫在 send() 内强制执行，
任何绕过 scope 的请求在代码层面不可达。
"""
import hashlib
import random
import re
import threading
import time

from . import config as cfg
from . import logger

log = logger.get("bt.http")
try:
    import requests
except Exception:  # pragma: no cover
    requests = None

WAF_SIGNS = [
    ("安全狗", [r"safedog", r"waf\.safedog", r"安全狗"]),
    ("云锁", [r"yunsuo", r"云锁"]),
    ("D盾", [r"d_safe", r"D盾"]),
    ("360网站卫士", [r"360wzws", r"wangzhan\.360"]),
    ("阿里云WAF", [r"aliyun", r"yundun", r"aliyundun"]),
    ("腾讯云WAF", [r"tencent", r"tcdn", r"waf\.qcloud"]),
    ("百度云加速", [r"yunjiasu", r"baidu\.com/su"]),
    ("Cloudflare", [r"cloudflare", r"cf-ray", r"__cfduid"]),
    ("ModSecurity", [r"mod_security", r"modsecurity", r"NOYB"]),
    ("长亭雷池", [r"chaitin", r"safeline"]),
    ("Imperva", [r"incap_ses", r"visid_incap", r"imperva"]),
    ("F5 BIG-IP", [r"bigip", r"TS[0-9a-f]{8}", r"BIGipServer"]),
]


class RateLimiter(object):
    """全局令牌桶限速。"""

    def __init__(self, rate):
        self.rate = max(0.1, float(rate or 12.0))
        self._ceiling = self.rate
        self._lock = threading.Lock()
        self._next = 0.0

    def wait(self):
        """令牌桶：只在锁内"预占"下一个发车时刻，sleep 放到锁外。

        原实现在持锁期间直接 time.sleep()，会让所有工作线程在限速器上
        排成一队依次睡眠——concurrency=8 被退化成单线程，吞吐不升反降。
        正确做法是锁内只推进 _next（预留本线程的槽位），锁外再睡。
        """
        with self._lock:
            now = time.time()
            slot = self._next if self._next > now else now
            self._next = slot + 1.0 / self.rate
            delay = slot - now
        if delay > 0:
            time.sleep(delay)

    def speed_up(self, factor=1.25):
        # round87 A3: recover throughput after a quiet stretch.
        # slow_down() existed but nothing ever sped back up, so one WAF
        # hiccup pinned the whole scan at 0.2 req/s for the rest of the run.
        # Capped by _ceiling so we never exceed what the user allowed.
        with self._lock:
            if self.rate < self._ceiling:
                self.rate = min(self._ceiling, self.rate * factor)
    def slow_down(self, factor=1.5):
        """被 WAF 拦或触发限流时自动降速。"""
        with self._lock:
            self.rate = max(0.2, self.rate / factor)
            log.warning("检测到拦截/限流，自动降速至 %.2f req/s", self.rate)


def _decode_body(resp, max_sniff=4096):
    """把响应字节解码成文本，避免中文拦截页变乱码。

    round89 FIX-7：requests 在响应头无 charset 且正文无 <meta charset> 时
    按 ISO-8859-1 解码（RFC 2616 的默认值）。真实站点（如 ztgame 的 WAF
    拦截页）恰恰是「utf-8 中文 + 不声明编码」，于是标题被打成
    ``WAFæ¦æªé¡µé¢``，日志和报告都不可读。

    策略（从严到宽）：
      1) 响应头显式 charset 优先，照它解；
      2) 正文前 4KB 有 <meta charset>/<meta http-equiv> 则照它解；
      3) 否则先按 utf-8 严格解码，失败再退回 apparent_encoding / gb18030
         / latin-1，全程 errors="replace"，绝不抛异常打断扫描。
    """
    ct = (resp.headers.get("Content-Type") or "") if hasattr(resp, "headers") else ""
    m = re.search(r"charset\s*=\s*[\"']?([\w\-]+)", ct, re.I)
    encs = []
    if m:
        encs.append(m.group(1))
    try:
        raw = resp.content or b""
    except Exception:
        raw = b""
    if raw:
        head = raw[:max_sniff].decode("latin-1", "ignore")
        m2 = re.search(r"<meta[^>]+charset\s*=\s*[\"']?([\w\-]+)", head, re.I)
        if m2:
            encs.append(m2.group(1))
    encs += ["utf-8", "gb18030"]
    for enc in encs:
        try:
            return raw.decode(enc)
        except Exception:
            continue
    try:
        return raw.decode("utf-8", "replace")
    except Exception:
        return ""


class Response(object):
    __slots__ = ("status", "headers", "text", "url", "elapsed", "length",
                 "content_type", "history", "raw_request", "waf", "error")

    def __init__(self, **kw):
        for s in self.__slots__:
            setattr(self, s, kw.get(s))
        # status 缺省置 0（而非 None），否则 dump()/报告里会打印 "HTTP None"。
        if self.status is None:
            self.status = 0
        self.headers = self.headers or {}
        self.text = self.text or ""
        self.length = self.length if self.length is not None else len(self.text)

    @property
    def body_hash(self):
        return hashlib.md5(self.text.encode("utf-8", "ignore")).hexdigest()

    def header(self, name, default=""):
        for k, v in self.headers.items():
            if k.lower() == name.lower():
                return v
        return default

    def dump(self, max_body=2048):
        lines = ["%s %s" % ("HTTP", self.status), "URL: %s" % self.url]
        for k, v in list(self.headers.items())[:20]:
            lines.append("%s: %s" % (k, v))
        body = self.text[:max_body]
        if len(self.text) > max_body:
            body += "\n...[截断 %d 字节]" % (len(self.text) - max_body)
        lines.append("")
        lines.append(body)
        return "\n".join(lines)


class HttpClient(object):
    def __init__(self, scope, config=None):
        self.config = config or cfg.Config()
        self.scope = scope
        self._ok_streak = 0
        self.rate = RateLimiter(self.config.get("http.rate_limit", 12.0))
        self.timeout = self.config.get("http.timeout", 12)
        self.retries = self.config.get("http.retries", 2)
        self.verify = self.config.get("http.verify_tls", False)
        # verify_tls=False 是安全扫描的常态（目标多为自签 / 过期 / 域名不匹配
        # 证书）。requests 会对「每个请求」各刷一条 InsecureRequestWarning，
        # 端到端实测中它把 87s 的扫描日志淹成了 100+ 行噪声，用户读不到真正
        # 的阶段进度。这里在关闭校验时统一静音，verify_tls=True 时不受影响。
        if not self.verify:
            try:
                import urllib3
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            except Exception:
                pass
        self.allow_redirects = self.config.get("http.follow_redirects", True)
        self.uas = self.config.get("http.user_agents") or ["Mozilla/5.0"]
        self.proxy = self.config.get("http.proxy") or ""
        self.extra_headers = dict(self.config.get("http.headers") or {})
        self.extra_headers.update(getattr(scope, "test_headers", {}) or {})
        self.request_count = 0
        self._lock = threading.Lock()
        self._waf_cache = {}
        # requests.Session 官方声明非线程安全（连接池 / headers / 重定向
        # 状态会被并发写坏，表现为串包、拿到别人的响应、TLS 状态错乱）。
        # 引擎会用 ThreadPoolExecutor(concurrency) 并发跑多个 scan_host，
        # 它们共用同一个 HttpClient，因此这里必须"每线程一个 Session"。
        self._tls = threading.local()
        self._sessions = []
        if requests is not None:
            self.session = self._new_session()
        else:
            self.session = None

    def _new_session(self):
        """建一个绑定到当前线程的 requests.Session（并登记以便 close）。"""
        s = requests.Session()
        s.verify = self.verify
        if self.proxy:
            s.proxies = {"http": self.proxy, "https": self.proxy}
        self._sessions.append(s)
        return s

    def session_for_thread(self):
        """取当前线程专属 Session；没有就懒建一个。"""
        if requests is None:
            return None
        s = getattr(self._tls, "session", None)
        if s is None:
            s = self._new_session()
            self._tls.session = s
        return s

    def close(self):
        """关闭所有线程建过的 Session，释放连接池。"""
        for s in list(self._sessions):
            try:
                s.close()
            except Exception:
                pass
        self._sessions = []

    # ---------- 核心 ----------
    def send(self, method, url, params=None, data=None, json_body=None,
             headers=None, allow_redirects=None, purpose="", timeout=None):
        # 1) scope 强制校验（默认拒绝）
        if not self.scope.is_allowed(url, purpose=purpose or method):
            logger.audit("request_blocked", url=url, method=method, purpose=purpose)
            log.warning("越界请求已拦截: %s", url)
            return Response(status=0, url=url, text="", error="out_of_scope",
                            headers={})
        if self.session is None:
            return Response(status=0, url=url, text="",
                            error="requests 未安装，请先运行 install", headers={})

        # 每线程取自己的 Session：并发时绝不共用同一个连接池 / 状态。
        session = self.session_for_thread() or self.session


        hdrs = {
            "User-Agent": random.choice(self.uas),
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "close",
        }
        hdrs.update(self.extra_headers)
        hdrs.update(headers or {})

        last_err = None
        for attempt in range(self.retries + 1):
            self.rate.wait()
            t0 = time.time()
            try:
                resp = session.request(
                    method, url, params=params, data=data, json=json_body,
                    headers=hdrs, timeout=timeout or self.timeout,
                    allow_redirects=(self.allow_redirects if allow_redirects is None
                                     else allow_redirects))
                elapsed = time.time() - t0
                _txt = _decode_body(resp)
                out = Response(
                    status=resp.status_code,
                    headers=dict(resp.headers),
                    text=_txt,
                    url=resp.url,
                    elapsed=elapsed,
                    length=len(resp.content or b""),
                    content_type=resp.headers.get("Content-Type", ""),
                    history=[r.status_code for r in resp.history],
                    raw_request=self._dump_request(resp, method, url, hdrs, params, data),
                    waf=self.detect_waf(resp.headers, _txt),
                )
                with self._lock:
                    self.request_count += 1
                logger.audit("request", url=url, method=method, status=out.status,
                             elapsed=round(elapsed, 3), waf=out.waf, purpose=purpose)
                # 403/429/5xx 疑似 WAF 或限流 → 降速
                if out.status in (403, 429) and out.waf:
                    self.rate.slow_down()
                    self._ok_streak = 0
                else:
                    self._ok_streak += 1
                    if self._ok_streak >= 40:
                        self._ok_streak = 0
                        self.rate.speed_up()
                return out
            except Exception as e:
                last_err = e
                logger.audit("request_error", url=url, method=method, error=str(e)[:200])
                time.sleep(0.5 * (attempt + 1))
        return Response(status=0, url=url, text="", error=str(last_err), headers={})

    def get(self, url, **kw):
        return self.send("GET", url, **kw)

    def post(self, url, **kw):
        return self.send("POST", url, **kw)

    def head(self, url, **kw):
        return self.send("HEAD", url, **kw)

    def options(self, url, **kw):
        return self.send("OPTIONS", url, **kw)

    # ---------- 工具 ----------
    def _dump_request(self, resp, method, url, hdrs, params, data):
        try:
            req = resp.request
            lines = ["%s %s" % (req.method, req.url)]
            for k, v in req.headers.items():
                lines.append("%s: %s" % (k, v))
            if req.body:
                body = req.body
                if isinstance(body, bytes):
                    body = body.decode("utf-8", "ignore")
                lines.append("")
                lines.append(str(body)[:2000])
            return "\n".join(lines)
        except Exception:
            lines = ["%s %s" % (method, url)]
            for k, v in (hdrs or {}).items():
                lines.append("%s: %s" % (k, v))
            if data:
                lines.append("")
                lines.append(str(data)[:2000])
            return "\n".join(lines)

    def detect_waf(self, headers, body):
        blob = (" ".join("%s %s" % (k, v) for k, v in (headers or {}).items())
                + " " + (body or "")[:4096]).lower()
        for name, pats in WAF_SIGNS:
            for p in pats:
                if re.search(p, blob, re.I):
                    return name
        return ""

    def count(self):
        return self.request_count