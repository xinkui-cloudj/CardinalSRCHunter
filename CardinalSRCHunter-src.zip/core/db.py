# -*- coding: utf-8 -*-
"""SQLite 结果库：资产 / 漏洞 / 请求证据 / 扫描进度（支持断点续扫）。"""
import json
import os
import sqlite3
import threading
import time
from . import config as cfg
from . import logger
log = logger.get("bt.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    host TEXT, url TEXT, ip TEXT, port INTEGER,
    status INTEGER, title TEXT, tech TEXT, server TEXT,
    source TEXT, created_at REAL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_assets_url ON assets(url);

CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT, host TEXT, url TEXT,
    vuln_type TEXT, severity TEXT, confidence TEXT,
    title TEXT, description TEXT, request TEXT, response TEXT,
    payload TEXT, cvss TEXT, fix TEXT, extra TEXT,
    created_at REAL
);
CREATE INDEX IF NOT EXISTS idx_findings_target ON findings(target);
CREATE INDEX IF NOT EXISTS idx_findings_severity ON findings(severity);
CREATE INDEX IF NOT EXISTS idx_findings_url ON findings(url);

CREATE TABLE IF NOT EXISTS progress (
    k TEXT PRIMARY KEY, v TEXT, updated_at REAL
);

CREATE TABLE IF NOT EXISTS scanned (
    url TEXT PRIMARY KEY, status INTEGER, length INTEGER,
    ctype TEXT, hash TEXT, created_at REAL
);
CREATE TABLE IF NOT EXISTS verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id INTEGER, target TEXT, host TEXT, url TEXT,
    vuln_type TEXT, param TEXT, method TEXT,
    verdict TEXT, confidence TEXT, method_used TEXT,
    requests INTEGER, evidence TEXT, detail TEXT,
    created_at REAL
);
CREATE INDEX IF NOT EXISTS idx_verif_target ON verifications(target);
CREATE INDEX IF NOT EXISTS idx_verif_finding ON verifications(finding_id);
CREATE INDEX IF NOT EXISTS idx_verif_verdict ON verifications(verdict);
CREATE INDEX IF NOT EXISTS idx_verif_type ON verifications(vuln_type);
"""


class DB(object):
    def __init__(self, path=None):
        cfg.ensure_dirs()
        self.path = path or os.path.join(cfg.DATA_DIR, "findings.db")
        self._lock = threading.Lock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        # WAL：允许读写并发，避免扫描线程落库时 GUI/CLI 读报告出现
        # "database is locked"。busy_timeout 让偶发写冲突自动等待而非直接抛错。
        try:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA busy_timeout=5000")
        except Exception:
            pass
        self.conn.executescript(_SCHEMA)
        self.conn.commit()

    # ---------- 通用 ----------
    @staticmethod
    def _hydrate(row):
        """把 findings 行的 extra(JSON 字符串) 反序列化成 dict。

        写入侧 add_finding 用 json.dumps 存字符串；读侧若原样返回，
        调用方 `row["extra"].get("verified")` 会抛 AttributeError
        （'str' object has no attribute 'get'）。这里统一在出口处还原，
        解析失败时回退空 dict，保证消费方拿到的永远是 dict。
        """
        if row and isinstance(row.get("extra"), str):
            try:
                row["extra"] = json.loads(row["extra"]) or {}
            except Exception:
                row["extra"] = {}
        return row

    def _exec(self, sql, args=()):
        with self._lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    def query(self, sql, args=()):
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    # ---------- 资产 ----------
    def add_asset(self, host, url, ip="", port=0, status=0, title="",
                  tech="", server="", source=""):
        try:
            self._exec(
                "INSERT OR REPLACE INTO assets(host,url,ip,port,status,title,tech,server,"
                "source,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (host, url, ip, port, status, title,
                 tech if isinstance(tech, str) else ",".join(tech or []),
                 server, source, time.time()))
        except Exception:
            pass

    def all_assets(self):
        return self.query("SELECT * FROM assets ORDER BY id")
    def assets_of_host(self, host):
        """按 host 精确取资产（r88 存活回填用）。"""
        return self.query("SELECT * FROM assets WHERE host=? ORDER BY id", (host,))

    # ---------- 漏洞 ----------
    def add_finding(self, target, host, url, vuln_type, severity, confidence,
                    title, description="", request="", response="", payload="",
                    cvss="", fix="", extra=None):
        cur = self._exec(
            "INSERT INTO findings(target,host,url,vuln_type,severity,confidence,title,"
            "description,request,response,payload,cvss,fix,extra,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (target, host, url, vuln_type, severity, confidence, title, description,
             request, response, payload, cvss, fix,
             json.dumps(extra or {}, ensure_ascii=False), time.time()))
        return cur.lastrowid

    def all_findings(self, target=None, min_severity=None):
        order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        # 过滤下推到 SQL，配合 idx_findings_target/severity 走索引，
        # 避免原来 SELECT * 全表拉取后再在 Python 侧过滤。
        sql = "SELECT * FROM findings"
        args = []
        where = []
        if target:
            where.append("target=?")
            args.append(target)
        if min_severity:
            allowed = [k for k, v in order.items() if v <= order.get(min_severity, 4)]
            if allowed:
                where.append("severity IN (%s)" % ",".join("?" * len(allowed)))
                args.extend(allowed)
        if where:
            sql += " WHERE " + " AND ".join(where)
        rows = self.query(sql, tuple(args))
        rows = [self._hydrate(r) for r in rows]
        return sorted(rows, key=lambda r: order.get(r["severity"], 9))

    def findings_by_ids(self, ids):
        """按 id 批量取 finding（r88 缺陷 #6：报告只收本轮写入的记录）。

        背景：report.generate(findings=None) 原来回退 db.all_findings(target)，
        会把该目标**全部历史** finding 拉进新报告——修好检测规则后重跑，
        旧误报仍原样出现在新报告里（实测 scan5 把 scan3 的 5 条时间盲注
        带了出来），导致修复效果无法验收。
        改为由 engine.scan_target 收集本轮落库的 id，报告只取这些行。
        ids 为空时返回空列表（不退回全量，宁可空也不污染）。
        """
        _ids = []
        for i in (ids or []):
            try:
                _ids.append(int(i))
            except Exception:
                continue
        if not _ids:
            return []
        out = []
        # 分块查，避免 SQLite 变量上限（默认 999）。
        for _i in range(0, len(_ids), 500):
            _chunk = _ids[_i:_i + 500]
            sql = "SELECT * FROM findings WHERE id IN (%s)" % ",".join(
                "?" * len(_chunk))
            try:
                rows = self.query(sql, tuple(_chunk))
            except Exception as e:
                log.warning("findings_by_ids 查询失败：%s", e)
                continue
            out.extend(self._hydrate(r) for r in rows)
        order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        return sorted(out, key=lambda r: order.get(r.get("severity"), 9))
    def finding(self, fid):
        rows = self.query("SELECT * FROM findings WHERE id=?", (fid,))
        return self._hydrate(rows[0]) if rows else None

    def mark_verified(self, fid, severity=None, confidence=None, description=None,
                      request=None, response=None, payload=None, cvss=None,
                      fix=None, evidence=None, timing=None):
        """把已落库的"疑似"行原地升级为"已复现"（缺陷 P 修复配套）。

        背景：PoC 复现项与疑似项共用同一去重键，疑似先落库。若升级时另
        INSERT 一行会被去重挡住、整条确认丢失（实测 verified 全 False）。
        这里改为 UPDATE 原行：extra.verified=True，并把 PoC 才有的证据
        （请求/响应原文、载荷、CVSS、时间对比）补进去，保证报告能显示
        "已复现"。不改 url/vuln_type/param/method，去重语义保持不变。
        """
        rows = self.query("SELECT extra FROM findings WHERE id=?", (fid,))
        if not rows:
            return False
        try:
            extra = json.loads(rows[0].get("extra") or "{}") or {}
        except Exception:
            extra = {}
        extra["verified"] = True
        if evidence:
            extra["evidence"] = evidence
        if timing:
            extra["timing"] = timing
        sets = ["extra=?"]
        args = [json.dumps(extra, ensure_ascii=False)]
        for col, val in (("severity", severity), ("confidence", confidence),
                         ("description", description), ("request", request),
                         ("response", response), ("payload", payload),
                         ("cvss", cvss), ("fix", fix)):
            if val:
                sets.append("%s=?" % col)
                args.append(val)
        args.append(fid)
        self._exec("UPDATE findings SET %s WHERE id=?" % ",".join(sets), tuple(args))
        return True
    # ---------- 核验结论回写（core/verify.py 消费） ----------
    def set_verdict(self, fid, verdict, method="", evidence="", confidence=""):
        """把核验结论写进 findings.extra["verify_verdict"]。

        与 mark_verified 的区别：mark_verified 表达"PoC 复现成功"（只升不降，
        用于把疑似升级成已复现）；本方法表达核验层的**三档判定**，可以是
        confirmed/refuted/inconclusive，因此允许覆盖写入（同一 finding 反复
        核验以最后一次为准）。refuted 的行由 report 层据此剔除主报告。

        同样只 UPDATE 原行、绝不新 INSERT——否则会被 engine._persist 的
        (vtype,url,param,method) 去重键挡住，确认/证伪结果整条丢失。
        """
        rows = self.query("SELECT extra FROM findings WHERE id=?", (fid,))
        if not rows:
            return False
        try:
            extra = json.loads(rows[0].get("extra") or "{}") or {}
        except Exception:
            extra = {}
        extra["verify_verdict"] = verdict
        if method:
            extra["verify_method"] = method
        if evidence:
            extra["verify_evidence"] = evidence
        if confidence:
            extra["verify_confidence"] = confidence
        extra["verified_at"] = time.time()
        self._exec("UPDATE findings SET extra=? WHERE id=?",
                   (json.dumps(extra, ensure_ascii=False), fid))
        return True

    def set_ai_review(self, fid, verdict="", reason="", confidence=None, model=""):
        """round89：把 AI 复核结论写进 findings.extra["ai_review"]（**新增字段**）。

        与 set_verdict 的区别（这是本功能最要紧的一条）：
          - set_verdict 写 extra["verify_verdict"]，那只是规则核验的结论；
          - 本方法写 extra["ai_review"]，只做旁证，**绝不改动 verify_verdict**。
        AI 只有建议权、没有改判权——否则模型一附和，误报就被“洗白”成正洞，
        审计链断掉就查不出错。

        仍只 UPDATE 原行、绝不 INSERT（否则会被 _persist 的去重键挡住）。
        """
        rows = self.query("SELECT extra FROM findings WHERE id=?", (fid,))
        if not rows:
            return False
        try:
            extra = json.loads(rows[0].get("extra") or "{}") or {}
        except Exception:
            extra = {}
        block = {"verdict": verdict, "reason": reason, "model": model}
        if confidence is not None:
            try:
                block["confidence"] = float(confidence)
            except Exception:
                pass
        block["at"] = time.time()
        extra["ai_review"] = block
        self._exec("UPDATE findings SET extra=? WHERE id=?",
                   (json.dumps(extra, ensure_ascii=False), fid))
        return True

    def add_verification(self, finding_id, target, host="", url="", vuln_type="",
                         param="", method="", verdict="", confidence="",
                         method_used="", requests=0, evidence="", detail=None):
        """把一次核验的完整结论落 verifications 表（审计 + 误报率统计源）。

        独立成表的原因：一条 finding 可能被核验多次（规则调整后复验），
        findings 行只保留最后一次结论，而这里保留**全部历史**，供
        verify_stats() 统计各漏洞类型的误报率、驱动检测规则收紧。
        detail 为核验器返回的结构化细节，落库前序列化成 JSON 字符串。
        """
        try:
            cur = self._exec(
                "INSERT INTO verifications(finding_id,target,host,url,vuln_type,"
                "param,method,verdict,confidence,method_used,requests,evidence,"
                "detail,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (finding_id, target, host, url, vuln_type, param, method,
                 verdict, confidence, method_used, int(requests or 0), evidence,
                 json.dumps(detail or {}, ensure_ascii=False), time.time()))
            return cur.lastrowid
        except Exception as e:
            log.warning("核验记录落库失败 fid=%s: %s", finding_id, e)
            return None

    def verifications(self, target=None, limit=None):
        """按目标读取核验历史（最近优先），detail 出口还原为 dict。"""
        sql = "SELECT * FROM verifications"
        args = []
        if target:
            sql += " WHERE target=?"
            args.append(target)
        sql += " ORDER BY id DESC"
        if limit:
            sql += " LIMIT ?"
            args.append(int(limit))
        rows = self.query(sql, tuple(args))
        for r in rows:
            if isinstance(r.get("detail"), str):
                try:
                    r["detail"] = json.loads(r["detail"]) or {}
                except Exception:
                    r["detail"] = {}
        return rows

    def verify_stats(self, target=None):
        """按漏洞类型聚合核验结论，返回误报率统计（检测器自我升级的数据源）。

        误报率定义：refuted / (confirmed + refuted)，即**在能判定的样本里**
        有多少被证伪。inconclusive 不参与分母——"无法判定"既不是误报也不是
        真实漏洞，把它算进分母会把误报率稀释成好看但无意义的数字。
        """
        rows = self.verifications(target)
        agg = {}
        for r in rows:
            t = r.get("vuln_type") or "未知"
            d = agg.setdefault(t, {"total": 0, "confirmed": 0, "refuted": 0,
                                   "inconclusive": 0, "not_verified": 0,
                                   "decidable": 0, "false_positive_rate": 0.0})
            d["total"] += 1
            v = r.get("verdict") or ""
            if v in d:
                d[v] += 1
        for t, d in agg.items():
            decidable = d["confirmed"] + d["refuted"]
            # round78 ⑤：decidable=0 时 0.0 表示「无样本可算」，
            # 而不是「无误报」；消费方据此决定是否展示。
            d["decidable"] = decidable
            d["false_positive_rate"] = round(d["refuted"] / float(decidable), 4) \
                if decidable else 0.0
        return agg

    def stats(self, target=None):
        """按等级统计漏洞数。

        round89 FIX-9：原实现只在某个等级**有记录**时才建键，
        空库返回 ``{"total": 0}``、只有 low 时返回 ``{"total": 3, "low": 3}``。
        前端 _renderStats() 与 lab/verify_round34 C2 都假定
        ``critical``/``high`` 恒在，键一缺就报 undefined（本轮清理
        findings.db 后 C2 变红，就是这个结构塌陷暴露出来的）。
        这里把全等级键一次性补齐（缺的填 0），保证返回结构恒定。
        """
        rows = self.all_findings(target)
        out = {"total": len(rows)}
        for sev in ("critical", "high", "medium", "low", "info"):
            out[sev] = 0
        for r in rows:
            key = r["severity"] or "info"
            out[key] = out.get(key, 0) + 1
        return out

    # ---------- 批量删除 ----------
    @staticmethod
    def _norm_ids(ids):
        out = []
        for i in (ids or []):
            try:
                out.append(int(i))
            except Exception:
                continue
        return out

    def _delete_by_ids(self, table, ids):
        ids = self._norm_ids(ids)
        if not ids:
            return 0
        try:
            sql = "DELETE FROM %s WHERE id IN (%s)" % (table, ",".join("?" * len(ids)))
            return self._exec(sql, tuple(ids)).rowcount or 0
        except Exception:
            return 0

    def delete_findings(self, ids):
        return self._delete_by_ids("findings", ids)

    def delete_verifications(self, ids):
        return self._delete_by_ids("verifications", ids)

    def delete_assets(self, ids):
        return self._delete_by_ids("assets", ids)

    # ---------- 断点续扫 ----------
    def mark_scanned(self, url, status=0, length=0, ctype="", h=""):
        try:
            self._exec("INSERT OR REPLACE INTO scanned(url,status,length,ctype,hash,"
                       "created_at) VALUES(?,?,?,?,?,?)",
                       (url, status, length, ctype, h, time.time()))
        except Exception:
            pass

    def is_scanned(self, url):
        return bool(self.query("SELECT 1 FROM scanned WHERE url=?", (url,)))

    def set_progress(self, k, v):
        self._exec("INSERT OR REPLACE INTO progress(k,v,updated_at) VALUES(?,?,?)",
                   (k, json.dumps(v, ensure_ascii=False), time.time()))

    def get_progress(self, k, default=None):
        rows = self.query("SELECT v FROM progress WHERE k=?", (k,))
        if not rows:
            return default
        try:
            return json.loads(rows[0]["v"])
        except Exception:
            return default

    # ---------- 扫描会话存档（进程被关 -> 下次接着跑） ----------
    # 与断点续扫（scanned 表）互补：scanned 决定"URL 层跳不跳"，会话
    # 存档决定"任务层还剩哪些目标没跑"。两者都落 data/，都不进发布包。
    SESSION_KEY = "scan_session"

    def save_session(self, data):
        """整段覆盖写会话档；data 为空/None 即清档（全部跑完时调用）。"""
        try:
            if not data:
                self._exec("DELETE FROM progress WHERE k=?", (self.SESSION_KEY,))
            else:
                self.set_progress(self.SESSION_KEY, dict(data))
            return True
        except Exception:
            return False

    def load_session(self):
        """读会话档；无档或已全部跑完（status=done）返回 None。

        只返回**未完成**的会话，这样"扫描任务完成的不用"由数据层兜住，
        两台前端不必各写一遍同样的判断。
        """
        d = self.get_progress(self.SESSION_KEY, None)
        if not isinstance(d, dict):
            return None
        if str(d.get("status") or "") == "done":
            return None
        if not (d.get("targets") or []):
            return None
        return d

    def clear_session(self):
        return self.save_session(None)

    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass
