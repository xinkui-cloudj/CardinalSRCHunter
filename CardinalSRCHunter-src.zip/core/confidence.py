# -*- coding: utf-8 -*-
"""置信度证据化（主动增强 U-3）。

背景（为什么要做）：
    修复前，各检测点的 confidence 是"按漏洞类型写死的字面量"——
    报错注入永远是 medium、SSRF 永远是 medium、备份泄露永远是 medium。
    但真实证据强度差异很大：
      · 报错注入只回显一个 `SQLSTATE` 弱词 vs 直接吐出
        `You have an error in your SQL syntax`；
      · SSRF 只在页面里出现 `localhost` 一词 vs 真的取回
        `root:x:0:0`（/etc/passwd 内容）或 `redis_version`（Redis INFO）；
      · 备份文件只 HEAD 到 200 vs 真能 GET 回 PK 魔数 / `CREATE TABLE`。
    写死字面量会把"证据很硬"和"证据很软"报成同一档，人工复核成本高。

评分模型（保守，只升不降）：
    每个 kind 定义两张表，表内按**家族**分组：
      · STRONG —— 强特征家族，命中一族视为"独立硬证据"（几乎不可能由
        静态页面或参数回显产生），每族计 2 分；
      · WEAK   —— 弱特征家族，每族最多计 1 分（同源词不重复计数，
        如 loopback 家族的 127.0.0.1 / localhost / ::1 只算一族）。
    证据分 = 强族命中数 * 2 + 弱族命中数。
    仅当 base == "medium" 且 证据分 >= threshold（默认 2）时上调为 high。
    ⇒ 单条弱特征（1 分）不上调；两条**同源**弱特征（仍 1 分）不上调；
      一条强特征或两条**不同家族**弱特征（2 分）才上调。

设计约束：
    - 纯函数、无副作用、不依赖网络与项目其它模块（避免循环导入）；
    - 全部可离线单测；
    - 只做 medium → high 的**上调**，绝不降级，绝不改动其它档位；
    - 评分只读**响应正文**，剥离 dump() 头部的 `HTTP xxx` / `URL: ...`
      行——否则 SSRF 注入地址里的 127.0.0.1 会被当"服务端取回的证据"，
      造成自证式虚高。
"""

# ============================================================
# 报错注入：强 / 弱 特征家族
# ============================================================
SQL_ERROR_STRONG = (
    ("mysql_syntax", ("you have an error in your sql syntax",)),
    ("oracle", ("ora-0",)),
    ("postgres", ("pg_query",)),
    ("sqlite", ("sqlite3::",)),
    ("mssql", ("unclosed quotation mark", "incorrect syntax near",
               "microsoft ole db provider", "odbc sql server driver")),
    ("java", ("java.sql.sqlexception",)),
    ("db_object", ("information_schema", "sqlite_master", "unknown column")),
    ("expr", ("xpath syntax error",)),
)

SQL_ERROR_WEAK = (
    ("mysql", ("sqlstate", "mysql_fetch", "mysqli_", "warning: mysql",
               "valid mysql result", "mysqlsyntaxerrorexception")),
    ("oracle", ("oracle error", "oracle driver")),
    ("postgres", ("postgresql", "valid postgresql result")),
    ("java", ("jdbc", "com.mysql.jdbc")),
    ("generic", ("quoted string not properly terminated",
                 "syntax error in query expression")),
)

# ============================================================
# SSRF：强 / 弱 特征家族
# ============================================================
SSRF_STRONG = (
    ("passwd", ("root:x:0:0",)),
    ("redis", ("redis_version", "redis_mode")),
    ("cloud_meta", ("meta-data", "ami-id", "security-credentials")),
    ("private_key", ("-----begin rsa private key-----",
                     "-----begin openssh private key-----")),
)

SSRF_WEAK = (
    ("loopback", ("127.0.0.1", "localhost", "::1")),
    ("refused", ("connection refused", "connection reset")),
    ("cloud", ("169.254.169.254", "amazon")),
    ("generic", ("ssrf", "file://")),
)

# ============================================================
# 备份 / 源码泄露：强 / 弱 特征家族
# ============================================================
BACKUP_STRONG = (
    ("zip", ("pk\x03\x04",)),
    ("gzip", ("\x1f\x8b",)),
    ("rar", ("rar!\x1a\x07",)),
    ("7z", ("7z\xbc\xaf",)),
    ("private_key", ("-----begin rsa private key-----",
                     "-----begin openssh private key-----")),
    ("ddl", ("create table", "mysqldump")),
)

BACKUP_WEAK = (
    ("dml", ("insert into", "drop table", "sql dump")),
    ("source", ("<?php", "<?xml", "package ", "import ", "def ", "function ")),
    ("cred", ("db_password", "password=", "secret_key", "api_key")),
    ("config", ("spring.datasource", "jdbc:mysql")),
)

# ============================================================
# 弱口令：强 / 弱 特征家族（主动增强 U-5）
# ============================================================
# 弱口令的判定输入是"登录响应"，证据主要落在**响应头**（Set-Cookie /
# Location）与正文（token / 欢迎语 / 控制台链接），因此这一族的评分
# 必须保留响应头（keep_headers=True），否则会漏掉最强的那类证据。
WEAKPASS_STRONG = (
    ("token", ("access_token", "id_token", "authorization: bearer",
               "\"token\"", "'token'")),
    ("jwt", ("eyj",)),                       # JWT 的 base64 头固定以 eyJ 开头
    ("session", ("set-cookie: session", "jsessionid=", "phpsessid=",
                 "asp.net_sessionid", "sessionid=")),
    ("success_kw", ("登录成功", "login success", "welcome back",
                    "signed in", "authenticated")),
    ("console", ("/dashboard", "/admin/index", "/console", "/main.html")),
)

WEAKPASS_WEAK = (
    ("cookie", ("set-cookie:",)),
    ("redirect", ("location: /", "location: http")),
    ("token_word", ("token", "csrf")),
)

# ============================================================
# 未授权访问：强 / 弱 特征家族（主动增强 U-5）
# ============================================================
# 未授权访问的证据是"这个 200 响应到底是不是真后台/真配置"，
# 因此评分要保留响应头（有 Server/Set-Cookie 才像真页面），
# 但必须剔除 URL 行以防自证。
UNAUTH_STRONG = (
    ("phpinfo", ("phpinfo()", "php version =>")),
    ("env_dump", ("document_root", "server_software", "http_user_agent",
                  "path=/usr", "path=/www")),
    ("user_list", ("用户列表", "user list", "管理员列表", "会员列表")),
    ("admin_ui", ("管理后台", "控制台", "dashboard", "admin panel",
                  "系统管理", "后台管理")),
    ("db_panel", ("phpmyadmin", "adminer", "数据库管理", "redis_version",
                  "elasticsearch", "kibana")),
    ("stack", ("traceback (most recent call last)", "stack trace",
               "at java.", "at org.springframework")),
)

UNAUTH_WEAK = (
    ("html", ("<html", "<!doctype")),
    ("json", ("{\"", "[{")),
    ("form", ("<form", "<input", "type=\"password\"")),
)

# ============================================================
# 目录列表泄露：强 / 弱 特征家族（主动增强 U-6）
# ============================================================
# 目录列表（CWE-548）的证据是"响应体本身就是一个可枚举的索引页"，
# 因此只看正文（不需要响应头）。强族取各服务器索引页**独有**的标记，
# 弱族取"像 HTML 页/含链接"这类通用标记——单条弱特征不足以升档。
DIRLIST_STRONG = (
    ("index_page", ("index of /", "<title>directory listing for",
                    "parent directory")),
    ("parent_link", ("<a href=\"..\">", "<a href=\"../\"", ">..<",
                     "[to parent directory]")),
    ("cn_index", ("文件夹</a>", "目录列表", "文件列表", "上级目录")),
)
DIRLIST_WEAK = (
    ("html", ("<html", "<!doctype")),
    ("links", ("<a href=",)),
    ("pre", ("<pre>", "<table")),
)
_STRONG_WEIGHT = 2
_WEAK_WEIGHT = 1

# 证据达标时的"升一档"映射：保守上调，绝不降级。
# 未授权 base=medium → high；弱口令 base=low → medium。
_PROMOTE = {"low": "medium", "medium": "high", "high": "high",
            "critical": "critical"}


def _resp_text(f, keep_headers=False):
    """取 finding 的**响应正文**（小写），剥离 dump() 的头部行。

    dump() 的结构是：
        HTTP 200
        URL: http://...
        Header: value
        <空行>
        <正文>

    URL 行里可能含我们自己的注入地址（SSRF 的 payload 就带
    127.0.0.1 / localhost），若不过滤会被当成"服务端取回的证据"，
    造成自证式虚高。因此这里只保留空行之后的正文。

    keep_headers=True 时保留响应头（仍剥离 `HTTP xxx` / `URL:` 两行）：
    弱口令 / 未授权这类判定的最强证据恰在响应头（Set-Cookie、
    Location、Server），若一刀切只留正文会漏掉它们。
    """
    if not isinstance(f, dict):
        return ""
    raw = f.get("response") or ""
    if not raw:
        return ""
    txt = raw
    head = txt.split("\n", 1)[0]
    looks_dump = (head.startswith("HTTP ") or txt.startswith("URL: ")
                  or "\nURL: " in txt[:400])
    if looks_dump:
        sep = txt.find("\n\n")
        if sep != -1:
            if keep_headers:
                # 保留头部（去掉首行 HTTP 状态与 URL 行），再接正文
                hdr = [ln for ln in txt[:sep].split("\n")
                       if not ln.startswith("URL: ")]
                if hdr and hdr[0].startswith("HTTP "):
                    hdr = hdr[1:]
                txt = "\n".join(hdr) + "\n" + txt[sep + 2:]
            else:
                txt = txt[sep + 2:]
        else:
            lines = [ln for ln in txt.split("\n") if not ln.startswith("URL: ")]
            if lines and lines[0].startswith("HTTP "):
                lines = lines[1:]
            txt = "\n".join(lines)
    return txt.lower()


def count_markers(text, markers):
    """通用工具：统计 text 里命中了几个互不相同的标记（不分组）。"""
    t = (text or "").lower()
    n = 0
    for m in markers:
        if m and m.lower() in t:
            n += 1
    return n


def _hit_families(text, families):
    """统计命中了几"族"特征（同族多个词只计一次，避免同源重复计分）。"""
    n = 0
    for _name, marks in families:
        for m in marks:
            if m in text:
                n += 1
                break
    return n


def _fam_hit(text, families, name):
    """指定名字的家族是否命中（用于跨强/弱族的同源去重）。"""
    for _name, marks in families:
        if _name == name:
            for m in marks:
                if m in text:
                    return True
            return False
    return False


def strength_from(strong_hits, weak_hits):
    """证据分 = 强族命中数 * 2 + 弱族命中数。"""
    return int(strong_hits or 0) * _STRONG_WEIGHT + int(weak_hits or 0) * _WEAK_WEIGHT


def _score(f, strong_families, weak_families, keep_headers=False):
    t = _resp_text(f, keep_headers=keep_headers)
    return (_hit_families(t, strong_families), _hit_families(t, weak_families))


def has_evidence(f, kind=None):
    """是否携带可核验证据（响应正文/头非空）。空证据的项不允许上调。

    kind 为 weakpass / unauth 时证据可能只出现在响应头，故保留头部再判。
    """
    if not isinstance(f, dict):
        return False
    keep = kind in ("weakpass", "unauth")
    return bool(_resp_text(f, keep_headers=keep).strip())


def sql_error_strength(f):
    """报错注入证据分。"""
    s, w = _score(f, SQL_ERROR_STRONG, SQL_ERROR_WEAK)
    return strength_from(s, w)


def ssrf_strength(f):
    """SSRF 证据分。"""
    s, w = _score(f, SSRF_STRONG, SSRF_WEAK)
    return strength_from(s, w)


def backup_strength(f):
    """备份 / 源码泄露证据分。"""
    s, w = _score(f, BACKUP_STRONG, BACKUP_WEAK)
    return strength_from(s, w)


def dirlist_strength(f):
    """目录列表泄露证据分（主动增强 U-6）。

    只看响应正文：索引页的判据全在 body（`Index of /`、`Parent Directory`、
    条目链接），响应头没有区分度。同族多词只计一次，跨族才算独立证据。
    """
    s, w = _score(f, DIRLIST_STRONG, DIRLIST_WEAK)
    return strength_from(s, w)


def weakpass_strength(f):
    """弱口令证据分（保留响应头：Set-Cookie / Location / token 多在头里）。

    跨族同源去重：`Set-Cookie: session=...` 同时命中强族 session 与弱族
    cookie（`set-cookie:`），若不处理会让同一条响应头被计两次（2+1），
    违背"同源不叠加"。强族 session 命中即视为已覆盖弱族 cookie。
    """
    t = _resp_text(f, keep_headers=True)
    s = _hit_families(t, WEAKPASS_STRONG)
    w = _hit_families(t, WEAKPASS_WEAK)
    if _fam_hit(t, WEAKPASS_STRONG, "session") and _fam_hit(t, WEAKPASS_WEAK, "cookie"):
        w -= 1
    return strength_from(s, w)


def unauth_strength(f):
    """未授权访问证据分（保留响应头，剔除 URL 行防自证）。"""
    s, w = _score(f, UNAUTH_STRONG, UNAUTH_WEAK, keep_headers=True)
    return strength_from(s, w)


def raise_if_multi(base, strength, threshold=2):
    """多证据交叉上调：base 为 medium 且证据分 >= threshold 时升为 high。

    只做 medium → high 的上调，不触碰其它档位，也不下调。
    证据不足时原样返回，保持"弱证据不吹高"。
    """
    if base == "medium" and int(strength or 0) >= int(threshold):
        return "high"
    return base


# 各 kind 允许被上调的 base 档位（保守白名单，避免语义漂移）
_KIND_BASE = {
    "sqli_error": ("medium",),
    "ssrf": ("medium",),
    "backup": ("medium",),
    "weakpass": ("low",),
    "unauth": ("medium",),
    "dirlist": ("medium",),
}


def _dynamic_threshold(kind, base=2):
    """Return the effective promote-threshold for kind (FPR-driven).
    Defaults to base; falls back silently when tuning.json is absent.
    """
    try:
        from core import tuning as _t
        return _t.threshold_for(kind, base)
    except Exception:
        return base


def effective_confidence(f, base, kind=None, threshold=None):
    """统一入口：按漏洞类型计算证据化后的置信度。

    kind 取值：
      "sqli_error" —— 报错注入（medium → high）
      "ssrf"       —— SSRF（medium → high）
      "backup"     —— 备份 / 源码泄露（medium → high）
      "weakpass"   —— 弱口令 / 默认凭据（low → medium）
      "unauth"     —— 未授权访问（medium → high）
      None / 其它  —— 不做上调，原样返回 base（保持既有行为）

    规则（保守）：
      1) base 不在该 kind 的白名单内 → 原样返回（不降级、不越档）；
      2) 无证据 → 原样返回；
      3) 证据分 < threshold → 原样返回；
      4) 证据分 >= threshold → 按 _PROMOTE 升一档。
    """
    if threshold is None:
        threshold = _dynamic_threshold(kind)
    allowed = _KIND_BASE.get(kind)
    if not allowed or base not in allowed:
        return base
    if not has_evidence(f, kind=kind):
        return base
    if kind == "sqli_error":
        s = sql_error_strength(f)
    elif kind == "ssrf":
        s = ssrf_strength(f)
    elif kind == "backup":
        s = backup_strength(f)
    elif kind == "weakpass":
        s = weakpass_strength(f)
    elif kind == "unauth":
        s = unauth_strength(f)
    elif kind == "dirlist":
        s = dirlist_strength(f)
    else:
        return base
    if int(s or 0) >= int(threshold):
        return _PROMOTE.get(base, base)
    return base