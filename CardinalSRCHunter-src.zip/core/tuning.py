# -*- coding: utf-8 -*-
"""误报率驱动的检测规则收紧（自我升级的消费层）。

此前数据采集（verifications 表）、统计（db.verify_stats）、展示
（verify_report 的按类型误报率表）都已具备，却没有任何代码去**消费**
统计结果——“建议收紧该规则判定阈值”只是一句写给用户看的文本。

本模块把统计落成可被检测层读取的调参文件 data/tuning.json：某类型
误报率偏高（能判定样本足够且 refuted 占比 >= 阈值）时，上调该类型在
core.confidence 里的**升档阈值**（2 -> 3 -> 4），使证据化升档更难发生，
即实质收紧，同时不破坏 confidence.py “只升不降”的既有约束。

保守约束：
  - 能判定样本 < min_samples 不调参，避免单条样本改行为；
  - 额外阈值上限 MAX_EXTRA，避免脏数据把规则打死；
  - 误报率回落时自动把额外阈值降回来（自愈）；
  - 读不到 / 写不动 tuning.json 一律静默降级为默认阈值。
"""
import json
import os
import time

try:
    from core import config as cfg
    _DATA = cfg.DATA_DIR
except Exception:
    _DATA = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

TUNING_PATH = os.path.join(_DATA, "tuning.json")
BASE_THRESHOLD = 2      # 与 confidence.effective_confidence 默认阈值一致
MIN_SAMPLES = 3         # 能判定样本下限
FPR_THRESHOLD = 0.5     # 误报率触发线
MAX_EXTRA = 2           # 额外阈值上限（2 -> 最多 4）

def _default():
    return {"thresholds": {}, "updated": None, "source": {}}


def load_tuning():
    """读取调参文件；缺失/损坏一律返回默认值（不抛异常）。"""
    d = _default()
    try:
        with open(TUNING_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            th = raw.get("thresholds")
            if isinstance(th, dict):
                for k, v in th.items():
                    try:
                        iv = int(v)
                    except Exception:
                        continue
                    if 0 <= iv <= BASE_THRESHOLD + MAX_EXTRA:
                        d["thresholds"][str(k)] = iv
            d["updated"] = raw.get("updated")
            src = raw.get("source")
            if isinstance(src, dict):
                d["source"] = src
    except Exception:
        pass
    return d


def threshold_for(kind, base=BASE_THRESHOLD):
    """检测层读取入口：返回该 kind 当前生效的升档阈值。"""
    if not kind:
        return base
    try:
        t = load_tuning().get("thresholds", {}).get(str(kind))
        if t is None:
            return base
        t = int(t)
        if t < 0 or t > base + MAX_EXTRA:
            return base
        return t
    except Exception:
        return base


# vuln_type（中文长名）→ confidence kind（短码）映射。
# 静态表用关键词包含匹配，抗描述文字微调；未授权类的中文名来自
# dicts.SENSITIVE_PATHS 的 desc，故在 type_to_kind 里动态核对。
_KIND_HINTS = (
    ("sqli_error", ("sql 报错注入", "sql注入", "报错注入")),
    ("ssrf", ("ssrf", "服务端请求伪造")),
    ("weakpass", ("弱口令", "默认凭据")),
    ("backup", ("备份", "源码文件泄露")),
    ("dirlist", ("目录列表", "目录浏览")),
)


def type_to_kind(vuln_type):
    """把报告里的 vuln_type 映射回证据化置信度的 kind；无映射返回 None。"""
    if not vuln_type:
        return None
    t = str(vuln_type).strip()
    low = t.lower().replace(" ", "")
    for kind, hints in _KIND_HINTS:
        for h in hints:
            if h.lower().replace(" ", "") in low:
                return kind
    try:
        from core import dicts as _d
        for _p, desc, _sev in _d.SENSITIVE_PATHS:
            if desc and desc.strip() == t:
                return "unauth"
    except Exception:
        pass
    return None


def _extra_for(decidable, rate, min_samples=MIN_SAMPLES,
               fpr=FPR_THRESHOLD, max_extra=MAX_EXTRA):
    """根据能判定样本数与误报率算出额外阈值（0..max_extra）。"""
    if decidable < min_samples or rate < fpr:
        return 0
    extra = 1
    if rate >= min(fpr + 0.25, 0.95):
        extra = 2
    return min(extra, max_extra)


def compute_tuning(stats, min_samples=MIN_SAMPLES):
    """把 verify_stats() 的统计换算成每 kind 的**目标**阈值（纯函数，不落盘）。

    返回 {"thresholds": {kind: 目标阈值}, "detail": {kind: {...}},
          "unmapped": [无法映射到 kind 的 vuln_type, ...]}。
    注意：这里给的是「有样本时的目标值」，**不是**最终写盘值 ——
    样本不足或本次没出现的 kind 由 apply_from_stats() 决定保持原值。
    """
    kinds = {}
    unmapped = []
    for vtype, d in (stats or {}).items():
        kind = type_to_kind(vtype)
        if not kind:
            unmapped.append(str(vtype))
            continue
        dec = int(d.get("confirmed", 0)) + int(d.get("refuted", 0))
        ref = int(d.get("refuted", 0))
        k = kinds.setdefault(
            kind, {"decidable": 0, "refuted": 0, "types": {}})
        k["decidable"] += dec
        k["refuted"] += ref
        k["types"][vtype] = {
            "decidable": dec, "refuted": ref,
            "false_positive_rate": d.get("false_positive_rate", 0.0)}
    thresholds = {}
    detail = {}
    for kind, k in kinds.items():
        dec = k["decidable"]
        ref = k["refuted"]
        rate = (ref / float(dec)) if dec else 0.0
        extra = _extra_for(dec, rate, min_samples=min_samples)
        thresholds[kind] = BASE_THRESHOLD + extra
        detail[kind] = {"decidable": dec, "refuted": ref,
                        "false_positive_rate": round(rate, 4),
                        "extra": extra,
                        "sample_enough": dec >= min_samples,
                        "types": k["types"]}
    return {"thresholds": thresholds, "detail": detail,
            "unmapped": unmapped}


def write_tuning(data):
    """把调参结果写入 tuning.json；失败返回 False（不抛）。"""
    try:
        d = os.path.dirname(TUNING_PATH)
        if d and not os.path.isdir(d):
            os.makedirs(d)
        with open(TUNING_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _load_raw():
    """读取 tuning.json 原始内容（用于保留 detail 历史）；失败返回 {}。"""
    try:
        with open(TUNING_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def merge_tuning(prev, target, detail=None, min_samples=MIN_SAMPLES):
    """把「本次算出的目标阈值」合并到「已有阈值」上，返回 (新阈值, 决策表)。

    round93 调参升级的核心：**合并而不是覆盖**。原实现直接
    write_tuning(compute_tuning(stats) 的结果)，一旦某次没有可判定样本
    （例如清库后 verifications 为 0），thresholds 被整份写成 {}，用户
    历史上收紧过的阈值全部丢失 —— 点一次“调参”按钮就丢一次配置。

    规则（每条都可被 verify_round93_tuning 断言）：
      1) 本次样本不足（< min_samples）的 kind —— **保持**已有值，不写不改；
      2) 本次样本足够且目标 > BASE（要收紧）—— 覆盖/新增该 kind；
      3) 本次样本足够且目标 == BASE（误报率已回落）—— **删除**该 kind，
         让它回到默认阈值（原有的自愈语义保留）；
      4) 本次统计里根本没出现的 kind —— 原样保留，绝不因为“没提到”而清掉。
    """
    detail = detail or {}
    out = {}
    for k, v in (prev or {}).items():
        try:
            out[str(k)] = int(v)
        except Exception:
            continue
    decisions = {}
    for kind, t in (target or {}).items():
        info = detail.get(kind) or {}
        if not info.get("sample_enough", False):
            decisions[kind] = "keep"
            continue
        try:
            ti = int(t)
        except Exception:
            decisions[kind] = "keep"
            continue
        if ti > BASE_THRESHOLD:
            out[str(kind)] = ti
            decisions[kind] = "tighten"
        else:
            out.pop(str(kind), None)
            decisions[kind] = "reset"
    for k in out:
        decisions.setdefault(k, "keep")
    return out, decisions


def apply_from_stats(db, dry_run=False, min_samples=MIN_SAMPLES, target=None):
    """从 DB 读核验统计 → 算目标阈值 → **合并**已有阈值 → 按需落盘。

    返回结构化报告（桌面按钮与 CLI 共用同一份结论，不再只有一段文本）：
      thresholds/detail/decisions/changed/written/samples/stats_empty/unmapped
    dry_run=True 只算不写（桌面“试算”用它，绝不碰盘）。
    """
    try:
        stats = db.verify_stats(target)
    except Exception:
        stats = {}
    res = compute_tuning(stats, min_samples=min_samples)
    raw = _load_raw()
    prev_th = load_tuning().get("thresholds") or {}
    prev_detail = raw.get("detail") if isinstance(raw.get("detail"), dict) else {}
    merged, decisions = merge_tuning(prev_th, res["thresholds"], res["detail"],
                                   min_samples=min_samples)
    det = {}
    for kind in sorted(set(list(merged.keys()) + list(res["detail"].keys()))):
        cur = res["detail"].get(kind)
        if cur:
            det[kind] = cur
        elif kind in prev_detail:
            det[kind] = prev_detail[kind]
    changed = bool(merged != prev_th) or bool(det != prev_detail)
    report = {
        "thresholds": merged,
        "detail": det,
        "decisions": decisions,
        "changed": changed,
        "written": False,
        "dry_run": bool(dry_run),
        "samples": len(stats or {}),
        "stats_empty": not bool(stats),
        "unmapped": list(res.get("unmapped") or []),
        "path": TUNING_PATH,
        "base_threshold": BASE_THRESHOLD,
        "min_samples": min_samples,
        "fpr_threshold": FPR_THRESHOLD,
        "max_extra": MAX_EXTRA,
        "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    if dry_run:
        return report
    if report["stats_empty"]:
        # 无任何核验样本：一个字节都不动盘（旧实现正是在这里丢数据）。
        return report
    data = dict(report)
    data["source"] = det
    report["written"] = write_tuning(data)
    return report


def format_report(rep):
    """把结构化结论转成给人看的若干行（CLI 与桌面共用）。"""
    lines = []
    lines.append("[调参] 依据 %d 类核验统计（能判定样本下限 %d，误报率触发线 %.0f%%，阈值上限 %d）"
                 % (rep.get("samples", 0), rep.get("min_samples", MIN_SAMPLES),
                    FPR_THRESHOLD * 100, BASE_THRESHOLD + MAX_EXTRA))
    th = rep.get("thresholds") or {}
    det = rep.get("detail") or {}
    dec = rep.get("decisions") or {}
    label = {"tighten": "收紧", "reset": "回落默认", "keep": "保持"}
    if rep.get("stats_empty"):
        lines.append("  本库暂无核验样本（verifications 为空），阈值全部保持原值，未写盘。")
    for kind in sorted(th):
        d = det.get(kind) or {}
        lines.append("  %-11s 生效阈值 %d（本次：%s；能判定 %d，误报率 %.1f%%%s）"
                     % (kind, th[kind], label.get(dec.get(kind), str(dec.get(kind, "-"))),
                        int(d.get("decidable", 0)),
                        float(d.get("false_positive_rate", 0)) * 100,
                        "" if d.get("sample_enough", True) else "，样本不足"))
    if not th:
        lines.append("  当前没有任何生效阈值（全部类型均为默认 %d）。" % BASE_THRESHOLD)
    if rep.get("unmapped"):
        lines.append("  无法映射到证据化类型的 vuln_type（不参与调参）：%s"
                     % "，".join(rep["unmapped"][:8]))
    lines.append("  结论：%s" % ("有变化" if rep.get("changed") else "无变化（阈值与上次一致）"))
    if rep.get("written"):
        lines.append("  已写入：%s" % rep.get("path"))
    elif rep.get("dry_run"):
        # dry-run 优先标注：用户主动选了「只试算」，即使同时无样本也要说明
        # 这次**本来**不会落盘。
        lines.append("  未写入（dry-run 试算）：%s" % rep.get("path"))
    elif rep.get("stats_empty"):
        lines.append("  未写入（无样本，保持原阈值）：%s" % rep.get("path"))
    else:
        lines.append("  未写入：%s" % rep.get("path"))
    return lines


def cli(args):
    """命令行入口：输出调参结论并按需落盘；返回进程退出码。"""
    from core.db import DB
    if getattr(args, "reset", False):
        try:
            if os.path.exists(TUNING_PATH):
                os.remove(TUNING_PATH)
                print("已删除调参文件，恢复默认阈值：%s" % TUNING_PATH)
            else:
                print("无调参文件，已是默认阈值。")
        except Exception as e:
            print("删除失败：%s" % e)
            return 2
        return 0
    db = DB()
    try:
        rep = apply_from_stats(db, dry_run=bool(getattr(args, "dry_run", False)),
                               target=getattr(args, "target", None))
    finally:
        db.close()
    print("-" * 60)
    for line in format_report(rep):
        print(line)
    if rep.get("written"):
        return 0
    if rep.get("stats_empty") or getattr(args, "dry_run", False):
        return 0
    print("写入失败（权限/磁盘？），本次未生效。")
    return 2
