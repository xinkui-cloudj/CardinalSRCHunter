# -*- coding: utf-8 -*-
"""出网失败自愈：把 netdiag 的确定性归因映射为可执行的自愈动作。

设计边界（重要，改本模块前必读）
--------------------------------
本模块**不含任何模型调用**，全部是确定性规则。三条理由：

1) 延迟：扫描热路径上一次失败要毫秒级决策。一个 63 条敏感路径 + 190 条
   目录字的扫描会产生几百次失败，若每次都调模型做"搜索 + 学习 + 决策"，
   分钟级扫描会变成小时级。
2) 可回归：自愈动作必须可写断言。同一个 code 永远给同一组动作，才能像
   verify_round31 那样用"N 次采样 + 静态守卫"证明它没退化。非确定性
   决策者会让全量回归失去意义。
3) 边界认知：模型不具备 scope.is_allowed / http.rate_limit /
   scan.max_requests_per_host 的边界知识。让它自主决定"下一步发什么
   请求"，等于把授权与限速护栏交给一个看不见它们的组件。

AI 的正确位置在**旁路**：离线扩充字典 / payload / 模板、辅助归因难例、
生成报告文案。产物经人工审核后落盘为静态数据，扫描器只读静态数据——
即"AI 生产知识，规则执行知识"。

已由本模块固化的两个既有认知
----------------------------
· nxdomain 必须 stop：域名确定不存在（见 netdiag.REASONS["nxdomain"]），
  重试只会把 dnsx 已优化的"多数票即下结论 + 拿到 IPv4 即早退"重新变成
  全量等待（首版失败域名要 2.6s 的真凶就是等待而非早退）。
· 本机无 IPv6 路由时 v6 优先会直接连不上，故 dnsx 结果强制"v4 在前"；
  自愈层对应动作是 family_v4_only，而不是"再试一次 v6"。
"""
import json
import os

from . import config as cfg
from . import netdiag

# 外置自愈规则的落盘位置（阶段 1-1）。
# 文件由**人工审核后**生成（见 tools/selfheal_learn.py 产出的草稿），
# 扫描器只读它、不写它——遵守"AI 生产知识、规则执行知识"的红线。
# 该文件不存在时，本模块行为与内置表**逐字节一致**（见 _apply_extra）。
EXTRA_PATH = os.path.join(cfg.DATA_DIR, "selfheal_extra.json")


def _apply_extra(actions, budget, path=None):
    """把外置规则补进内置动作表，**只补不覆盖**。

    参数：
      actions / budget —— 内置的 ACTIONS / _BUDGET（只读，不原地改）。
      path —— 外置 json 路径；默认 EXTRA_PATH（便于单测注入临时文件）。

    返回 (新 actions, 新 budget)。以下任一情况都**原样返回内置表**：
      · 文件不存在 / 不是文件
      · 读取或 JSON 解析失败
      · 顶层不是 dict
    这是"文件不存在时行为逐字节一致"的实现保证——异常一律静默吞掉。

    外置文件格式（所有字段可选）::

        {
          "actions": { "some-new-code": [["dns_rotate", "为什么这么做", {}]] },
          "budget":  { "some-new-code": 2 }
        }

    约束（与 round32 G 组断言一致，违反即忽略该条）：
      · 内置已有的 code 一律跳过（只补不覆盖，防止外置文件改坏既有行为）
      · 动作名 / why 必须是字符串；params 非 dict 时回落 {}
      · 预算必须为正整数，且被钳制到不超过该 code 的动作条数
    """
    try:
        p = path or EXTRA_PATH
        # 阶段 2-3 人审闸门：草稿（*.draft）永不被加载。
        # 学习器（tools/selfheal_learn.py）产出的是 EXTRA_PATH + ".draft"，
        # 必须由人工审核后改名去掉后缀才会走到下面的 open()。这里做显式
        # 拒绝而非依赖「路径恰好不同」，即使调用方把 path 误指到草稿也安全。
        # 契约常量见 core/dicts.py 的 DRAFT_SUFFIX（三处字面一致）。
        if str(p).endswith(".draft"):
            return actions, budget
        if not os.path.isfile(p):
            return actions, budget
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return actions, budget
    if not isinstance(data, dict):
        return actions, budget

    new_a = dict(actions)
    new_b = dict(budget)

    ex_a = data.get("actions")
    if isinstance(ex_a, dict):
        for code, rows in ex_a.items():
            if not isinstance(code, str) or not code:
                continue
            if code in new_a:
                continue                      # 只补不覆盖
            if not isinstance(rows, list):
                continue
            items = []
            for r in rows:
                if (isinstance(r, (list, tuple)) and len(r) >= 2
                        and isinstance(r[0], str) and isinstance(r[1], str)):
                    prm = r[2] if len(r) > 2 and isinstance(r[2], dict) else {}
                    items.append((r[0], r[1], dict(prm)))
            if items:
                new_a[code] = items

    ex_b = data.get("budget")
    if isinstance(ex_b, dict):
        for code, n in ex_b.items():
            if code not in new_a or code in new_b:
                continue
            try:
                n = int(n)
            except Exception:
                continue
            if n > 0:
                new_b[code] = min(n, len(new_a[code]))

    # 兜底：任何新增 code 若未声明预算，给不超过动作条数的默认值
    # （保证 round32 G4"预算不超过动作表长度"恒成立）。
    for code, rows in new_a.items():
        if code not in new_b:
            new_b[code] = min(3, len(rows))
    return new_a, new_b


# 动作字典：code -> [(action, why, params), ...]
# 顺序即执行优先级；调用方按预算截断，不改变内部顺序。
ACTIONS = {
    # —— 确定性失败：不重试，直接停 ——
    "nxdomain": [
        ("stop", "域名确定不存在：有限域名联想已在探测层完成（probe_host 调 "
                 "dnsx.probe_variants，只发 DNS 不发 HTTP、不占主机请求预算）；"
                 "联想后仍无候选可解析才停，有命中则 should_stop 返回 False 改用该形态", {}),
    ],
    "nodata": [
        ("try_www", "域名存在但无 A/AAAA，常见于仅 www 形态有解析", {}),
        ("dns_rotate", "换解析池确认是否为单池缓存问题", {}),
        ("stop_if_exhausted", "两次动作后仍 nodata 即停止，不占用重试预算", {}),
    ],

    # —— 解析层失败：换池 / 回退系统解析 / 分离双栈 ——
    "dns": [
        ("dns_rotate", "换一组解析服务器（默认池 223.5.5.5 / 119.29.29.29 / 180.76.76.76）", {}),
        ("socket_fallback", "退化到系统 getaddrinfo（dnsx._socket_fallback 同路径）", {}),
        ("family_v4_only", "本机无 IPv6 路由时，v6 优先会直接连不上", {}),
    ],

    # —— 连接层失败 ——
    "timeout": [
        ("port_retry", "80/443 互换再试（协议错配常表现为超时）", {"ports": [443, 80]}),
        ("slow_down", "降速：可能被链路侧限速吞包", {"factor": 1.5}),
        ("proxy_hint", "TCP 无响应常见于需代理 / VPN 出口", {}),
    ],
    "refused": [
        ("port_retry", "端口未开放，换端口确认服务真实监听口", {"ports": [443, 80, 8080, 8443]}),
        ("stop_if_exhausted", "端口全部未开放即停止，不反复打同一端口", {}),
    ],
    "reset": [
        ("slow_down", "RST 注入（WAF / 运营商拦截），降速可绕过触发阈值", {"factor": 2.0}),
        ("proxy_hint", "换出口可规避链路侧 RST 注入", {}),
    ],
    "noroute": [
        ("proxy_hint", "本机到该网段无路由，需 VPN / 代理", {}),
        ("stop", "无路由时本地重试不可能成功，交给出口层处理", {}),
    ],
    "tls": [
        ("scheme_retry", "证书或协议版本不兼容时，退回 http 再试", {"schemes": ["https", "http"]}),
    ],
    "http": [
        ("slow_down", "TCP 已连通，反爬 / 限速导致的 HTTP 层失败靠降速化解", {"factor": 1.5}),
        ("rotate_ua", "换 User-Agent 规避简单指纹拦截", {}),
    ],
    "connect": [
        ("family_v4_only", "目标可能仅 IPv6 可达，先锁定单栈排除干扰", {}),
        ("port_retry", "重试耗尽后换端口确认", {"ports": [443, 80]}),
        ("stop_if_exhausted", "重试预算用尽即停止", {}),
    ],
    "unknown": [
        ("dns_rotate", "未归类失败先换池排除解析干扰", {}),
        ("slow_down", "再降速一轮", {"factor": 1.5}),
        ("stop_if_exhausted", "两轮无效即停止，不消耗更多请求预算", {}),
    ],
}

# 每个 code 允许的最大动作数（防止自愈本身变成无限重试）。
_BUDGET = {
    "nxdomain": 1, "nodata": 3, "dns": 3, "timeout": 3, "refused": 2,
    "reset": 2, "noroute": 2, "tls": 1, "http": 2, "connect": 3, "unknown": 3,
}
# 允许在自愈中"再发一次请求"的动作。stop / *_hint 类不产生请求。
_SENDING = ("try_www", "port_retry", "scheme_retry", "rotate_ua")

# 阶段 1-1：把人工审核后的外置规则补进来（只补不覆盖）。
# 放在 _SENDING 之后，是因为 _apply_extra 需要同时改 ACTIONS / _BUDGET，
# 而 _BUDGET 定义在 ACTIONS 之后。文件不存在时这两行是空操作，
# 模块对外行为与改造前逐字节一致（round32 全部 11 项断言仍绿）。
ACTIONS, _BUDGET = _apply_extra(ACTIONS, _BUDGET)



def plan(diag):
    """把一次 netdiag.diagnose 结果映射为自愈动作列表。

    参数：diag 为 netdiag.diagnose() 返回的 dict（可只带 code 字段）。
    返回：[{"action":..., "why":..., "params":{...}}, ...]，已按预算截断。
    """
    code = (diag or {}).get("code") or "unknown"
    # round57：域名 NXDOMAIN 但联想出可解析形态时不能只 stop —— probe 层已算好
    # 的 variants 必须在自愈层被消费，否则能力空转（用户复测"扫不了"的根因）。
    # 无 variants 时与改造前逐字节一致（round32 H1 / round36 M9 锁死）。
    if code == "nxdomain":
        _vars = [str(v) for v in ((diag or {}).get("variants") or []) if str(v).strip()]
        if _vars:
            return [{"action": "switch_variant",
                     "why": "域名 NXDOMAIN，但联想出可解析形态，改用该形态继续扫描",
                     "params": {"hosts": _vars}}]
    acts = ACTIONS.get(code)
    if not acts:
        code, acts = "unknown", ACTIONS["unknown"]
    out = []
    for a, why, prm in acts[:_BUDGET.get(code, 3)]:
        out.append({"action": a, "why": why, "params": dict(prm)})
    return out


def sends_requests(action):
    """该动作是否会额外产生网络请求（供 max_requests_per_host 预算扣减）。"""
    return action in _SENDING


def request_cost(actions):
    """一组动作预计产生的额外请求数。调用方用它扣减主机请求预算。"""
    return sum(1 for a in (actions or []) if sends_requests(a.get("action")))


def should_stop(diag):
    """该失败是否属于"确定性、不该重试"。

    nxdomain：域名不存在时，探测层（probe_host）已做一次零成本有限域名联想
    （近音/近形/跨 TLD、只发 DNS 不发 HTTP、不占主机请求预算）。联想后仍无任何
    候选可解析，才算确定性失败；有候选命中则返回 False，让调用方改用该形态继续。
    这样既保住"不做全量等待"的优化，又不会把"域名拼错 / 换了 TLD"直接判死。
    """
    d = diag or {}
    if (d.get("code") or "") != "nxdomain":
        return False
    # 探测层已完成域名级联想：命中候选即不判死，无候选才算确定性失败。
    return not (d.get("variants") or [])


def describe(actions):
    """把动作列表压成一行，供日志 / 报告展示。"""
    if not actions:
        return "无自愈动作"
    return " → ".join(a["action"] for a in actions)
