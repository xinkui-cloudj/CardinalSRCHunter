# -*- coding: utf-8 -*-
"""内置数据字典：指纹 / 路径 / 凭据 / 子域 / payload。

全部为静态数据，不依赖网络，保证离线可用。
"""

# ============================================================
# 1. 组件指纹（正则 → 名称, 分类）
# ============================================================
FINGERPRINTS = [
    # 国产 OA
    ("致远OA", r"/seeyon/|seeyon\.|A8-V5|协同管理软件|com\.seeyon", "OA"),
    ("泛微OA", r"/weaver/|ecology|泛微|e-cology|weaver\.", "OA"),
    ("通达OA", r"通达OA|Office Anywhere|/general/|MYOA", "OA"),
    ("万户OA", r"/defaultroot/|万户|ezOFFICE", "OA"),
    ("蓝凌OA", r"/sys/ui/|蓝凌|landray|EKP", "OA"),
    ("华天动力OA", r"华天动力|htoa|/oa/htoa", "OA"),
    ("用友NC", r"/nc/|用友|yonyou|UAP-NC", "ERP"),
    ("用友U8", r"U8Cloud|/u8/|用友U8", "ERP"),
    ("金蝶EAS", r"金蝶|kingdee|/eas/|apusic", "ERP"),
    ("金蝶K3", r"K3Cloud|/k3cloud/", "ERP"),
    # 中间件
    ("Apache Tomcat", r"Apache-Coyote|Tomcat", "中间件"),
    ("Nginx", r"nginx", "中间件"),
    ("Apache httpd", r"Apache/2\.", "中间件"),
    ("IIS", r"Microsoft-IIS", "中间件"),
    ("Weblogic", r"WebLogic|weblogic", "中间件"),
    ("JBoss", r"JBoss|jboss", "中间件"),
    ("Jetty", r"Jetty", "中间件"),
    # 框架 / 语言
    ("Spring Boot", r"Whitelabel Error Page|/actuator|spring", "框架"),
    ("Shiro", r"rememberMe=|shiro", "框架"),
    ("Struts2", r"struts|\.action|\.do", "框架"),
    ("ThinkPHP", r"ThinkPHP|thinkphp", "框架"),
    ("Laravel", r"laravel_session|Laravel", "框架"),
    ("Django", r"csrfmiddlewaretoken|django", "框架"),
    ("Flask", r"Werkzeug|flask", "框架"),
    ("PHP", r"X-Powered-By: PHP|PHPSESSID", "语言"),
    ("ASP.NET", r"ASP\.NET|__VIEWSTATE|__EVENTVALIDATION", "语言"),
    ("JSP", r"JSESSIONID", "语言"),
    # 数据库 / 服务
    ("Redis", r"redis_version|Redis", "数据库"),
    ("MySQL", r"mysql|MariaDB", "数据库"),
    ("Elasticsearch", r"you know, for search|elasticsearch", "数据库"),
    ("MongoDB", r"mongodb|It looks like you are trying to access MongoDB", "数据库"),
    ("Nacos", r"nacos|Nacos", "服务"),
    ("Druid", r"Druid Stat|druid", "服务"),
    ("Consul", r"Consul by HashiCorp|consul", "服务"),
    ("Zookeeper", r"zookeeper", "服务"),
    ("Jenkins", r"Jenkins|X-Jenkins", "CI/CD"),
    ("GitLab", r"GitLab|gitlab", "CI/CD"),
    ("Grafana", r"grafana", "监控"),
    ("Kibana", r"kibana", "监控"),
    ("Prometheus", r"Prometheus", "监控"),
    ("Zabbix", r"Zabbix|zb_system", "监控"),
    # 安全设备 / WAF
    ("宝塔面板", r"Bt-Panel|宝塔|bt\.", "面板"),
    ("phpMyAdmin", r"phpMyAdmin|pma_", "面板"),
    ("Adminer", r"Adminer", "面板"),
    ("Kubernetes Dashboard", r"kubernetes-dashboard", "容器"),
    ("Swagger", r"swagger-ui|Swagger UI", "文档"),
    ("Jolokia", r"jolokia", "JMX"),
    ("Harbor", r"harbor", "容器"),
    ("RabbitMQ", r"RabbitMQ", "服务"),
    ("XXL-JOB", r"xxl-job", "任务调度"),
    ("Fastjson", r"fastjson", "组件"),
    ("ShardingSphere", r"ShardingSphere", "组件"),
    ('帆软报表', 'FineReport|fr_dialog|帆软', '报表'),
    ('润乾报表', 'raqsoft|润乾', '报表'),
    ('金和OA', 'jinher|/jc6/|金和', 'OA'),
    ('红帆OA', 'iOffice|hongfan|红帆', 'OA'),
    ('泛微e-office', 'e-office|eo_web', 'OA'),
    ('致远A6', 'A6-V5|/seeyon/a6', 'OA'),
    ('若依RuoYi', 'ruoyi|RuoYi', '框架'),
    ('JEECG', 'jeecg|jeecg-boot', '框架'),
    ('SpringBlade', 'SpringBlade|blade-auth', '框架'),
    ('Guns框架', 'guns-admin', '框架'),
    ('用友GRP-U8', 'GRP-U8|/u8qx/', 'ERP'),
    ('浪潮GS', 'inspur|/gs/', 'ERP'),
    ('东软平台', 'neusoft', 'ERP'),
    ('金蝶Apusic', 'apusic', '中间件'),
    ('WebSphere', 'WebSphere', '中间件'),
    ('Undertow', 'Undertow', '中间件'),
    ('Resin', 'Resin', '中间件'),
    ('WildFly', 'WildFly', '中间件'),
    ('OpenResty', 'openresty', '中间件'),
    ('Tengine', 'Tengine', '中间件'),
    ('Caddy', 'Caddy', '中间件'),
    ('LiteSpeed', 'LiteSpeed', '中间件'),
    ('Kestrel', 'Kestrel', '中间件'),
    ('Gunicorn', 'gunicorn', '中间件'),
    ('uWSGI', 'uWSGI', '中间件'),
    ('Waitress', 'waitress', '中间件'),
    ('Traefik', 'Traefik', '中间件'),
    ('Envoy', 'envoy', '中间件'),
    ('PostgreSQL', 'PostgreSQL', '数据库'),
    ('Oracle', 'Oracle|XDB', '数据库'),
    ('SQLServer', 'Microsoft SQL Server', '数据库'),
    ('ClickHouse', 'ClickHouse', '数据库'),
    ('InfluxDB', 'InfluxDB', '数据库'),
    ('Cassandra', 'Cassandra', '数据库'),
    ('CouchDB', 'CouchDB', '数据库'),
    ('Memcached', 'Memcached', '数据库'),
    ('etcd', 'etcd', '服务'),
    ('Kafka', 'kafka', '服务'),
    ('RocketMQ', 'RocketMQ', '服务'),
    ('ActiveMQ', 'ActiveMQ', '服务'),
    ('Pulsar', 'Pulsar', '服务'),
    ('Solr', 'Solr', '数据库'),
    ('MinIO', 'MinIO', '存储'),
    ('Nexus', 'Nexus Repository', 'CI/CD'),
    ('SonarQube', 'SonarQube', 'CI/CD'),
    ('Neo4j', 'Neo4j', '数据库'),
]

# ============================================================
# 2. 高价值未授权 / 信息泄露路径
# ============================================================
SENSITIVE_PATHS = [
    # Spring Boot Actuator
    ("/actuator", "Spring Boot Actuator 暴露", "high"),
    ("/actuator/env", "Actuator env 环境变量泄露", "critical"),
    ("/actuator/heapdump", "Actuator heapdump 堆转储泄露", "critical"),
    ("/actuator/beans", "Actuator beans 信息泄露", "medium"),
    ("/actuator/mappings", "Actuator 路由泄露", "medium"),
    ("/actuator/health", "Actuator health", "info"),
    ("/actuator/configprops", "Actuator configprops 配置泄露", "high"),
    ("/env", "env 环境变量泄露", "high"),
    ("/heapdump", "heapdump 泄露", "critical"),
    ("/trace", "trace 请求记录泄露", "medium"),
    # API 文档
    ("/swagger-ui.html", "Swagger UI 未授权", "medium"),
    ("/swagger-ui/index.html", "Swagger UI 未授权", "medium"),
    ("/v2/api-docs", "Swagger api-docs 泄露", "medium"),
    ("/v3/api-docs", "OpenAPI 文档泄露", "medium"),
    ("/api-docs", "API 文档泄露", "medium"),
    ("/doc.html", "Knife4j 文档泄露", "medium"),
    # 配置 / 源码
    ("/.git/config", ".git 源码泄露", "critical"),
    ("/.git/HEAD", ".git 源码泄露", "critical"),
    ("/.svn/entries", ".svn 源码泄露", "high"),
    ("/.env", ".env 配置泄露", "critical"),
    ("/.env.bak", ".env 备份泄露", "critical"),
    ("/config.php.bak", "PHP 配置备份泄露", "high"),
    ("/web.config", "web.config 泄露", "medium"),
    ("/application.yml", "Spring 配置泄露", "critical"),
    ("/application.properties", "Spring 配置泄露", "critical"),
    ("/bootstrap.yml", "Spring 配置泄露", "critical"),
    ("/backup.sql", "数据库备份泄露", "critical"),
    ("/www.zip", "网站源码包泄露", "critical"),
    ("/wwwroot.zip", "网站源码包泄露", "critical"),
    ("/robots.txt", "robots 路径泄露", "info"),
    ("/sitemap.xml", "sitemap", "info"),
    # 中间件 / 服务
    ("/druid/index.html", "Druid 监控未授权", "high"),
    ("/druid/websession.html", "Druid Session 监控", "high"),
    ("/nacos/", "Nacos 未授权", "critical"),
    ("/nacos/v1/auth/users", "Nacos 用户列表泄露", "critical"),
    ("/console/", "Weblogic 控制台", "medium"),
    ("/jenkins/", "Jenkins 未授权", "high"),
    ("/script", "Jenkins script 控制台", "critical"),
    ("/manager/html", "Tomcat Manager", "high"),
    ("/host-manager/html", "Tomcat Host Manager", "high"),
    ("/solr/", "Solr 未授权", "high"),
    ("/geoserver/web/", "GeoServer 未授权", "high"),
    ("/harbor/projects", "Harbor 项目列表", "medium"),
    ("/api/v1/namespaces", "K8s API 未授权", "critical"),
    # 面板
    ("/phpmyadmin/", "phpMyAdmin", "medium"),
    ("/adminer.php", "Adminer", "medium"),
    ("/pma/", "phpMyAdmin", "medium"),
    # 其它
    ("/api/v1/users", "用户列表接口", "medium"),
    ("/api/user/list", "用户列表接口", "medium"),
    ("/actuator/gateway/routes", "Spring Gateway 路由泄露", "high"),
    ("/jolokia/list", "Jolokia MBean 列表", "high"),
    ("/metrics", "Prometheus metrics", "low"),
    ("/debug/pprof/", "Go pprof 泄露", "high"),
    ("/server-status", "Apache server-status", "low"),
    ("/nginx_status", "Nginx status", "low"),
    ("/WEB-INF/web.xml", "web.xml 泄露", "high"),
    ("/WEB-INF/classes/", "class 目录列举", "high"),
    ("/swagger-resources", "Swagger resources", "low"),
    ("/v1/users", "API v1 用户", "medium"),
    ("/user/list", "用户列表", "medium"),
    ("/admin/", "管理后台", "info"),
    ("/manage/", "管理后台", "info"),
    ("/system/", "系统管理", "info"),
    # round87c: 新增敏感路径（Actuator 扩展/云控制台/备份包）
    ("/actuator/jolokia", "Jolokia MBean 暴露", "critical"),
    ("/actuator/threaddump", "线程堆栈泄露", "medium"),
    ("/actuator/httptrace", "HTTP 请求追踪泄露", "high"),
    ("/actuator/auditevents", "审计事件泄露", "medium"),
    ("/actuator/loggers", "日志级别可被改", "medium"),
    ("/actuator/caches", "缓存信息泄露", "low"),
    ("/actuator/scheduledtasks", "定时任务泄露", "low"),
    ("/actuator/shutdown", "Actuator 停机端点开放", "critical"),
    ("/nacos/v1/console/health/readiness", "Nacos 就绪探针", "info"),
    ("/eureka/apps", "Eureka 服务列表泄露", "medium"),
    ("/.well-known/security.txt", "安全联系信息", "info"),
    ("/phpinfo.php", "phpinfo 暴露", "high"),
    ("/.env.local", ".env.local 泄露", "critical"),
    ("/.env.production", ".env.production 泄露", "critical"),
    ("/.svn/wc.db", "SVN wc.db 可读", "high"),
    ("/META-INF/MANIFEST.MF", "MANIFEST.MF 泄露", "low"),
    ("/wwwroot.rar", "站点源码压缩包", "critical"),
    ("/db.sql", "数据库导出文件", "critical"),
]

# ============================================================
# 3. 默认凭据（国产 OA / 中间件）
# ============================================================
DEFAULT_CREDS = [
    ("admin", "admin"), ("admin", "123456"), ("admin", "admin123"),
    ("admin", "admin888"), ("admin", "password"), ("admin", "12345678"),
    ("admin", "admin@123"), ("root", "root"), ("root", "123456"),
    ("test", "test"), ("guest", "guest"), ("system", "system"),
    ("sa", ""), ("sa", "sa"), ("weblogic", "weblogic"),
    ("tomcat", "tomcat"), ("manager", "manager"), ("nacos", "nacos"),
    ("jenkins", "jenkins"), ("zhangsan", "123456"),
]

# ============================================================
# 4. 子域名字典（高频 + 通用）
# ============================================================
SUBDOMAIN_WORDS = [
    # dedup r87d (391)
    'www', 'mail', 'webmail', 'smtp', 'pop', 'imap', 'mx', 'ns1', 'ns2', 'api', 'open',
    'openapi', 'gateway', 'gw', 'service', 'services', 'admin', 'manage', 'manager',
    'management', 'console', 'dashboard', 'test', 'testing', 'dev', 'develop',
    'development', 'debug', 'demo', 'stage', 'staging', 'uat', 'pre', 'preview', 'beta',
    'alpha', 'gray', 'prod', 'production', 'release', 'online', 'app', 'apps', 'm',
    'mobile', 'wap', 'web', 'portal', 'home', 'shop', 'mall', 'store', 'pay', 'payment',
    'order', 'trade', 'user', 'member', 'vip', 'crm', 'erp', 'oa', 'hr', 'sso', 'auth',
    'login', 'passport', 'account', 'id', 'oauth', 'cas', 'git', 'gitlab', 'github', 'svn',
    'jenkins', 'ci', 'cd', 'build', 'deploy', 'docker', 'k8s', 'rancher', 'harbor',
    'registry', 'nexus', 'maven', 'db', 'mysql', 'redis', 'mongo', 'es', 'elastic',
    'kibana', 'grafana', 'log', 'logs', 'elk', 'zabbix', 'nagios', 'prometheus', 'monitor',
    'static', 'cdn', 'img', 'image', 'images', 'pic', 'file', 'files', 'upload',
    'download', 'resource', 'assets', 'media', 'video', 'oss', 's3', 'vpn', 'fw',
    'firewall', 'proxy', 'ns', 'dns', 'ldap', 'ad', 'dc', 'backup', 'bak', 'old', 'new',
    'temp', 'tmp', 'cache', 'cache1', 'blog', 'news', 'help', 'support', 'kf', 'service1',
    'callcenter', 'weixin', 'wechat', 'qq', 'weibo', 'alipay', 'unionpay', 'internal',
    'intranet', 'office', 'vpn2', 'remote', 'rdp', 'data', 'bi', 'report', 'reports',
    'stat', 'stats', 'analytics', 'search', 's', 'es2', 'solr', 'mq', 'rabbit', 'kafka',
    'zk', 'msg', 'message', 'sms', 'email', 'push', 'notify', 'school', 'edu', 'training',
    'learn', 'study', 'gov', 'public', 'info', 'news2', 'notice', 'announce', 'console2',
    'manage2', 'mgmt', 'itsm', 'jira', 'wiki', 'confluence', 'gitlab2', 'svn2', 'repo',
    'maven2', 'nuget', 'npm', 'pypi', 'artifactory', 'jump', 'jumpserver', 'bastion',
    'fort', 'citrix', 'vdi', 'ops', 'devops', 'sre', 'pe', 'infra', 'ops1', 'ops2',
    'zabbix2', 'skywalking', 'pinpoint', 'apm', 'trace2', 'otel', 'jaeger', 'sentinel',
    'dubbo', 'dubboadmin', 'eureka', 'nacos', 'apollo', 'config', 'configserver', 'xxljob',
    'quartz', 'flow', 'workflow', 'bpm', 'activiti', 'form', 'report2', 'finebi',
    'finereport', 'bi2', 'dw', 'hive', 'spark', 'flink', 'kafka2', 'rocketmq', 'rabbitmq',
    'minio', 'ceph', 'hdfs', 'nas', 'ftp', 'sftp', 'smb', 'share', 'crm2', 'scrm', 'cms',
    'ecm', 'pms', 'wms', 'tms', 'oms', 'pos', 'invoice', 'contract', 'seal', 'esign',
    'finance', 'fms', 'budget', 'edu2', 'examine', 'exam', 'lms', 'mooc', 'course',
    'class', 'med', 'his', 'lis', 'pacs', 'emr', 'clinic', 'hospital', 'gov2', 'zwdt',
    'zwfw', '12345', 'govopen', 'zww', 'zwgk', 'iot', 'mqtt', 'emqx', 'device', 'devices',
    'gps', 'lbs', 'geo', 'video2', 'live', 'stream', 'rtmp', 'hls', 'vod', 'player', 'im',
    'chat', 'meeting', 'conf', 'zoom', 'rtc', 'webinar', 'mail2', 'exchange', 'owa',
    'zimbra', 'postfix', 'sendmail', 'proxy2', 'nginx', 'haproxy', 'apigateway', 'kong',
    'zuul', 'gateway2', 'cmdb', 'itsm2', 'servicedesk', 'ticket', 'helpdesk', 'u', 'uac',
    'uaa', 'keycloak', 'auth2', 'oauth2', 'oidc', 'saml', 'sms2', 'mms', 'wechat2',
    'miniapp', 'mp', 'official', 'stat2', 'tongji', 'umeng', 'track', 'tracking',
    'collect', 'pub', 'open2', 'partner', 'agent', 'channel', 'dealer', 'supplier', 'apk',
    'ipa', 'android', 'ios', 'h5', 'pc', 'web2', 'site', 'sandbox', 'lab', 'poc',
    'pentest', 'sec', 'soc', 'siem', 'waf', 'dev1', 'dev2', 'dev3', 'test1', 'test2',
    'test3', 'uat1', 'uat2', 'gray1', 'pre1', 'pre2', 'release1', 'prod1', 'prod2', 'bak2',
    'old2',
]

# ============================================================
# 5. 目录爆破字典
# ============================================================
# 目录列表泄露特征（主动增强 U-6）：判定"页面像不像可枚举的索引页"。
# 与"备份文件泄露"互为线索但口径不同——后者看**文件内容像不像备份**，
# 前者看**页面像不像索引**。同族多词只计一次，跨族才算独立证据。
DIR_LIST_MARKERS = (
    # nginx / Apache 经典索引页
    ("apache_nginx", ("index of /", "parent directory", "<title>index of")),
    # Python http.server / SimpleHTTPServer
    ("python_simplehttp", ("<title>directory listing for",)),
    # 中文"文件夹/目录"列表页
    ("cn_folder", ("文件夹</a>", "文件列表", "目录列表", "上级目录")),
    # IIS 目录浏览
    ("iis_dirbrowse", ("[to parent directory]", "directory listing for /")),
)
DIR_WORDS = [
    # dedup r87d (340)
    'admin', 'administrator', 'manage', 'manager', 'management', 'console', 'login',
    'signin', 'logon', 'auth', 'sso', 'user', 'users', 'account', 'api', 'apis', 'v1',
    'v2', 'v3', 'rest', 'graphql', 'rpc', 'soap', 'upload', 'uploads', 'download',
    'downloads', 'file', 'files', 'static', 'assets', 'public', 'private', 'secret',
    'backup', 'bak', 'old', 'temp', 'test', 'tests', 'dev', 'debug', 'demo', 'example',
    'sample', 'config', 'conf', 'setting', 'settings', 'install', 'setup', 'installer',
    'log', 'logs', 'error', 'errors', 'trace', 'debug.log', 'app.log', 'docs', 'doc',
    'document', 'documentation', 'help', 'readme', 'changelog', 'status', 'health',
    'healthz', 'ping', 'version', 'info', 'metrics', 'swagger', 'swagger-ui.html',
    'api-docs', 'openapi.json', 'doc.html', 'actuator', 'env', 'beans', 'heapdump',
    'mappings', 'configprops', 'druid', 'nacos', 'jenkins', 'gitlab', 'harbor', 'grafana',
    'kibana', '.git', '.svn', '.env', '.htaccess', 'web.config', 'robots.txt',
    'sitemap.xml', 'crossdomain.xml', 'phpinfo.php', 'info.php', 'test.php', 'index.php',
    'index.jsp', 'index.action', 'home', 'main', 'dashboard', 'portal', 'cms', 'wp-admin',
    'wp-login.php', 'phpmyadmin', 'pma', 'server-status', 'nginx_status', 'WEB-INF',
    'META-INF', 'classes', 'js', 'css', 'img', 'images', 'fonts', 'media', 'video',
    'audio', 'report', 'reports', 'export', 'import', 'sync', 'task', 'job', 'cron',
    'system', 'sys', 'monitor', 'stat', 'stats', 'analyze', 'analysis', 'search', 'query',
    'list', 'detail', 'info2', 'get', 'post', 'put', 'webhook', 'callback', 'notify',
    'hook', 'ws', 'websocket', 'socket', 'proxy', 'forward', 'redirect', 'link', 'url',
    'jump', 'go', 'order', 'orders', 'pay', 'payment', 'refund', 'invoice', 'bill', 'cart',
    'shop', 'goods', 'product', 'products', 'item', 'items', 'member', 'members',
    'profile', 'avatar', 'message', 'messages', 'comment', 'comments', 'feedback',
    'contact', 'about', 'faq', 'adminer', 'phpmyadmin2', 'admin2', 'sysadmin',
    'superadmin', 'eureka', 'hystrix', 'swagger2', 'redoc', 'rapidoc', 'knife4j', 'doc2',
    'api2', 'openapi2', 'jolokia', 'jmx', 'jolokia2', 'mbeans', 'threaddump', 'gc',
    'sessions', 'trace2', 'httptrace', 'auditevents', 'logfile', 'loggers', 'caches',
    'quartz2', 'scheduledtasks', 'flyway', 'liquibase', 'shutdown', 'restart',
    'uploadfile', 'uploadfiles', 'downloadfile', 'downloads2', 'fileupload', 'excel',
    'csv', 'download2', 'print', 'ueditor', 'uploader', 'kindeditor', 'ckeditor',
    'fckeditor', 'jsp', 'elFinder', 'filemanager', 'elfinder2', 'tinymce', 'console2',
    'terminal', 'shell', 'webshell', 'cmd', 'exec', 'run', 'phpinfo2', 'i.php', 'a.php',
    'index2', 'home2', 'default', 'portals', 'login2', 'logout', 'register', 'signup',
    'findpassword', 'resetpwd', 'captcha', 'kaptcha', 'verify', 'sendmail2', 'sendcode',
    'sms2', 'rest2', 'restful', 'grpc', 'io', 'h5', 'mp', 'miniapp', 'weapp', 'wx',
    'alipay2', 'pay2', 'notify2', 'health2', 'readyz', 'livez', 'readiness', 'liveness',
    'probe', 'metrics2', 'prometheus', 'actuator2', 'datadog', 'clientaccesspolicy.xml',
    'security.txt', 'humans.txt', 'manifest.json', 'service-worker.js', '.well-known',
    'well-known', 'adfs', 'microsoft', 'azure', 'aws', 's3', 'oss2', 'cos', 'obs',
    'bucket', 'buckets', 'blob', 'files2', 'storage', 'vault', 'secret2', 'secrets',
    'keys', 'certs', 'ca', 'install2', 'installer2', 'upgrade', 'update', 'patch',
    'migrate', 'data', 'db', 'mysql', 'sql', 'sqlite', 'dump', 'export2', 'backup2',
    'jobs', 'scheduler', 'queue', 'worker', 'consumer', 'debug2', 'profiler',
    'phpmyadmin3', 'admin-login', 'login-admin',
]

# ============================================================
# 6. 敏感文件扩展名（目录发现命中后二次探测）
# ============================================================
SENSITIVE_EXTS = [
    ".bak", ".old", ".orig", ".save", ".swp", ".tmp", ".temp", ".copy",
    ".zip", ".rar", ".tar", ".tar.gz", ".tgz", ".7z", ".gz", ".sql",
    ".txt", ".log", ".json", ".xml", ".yml", ".yaml", ".ini", ".conf",
    "~", ".1", ".2", ".php.bak", ".jsp.bak", ".asp.bak",
]

# ============================================================
# 7. 子域接管指纹（CNAME 指向 + 未注册特征）
# ============================================================
TAKEOVER_SIGNS = [
    ("github.io", "There isn't a GitHub Pages site here"),
    ("herokuapp.com", "No such app"),
    ("herokussl.com", "No such app"),
    ("s3.amazonaws.com", "NoSuchBucket"),
    ("cloudfront.net", "Bad request"),
    ("azurewebsites.net", "404 Web Site not found"),
    ("cloudapp.net", "404 Web Site not found"),
    ("trafficmanager.net", "Not Found"),
    ("blob.core.windows.net", "BlobNotFound"),
    ("fastly.net", "Fastly error: unknown domain"),
    ("pantheonsite.io", "The gods are wise"),
    ("zendesk.com", "Help Center Closed"),
    ("readthedocs.io", "unknown to Read the Docs"),
    ("surge.sh", "project not found"),
    ("bitbucket.io", "Repository not found"),
    ("wordpress.com", "Do you want to register"),
    ("tumblr.com", "Whatever you were looking for doesn't currently exist"),
    ("desk.com", "Please try again later"),
    ("teamwork.com", "Oops - We didn't find your site"),
    ("helpscoutdocs.com", "No settings were found for this company"),
    ("statuspage.io", "You are being redirected"),
    ("pingdom.com", "This public report page has not been activated"),
    ("uservoice.com", "This UserVoice subdomain is currently available"),
]

# ============================================================
# 8. 敏感信息正则（响应体里找泄露）
# ============================================================
SECRET_PATTERNS = [
    # 密钥前缀（LTAI/AKIA/AIza）大小写敏感，且必须整段独立，不能被
    # 更长的字母数字串包住；否则 base64 数据流里会凑出假命中。
    ("AK/SK (阿里云)", r"(?<![0-9A-Za-z])LTAI[A-Za-z0-9]{12,20}(?![0-9A-Za-z])", "critical"),
    ("AWS AccessKey", r"(?<![0-9A-Za-z])AKIA[0-9A-Z]{16}(?![0-9A-Za-z])", "critical"),
    ("私钥", r"-----BEGIN (RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----", "critical"),
    ("JWT Token", r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}", "high"),
    ("JDBC 连接串", r"jdbc:(mysql|postgresql|oracle|sqlserver|mongodb)://[^\s\"'<>]+", "critical"),
    # 密码类：必须带引号的赋值，或非 JS 字面量的裸赋值；值长度 >=5 且排除 true/null 等。
    ("数据库密码", r"(?:password|passwd|pwd)\s*[=:]\s*[\"']([^\"'\s]{4,40})[\"']", "high"),
    ("数据库密码", r"(?:password|passwd|pwd)\s*[=:]\s*(?!(?:true|false|null|undefined|function|string|number|boolean|object|value|input|text|checkbox|radio|file|image)\b)([A-Za-z0-9!@#$%^&*_\-\.]{5,40})", "high"),
    ("Redis 密码", r"requirepass\s+[^\s]+", "high"),
    ("邮箱", r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", "low"),
    ("手机号", r"(?<!\d)1[3-9]\d{9}(?!\d)", "low"),
    ("身份证", r"(?<!\d)[1-9]\d{5}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx](?!\d)", "high"),
    ("内网 IP", r"(?<!\d)(10\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}|192\.168\.\d{1,3})\.\d{1,3}(?!\d)", "medium"),
    ("Git 凭证", r"https://[^/\s:]+:[^/\s@]+@github\.com", "critical"),
    ("Slack Token", r"xox[baprs]-[0-9a-zA-Z\-]{10,}", "high"),
    ("Google API Key", r"AIza[0-9A-Za-z\-_]{35}", "high"),
    ("微信 AppSecret", r"(appsecret|AppSecret)\s*[=:]\s*[\"']?[0-9a-f]{32}", "critical"),
]

# ============================================================
# 9. SQL 注入探测 payload（时间盲注，无危害）
# ============================================================
SQLI_TIME_PAYLOADS = [
    ("' AND SLEEP({d})-- -", "mysql"),
    ("\" AND SLEEP({d})-- -", "mysql"),
    ("1' AND SLEEP({d})#", "mysql"),
    ("';WAITFOR DELAY '0:0:{d}'-- -", "mssql"),
    ("1) AND SLEEP({d})-- -", "mysql"),
    ("' AND (SELECT 1 FROM (SELECT SLEEP({d}))x)-- -", "mysql"),
    ("'||(SELECT pg_sleep({d}))||'", "postgres"),
    ("' AND 1=(SELECT 1 FROM PG_SLEEP({d}))-- -", "postgres"),
]

SQLI_ERROR_PAYLOADS = [
    "'", "\"", "')", "\"))", "1'", "1 AND 1=1", "1 AND 1=2",
    "' AND '1'='1", "' AND '1'='2", "\\", "1%27", "1'--",
]

SQLI_ERROR_SIGNS = [
    r"SQL syntax.*MySQL", r"Warning.*mysql_", r"MySQLSyntaxErrorException",
    r"valid MySQL result", r"MySqlClient\.", r"PostgreSQL.*ERROR",
    r"Warning.*\Wpg_", r"valid PostgreSQL result", r"ORA-[0-9]{4,5}",
    r"Oracle error", r"Oracle.*Driver", r"SQLite/JDBCDriver", r"SQLite\.Exception",
    r"System\.Data\.SQLite", r"Microsoft.*ODBC.*SQL Server",
    r"ODBC SQL Server Driver", r"SQLServer JDBC Driver", r"Unclosed quotation mark",
    r"Microsoft OLE DB Provider for SQL Server", r"Incorrect syntax near",
    r"quoted string not properly terminated", r"Syntax error.*in query expression",
    r"com\.mysql\.jdbc", r"java\.sql\.SQLException", r"org\.hibernate",
]

# ============================================================
# 10. XSS 反射 payload
# ============================================================
XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    "\"><script>alert(1)</script>",
    "'><img src=x onerror=alert(1)>",
    "<svg/onload=alert(1)>",
    "javascript:alert(1)",
    "\"onmouseover=\"alert(1)",
    "<body onload=alert(1)>",
    "<img src=x onerror=alert(document.domain)>",
    "{{7*7}}",
    "${7*7}",
    "<%= 7*7 %>",
]

XSS_MARKER = "btxsstest1337"

# ============================================================
# 11. SSRF / 开放重定向
# ============================================================
REDIRECT_PAYLOADS = [
    "//evil.com", "https://evil.com", "http://evil.com",
    "/\\evil.com", "////evil.com", "https:evil.com",
    "//evil.com/%2f..", "/%09/evil.com", "https://evil.com%00.example.com",
]

SSRF_PAYLOADS = [
    "http://127.0.0.1:80/", "http://127.0.0.1:8080/", "http://localhost/",
    "http://[::1]/", "http://0.0.0.0/", "http://169.254.169.254/latest/meta-data/",
    "http://metadata.google.internal/", "http://100.100.100.200/latest/meta-data/",
    "file:///etc/passwd", "dict://127.0.0.1:6379/info", "gopher://127.0.0.1:6379/_INFO",
]
# 参数面扩展用：给无参路由补的常见参数名（缺陷 I）。
# 只作为"候选注入面"，不代表这些参数一定存在；是否成漏洞由检测判定口径决定。
COMMON_PARAMS = [
    "id", "q", "keyword", "search", "page", "url", "name", "user",
    "file", "path", "type", "action", "cmd", "redirect", "next", "callback",
]

# ============================================================
# 12. 常见未授权 API 路径（越权 / IDOR）
# ============================================================
API_PATHS = [
    "/api/user/{id}", "/api/users/{id}", "/api/v1/user/{id}",
    "/api/v1/users/{id}", "/user/{id}", "/user/info?id={id}",
    "/api/order/{id}", "/api/orders/{id}", "/order/detail?id={id}",
    "/api/account/{id}", "/api/member/{id}", "/api/profile/{id}",
    "/api/file/{id}", "/api/download/{id}", "/api/document/{id}",
    "/api/message/{id}", "/api/address/{id}", "/api/coupon/{id}",
]

# ============================================================
# 12.5 开放 API 注册端点（未鉴权即可调用 / 直接下发会话凭据）
# ============================================================
# 为什么单列一张表（round58）：round57 基线成功报告的高危 #1 是
# 「开放注册接口无鉴权 + 响应体直接下发会话 token」——匿名
# `POST /openApi/faUser/register` 即回 `{"data":{"token":"..."}}`。
# 这条此前**全项目零覆盖**：SENSITIVE_PATHS 只探 GET 路径存在性，
# 参数级检测只注入 URL 里已有的参数，两者都没有「对注册类接口做一次
# 匿名调用、看回包有没有吐凭据」的能力。
#
# 结构：(path, method, body 模板, desc, severity)
#   · body 模板里的 {u}/{p}/{m}/{e} 在运行时替换为一次性随机测试账号
#     （带 srctest_ 前缀，与基线手工复现同一手法），每个端点只调用一次，
#     绝不爆破、绝不重复提交；
#   · 判定在 modules/vulnchecks.check_open_api_auth：必须真的在回包里
#     解析出**凭据值**（token/sessionId/jwt…）才报，绝不靠状态码猜。
OPEN_API_PROBES = [
    ("/openApi/faUser/register", "POST",
     {"username": "{u}", "password": "{p}", "mobile": "{m}"},
     "开放注册接口未鉴权且下发会话凭据", "high"),
    ("/api/user/register", "POST",
     {"username": "{u}", "password": "{p}", "mobile": "{m}"},
     "开放注册接口未鉴权且下发会话凭据", "high"),
    ("/api/register", "POST",
     {"username": "{u}", "password": "{p}", "email": "{e}"},
     "开放注册接口未鉴权且下发会话凭据", "high"),
    ("/user/register", "POST",
     {"username": "{u}", "password": "{p}"},
     "开放注册接口未鉴权且下发会话凭据", "high"),
    ("/api/v1/user/register", "POST",
     {"username": "{u}", "password": "{p}"},
     "开放注册接口未鉴权且下发会话凭据", "high"),
]

# ============================================================
# 13. 国产组件高危路径（一次性检测）
# ============================================================
# ============================================================
# 14. 账号枚举探测（round71c 遗留③-1）
# ============================================================
# 判定在 modules/vulnchecks.check_user_enum（三条硬门槛，缺一不报）。
# 只用「几乎肯定不存在」的探测名 + 一个常见默认名做对照，共 4 次只读请求，
# 不带字典、不做爆破、不试真实用户名。
# 字段：(path, method, param, desc, sev)
USER_ENUM_PROBES = [
    ("/api/user/check", "POST", "username", "账号枚举（用户名存在性泄露）", "medium"),
    ("/api/user/exist", "POST", "username", "账号枚举（用户名存在性泄露）", "medium"),
    ("/user/check", "GET", "username", "账号枚举（用户名存在性泄露）", "medium"),
    ("/api/login", "POST", "username", "账号枚举（用户名存在性泄露）", "medium"),
    ("/login", "POST", "username", "账号枚举（用户名存在性泄露）", "medium"),
]
# 对照用的常见默认名（仅 1 个，不做用户名枚举）
USER_ENUM_CONTROL = "admin"

# ============================================================
# 15. 硬编码公钥探测（round71c 遗留③-2）
# ============================================================
# 判定在 modules/vulnchecks.check_hardcoded_key（三条硬门槛，缺一不报）。
# 与 SECRET_PATTERNS 的「私钥」不同：私钥只抓 PRIVATE KEY；这里专抓被写死
# 在前端可读位置（首页 / 前端 JS / 配置脚本）的**公钥材料**——它本身不致命，
# 但意味着签名/加密逻辑在前端可完整复现，常与客户端可篡改凭据链路相关。
HARDCODED_KEY_PATHS = [
    "/", "/index.html", "/js/app.js", "/static/js/app.js",
    "/config.js", "/static/config.js", "/static/js/config.js",
]

# ============================================================
# 16. token 跨主机复用探测（round71c 遗留③-3）
# ============================================================
# 判定在 modules/vulnchecks.check_token_reuse（三条硬门槛，缺一不报）。
# 只读 GET，不写数据；每台目标最多 TOKEN_REUSE_PATHS 条请求。
TOKEN_REUSE_PATHS = [
    "/api/user/info", "/api/me", "/api/user/profile",
    "/user/info", "/api/v1/user/info",
]

CN_COMPONENT_CHECKS = [
    # 缺陷 A/D 修复：原先 20 条里 18 条的 marker 是空串，导致
    # `if marker and marker.lower() not in body` 这道守卫永远短路，
    # check_cn_components 退化成"路径返回 200/302/401/403/500 就报组件漏洞"，
    # 在 WAF 整站 403、nginx 整站 200 兜底两类站点上全量误报。
    # 现在为每条补上真实特征串：marker 支持 `|` 分隔的多候选，任一命中即可，
    # 特征串取自本文件 FINGERPRINTS 里同组件的正则（去掉正则语法、只留字面
    # 关键词），保证 marker 是"该组件独有"的证据，而不是通用单词。
    # 致远 OA
    ("致远OA 任意文件上传", "POST", "/seeyon/htmlofficeservlet",
     "DBSTEP V3.0|seeyon", "critical"),
    ("致远OA A8 未授权", "GET", "/seeyon/management/status.jsp",
     "seeyon|A8-V5|A8", "high"),
    ("致远OA 敏感信息", "GET", "/seeyon/rest/token", "seeyon", "high"),
    # 泛微 OA
    ("泛微OA 任意文件上传", "GET", "/weaver/weaver.file.FileDownload?fileid=",
     "weaver", "high"),
    ("泛微OA SQL注入", "GET", "/weaver/ln.FileDownload?fileName=",
     "weaver", "high"),
    ("泛微OA 未授权", "GET", "/weaver/security/monitor/Monitor.jsp",
     "weaver", "high"),
    # 通达 OA
    ("通达OA 任意文件上传", "GET", "/ispirit/im/upload.php",
     "Office Anywhere|通达|MYOA", "critical"),
    ("通达OA 未授权访问", "GET", "/module/",
     "Office Anywhere|通达OA|MYOA", "high"),
    ("通达OA SQL注入", "GET", "/general/document/index.php/",
     "Office Anywhere|通达OA|MYOA", "high"),
    # 万户 OA
    ("万户OA 任意文件上传", "GET", "/defaultroot/upload/fileUpload.controller",
     "defaultroot|ezOFFICE|万户", "critical"),
    ("万户OA 未授权", "GET", "/defaultroot/",
     "defaultroot|ezOFFICE|万户", "medium"),
    # 蓝凌 OA
    ("蓝凌OA 任意文件读取", "GET", "/sys/ui/extend/varkind/custom.jsp",
     "landray|蓝凌|EKP", "high"),
    ("蓝凌OA 未授权", "GET", "/admin.do", "landray|蓝凌|EKP", "medium"),
    # 用友
    ("用友NC 未授权", "GET", "/portal/pt/",
     "yonyou|用友|UAP-NC|/nc/", "high"),
    ("用友NC bsh 反序列化", "GET", "/uapws/service",
     "uapws|yonyou|UAP-NC", "critical"),
    ("用友U8 未授权", "GET", "/U8Api/", "U8Cloud|用友U8|u8", "high"),
    # 金蝶
    ("金蝶EAS 未授权", "GET", "/easweb/", "kingdee|金蝶|apusic", "medium"),
    ("金蝶 apusic 未授权", "GET", "/apusic/", "apusic|kingdee", "high"),
    # 其它
    ("若依 RuoYi 未授权", "GET", "/prod-api/", "RuoYi|若依|prod-api", "medium"),
    ("宝塔面板未授权", "GET", "/pma/", "phpMyAdmin|pma_|宝塔", "medium"),
]
# ============================================================
# round33 扩充段 A：指纹库 + 版本捕获正则
# 说明：本段全部为“追加”，不改动上方既有 (名称, 正则, 分类) 三元组表，
#       保证 modules/probe.fingerprint 的 name, pattern, _cat 解包兼容。
# ============================================================
import re as _re

# ---- A1. 指纹库扩充（保持 (名称, 正则, 分类) 三元组）----
FINGERPRINTS += [
    # 国产 OA / 协同 / 报表
    ("泛微E-Mobile", r"EMobile|e-mobile|/extend/mobile", "OA"),
    ("帆软报表", r"FineReport|reportserver|/WebReport/|FineBI|帆软", "报表"),
    ("润乾报表", r"raqsoft|润乾|/raqsoft/", "报表"),
    ("金和OA", r"jinher|金和|/jc6/", "OA"),
    ("红帆OA", r"iOffice|红帆|/ioffice/", "OA"),
    ("蓝凌EIS", r"/eis/|landray-eis|EIS智慧协同", "OA"),
    # 国产安全 / 网络设备
    ("深信服设备", r"Sangfor|深信服|/por/login_psw", "安全设备"),
    ("天融信设备", r"TopSec|天融信", "安全设备"),
    ("锐捷设备", r"Ruijie|锐捷", "网络设备"),
    ("H3C设备", r"H3C|新华三", "网络设备"),
    ("华为设备", r"Huawei|华为技术", "网络设备"),
    ("Hikvision", r"Hikvision|/doc/page/login.asp", "设备"),
    ("Dahua", r"Dahua|/RPC2_Login", "设备"),
    # CMS
    ("WordPress", r"wp-content|wp-includes|WordPress", "CMS"),
    ("Drupal", r"Drupal|drupal", "CMS"),
    ("Joomla", r"Joomla|/components/com_", "CMS"),
    ("织梦DedeCMS", r"dedecms|/dede/|DedeCMS", "CMS"),
    ("帝国CMS", r"EmpireCMS|/e/admin/|帝国CMS", "CMS"),
    ("Discuz", r"Discuz|discuz", "CMS"),
    ("PHPCMS", r"phpcms|PHPCMS", "CMS"),
    # 面板 / 工具
    ("phpStudy", r"phpstudy|phpStudy", "面板"),
    ("Cockpit", r"cockpit|/cockpit/", "面板"),
    # 邮件
    ("Coremail", r"Coremail|/coremail/", "邮件"),
    ("Exchange OWA", r"Outlook Web App|/owa/|Exchange", "邮件"),
    ("Zimbra", r"Zimbra|/zimbra/", "邮件"),
    # 中间件 / 消息
    ("Kafka", r"kafka", "中间件"),
    ("ActiveMQ", r"ActiveMQ", "中间件"),
    ("RocketMQ", r"RocketMQ", "中间件"),
    ("Tomcat Manager", r"Tomcat Manager|/manager/html", "中间件"),
    ("OpenSSH", r"OpenSSH", "服务"),
    # 存储 / 搜索 / 大数据
    ("MinIO", r"MinIO|minio", "存储"),
    ("Solr", r"Solr|solr", "搜索"),
    ("ClickHouse", r"ClickHouse|clickhouse", "数据库"),
    ("TiDB", r"TiDB|tidb", "数据库"),
    ("PostgreSQL", r"PostgreSQL", "数据库"),
    ("Hadoop", r"Hadoop|hadoop", "大数据"),
    ("Hive", r"HiveServer2|apache-hive", "大数据"),
    ("Spark", r"Spark Master|spark-master", "大数据"),
    ("Flink", r"Flink|flink", "大数据"),
    # CI/CD / 运维
    ("Nexus", r"Nexus Repository|nexus", "CI/CD"),
    ("SonarQube", r"SonarQube|sonarqube", "CI/CD"),
    ("Jupyter", r"Jupyter|jupyter", "工具"),
    ("Airflow", r"Airflow|airflow", "任务调度"),
    ("DolphinScheduler", r"DolphinScheduler|dolphinscheduler", "任务调度"),
    # 监控
    ("Cacti", r"Cacti|cacti", "监控"),
    ("Nagios", r"Nagios|nagios", "监控"),
    # 组件 / 框架
    ("Seata", r"Seata|seata", "组件"),
    ("Sentinel", r"Sentinel Dashboard|sentinel-dashboard", "组件"),
    ("Dubbo", r"dubbo", "组件"),
    ("MyBatis", r"MyBatis", "组件"),
    ("Log4j", r"log4j", "组件"),
    ("Spring Cloud Gateway", r"Spring Cloud Gateway|spring cloud gateway", "框架"),
    ("Kubernetes API", r"\"kind\":\"Status\"|kubernetes", "容器"),
]

# ---- A2. 版本捕获正则：(显示名, 正则, 组件键) ----
# 组件键用于关联下方 CVE_MAP；正则第一个非空分组即版本号。
VERSION_PATTERNS = [
    ("Nginx", r"nginx/([0-9]+(?:\.[0-9]+){1,3})", "nginx"),
    ("Apache httpd", r"Apache/([0-9]+(?:\.[0-9]+){1,3})", "apache"),
    ("Apache Tomcat", r"Tomcat/([0-9]+(?:\.[0-9]+){1,3})", "tomcat"),
    ("Jetty", r"Jetty\(([0-9]+(?:\.[0-9]+){1,3})", "jetty"),
    ("JBoss", r"JBoss[/ ]?(?:EAP[/ ]?)?([0-9]+(?:\.[0-9]+){1,3})", "jboss"),
    ("IIS", r"Microsoft-IIS/([0-9]+(?:\.[0-9]+){1,3})", "iis"),
    ("Weblogic", r"WebLogic Server/([0-9]+(?:\.[0-9]+){1,3})", "weblogic"),
    ("PHP", r"PHP/([0-9]+(?:\.[0-9]+){1,3})", "php"),
    ("ASP.NET", r"ASP\.NET[/ ]?([0-9]+(?:\.[0-9]+){1,3})", "aspnet"),
    ("OpenSSH", r"OpenSSH[_/]([0-9]+(?:\.[0-9]+){1,3})", "openssh"),
    ("Redis", r"redis_version:([0-9]+(?:\.[0-9]+){1,3})", "redis"),
    ("Elasticsearch", r"\"number\"\s*:\s*\"([0-9]+\.[0-9]+\.[0-9]+)\"", "elasticsearch"),
    ("Grafana", r"[Gg]rafana[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "grafana"),
    ("Kibana", r"[Kk]ibana[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "kibana"),
    ("Jenkins", r"Jenkins[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "jenkins"),
    ("GitLab", r"GitLab[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "gitlab"),
    ("Harbor", r"[Hh]arbor[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "harbor"),
    ("RabbitMQ", r"RabbitMQ/([0-9]+(?:\.[0-9]+){1,3})", "rabbitmq"),
    ("Druid", r"Druid[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "druid"),
    ("Fastjson", r"fastjson[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "fastjson"),
    ("ShardingSphere", r"ShardingSphere[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "shardingsphere"),
    ("ThinkPHP", r"ThinkPHP[/ ]?v?([0-9]+(?:\.[0-9]+){1,3})", "thinkphp"),
    ("Laravel", r"Laravel[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "laravel"),
    ("Django", r"Django[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "django"),
    ("Flask", r"Werkzeug/([0-9]+(?:\.[0-9]+){1,3})", "flask"),
    ("phpMyAdmin", r"phpMyAdmin[/ ]([0-9]+(?:\.[0-9]+){1,3})", "phpmyadmin"),
    ("Adminer", r"Adminer ([0-9]+(?:\.[0-9]+){1,3})", "adminer"),
    ("WordPress", r"WordPress[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "wordpress"),
    ("Drupal", r"Drupal[/ ]([0-9]+(?:\.[0-9]+){1,3})", "drupal"),
    ("Solr", r"[Ss]olr[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "solr"),
    ("MinIO", r"MinIO[/ ]?([0-9]+(?:\.[0-9]+){1,3})", "minio"),
    ("Nexus", r"Nexus Repository Manager[/ ]?v?([0-9]+(?:\.[0-9]+){1,3})", "nexus"),
    ("SonarQube", r"SonarQube[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "sonarqube"),
    ("Consul", r"Consul[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "consul"),
    ("Prometheus", r"Prometheus[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "prometheus"),
    ("Zabbix", r"Zabbix[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "zabbix"),
    ("Nacos", r"[Nn]acos[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "nacos"),
    ("XXL-JOB", r"xxl-job[/ ]v?([0-9]+(?:\.[0-9]+){1,3})", "xxljob"),
    ("Jolokia", r"jolokia/([0-9]+(?:\.[0-9]+){1,3})", "jolokia"),
    ("Spring Boot", r"\"spring-boot\"\s*:\s*\{[^}]{0,200}?\"version\"\s*:\s*\"([0-9]+(?:\.[0-9]+){1,3})", "spring"),
    ("Kubernetes", r"\"gitVersion\"\s*:\s*\"v?([0-9]+(?:\.[0-9]+){1,3})", "k8s"),
    ('OpenResty', 'openresty/([0-9]+(?:\\.[0-9]+){1,3})', 'openresty'),
    ('Tengine', '[Tt]engine/([0-9]+(?:\\.[0-9]+){1,3})', 'tengine'),
    ('Caddy', 'Caddy[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'caddy'),
    ('LiteSpeed', 'LiteSpeed/([0-9]+(?:\\.[0-9]+){1,3})', 'litespeed'),
    ('Kestrel', 'Kestrel/([0-9]+(?:\\.[0-9]+){1,3})', 'kestrel'),
    ('Gunicorn', 'gunicorn/([0-9]+(?:\\.[0-9]+){1,3})', 'gunicorn'),
    ('uWSGI', 'uWSGI/([0-9]+(?:\\.[0-9]+){1,3})', 'uwsgi'),
    ('Waitress', 'waitress/([0-9]+(?:\\.[0-9]+){1,3})', 'waitress'),
    ('WildFly', 'WildFly[/ ](?:Full )?([0-9]+(?:\\.[0-9]+){1,3})', 'wildfly'),
    ('Undertow', 'Undertow/([0-9]+(?:\\.[0-9]+){1,3})', 'undertow'),
    ('Resin', 'Resin/([0-9]+(?:\\.[0-9]+){1,3})', 'resin'),
    ('WebSphere', 'WebSphere Application Server/([0-9]+(?:\\.[0-9]+){1,3})', 'websphere'),
    ('PostgreSQL', 'PostgreSQL[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'postgresql'),
    ('MySQL', 'MySQL[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'mysql'),
    ('Microsoft SQL Server', 'Microsoft SQL Server[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'mssql'),
    ('ClickHouse', 'ClickHouse[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'clickhouse'),
    ('InfluxDB', 'InfluxDB[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'influxdb'),
    ('Cassandra', 'Cassandra/([0-9]+(?:\\.[0-9]+){1,3})', 'cassandra'),
    ('CouchDB', 'CouchDB/([0-9]+(?:\\.[0-9]+){1,3})', 'couchdb'),
    ('Memcached', 'memcached[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'memcached'),
    ('etcd', 'etcd[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'etcd'),
    ('Kafka', '[Kk]afka[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'kafka'),
    ('RocketMQ', 'RocketMQ[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'rocketmq'),
    ('ActiveMQ', 'ActiveMQ[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'activemq'),
    ('Pulsar', 'Pulsar[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'pulsar'),
    ('Neo4j', 'Neo4j[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'neo4j'),
    ('Jira', '[Jj]ira[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'jira'),
    ('Confluence', 'Confluence[/ ]([0-9]+(?:\\.[0-9]+){1,3})', 'confluence'),
    ('TeamCity', 'TeamCity[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'teamcity'),
    ('Gitea', 'Gitea[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'gitea'),
    ('Kong', '[Kk]ong/([0-9]+(?:\\.[0-9]+){1,3})', 'kong'),
    ('APISIX', 'APISIX/([0-9]+(?:\\.[0-9]+){1,3})', 'apisix'),
    ('Portainer', 'Portainer[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'portainer'),
    ('Discuz', 'Discuz[ ]?X?[ ]?([0-9]+(?:\\.[0-9]+){1,3})', 'discuz'),
    ('Joomla', 'Joomla[/ ]?([0-9]+(?:\\.[0-9]+){1,3})', 'joomla'),
    ('Magento', 'Magento[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'magento'),
    ('SkyWalking', 'SkyWalking[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'skywalking'),
    ('Airflow', '[Aa]irflow[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'airflow'),
    ('Verdaccio', 'Verdaccio/([0-9]+(?:\\.[0-9]+){1,3})', 'verdaccio'),
    ('Sentry', '[Ss]entry[/ ]v?([0-9]+(?:\\.[0-9]+){1,3})', 'sentry'),
]

# ---- A3. CVE 映射表：组件键 → [(CVE, 影响版本区间, 简述, CVSS)] ----
# 版本区间用 (min, max, 开闭) 表达：None 表示无下/上限。
# 只收录“版本可直接从指纹判断”的公开已知漏洞，宁缺毋滥，避免误报。
CVE_MAP = {
    'nginx': [
        ('CVE-2019-20372', ('1.0.0', '1.17.6'), 'HTTP/2 内存泄露', '5.3'),
        ('CVE-2021-23017', ('0.6.18', '1.20.0'), 'DNS resolver 1字节溢出可 RCE', '9.8'),
        ('CVE-2017-7529', ('0.5.6', '1.13.2'), 'range 过滤器整数溢出信息泄露', '7.5'),
    ],
    'apache': [
        ('CVE-2021-41773', ('2.4.49', '2.4.49'), '路径穿越 + RCE', '9.8'),
        ('CVE-2021-42013', ('2.4.50', '2.4.50'), '路径穿越绕过（41773 修复不完全）', '9.8'),
        ('CVE-2017-15715', ('2.4.0', '2.4.29'), '换行符绕过上传黑名单', '8.1'),
        ('CVE-2021-40438', ('2.4.0', '2.4.48'), 'mod_proxy SSRF', '9.0'),
    ],
    'tomcat': [
        ('CVE-2017-12615', ('7.0.0', '7.0.81'), 'PUT 任意文件写入 RCE', '9.8'),
        ('CVE-2020-1938', ('7.0.0', '9.0.31'), 'AJP Ghostcat 文件读取', '9.8'),
        ('CVE-2024-50379', ('9.0.0', '9.0.98'), 'TOCTOU 写入 JSP 可 RCE', '9.8'),
        ('CVE-2020-9484', ('7.0.0', '9.0.34'), 'session 反序列化 RCE（需持久化配置）', '7.0'),
    ],
    'weblogic': [
        ('CVE-2019-2725', ('10.3.6', '12.1.3'), 'wls9-async 反序列化 RCE', '9.8'),
        ('CVE-2020-14882', ('10.3.6', '14.1.1'), '控制台未授权 RCE', '9.8'),
        ('CVE-2018-2628', ('10.3.6', '12.2.1'), 'T3 反序列化 RCE', '9.8'),
        ('CVE-2023-21839', ('12.2.1.3', '12.2.1.4'), 'T3/IIOP JNDI 注入 RCE', '9.8'),
    ],
    'jboss': [
        ('CVE-2017-12149', ('4.2.0', '5.2.2'), 'HttpInvoker 反序列化 RCE', '9.8'),
        ('CVE-2010-0738', ('4.2.0', '5.1.0'), 'JMX Console 未授权', '7.5'),
    ],
    'spring': [
        ('CVE-2022-22965', ('2.0.0', '2.6.6'), 'Spring4Shell RCE', '9.8'),
        ('CVE-2022-22947', ('3.0.0', '3.1.0'), 'Gateway SpEL RCE', '9.8'),
        ('CVE-2023-20860', ('2.0.0', '2.7.24'), 'Security 鉴权绕过', '7.5'),
        ('CVE-2022-22963', ('3.0.0', '3.2.2'), 'Cloud Function SpEL RCE', '9.8'),
    ],
    'fastjson': [
        ('CVE-2022-25845', ('1.2.0', '1.2.83'), 'AutoType 反序列化 RCE', '9.8'),
        ('CVE-2017-18349', ('1.1.0', '1.2.25'), 'AutoType 绕过 RCE', '9.8'),
    ],
    'thinkphp': [
        ('CVE-2018-20062', ('5.0.0', '5.1.31'), '5.x 远程代码执行', '9.8'),
        ('CVE-2019-9082', ('3.2.0', '3.2.3'), '3.2 缓存写入 RCE', '9.8'),
    ],
    'nacos': [
        ('CVE-2021-29441', ('1.0.0', '1.4.0'), 'User-Agent 鉴权绕过', '7.5'),
        ('CVE-2021-29442', ('1.0.0', '1.4.0'), '/nacos/v1/console 未授权', '7.5'),
    ],
    'jenkins': [
        ('CVE-2018-1000861', ('1.0', '2.153'), 'Stapler 反序列化 RCE', '9.8'),
        ('CVE-2024-23897', ('2.0', '2.441'), 'CLI 任意文件读取', '9.8'),
        ('CVE-2019-1003000', ('1.0', '2.150'), 'Script Security 沙箱绕过 RCE', '8.8'),
    ],
    'gitlab': [
        ('CVE-2021-22205', ('11.9.0', '13.10.2'), 'ExifTool 图片上传 RCE', '10.0'),
        ('CVE-2023-2825', ('16.0.0', '16.0.0'), '路径穿越任意文件读取', '7.5'),
        ('CVE-2022-1162', ('14.7.0', '14.9.1'), '硬编码口令导致账号接管', '9.8'),
    ],
    'grafana': [
        ('CVE-2021-43798', ('8.0.0', '8.3.0'), '插件路径穿越任意文件读取', '7.5'),
        ('CVE-2022-31107', ('8.0.0', '9.0.5'), 'OAuth 账号接管', '8.0'),
    ],
    'elasticsearch': [
        ('CVE-2015-1427', ('1.3.0', '1.4.2'), 'Groovy 沙箱绕过 RCE', '9.8'),
        ('CVE-2015-3337', ('1.4.0', '1.5.2'), '插件路径穿越', '5.0'),
    ],
    'redis': [
        ('CVE-2022-0543', ('0.0.0', '6.2.6'), 'Debian Lua 沙箱逃逸 RCE', '10.0'),
    ],
    'druid': [
        ('未授权监控页', ('0.0.0', '999.0.0'), '/druid/index.html 未授权访问', '5.3'),
        ('CVE-2021-36749', ('0.0.0', '1.2.4'), 'load data 任意文件读取', '7.5'),
    ],
    'harbor': [
        ('CVE-2022-46463', ('1.0.0', '2.7.0'), '未授权拉取私有镜像', '7.5'),
    ],
    'solr': [
        ('CVE-2019-17558', ('5.0.0', '8.3.1'), 'Velocity 模板 RCE', '9.8'),
        ('CVE-2017-12629', ('5.5.0', '7.1.0'), 'RunExecutableListener RCE', '9.8'),
        ('CVE-2021-27905', ('7.0.0', '8.8.1'), 'ReplicationHandler SSRF', '9.8'),
    ],
    'consul': [
        ('CVE-2020-12797', ('1.0.0', '1.7.3'), '未授权 KV 访问', '7.5'),
    ],
    'phpmyadmin': [
        ('CVE-2018-12613', ('4.8.0', '4.8.1'), 'LFI 包含 RCE', '8.8'),
        ('CVE-2016-5734', ('4.0.0', '4.6.2'), 'preg_replace 代码执行', '9.8'),
    ],
    'wordpress': [
        ('CVE-2019-8942', ('4.9.0', '5.0.0'), '任意文件删除 + RCE', '8.8'),
    ],
    'xxljob': [
        ('未授权执行器', ('1.0.0', '2.4.1'), '执行器未授权 API 命令执行', '9.8'),
    ],
    'minio': [
        ('CVE-2023-28432', ('0.0.0', 'RELEASE.2023-03-20'), '信息泄露（环境变量）', '7.5'),
    ],
    'nexus': [
        ('CVE-2019-7238', ('3.0.0', '3.14.0'), '未授权 RCE', '9.8'),
        ('CVE-2020-10199', ('3.0.0', '3.21.1'), 'EL 表达式注入 RCE', '8.8'),
    ],
    'sonarqube': [
        ('CVE-2020-27986', ('7.0', '8.4.2'), '未授权信息泄露', '5.3'),
    ],
    'jolokia': [
        ('未授权JMX', ('0.0.0', '999.0.0'), '/jolokia/list 未授权可 MBean 调用', '9.8'),
    ],
    'k8s': [
        ('CVE-2018-1002105', ('1.0.0', '1.12.2'), 'API 代理提权 RCE', '9.8'),
        ('CVE-2020-8554', ('1.0.0', '1.19.99'), 'externalIPs 中间人劫持', '5.0'),
    ],
    'mysql': [
        ('CVE-2012-2122', ('5.1.0', '5.5.24'), '认证绕过（随机数比较缺陷）', '7.5'),
        ('CVE-2016-6662', ('5.5.0', '5.7.15'), 'mysqld_safe 配置注入 RCE', '9.8'),
    ],
    'postgresql': [
        ('CVE-2019-9193', ('9.3.0', '11.2'), 'COPY PROGRAM 命令执行（需超级用户）', '7.2'),
    ],
    'memcached': [
        ('CVE-2018-1000115', ('1.0.0', '1.5.5'), 'UDP 反射放大攻击', '7.5'),
    ],
    'etcd': [
        ('CVE-2020-15106', ('3.3.0', '3.4.9'), '超大日志条目触发 panic', '5.3'),
    ],
    'kafka': [
        ('CVE-2023-25194', ('2.4.0', '3.3.2'), 'Kafka Connect JNDI 注入 RCE', '8.8'),
    ],
    'rocketmq': [
        ('CVE-2023-33246', ('4.0.0', '5.0.0'), 'Broker 未授权命令执行', '9.8'),
    ],
    'activemq': [
        ('CVE-2016-3088', ('5.0.0', '5.13.2'), 'Fileserver PUT 上传 RCE', '9.8'),
        ('CVE-2015-5254', ('5.0.0', '5.13.0'), '反序列化 RCE', '9.8'),
    ],
    'jira': [
        ('CVE-2019-11581', ('4.4.0', '8.2.0'), 'SSTI 模板注入 RCE', '9.8'),
        ('CVE-2021-26086', ('8.0.0', '8.16.1'), '路径穿越任意文件读取', '5.3'),
    ],
    'confluence': [
        ('CVE-2022-26134', ('1.3.0', '7.18.1'), 'OGNL 注入未授权 RCE', '9.8'),
        ('CVE-2023-22515', ('8.0.0', '8.5.1'), '权限提升创建管理员', '10.0'),
    ],
    'teamcity': [
        ('CVE-2024-27198', ('2018.1', '2023.11.3'), '认证绕过 RCE', '9.8'),
        ('CVE-2023-42793', ('2017.1', '2023.05.3'), '认证绕过 RCE', '9.8'),
    ],
    'apisix': [
        ('CVE-2022-24112', ('1.3.0', '2.12.1'), 'batch-requests IP 伪造 RCE', '9.8'),
    ],
    'joomla': [
        ('CVE-2015-8562', ('1.5.0', '3.4.5'), 'HTTP 头反序列化 RCE', '9.8'),
        ('CVE-2023-23752', ('4.0.0', '4.2.7'), '未授权配置信息泄露', '5.3'),
    ],
    'magento': [
        ('CVE-2022-24086', ('2.0.0', '2.4.3'), '结账页模板注入 RCE', '9.8'),
    ],
    'skywalking': [
        ('CVE-2020-9483', ('6.0.0', '8.3.0'), 'GraphQL SQL 注入', '7.5'),
    ],
    'airflow': [
        ('CVE-2020-13927', ('1.10.10', '2.0.0'), '实验性 API 默认无认证', '9.8'),
        ('CVE-2020-11978', ('1.10.10', '2.0.0'), '示例 DAG 命令注入 RCE', '8.8'),
    ],
    'gitea': [
        ('CVE-2022-30781', ('1.0.0', '1.16.6'), '仓库迁移 Git 命令注入', '7.5'),
    ],
    'couchdb': [
        ('CVE-2017-12635', ('1.0.0', '2.1.0'), '权限提升 RCE', '9.8'),
    ],
}

# ---- A4. 弱口令字典扩充（保持 (user, pass) 二元组）----
# 原 20 条保持不动（在 DEFAULT_CREDS 定义处），此处追加常见运维/中间件/国产组件凭据。
DEFAULT_CREDS_EXTRA = [
    ("admin", "admin888"), ("admin", "admin@2024"), ("admin", "Admin@123"),
    ("admin", "admin1234"), ("admin", "admin12345"), ("admin", "admin.123"),
    ("admin", "123456789"), ("admin", "1234567890"), ("admin", "abc123"),
    ("admin", "qwerty123"), ("admin", "P@ssw0rd"), ("admin", "Passw0rd"),
    ("admin", "1qaz2wsx"), ("admin", "admin@123456"), ("admin", "root123"),
    ("root", "admin"), ("root", "123456789"), ("root", "toor"),
    ("root", "root123"), ("root", "P@ssw0rd"), ("root", "calvin"),
    ("administrator", "administrator"), ("administrator", "123456"),
    ("administrator", "P@ssw0rd"), ("administrator", "admin888"),
    ("user", "user"), ("user", "123456"), ("user", "password"),
    ("operator", "operator"), ("oracle", "oracle"), ("oracle", "oracle123"),
    ("postgres", "postgres"), ("postgres", "123456"), ("mysql", "mysql"),
    ("mysql", "root"), ("mssql", "sa"), ("admin", "sa123456"),
    ("weblogic", "weblogic123"), ("weblogic", "Oracle@123"),
    ("tomcat", "tomcat123"), ("tomcat", "admin"), ("jboss", "jboss"),
    ("nacos", "nacos123"), ("nacos", "123456"),
    ("redis", "redis"), ("redis", "123456"),
    ("elastic", "elastic"), ("elastic", "changeme"),
    ("elasticsearch", "elasticsearch"),
    ("rabbitmq", "rabbitmq"), ("guest", "guest123"),
    ("jenkins", "jenkins123"), ("jenkins", "password"),
    ("gitlab", "gitlab"), ("gitlab", "12345678"),
    ("grafana", "grafana"), ("grafana", "admin"),
    ("zabbix", "zabbix"), ("zabbix", "admin"),
    ("admin", "zabbix"), ("admin", "grafana"),
    ("sa", "sa123"), ("sa", "123456"), ("sa", "password"),
    ("system", "manager"), ("manager", "s3cret"),
    ("admin", "harbor12345"), ("harbor", "Harbor12345"),
    ("admin", "minioadmin"), ("minioadmin", "minioadmin"),
    ("admin", "nexus"), ("admin", "admin123!@#"),
    ("admin", "sonar"), ("admin", "admin12345678"),
    ("admin", "123456a"), ("admin", "a123456"), ("admin", "123456."),
    ("test", "123456"), ("test", "test123"), ("test", "admin"),
    ("guest", "123456"), ("guest", "guest"), ("demo", "demo"),
    ("admin", "Aa123456"), ("admin", "Aa123456!"), ("admin", "Admin123!"),
    ("admin", "admin123."), ("admin", "888888"), ("admin", "666666"),
    ("admin", "000000"), ("admin", "111111"), ("admin", "123123"),
    ("admin", "woaini"), ("admin", "iloveyou"), ("admin", "sunshine"),
    ("admin", "letmein"), ("admin", "monkey"), ("admin", "dragon"),
    ('admin', 'admin2024'),
    ('admin', 'admin2023'),
    ('admin', 'admin2022'),
    ('admin', 'admin2025'),
    ('admin', 'Admin@2024'),
    ('admin', 'Admin@2023'),
    ('admin', 'admin@2025'),
    ('admin', '123qwe'),
    ('admin', 'qwe123'),
    ('admin', '1q2w3e4r'),
    ('admin', '1qaz@wsx'),
    ('admin', 'zaq12wsx'),
    ('admin', 'Aa123456789'),
    ('admin', 'Abc@12345'),
    ('admin', 'admin!@#'),
    ('admin', 'admin@2021'),
    ('admin', 'Admin@2021'),
    ('admin', 'admin2021'),
    ('admin', 'Welcome123'),
    ('admin', 'Welcome@123'),
    ('admin', 'changeme'),
    ('admin', 'ChangeMe123'),
    ('admin', 'P@ssw0rd123'),
    ('admin', 'P@ssw0rd!'),
    ('admin', 'Passw0rd!'),
    ('admin', '1qaz2wsx3edc'),
    ('admin', 'administrator'),
    ('admin', 'admin1'),
    ('admin', 'admin2'),
    ('admin', 'admin1234567'),
    ('admin', 'Admin@1234'),
    ('admin', 'admin@1234'),
    ('admin', 'root'),
    ('admin', 'toor'),
    ('admin', 'admin@12345'),
    ('admin', 'Aa@123456'),
    ('admin', 'Zxcvbnm123'),
    ('admin', 'Qwer1234'),
    ('admin', 'admin2020'),
    ('admin', 'Admin@2020'),
    ('root', 'root@123'),
    ('root', 'Root@123'),
    ('root', '1qaz@wsx'),
    ('root', 'root1234'),
    ('root', 'password'),
    ('root', 'Passw0rd!'),
    ('root', 'root@1234'),
    ('test', 'test1234'),
    ('test', 'test@123'),
    ('test', '12345678'),
    ('guest', '12345'),
    ('guest', 'guest1234'),
    ('user', '12345678'),
    ('user', 'user123'),
    ('user', 'User@123'),
    ('operator', '123456'),
    ('operator', 'operator123'),
    ('superadmin', 'superadmin'),
    ('superadmin', '123456'),
    ('superadmin', 'admin123'),
    ('manager', '123456'),
    ('manager', 'Manager@123'),
    ('sa', 'sa123456'),
    ('sa', '12345678'),
    ('sa', 'sa@123'),
    ('postgres', 'postgres123'),
    ('postgres', 'admin'),
    ('mysql', '123456'),
    ('mysql', 'mysql123'),
    ('oracle', 'oracle@123'),
    ('oracle', '123456'),
    ('elastic', 'elastic123'),
    ('elasticsearch', 'changeme'),
    ('tomcat', 'tomcat1234'),
    ('weblogic', 'weblogic1'),
    ('nacos', 'nacos@123'),
    ('jenkins', 'jenkins1234'),
    ('gitlab', 'gitlab123'),
    ('grafana', 'grafana123'),
    ('zabbix', 'zabbix123'),
    ('rabbitmq', 'rabbitmq123'),
    ('redis', 'redis123'),
    ('admin', 'harbor123456'),
    ('admin', 'minio123'),
    ('minioadmin', 'minio123'),
    ('admin', 'nexus123'),
    ('admin', 'sonarqube'),
    ('admin', 'sonar123'),
    # round87c: 补齐国产中间件 / SaaS / 默认口令组合
    ("admin", "admin@123"),
    ("admin", "Admin@123"),
    ("admin", "admin@2024"),
    ("admin", "P@ssw0rd"),
    ("admin", "Passw0rd!"),
    ("admin", "abc123456"),
    ("admin", "admin@888"),
    ("admin", "admin#123"),
    ("admin", "admin!@#"),
    ("admin", "a123456789"),
    ("admin", "Aa123456!"),
    ("admin", "Zxcvbnm123"),
    ("root", "root@123"),
    ("root", "P@ssw0rd"),
    ("root", "toor"),
    ("root", "root1234"),
    ("root", "123qwe"),
    ("root", "qwerty"),
    ("root", "admin@123"),
    ("test", "test@123"),
    ("test", "Test1234"),
    ("guest", "guest@123"),
    ("nacos", "nacos"),
    ("nacos", "nacos@123"),
    ("jumpserver", "jumpserver"),
    ("jumpserver", "admin@123"),
    ("zabbix", "Admin@123"),
    ("apollo", "admin"),
    ("apollo", "apollo"),
    ("xxljob", "123456"),
    ("xxl-job", "123456"),
    ("dubbo", "dubbo"),
    ("dubbo-admin", "root"),
    ("elastic", "changeme"),
    ("kong", "kong"),
    ("influxdb", "influxdb"),
    ("clickhouse", "default"),
    ("postgres", "postgres@123"),
    ("mysql", "mysql@123"),
    ("mysql", "root123"),
    ("sqlserver", "sa@123"),
    ("oracle", "oracle"),
    ("weblogic", "weblogic@123"),
    ("tomcat", "tomcat@123"),
    ("manager", "manager"),
    ("admin", "manager"),
    ("harbor", "Harbor12345"),
    ("admin", "Harbor12345"),
    ("minio", "minioadmin"),
    ("minioadmin", "minioadmin123"),
    ("sonar", "sonar"),
    ("nexus", "nexus@123"),
    ("admin", "grafana"),
    ("jenkins", "jenkins"),
    ("jenkins", "admin@123"),
    ("gitlab", "gitlab@123"),
    ("admin", "gitlab123"),
    ("admin", "rabbitmq"),
    ("consul", "consul"),
    ("vault", "vault"),
    ("kibana", "kibana"),
    ("admin", "kibana"),
    ("graylog", "graylog"),
    ("admin", "graylog"),
    ("sentry", "sentry"),
    ("admin", "sentry"),
    ("ruoyi", "admin123"),
    ("admin", "ruoyi123"),
    ("jeecg", "jeecg"),
    ("admin", "jeecg123"),
    ("shiro", "shiro"),
    ("admin", "shiro"),
    ("seeyon", "seeyon"),
    ("admin", "seeyon123"),
    ("weaver", "weaver"),
    ("admin", "weaver"),
    ("ecology", "ecology"),
    ("sysadmin", "sysadmin"),
    ("kingdee", "kingdee"),
    ("admin", "kingdee"),
    ("yonyou", "yonyou"),
    ("admin", "yonyou"),
    ("ufida", "ufida"),
    ("admin", "ufida"),
    ("chanjet", "chanjet"),
    ("admin", "chanjet"),
    ("server", "server"),
    ("demo", "demo"),
    ("user", "user@123"),
    ("user", "User@123"),
    ("ftp", "ftp"),
    ("ftpuser", "ftpuser"),
    ("www", "www"),
    ("web", "web@123"),
    ("api", "api@123"),
    ("dev", "dev@123"),
    ("prod", "prod@123"),
    ("backup", "backup"),
    ("oracle", "oracle@123"),
    ("sa", "sa"),
    ("sa", "Sa@12345"),
    ("sa", "1qaz@wsx"),
]
# 合并后的完整凭据池（供检测器统一取用）
DEFAULT_CREDS_ALL = list(dict.fromkeys(list(DEFAULT_CREDS) + list(DEFAULT_CREDS_EXTRA)))  # r87d 去重

# ---- A5. 弱口令字段名扩充（供表单枚举用）----
LOGIN_USER_FIELDS = ("username", "user", "name", "account", "email", "login",
                     "userName", "userid", "user_id", "uname", "usr", "loginname",
                     "loginName", "mobile", "phone", "tel")
LOGIN_PASS_FIELDS = ("password", "passwd", "pwd", "pass", "passcode", "userpass",
                     "userPassword", "passWord", "Password", "loginpwd", "passw",
                     "secret", "pwd1", "txtPassword")


# ============================================================
# 人审闸门（阶段 2-3）：AI 产物一律写 ".draft"，人工改名才生效
# ============================================================
# 契约（三处字面一致）：
#   · core/dicts.py         DRAFT_SUFFIX      <- 本处，判定/改名基准
#   · core/config.py        AI_DRAFT_SUFFIX   <- 配置层声明
#   · tools/selfheal_learn.py DRAFT_SUFFIX    <- 生产者，落盘时强制补后缀
# 规则：任何由 AI / 离线学习器生成的**候选**数据文件，文件名必须以
# DRAFT_SUFFIX 结尾；扫描器只读「非 draft」的正式文件。人工审核后
# 把 ".draft" 去掉即生效（live_path 给出目标名）。
# 本模块只提供纯判定函数，不做任何 IO —— 保证离线可测、可被任意调用方复用。
DRAFT_SUFFIX = ".draft"


def is_draft(path):
    """路径是否处于草稿态（待人工审核）。

    非字符串（None / 数字 / 对象）一律按**草稿**处理：安全侧默认，宁可
    不加载也不误加载未经人审的数据。
    """
    if not isinstance(path, str):
        return True
    return path.endswith(DRAFT_SUFFIX)


def live_path(path):
    """给定草稿路径，返回人工审核通过后应当使用的正式路径。

    对已是正式路径的输入原样返回（幂等）；非字符串原样返回。
    """
    if not isinstance(path, str):
        return path
    if path.endswith(DRAFT_SUFFIX):
        return path[: -len(DRAFT_SUFFIX)]
    return path


# ============================================================
# F3：SSRF 回显探针（round88-F）
# ============================================================
# 回显判定的核心思路：注入的 URL 指向一个「只有我们控制、会返回随机标记」的
# 地址。若响应体里出现了这个随机标记，说明**服务端真的帮我们把内容取回来了**，
# 而不是仅仅把参数原样回显。标记由 check_ssrf 运行时按随机数生成，字典里只放
# 路径模板，避免标记被目标端预知（写死标记等于给了对方伪造回显的机会）。
SSRF_ECHO_PATHS = (
    "/",
    "/r88echo",
    "/r88echo.txt",
)
# 探针地址模板：{scheme}://{host}:{port}{path}
# 只生成 http，不生成 https——回显探针跑在明文 HTTP 上，HTTPS 自签会让目标
# 端直接握手失败，反而把「回连不通」误读成「无 SSRF」。
SSRF_ECHO_TMPL = "http://%s%s"

# ============================================================
# F4：JWT 弱密钥字典（round88-F）
# ============================================================
# 体积红线：<= 200 条、序列化后 <= 4KB。全部为真实见过的弱密钥：
# 框架默认值 + 经典弱口令 + 开发者随手写的占位符。
# 刻意不放千兆级通用口令表——爆破成本会炸，且命中率提升有限。
JWT_WEAK_SECRETS = (
    # --- 极弱 / 空值类 ---
    "", "secret", "secretkey", "secret_key", "mysecret", "my_secret",
    "key", "keyboard", "password", "passwd", "pass", "p@ssw0rd",
    "123456", "1234567890", "12345678", "123456789", "12345", "111111",
    "000000", "abc123", "qwerty", "admin", "root", "test", "test123",
    "dev", "development", "prod", "production", "staging", "debug",
    # --- 框架 / 库的默认或占位值 ---
    "your-256-bit-secret", "your_jwt_secret", "your-secret-key",
    "YOUR_SECRET_KEY_HERE", "change_me", "changeme", "CHANGEME",
    "changeit", "changethis", "changemeplease", "please_change_me",
    "jwt", "jwtsecret", "jwt_secret", "jwt-secret", "jwtkey",
    "token", "tokensecret", "token_secret", "auth", "authkey",
    "auth_secret", "appsecret", "app_secret", "app-key", "appkey",
    "api", "apikey", "api_key", "apisecret", "api_secret",
    "spring", "springboot", "spring-security", "security", "secure",
    "laravel", "Laravel", "django", "django-insecure", "flask",
    "express", "node", "nodejs", "rails", "phoenix", "gin", "fiber",
    "default", "defaultsecret", "default_secret", "defaultkey",
    "example", "sample", "demo", "tutorial", "test_secret",
    "hs256", "HS256", "hs256secret", "sha256", "sha-256",
    # --- 开发者随手写 / 中文拼音类 ---
    "123qwe", "1qaz2wsx", "qazwsx", "zxcvbnm", "asdfgh", "iloveyou",
    "letmein", "welcome", "monkey", "dragon", "master", "shadow",
    "superman", "batman", "trustno1", "sunshine", "princess",
    "admin123", "root123", "test1234", "guest", "user", "operator",
    "ceshi", "ceshi123", "kaifa", "kaifa123", "shengchan", "yanshi",
    "mima", "mima123", "miyao", "miyao123", "zhongguo", "beijing",
    "shanghai", "woaini", "nihao", "woaini1314",
    # --- 常见带年份 / 版本号 ---
    "secret2024", "secret2025", "secret2026", "secret123", "secret1",
    "jwt2024", "jwt2025", "jwt2026", "key2024", "key2025", "key2026",
    "token2024", "token2025", "token2026", "v1", "v2", "v1.0",
    # --- 弱随机 / 短串 ---
    "a", "aa", "aaa", "abc", "abcd", "abcdef", "abcdefg",
    "1234", "123", "12", "1", "0000", "9999", "8888",
    "a1b2c3", "abc123456", "admin@123", "Admin123", "Admin@123",
    "P@ssw0rd", "Password1", "Password123", "passw0rd",
    # --- 常见凭据类 ---
    "sig", "sign", "signature", "signing", "signing_key", "signkey",
    "verify", "verification", "encrypt", "encryption", "decrypt",
    "private", "privatekey", "pkey", "rsa", "hmac", "hmac256",
)
# JWT 允许的对称算法（仅这些会被爆破；RS/ES/PS 等非对称算法直接跳过）。
JWT_HMAC_ALGS = {
    "HS256": "sha256",
    "HS384": "sha384",
    "HS512": "sha512",
}
# 从响应中提取 JWT 的正则（与 SCAN_SECRETS 里的同源，单独导出供检测模块复用）。
JWT_RE = r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"


def loadable(path):
    """该路径是否允许被扫描器加载：只有非草稿才可加载。"""
    return not is_draft(path)
