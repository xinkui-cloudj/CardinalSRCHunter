# round73 待做全部事项（执行清单，逐条打勾）

**锚点（原目标）**：在 CardinalSRCHunter 上做 4 件事 ——
1. **P0**：把 `data/hunt_queue.jsonl`（只写不读的死数据）回流给 AI，让 AI 拿"规则扫不出的零命中接口"去重扫；
2. **桌面 Tkinter** 加「暂停/继续」+「清空」按钮，且关程序时自动暂停并保留进度、下次可续；
3. **Web 控制台「资产」页删除失效**修复；
4. **Web 控制台「SKILL」页总开关**改成与「MCP」页总开关一致。

**边界（做什么 / 不做什么）**
- 做：以上 4 项；每项改完自测；改前 `cp -p xxx.py xxx.py.bak_r73` 备份。
- 不做：**P2 不做**（skill/MCP 由用户自己在 Web 控制台配置）；**本轮不重打包**（exe / src.zip / MD5SUMS.txt 全部不动，等后续改动齐了一次性打）；不重构无关模块、不动无关对话/无关目录、不顺手扩面。
- 已确认：①「关闭程序」= **EXE 进程**；② 暂停粒度 = 当前批次跑完再停；③ 输出框 = **桌面 Tkinter**（`ui/gui.py`）。

**验收标准**
- P0：构造一条"有参数但零命中"的接口 -> 确认 AI 侧收到名单并发起新请求；产出「AI 多找到 N 条 / 多花 X 秒」实测数字，并给出 **P1 值不值得做**的结论。
- B：扫描中点「暂停」-> 输出框停在检查点、按钮变「继续」；点「继续」-> 接着跑；点「清空」-> 输出框清空且不影响扫描；关闭窗口 -> 日志出现"已暂停并保存进度"，重开 + 勾「断点续扫」-> 只扫未完成部分（不重头扫、不跳过未扫项）。
- C：资产页单选 1 条 / 多选 N 条 -> 提示 `已删除 N` 且列表刷新、DB 行数减少。修复前 10 条资产 0 能删。
- D：SKILL 页总开关文案与行为与 MCP 页一致，且真正控制技能全局生效与否。

---

## A. P0 · hunt_queue 回流 AI

| # | 事项 | 落点 | 状态 |
|---|---|---|---|
| A1 | 读现存量与样本字段结构 | `data/hunt_queue.jsonl`、`core/hunt_queue.py` | ✅ |
| A2 | 写 consumer：取样本 -> 指纹去重 -> 转 AI 任务清单 | `tools/agent_loop.py` 或新 `tools/hunt_consumer.py` | ✅ |
| A3 | 接线：AI 接管分支内于 `run_agent` 后对 hunt 名单再跑一轮（不改规则主流程） | `core/engine.py` ~1128-1155 行 | ✅ |
| A4 | 出网走同一限速器/闸门（`HttpClient` + `enable_active`），不新开旁路 | `core/engine.py`、`tools/tool_registry.py` | ✅ |
| A5 | 验证：确认 AI 收到名单并发出新请求；记录多找到 N 条 / 多花 X 秒 | `lab/` 临时脚本 | ✅ |
| A6 | 产出 **P1 值不值得做** 结论，交用户拍板 | 对话回报 | ✅ |
| A7 | 选项2：给 check_sqli/check_xss 开可选 payloads 通道（AI 自造 payload，上限 12）并接进难例回流提示词 | `modules/vc_custom.py`、`modules/vulnchecks.py`、`tools/tool_registry.py`、`tools/hunt_consumer.py` | ✅ |


### A7+ 选项2（用户拍板加做）AI 自造 payload 通道

| # | 事项 | 落点 | 状态 |
| --- | --- | --- | --- |
| A7 | 新建 vc_custom.py（自定义 payload 发射 + 判响应，硬顶 12x12） | `modules/vc_custom.py` | ✅ |
| A8 | vulnchecks.check_sqli/check_xss 加可选 extra_payloads | `modules/vulnchecks.py` 81/178/192/220 | ✅ |
| A9 | tool_registry schema + 透传 payloads | `tools/tool_registry.py` 112/122/260/272 | ✅ |
| A10 | 决定性实测：内置字典 0 命中 -> AI 自造 1 命中（SQLi+XSS 双侧） | `/tmp/demo73b.py` | ✅ |
| A11 | 零破坏契约回归 13 个脚本全绿 | `lab/verify_round*` | ✅ |
| A12 | 提示词串通：hunt_consumer 教 AI 用 payloads | `tools/hunt_consumer.py` _SYSTEM_HEAD | ✅ |
| A13 | 修 A 组 P0 引入回归：`_SYSTEM_PROMPT` 里 `"{caps}"` 被连写成 `"{caps}{hunt}"` 致 round70 A12 字面断言失败，拆两行恢复锚点（功能不变） | `tools/agent_loop.py` 41 行 | ✅ |
## B. 桌面 Tkinter（`ui/gui.py`）

| # | 事项 | 落点 | 状态 |
|---|---|---|---|
| B1 | 新增「暂停 / 继续」按钮（两态） | `ui/gui.py` 496-505 行按钮区 | ✅ |
| B2 | 新增「清空」按钮：清空输出框，不影响扫描 | `ui/gui.py` 509 行日志区 | ✅ |
| B3 | 引擎加 `threading.Event` 暂停机制 + `pause()/unpause()` | `core/engine.py` 142 行附近 | ✅ |
| B4 | 暂停粒度：**当前批次跑完再停**（检查点判定，不硬掐线程） | engine 阶段循环 655/709/920/1162 处 | ✅ |
| B5 | 关闭 EXE 时自动暂停 + 留进度：`on_close` 先 pause 等收口再 destroy | `ui/gui.py` 580-592 行 | ✅ |
| B6 | 未扫完 URL **不得** `mark_scanned`（否则续扫误跳过） | `core/engine.py` 658-762 行 | ✅ |
| B7 | 验证：暂停 -> 继续 -> 关闭重开续扫 三路径实测 | `lab/` + 手工 | ✅ |

## C. Web 控制台「资产」页删除失效修复

| # | 事项 | 落点 | 状态 |
|---|---|---|---|
| C1 | `decorateTable` 优先读行内 `data-id`（无则回落首列文本） | `ui/web.py` 877-892 行 | ⬜ |
| C2 | `loadAssets` 每行加 `data-id`（assets 首列是主机名不是 id） | `ui/web.py` 592-601 行 | ⬜ |
| C3 | 验证：单选/多选 -> `已删除 N`，DB `assets` 行数减少 | 手工 + `sqlite3` | ⬜ |
| C4 | 回归确认：findings / verify 删除仍正常 | 手工 | ⬜ |

## D. Web 控制台「SKILL」页总开关对齐「MCP」页

| # | 事项 | 落点 | 状态 |
|---|---|---|---|
| D1 | 增加 SKILL 全局开关位（默认开） | `config/config.json` -> `takeover.skill.enabled` | ⬜ |
| D2 | 后端技能加载尊重该位 | `tools/skill_loader.py`、`tools/capability.py` | ⬜ |
| D3 | `/api/skill/list` 返回 `enabled` 全局位 | `ui/web.py` 1364 行附近 | ⬜ |
| D4 | 前端文案/行为改与 MCP 一致 | `ui/web.py` 773-775、834-835、497 行 | ⬜ |
| D5 | 验证：与 MCP 页并排对比一致；关掉后技能不生效 | 手工 | ⬜ |

## E. 交付与卫生

| # | 事项 | 状态 |
|---|---|---|
| E1 | 每处改动前 `cp -p xxx.py xxx.py.bak_r73`；绝不 mv/改名源文件 | ⬜ |
| E2 | `_PAGE` 内联 JS 嵌 onclick 用**四重**反斜杠；改完 `node --check` | ⬜ |
| E3 | 含中文+复杂引号的批量替换写 `.py` 落 `/tmp/` 再执行 | ⬜ |
| E4 | **A–E 全完成后统一重打包** exe / src.zip / MD5SUMS.txt（按 make_src_zip -> make_sfx_exe pack -> make_src_zip 三连） | ⬜ |
| E5 | 跑完 `pkill -9 -f vuln_server.py` 查残留 | ⬜ |

---

## 偏了怎么办（三步）
① 停；② 声明（我原本要做 X，刚才跑去做 Y 了）；③ 拉回（回到本清单的下一步继续）。
