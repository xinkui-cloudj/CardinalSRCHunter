# 交接文档 round86 — MCP 口径真统一 / DNS 兜底 / 换形态 / 阶段输出恢复 / 并发提速

## 一、本轮背景
r85 实机测试后用户报三问题：
1. MCP 三处显示口径矛盾：桌面主输出「0 服务/0 工具（未生效）」、AI 框「12 个工具已连接」、Web「握手成功」。
2. 之前不装 skill 与 mcp 插件也能扫域名，现在 lani.cc 直接不可达，进不了 7 个阶段。
3. 以前每阶段有明细（阶段1/7 敏感路径 +0.0s 字典63条 …阶段7/7），现在没了。
用户补充：没改过 DNS；连子域一起验证；所有功能必须正常好使。

## 二、六个真根因（均已实证）
### 根因 1：selfcheck 缓存常量根本不存在（本轮新发现，最严重）
tools/capability.py 的 selfcheck() 引用 _SELFCHECK_CACHE / _SELFCHECK_TTL，
但模块级从未定义 -> 首次调用必抛 NameError，被调用方 except 吞掉，退化成假的「MCP 段未配置」。
修前实证：verify_round85 直接 NameError 崩；修后 selfcheck(None) 返回 n_servers=2 n_tools=1 reason 空。

### 根因 2：_mcp() 不读兜底配置，与 selfcheck 两个数据源
_mcp(engine) 只读 engine.config；engine=None（CLI 自检 / 启动早期）拿不到配置，
于是一边 selfcheck 报 2 个服务、一边 _mcp 报「未配置」—— 正是用户看到的矛盾。
已补 cfg_obj 兜底：engine 为空时走 core.config.Config().data，与 selfcheck 同源。
实测：能力清单：SKILL 2 个｜MCP 服务 2 个｜MCP 工具 1 个（ping），不再误报。

### 根因 3：DNS 全服务器失败时没有系统 DNS 兜底
resolve_ex() 在全部服务器失败时直接判 dns 失败，从不试系统 getaddrinfo。
D2：收尾处 res[1] in (dns,timeout) 时先 _socket_fallback(h)，拿到 IP 就改写为 sysdns(...)。
D3：_hooked_getaddrinfo 内，两侧都空且 code in (dns,timeout) 时 return _ORIG_GETADDRINFO(...)，
彻底把 socket 交回系统实现，避免 urllib3 先报一次 getaddrinfo failed。
红线：nxdomain/nodata 是权威答案，不覆盖。

### 根因 4：域名本体无 A 记录，DNS 兜底也救不了，必须换形态
实测 lani.cc 在本环境是 nodata（域名存在但无 A/AAAA），系统解析也拿不到 IP。
但 probe_variants 能拿到真能解析的兄弟形态：lani.cn（103.207.166.56）、www.lani.cn、lani.com、www.lani.com。
D4：新增 _try_alt_host，原形态解析失败时切到候选形态，只切一个、先解析成功才发 HTTP；记录 original_host / via_variant。
D5：候选按实测 TCP 建连延迟排序（_tcp_latency，只建连不发 HTTP，budget=2.0），避免串到 24s 的慢候选。
实测：lani.cc -> lani.cn / www.lani.cn 返 200。

### 根因 5：阶段输出丢失是 DNS 失败的「症状」不是独立 bug
core/engine.py 的 _stage/_stage_done 与 13 处 _stage( 调用本就完整存在。
之前看不到阶段行，是 probe_host 在 DNS 失败时提前 return，根本没进阶段。
DNS+换形态修好后实测恢复：阶段1/7 敏感路径 +0.0s 字典 63 条 … 阶段7/7 落库 + PoC 复现。

### 根因 6：敏感路径串行太慢（63 条 x 2.9s = 182s）
probe_sensitive_paths 改 ThreadPoolExecutor 并发（读 http.concurrency_max，默认 8，上限 8），
_ex.map 保序回填，判定口径（软404/基线/WAF）完全不变，每 20 条打进度。
实测：182s -> 38.7s（4.7 倍）；e2e 内网靶场 63/63 仅 14.0s。

## 三、本轮改动清单
| 文件 | 改动 |
|---|---|
| tools/capability.py | 新增模块级 _SELFCHECK_TTL=20.0 / _SELFCHECK_CACHE；_mcp() 补 cfg_obj 兜底，engine 为空时用 Config().data |
| core/dnsx.py | D2 resolve_ex 收尾系统 DNS 兜底；D3 _hooked_getaddrinfo 两侧全空时交回 _ORIG_GETADDRINFO |
| modules/probe.py | 新增 _try_alt_host / _tcp_latency，fail 时换形态；probe_sensitive_paths 串行改并发 8 |
| ui/gui.py | 新增 eng.weak_password 显式覆盖（与 enable_active / enable_poc 对齐） |
| lab/verify_round86.py | 新建，35 条断言 |
| build/make_sfx_exe.py | BUILD_ID 升级 r86- |

## 四、验证结果（全部实测）
| 项 | 结果 |
|---|---|
| verify_round86.py | 35 / 35 PASS |
| verify_round85.py | 31 / 31 PASS |
| 关键脚本 15 个（27b/35/39/49/50/66/79/80/81/82/83/84/84_mcp_e2e/85/86） | 608 断言 0 失败 0 异常 |
| 全量回归 127 个脚本 | 7 个非零退出全部查实：4 个为环境干扰（端口占用 / 跨脚本残留队列），隔离重跑全绿 |
| selfcheck 真实执行 | n_servers=2 n_tools=1 reason 空（修前 NameError） |
| 能力清单口径 | SKILL 2 / MCP 服务 2 / MCP 工具 1（ping），三处同源 |
| e2e 内网靶场 | 7 阶段逐条输出，敏感路 63/63 仅 14.0s |

## 五、交付物（dist-win/）
| 文件 | 大小 | MD5 |
|---|---|---|
| CardinalSRCHunter.exe | 21726634 | d5f0d90ad18ab91db2a7e83cafc43457 |
| CardinalSRCHunter-src.zip | 978571（206 files） | 5172f7710fc5b210942b08da17276bca |
| MD5SUMS.txt | 250 | 三条清单，无残留字符 |
VERSION stamp = r86-20261019-171304
check_exe_r82：BAD=0，175 项 PASS（重解包 /tmp/verify82 后实测）

## 六、下次开工先看这里
1. 改完 ui/gui.py 或 tools/capability.py 后必须重打包，否则 check_exe_r82 会报 DIFF
   （本轮踩过：先打包后改码，BAD=2；重打后 BAD=0）。
2. check_exe_r82 读的是 /tmp/verify82 缓存，重打包后必须 rm -rf /tmp/verify82 再 7z x 解包，
   否则会读到旧产物，VERSION stamp 仍是上一版。
3. 全量回归里 verify_e2e.py 会真跑 7 阶段，>200s，批量跑时必须排除或加大 timeout，
   否则 EXIT=124 会被误判成失败。
4. 并行跑多个验证脚本会互相抢 8081 端口（round27/27b 报 Address already in use），
   分批串行跑或先 pkill 残留。
5. lani.cc 本身无 A 记录，靠换形态生效；验证时用 lani.cc 能验到 _try_alt_host 分支。
