#!/usr/bin/env bash
# 一键开 AI（Cardinal-SRC-Hunter）
# 用法：bash ai_on.sh scan -t 目标        # 开 AI 后跑工具
#       bash ai_on.sh status             # 只看 AI 是否就绪
#       bash ai_on.sh                    # 等价 status
#       bash ai_on.sh --on scan -t 目标   # 额外强制打开三个开关
#
# round76 重写要点（用户拍板「要移除 ai_on.sh 的环境变量覆盖」）：
#   旧版会 export BTSRHUNTER_AI_BASE / BTSRHUNTER_AI_MODEL（即使是空串），
#   而 core/config.py 的 _ai_env_override() 只跳过「None」——空串虽然被
#   跳过，但只要调用方 shell 里残留了这两个变量，它们就会**盖掉**你在
#   Web 控制台里保存的端点/模型，表现为「配了却不生效」。
#
#   现在改成：脚本**只保证密钥就位**，开关与端点/模型一律以
#   config/config.json（= Web 控制台写入的落点）为唯一事实来源。
#   想让脚本强制打开开关，用显式参数 --on；不带 --on 就完全不动配置。
#
# 密钥落点（与 core/config.py 的 ai_key_path() 对齐，按顺序取第一个存在的）：
#   1) $BTSRHUNTER_KEYFILE（显式指定优先）
#   2) 程序数据目录 data/ai_key.txt（Web 控制台「保存」写入的位置）
#   3) 项目外旧位置 /storage/emulated/0/Audiobooks/ai_key.txt（兼容老用户）
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1

FORCE_ON=0
NEWARGS=()
for a in "$@"; do
  if [ "$a" = "--on" ]; then
    FORCE_ON=1
  else
    NEWARGS[${#NEWARGS[@]}]="$a"
  fi
done

# ---- 定位密钥文件：只认文件，不再用环境变量往子进程里灌值 ----
KEYFILE=""
for cand in "${BTSRHUNTER_KEYFILE:-}" "$HERE/data/ai_key.txt" "/storage/emulated/0/Audiobooks/ai_key.txt"; do
  if [ -n "$cand" ] && [ -f "$cand" ]; then
    KEYFILE="$cand"
    break
  fi
done

if [ -z "$KEYFILE" ]; then
  echo "[x] 没找到密钥文件，已查过："
  echo "      \$BTSRHUNTER_KEYFILE / $HERE/data/ai_key.txt / /storage/emulated/0/Audiobooks/ai_key.txt"
  echo "    推荐做法：打开程序 →『Web 控制台』→『端点与API』页填好密钥点保存，"
  echo "    会自动写入 $HERE/data/ai_key.txt，本脚本即可直接读到。"
  exit 1
fi
KEY="$(tr -d ' \t\r\n' < "$KEYFILE")"
if [ -z "$KEY" ]; then
  echo "[x] 密钥文件是空的: $KEYFILE"
  exit 1
fi

# 只设 KEY 一个变量：端点/模型/开关全部留给 config.json 决定
export BTSRHUNTER_AI_KEY="$KEY"

if [ "$FORCE_ON" -eq 1 ]; then
  # 只有显式 --on 才动开关；端点/模型仍然读 config.json，绝不在此覆盖。
  export BTSRHUNTER_AI_ENABLED=1
  export BTSRHUNTER_AI_ONLINE=1
  export BTSRHUNTER_TAKEOVER=1
  echo "[+] 已按 --on 强制打开 AI 开关（端点/模型仍取 config.json）"
else
  echo "[i] 未加 --on：开关与端点/模型全部以 config/config.json 为准（Web 控制台保存的即生效）"
fi
echo "[i] 密钥来源: $KEYFILE"

if [ "${#NEWARGS[@]}" -eq 0 ]; then
  python3 tools/ai_client.py status
  exit 0
fi
exec python3 main.py "${NEWARGS[@]}"