# 交接文档 — round81
> 接手前先读 `进度.md`（任务锚点 + 逐轮进度）与 `项目总结报告.md` §21（本轮完整交代），再读本文件。

## 1. 本轮做了什么（三件实机反馈 + 版本戳连锁）
1. **长静默不可辨**：网络枚举 / 接管检测 / 参数级检测这些"发流量的循环"都要能被证明"不是卡死"。落在 `modules/recon.py`（3 处）、`core/engine.py`（9 处）、`core/engine.py::_collect_urls` 的浅爬心跳（B6 新增）。
2. **目标被落盘（填一次就锁死）**：桌面「保存配置」不再持久化目标。落在 `ui/gui.py`。
3. **AI 输出无独立框**：主日志与 AI 日志分流到上下两块框。落在 `ui/gui.py`。
4. **版本戳 r81 连锁**：任何"装机后可观测行为"新增，都必须同步两端版本戳并做连锁解锁。

## 2. 版本戳两端（同一条事实，必须同步）
| 位置 | 值 |
|---|---|
| `ui/web.py::_APP_VER` | `"r81"`（第 36 行） |
| `build/make_sfx_exe.py::BUILD_ID` | `"r81-" + time.strftime(...)`（第 36 行） |

`_APP_VER` 同时是 `/api/ver` 的握手标识：`create_server()` 端口被占时依次试 `port+1..port+tries-1`，撞到**同版本**控制台则认领（`_console_alive()` 判 `app == "Cardinal-SRC-Hunter"` 且 `ver == _APP_VER`）。
前缀锁沿用**区间口径** `re.match(r"r(?:7[5-9]|[89]\d)-", v)`：此后升版只动版本常量 + 脚本名/目录名，不要再写死具体版本。

## 3. 可观测性契约（B 组）
- 心跳闸门统一"**双闸门先到先打**"（计数 + 时间）；**心跳行必须带等待上限数值**，否则用户仍分不清"慢"与"死"。
| 点位 | 行格式要点 |
|---|---|
| `modules/recon.py` 枚举收尾 | `子域枚举完成：<域名> → N 个（耗时 %.1fs）` |
| `modules/recon.py::_beat()` | 接管检测：`_i % 20 == 0` 或 `now - _last_beat >= 15.0`，或 `_i == _n_probe` 收尾必打；开场先声明"串行、预计 N×0.3s 起" |
| `core/engine.py::_hb()` | 30s 长静默闸门（**纯日志，不改控制流**） |
| 主机开始 / 完成 | 开始行写明"单台走 7 个阶段，慢属正常，**不是卡死**"；完成行打 `耗时 %.1fs / 存活 N / 发现 N` |
| `[队列]` 交接 | `N 台主机 × 每台上限 M 请求（并发 C；…不是卡死）` |
| 参数级检测 | `[检测] <主机> 进行中 n/N（已 Xs，未卡死；本机参数级等待上限 Ys）`，`Y = _fut_timeout()` |
| `_collect_urls` 浅爬（**本轮新增 B6**） | 每轮第 1 页 / 每 10 页 / 距上次超 30s：`[浅爬] <主机> 第 d/D 轮：n/N 个页面（单页最坏 36s，未卡死）` |

- `_fut_timeout()` = `timeout 12 × (重试 2 + 1) × 4 = 144`，是**设计值**：真实长任务仍可能在该上限内静默，但已可由日志判读、不再是零信息静默。
- 静态扫描结论：`scan_host` 的 7 个主阶段 + 3.5~3.9 子阶段**每条都有 `_stage()` 行且带 `+%.1fs`**；`core/dnsx.py` 有 `lifetime` 与 `min(lifetime, 3.0)` 上限、`resolve_ex` 走 `as_completed(timeout=life+1.5)`；`crt_sh_subdomains` 是裸 `requests.get(timeout=20)`（刻意不走 scope 守卫）——单点 20s 上限。**唯一真实缺口是浅爬循环，已补**。

## 4. 目标不落盘的契约（C 组）
- `ui/gui.py::save_ui_prefs` 里 `_p["targets"] = ""`——**显式写空、不要 `pop`**：偏好是整段覆盖，`pop` 只是"这次不写"，老装机上旧值原地复活。
- 开窗 `target_var = tk.StringVar()`（第 277 行），**不从 `ui_prefs` 回填**，所以"上次填的目标"再也不会变成删不掉的默认值。
- 落盘时机**提前到 `Engine(...)` 创建之前**（旧顺序排在 Engine 之后，引擎一慢就轮不到落盘）。
- `ui.targets` **键保留在 `DEFAULT_UI` 里**（不删键），避免老装机读配置时 `KeyError`；只是不再承载语义。
- `_cfg_get_in_scope` 已无调用点，补注释标记为历史遗留。
- 曾计划的 C12（"坏配置不要让目标框变空"）**经复核废弃、未执行**：`Config.load()` 解析失败时自吞异常 + 回落默认值，`Config()` 不抛，目标框不会因坏配置变空。

## 5. AI 黑框契约（D 组）
```
_AI_LOG_PREFIXES = ("bt.agent", "bt.skill", "bt.mcp", "bt.ai")   # ui/gui.py:54
def _is_ai_log_name(name): ...                                   # ui/gui.py:57
```
- **分流按 logger 名**，不做正文关键词匹配；`_install_queue_logging(q, q_ai=None)` 保持单参形态向后兼容（老调用点仍全部进主框）。
- **两个独立队列 + 两个独立泵**：`pump_main(q)` / `pump_ai(q_ai)`，各 300ms 一轮。
- `_make_logbox(parent, height, bg=None, fg=None)` 复用同一套造框逻辑；AI 框 `bg="#0b0b0b"` / `fg="#39d353"`；上下 **70:30** 分栏。
- **AI 框独立清空**：`do_clear_ai()`（按钮「清空 AI 框」）只清 AI 那一路，不动主日志。
- **首行固定状态行**：`_AI_HEAD_PREFIX` + `_write_ai_head()`，用 `ai_box.delete("1.0", "2.0")` **原地改写第一行**，其余内容一律追加；`takeover.enabled=false` 时显示"○ AI 未连接（本轮扫描不调用 AI）"——**这一行是"AI 起没起"的唯一判据来源**。

## 6. `lab/verify_round81.py` 覆盖范围（五组）
| 组 | 条数 | 内容 |
|---|---|---|
| A | 18 | 静态锚点（分流常量 / 两队列两泵 / 清空函数 / 首行原地改写 / 目标写空非 pop / 落盘顺序 / 心跳双闸门 / 版本戳两端） |
| B | 6 | **真跑日志分流**：无头加载 `ui/gui.py` 后装分流，分别以 `bt.engine`/`bt.recon`/`bt.agent` 打日志，再断言各自的队列归属 |
| C | 3 | **真跑偏好往返**：`tempfile.mkdtemp()` + `BTSRHUNTER_USER_DIR` 起子进程，回读 `config.json` 断言 `targets` 为空、键仍在 |
| D | 6 | **真跑引擎**：`_hb()` 首真次假（30s 闸门真实生效）、`_fut_timeout() == 144`、`_host_prog` 起始为空、`db.load_session()` 无残留 |
| E | 16 | 版本戳连锁（两端 r81 / `check_exe_r81.py` 在且 r80 已删 / regall 登记与无残留 / 区间窗口 / 13 条 `r81:` 锚点 / `FILES` 含 `modules/recon.py`） |

→ 汇总 **`ROUND81 PASS=49 FAIL=0`**（首跑 37/3 的三条**全为脚本自身缺陷**，非代码缺陷）。

## 7. 跑回归的前置条件（易踩）
- `lab/regall.sh` **自己拉靶机** `python3 lab/vuln_server.py`（端口 8081）并等就绪；起不来会打 `WARN: vuln_server not reachable` 且 live 检查变红。
- **类 A 全量跑依赖 `dist-win/CardinalSRCHunter.exe` 与工作区一致**：改完源码没重打包 → EXE 复核组红（**设计意图，不许静默跳过**）。
- 重打包顺序：**文档先定稿** → `build/make_src_zip.py` → `build/make_sfx_exe.py pack` → 刷 `dist-win/MD5SUMS.txt` → 抽查载荷 → 再跑全量回归。**EXE pack 之前必须确认文档已定稿**，否则载荷内嵌旧文档（round80 踩过，EXE md5 变了旧锁定日志即失效）。
- 回归判定口径：只看末行 `REGALL TOTAL PASS=n FAIL=n SCRIPTS_FAILED=n` 的 `FAIL=0` 与 `SCRIPTS_FAILED=0`，**不看 PASS 绝对值**。重打包 AFTER 跑的日志 = `/tmp/reg81final.out`。

## 8. 本轮教训（防复发）
1. **"可观测"要给证据、不是口号**：心跳行必须带**上限数值**（`单页最坏 36s` / `参数级等待上限 144s`）。
2. **心跳闸门要"计数 + 时间"双闸门先到先打**：只按计数，子域少而每个都慢时仍静默；只按时间，子域多而每个都快时日志过密。
3. **不落盘的键要写空、不要 `pop`**：整段覆盖式偏好保存里，`pop` 只是"这次不写"。
4. **发出流量的循环都要有心跳**：凡 `for` 里发网络请求且循环内无日志，一律视为潜在静默源（本轮唯一真缺口就在浅爬循环）。
5. **验证脚本的 `%%` 陷阱**：内层 `%r` 会被外层 `%` 当占位符吃掉（本轮 C/D 整组红）——改用 `repr()` 拼接，不要靠数 `%` 转义。
6. **断言要看住"复位发生在哪个函数里"**：E5b 的 `_host_prog = None` 落在 `scan_target()` 内（`run()` 之前），断言却切了 `run()` 之后 3000 字——属**断言位置错**而非代码缺陷。排查顺序永远是：**先看 `extra` 输出，再怀疑代码**。
7. **报告里不要写会过期的回归数字**：本轮 §21.6 曾留下 `PASS=3362`（疑似 round78 旧值），已按 `/tmp/reg81final.out` 修正为 `3586`；交付物 md5 / 体积 / `VERSION` 戳一律以 `dist-win/MD5SUMS.txt` 为唯一出处。

## 9. 接手 checklist
- [ ] 读 `进度.md` 首行锚点 + 本轮段落，读 `项目总结报告.md` §21。
- [ ] `dist-win/MD5SUMS.txt` 核对工作区是否一致；若刚改过源码，必须先重打包（否则 EXE 复核组必红）。
- [ ] `bash lab/regall.sh`，末行须 `REGALL TOTAL PASS=… FAIL=0 SCRIPTS_FAILED=0`。
