# Cardinal-SRC-Hunter 交接文档 · round79

> 生成：2026-10-19 ｜ 代码版本 **round79**（round78 基线 + 技能工具声明与补调用提醒 + Web MCP 五态报因与探活 + 版本戳 r79）
> 交付物：`dist-win/CardinalSRCHunter.exe` + `dist-win/CardinalSRCHunter-src.zip`
>         （哈希一律以 `dist-win/MD5SUMS.txt` 为准，文档不写死）
> 版本戳：`ui/web.py::_APP_VER = "r79"`、`build/make_sfx_exe.py::BUILD_ID = "r79-"+时间戳`

---

## §1 本轮做了什么（用户两项待办 + 版本错位）

用户原话：「先把后续待办那两点做了，再修A」。两点取自 `项目总结报告.md` §18.8，A 指 `ui/web.py` 版本戳错位。

| # | 待办 | 结论 | 落点 |
|---|---|---|---|
| ① | SKILL 仍为提示词形态，不产生工具调用动作 | 完成（**甲方案**：技能可声明 `tools:`，收尾时一次未调则补一次提醒轮） | `tools/skill_loader.py::skill_tools()`、`tools/agent_loop.py::_skill_requirements/_skill_note/_remind_text` |
| ② | `ui/web.py` 的 MCP 展示没接 `mcp_reason` | 完成（五态报因 + **实地探活**「测试连接」） | `ui/web.py::_mcp_shape/_mcp_probe/_mcp_list`、前端 `probeMCP()` |
| A | `_APP_VER="r77"` 而 `BUILD_ID="r78-"` | 完成（**r79 两端同步** + 全套连锁解锁） | 见 §4 |

---

## §2 甲方案的确切语义（避免下一位误解）

**甲 ≠ 提前强制调用。** 既有行为不变：扫描进入 AI 环节后，模型自己判断调不调、调哪个。甲只加一处兜底：

```
模型说「不调了，我的结论是…」
        ↓
技能里声明了 tools，且这些工具一个都没被调用过？
   ├─ 否 → 正常收尾（技能没写 tools: 时永远是这一条，行为与 round78 逐字一致）
   └─ 是 → 追加 user 提醒轮（只 1 次，remind_used<1）
             ├─ 模型调用 → 继续，命中后记 [SKILL] 技能要求工具已全部命中
             └─ 模型仍不调 → 记 [SKILL] 收尾仍未调用技能工具（程序不代发请求），收尾
```

- **乙方案（未采用）**：技能声明了工具就由程序按顺序无条件调用。缺判断权、易打无关工具、更易撞强度闸门。
- **判断权归属**：始终在模型。程序只「问一次」，不替它发请求。
- **零风险**：现有两个技能都没写 `tools:`，`skill_tools()` 返回 `[]`，`skill_req` 为空 → 提醒分支永不进入（`verify_round79.py` C5 锁死：chat_step 只调 1 次）。

---

## §3 本轮契约（改代码前必读）

1. **`skill_loader` 导入面仍是纯标准库**（`round49 N3` 锁）。新增 `skill_tools()` 只用 `_parse`/`list_skills`/`global_enabled`，不 import 任何新东西，尤其不 import `tool_registry`（避免 `tools/` 内部环）。
2. **`tools:` 是可选键**，不写必须与旧行为完全一致。`_parse()` 里用 `re.split(r"[,;\s]+", ...)` 切分并去重，保持 front-matter 未声明时 `tools == []`。
3. **`skill_tools(kind)` 的 kind 口径与 `text_for(kind)` 完全一致**：`all` 类技能对任何 kind 都生效。不要把它写成「精确匹配」——`verify_round79.py` B6 锁的是「同口径」。
4. **提醒轮上限硬编码 `remind_used < 1`**：任何把它放宽成 `> 1` 的改动都属于方案变更，必须重新征得用户同意。
5. **探活函数（`_mcp_probe`）是纯读路径**：只允许 `MCPClient.initialize()` / `list_tools()` / `close()`，**函数体内不得出现 `_write_cfg_json`**（`verify_round79.py` F6 静态锁）。也不得调用 `call_tool`。
6. **`/api/mcp` 的分支顺序**：`upload` → `probe` → `list/show` → 其余写操作。`probe` 必须在任何写配置分支之前 `return`。
7. **`_mcp_list()` 的返回结构只增不改**：新增 `reason_code` / `reason` / `active_servers`，原有 `ok` / `enabled` / `servers` 一字不动（旧前端路径继续可用）。
8. **版本戳前缀锁已改为区间**：`re.match(r"r(?:7[3-9]|[89]\d)-", v)`。历史上「升版要改 check_exe 前缀锁」的 Labor 从此免除，但**脚本名还得随版本改**（`check_exe_rNN.py`）。

---

## §4 版本戳 r79 连锁清单（已全部执行）

| 文件 | 改动 |
|---|---|
| `ui/web.py:36` | `_APP_VER = "r77"` → `"r79"` |
| `build/make_sfx_exe.py:36` | `BUILD_ID = "r78-"` → `"r79-"` |
| `lab/check_exe_r78.py` | **改名 `lab/check_exe_r79.py`，旧版删除不留双版本** |
| `check_exe_r79.py` 内 | `EX78_DIR`/`/tmp/verify78` → `EX79_DIR`/`/tmp/verify79`（4 处）；`v.startswith("r78-")` → `re.match(r"r(?:7[3-9]|[89]\d)-", v)` |
| `lab/regall.sh` | 脚本名 2 处、`EX78_DIR` 5 处、`verify78` 2 处；**登记 `lab/verify_round79.py`** |
| `lab/verify_round73.py` | E4 改为接受区间 `re.match`；E6 追加「不得残留 `check_exe_r78.py` / `verify78`」 |
| `lab/verify_round75.py` | I7 改为接受区间 `re.match` |
| `lab/verify_round77.py` | H7 改为接受区间；H10 追加「`check_exe_r78.py` 不得存在」 |

**踩坑提醒（本轮真实发生）**：`/tmp/r79_p4.py` 在改 `check_exe_r79.py` docstring 时锚点不匹配，`sys.exit(1)` 中途退出，但**前 4 处已落盘**。按 round75 铁律 #1，续写 `/tmp/r79_p4b.py` 只做剩余部分即可，不要重跑整段补丁（会因已替换而 `MISS`）。

---

## §5 验证证据（可复现）

```sh
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter

python3 -B lab/verify_round79.py        # ROUND79 PASS=70 FAIL=0
python3 -B lab/verify_round78.py        # ROUND78 PASS=66 FAIL=0
python3 -B lab/verify_round77.py        # ROUND77 PASS=103 FAIL=0
python3 -B lab/verify_round75.py        # ROUND75 PASS=150 FAIL=0
python3 -B lab/verify_round73.py        # ROUND73 PASS=67 FAIL=0
python3 -B lab/verify_round59.py        # PASS=63 FAIL=0

sh lab/regall.sh                        # 全量回归，末行 REGALL TOTAL ... SCRIPTS_FAILED=0

rm -rf /tmp/verify79 && mkdir -p /tmp/verify79
7z x -y -o/tmp/verify79 dist-win/CardinalSRCHunter.exe
EX79_DIR=/tmp/verify79 python3 -B lab/check_exe_r79.py    # BAD=0
```

**回归口径**：只认 `FAIL=0` 且 `SCRIPTS_FAILED=0`，不看 PASS 绝对值（round25 的历史坑）。

---

## §6 交付物重建（改任何源码后必须重跑）

```sh
python3 build/make_src_zip.py        # 源码包
python3 build/make_sfx_exe.py pack   # EXE
python3 build/make_src_zip.py        # 再跑一次刷新 dist-win/MD5SUMS.txt
python3 build/make_src_zip.py --check # 自校验，必须 CHECK files=N bad=0
```

- `make_src_zip.py` 末尾两个硬自检：`BAK_LEAK bad=0`、`VERIFY bad=0`，任一非 0 返回 1；
- `make_sfx_exe.py pack` 的 `copy_app()` 有「包内混入备份文件」自检；
- EXE 内层 7z 必须 `-mf=off` 且格式版本 0.3（否则 7-Zip 9.20 SFX 报 `Unsupported Method`，双击无反应）。

---

## §7 本轮新增铁律

1. **「声明」必须可选且默认为空**：给既有机制加声明式能力时，不写必须与旧行为逐字节一致。加声明键的同时必须补一条「不声明 → 行为不变」的断言（本轮 B2 / C5）。
2. **任何可能为 0 的计数都要能报因**：round78 修了能力清单侧，round79 补 Web 侧。以后新增「N 个」类展示，必须同时设计 `reason_code` + 中文 `reason`。
3. **探活类功能一律只读**：只 `initialize` / `list`，禁止 `call`；用静态断言把「函数体内不得出现写配置调用」锁死。
4. **补漏 ≠ 代打**：提醒一次即止，模型不采纳就如实留痕。「有没有调」和「该不该调」是两件事，程序不越位。
5. **版本戳是同一条事实的两端**：`_APP_VER` 与 `BUILD_ID` 必须同步改；只改一侧就是一处离线可观测的错误（本轮修的正是这个）。
6. **`python3 - <<'PYEOF'` 里不要套三引号**；改文件的活一律写 `/tmp/*.py` 再跑（round75 铁律 #4 继续有效）。
7. **`create_file` 覆盖同名文件会被拒绝**，要先 `delete_file` 再建（round75 铁律 #5）。本轮用的是 `edit_file` 定点替换，未受影响。

---

## §8 待下一轮（本轮未动）

- **`tools:` 只做「要求」不做「校验」**：技能写了不存在的工具名，只在日志里出现，不报错。要强校验需在 `_skill_requirements()` 里与 `tool_registry.schemas()` 求交后给出警告（会新增一条日志与一个 UI 提示位，需决策）。
- **探活是按需单次的**：页面不会自动探活（避免引入后台线程，与「不自动起后台任务」的习惯冲突）。若要求「开机即显示已注册 N 个工具」，需另决策。
- **`ui/web.py` 的 `__ai_status.ready` 仍不含 takeover 第三闸门**（round75 §7 遗留，仍与 `gui.py::_ai_status_line()` 口径不一致，未动）。
- **`core/engine.py` 的 `os.path.basename` 死日志**（round75 §7 遗留，该文件未 import os），未触碰。
- **备份命名仍不统一**（`.bak` / `.bak_rNN` / `.r62bak` 并存），靠两个打包器的 `BAK_LEAK bad=0` 兜底。本轮新增 `.bak` 备份无。
