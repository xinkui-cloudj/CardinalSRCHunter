# Cardinal-SRC-Hunter · round58 交接文档（新会话对接用）

> 生成时间：2026-10-10 06:25（round58 收口后重写）
> 项目根：`/storage/emulated/0/Audiobooks/src/bt-src-hunter`
> 定位：**round58 已闭环交付。** 本轮补上了基线 12 项里工具此前 0 覆盖的头号高危（匿名开放注册接口下发会话凭据）。全量回归 `PASS=2123 FAIL=0 SCRIPTS_FAILED=0`（53 脚本），交付物已重建并校验一致。

---

## 0. 这份文档怎么用（新会话先读这段）

- 本文件是**会话交接摘要**：让新对话不用翻旧记录，直接接上工作。
- **默认路径（任务已完工）**：照 §1 跑核验命令 → 照 §2 看成果 → 照 §3 看交付物。核验通过即确认交付，**不需要重跑扫描、不需要重改代码**。
- **继续开发路径**：看 §6「下一轮方向（round59）」+ §4 环境坑，直接开工。
- **⚠️ 最高优先级红线（用户明确要求）**：**禁止后台自动跑任何长任务**。不要用 `nohup ... &`、不要用 `background=true` 启动 `lab/regall.sh` / `lab/vuln_server.py`。用户反馈后台自动触发的东西会干扰其他对话、导致工作无法进行或数据丢失。
  - 正确做法：**前台受控执行** + 显式 `timeout`，跑完即退，不留残留进程。
  - 全量回归单轮约 13 分钟（前台 `timeout 780 sh lab/regall.sh` 可覆盖到第 51 个脚本，e2e 与 t_malformed 单独补跑）。
  - 每次跑完**必须**复核残留进程（命令见 §1）。

---

## 1. 当前实时状态（核验命令）

**任务已全部收口，无后台进程在跑，8081 端口已释放。** 新会话第一件事：

```bash
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter
cat dist-win/MD5SUMS.txt                          # 三行 md5 应与本文件 §3 一致
for p in /proc/[0-9]*; do pid=${p#/proc/}; c=$(cat $p/cmdline 2>/dev/null | tr "\0" " "); case "$c" in *vuln_server*|*regall*|*verify_*) echo "残留 $pid $c";; esac; done   # 应无输出
ls -l lab/verify_round58.py                       # 346 行，本轮新增
```

- 回归日志：`/tmp/regall58b.log`（51 脚本，2096 PASS / 0 FAIL / 0 脚本失败）、`/tmp/e2e58b.log`（e2e RC=0 / 落库 13 条 / EXIT_OK）、`/tmp/tmal58.log`（27 PASS）。

---

## 2. 本轮已完成（round58）

### 2.0 选向依据

round57 基线（`reports/lhy.linghanyun.com-20261010-033901-20201-1/evidence/99_手工复现_基线对标.txt`）里**头号高危**是：
匿名 `POST https://lhy.linghanyun.com/openApi/faUser/register` → `200` + `{"data":{"token":"b79376ea68b34b2aa78b06e193072f6e"},"code":200,"message":"注册成功"}`，即**未鉴权即可注册并下发会话 token**。而工具报告对该点 **0 覆盖**。round58 就是补这个洞。

### 2.1 新增能力：开放 API 注册端点未鉴权 + 下发会话凭据检测器

| 文件 | 改动 |
|---|---|
| `core/dicts.py:446` | 新增 `OPEN_API_PROBES`（5 端点 5 元组：`path, method, body模板, desc, severity`，body 用 `{u}/{p}/{m}/{e}` 占位） |
| `core/config.py:45` | `scan` 段新增 `"open_api_probe": True` |
| `core/engine.py:513-516` | 新增「阶段 3.6/7 开放 API 注册面」接入（受 `scan.open_api_probe` + `_budget_ok` 控制，try/except 隔离） |
| `modules/vulnchecks.py:13` | `import zlib` |
| `modules/vulnchecks.py:822-920` | `_OPEN_API_CRED_RE` / `_open_api_placeholder()` / `_open_api_body()` / `check_open_api_auth()`（插在 `_finding()` 之后） |
| `lab/verify_round58.py` | 新增，346 行，54 断言 |
| `lab/regall.sh` | 清单加入 `verify_round58.py`（52 → 53 脚本） |
| `dist/CardinalSRCHunter/_internal/config/config.json` | 同步补 `open_api_probe`（打包产物内第二份 config） |

### 2.2 判定口径（三条硬门槛，缺一不报）

1. 状态必须 `200/201`（401/403 被拦、302 跳登录、5xx 报错均不算）；
2. 响应不得与随机路径软 404 基线同质（排除 WAF / 兜底首页）；
3. 正文必须真的解析出会话凭据值（命中 `token/access_token/sessionId/jwt/ticket/bearer/authorization` 等键名，值长 ≥ 8 且非占位）。

无危害约束：每个端点恰好 1 次匿名 POST，测试账号带 `srctest_` 前缀（crc32 稳定派生，同一目标重复扫描得同一账号），**不爆破、不重复提交、不枚举**。

### 2.3 验证结果

- `lab/verify_round58.py`：**54 PASS / 0 FAIL**（A 静态 21 / B 决策锁兼容 8 / C 合成响应 20 / D 端到端 5）。
- 端到端实跑命中日志：`阶段3.6/7 开放 API 注册面 +69.9s 端点 5 个` → `[命中] http://127.0.0.1:38857/openApi/faUser/register [200] 开放注册接口未鉴权且下发会话凭据` → 落库 1 条、`method=POST`、`severity=high`。
- 10 个关键决策锁脚本（round18/19/20/21/22/45/51/53/55/57）全部 `rc=0` / 0 FAIL。

### 2.4 决策锁硬约束（本轮全程遵守，后续务必保持）

- `verify_round18`：`vk_src.count('kind="unauth"') == 1`
- `verify_round19`：`len(_KIND_BASE) == 6`
- `verify_round21`：`_KIND_BASE == {sqli_error,ssrf,backup,weakpass,unauth,dirlist}` 且源码 `kind=` 字面量集合 == 该白名单
- `verify_round51`：`SENSITIVE_PATHS=63` / `DIR_WORDS=190` / `DEFAULT_CREDS_ALL=206`
- `verify_round20`：用正则 `def check_directory_listing\(.*?\ndef _finding\(` 提取函数体 → **新函数必须插在 `_finding()` 之后**

**⇒ 新检测器不得新增任何 `kind=` 字面量、不得动三张计数表。**

### 2.5 本轮修复的回归失败（重要）

`lab/verify_fixes.py` 断言「两份 config scan 段一致」曾 FAIL。根因：工程内存在**两份 config**——`config/config.json`（源）与 `dist/CardinalSRCHunter/_internal/config/config.json`（打包产物内副本）。本轮只给前者加了 `open_api_probe`，后者漏了。

**修复 = 两份同步**（已同步，现 19 PASS / 0 FAIL）。
**⇒ 铁律：凡改 `config/config.json` 的 `scan` 段，必须同步 `dist/CardinalSRCHunter/_internal/config/config.json`，否则 verify_fixes 必挂。** 备份：`dist/CardinalSRCHunter/_internal/config/config.json.bak_r58`。

---

## 3. 交付物（权威 md5；exe/zip/MD5SUMS 在 dist-win/，报告在项目根）

| 文件 | md5 |
|---|---|
| `dist-win/CardinalSRCHunter.exe` | 见 `MD5SUMS.txt` |
| `dist-win/CardinalSRCHunter-src.zip`（122 文件）| 见 `MD5SUMS.txt` |
| `项目总结报告.md`（项目根） | `a018771da393e27e17dddfd8ea007665`（54619 B，不随本包变动）|

- **权威基准文件：`dist-win/MD5SUMS.txt`（三行）——一切以它为准。**
- **为何本表不写死 exe/zip 的 md5**：本交接文档自身在 zip 内、也在 EXE payload 内，写死它们的 md5 会形成自指循环（改文档 → 包变 → 值失效）。故只列指针；报告 md5 不受影响，可直接引用。
- 交付时报值：`cat dist-win/MD5SUMS.txt`。
- 重打包命令：`python3 build/make_src_zip.py`（输出 `PACK files=122 size=... md5=...` + `BAK_LEAK bad=0` + `VERIFY bad=0`）。
- EXE 重建：`python3 build/make_sfx_exe.py pack` → `[verify] MZ=True PE=True (PE offset=0xF8)`。**EXE 内嵌代码副本，改任何 `.py`/`config.json` 后必须重建 EXE**（本轮 EXE 从 04:45 的旧版重建为 06:18 新版，已确认 payload 内含 `check_open_api_auth` 与 `open_api_probe`）。
- 打包顺序：**先写文档 → 再 `make_src_zip.py`（纳入文档）→ 再 `make_sfx_exe.py pack` → 最后 `make_src_zip.py` 刷新 MD5SUMS**。

---

## 4. 环境硬约束（踩过的坑，务必遵守）

- 工作区 `/storage/emulated/0/Audiobooks/`；主工作目录 `src/bt-src-hunter/`。
- **`SCOPE_PATH` 实际 = `/sdcard/Audiobooks/src/bt-src-hunter/config/scope.yaml`**（`cfg.ROOT` 派生）。
- **`read_file` / `read_file_part` 直读 `/storage/emulated/0/...` 会报 `File does not exist`，必须走 terminal。**
- **禁止 `set -e` / `set -o errexit`**（会让终端会话直接退出卡死）。
- **禁止后台自动跑长任务**（见 §0 红线）；改用前台 `timeout N cmd`，跑完复核残留进程。
- **PTY 回显会在长 heredoc 中向中文字符串插空格**，但**落盘字节是干净的**，判断以 `repr()` 为准。含中文的文本级 patch 走 `python3 - <<'PYX'` 按行处理。
- 文本级 patch 前必须 `repr()` / `cat -A` 取样真实字节；patch 时必须断言 `s.count(old) == 1` 锚点唯一。
- **`create_file` 的 path 语义有坑**：曾把 `lab/x.py` 落到工作区根，需 `find` 确认落点后 `mv` 补救。
- `ui/cli.py` 直跑需 `PYTHONPATH=.`。
- 无 `ps` / `unzip` / `nslookup` / `xxd`；有 `7z` / `7zr`；`yaml 6.0.3` 可用；模块导入须 `from modules import probe`。
- 进程存活检测：`ls /proc/<pid> >/dev/null 2>&1`；端口检测：`grep -i :1F91 /proc/net/tcp`（8081 = 0x1F91）。
- 网络依赖型断言必须契约化；三连跑是区分抖动与真回归的有效手段。
- `super_admin:terminal` 的 `package_proxy` 只接受 `tool_name` / `params` 两个参数，`timeoutMs` 必须放进 `params` 里。

---

## 5. 关键行号速查

| 位置 | 说明 |
|---|---|
| `core/dicts.py:446` | round58 `OPEN_API_PROBES`（5 端点） |
| `core/config.py:44-45` | round58 `scan.open_api_probe: True` |
| `core/engine.py:513-516` | round58 阶段 3.6/7 接入 |
| `modules/vulnchecks.py:822` | `_OPEN_API_CRED_RE` |
| `modules/vulnchecks.py:833` | `_open_api_placeholder()` |
| `modules/vulnchecks.py:850` | `_open_api_body()` |
| `modules/vulnchecks.py:871-920` | `check_open_api_auth()` |
| `core/selfheal.py:200-228` | round57 `plan()` nxdomain+variants 分支 |
| `core/engine.py:383-421` | round57 变体接管（`switch_variant`） |
| `core/report.py:633/757/774/790/936/1277` | round57 五处 patch |
| `tools/scope_sync.py:94` / `:127` / `:261` | `extract_hosts` / `collect` / `insert_in_scope` |
| `lab/regall.sh:33` | 53 脚本清单（round7~round58 + verify_fixes + verify_e2e + t_malformed） |

---

## 6. 下一轮方向（round59）与历史编号

### 6.1 可继续项

1. 基线 12 项里工具仍未覆盖的：**账号枚举** / **硬编码 RSA 公钥** / **token 跨主机复用**，可继续补检测规则（沿用 round58 的「三条硬门槛 + 无危害约束」范式）。
2. `www.langhanyun.cn` 报告命中 `Knife4j` / `Druid`，而基线报告是 `Swagger springfox 2.9.2` / 无 Druid → 站点组件随时间变化，可在报告里加「组件版本漂移」说明。
3. `tools/scope_sync.py --fetch` 的 AI 自动学习可改造为「指定目标域 + 相关性过滤」，而非纯公网泛检索。

### 6.2 round 编号（防冲突）

`round48`=config 运行时环境变量覆盖层；`round49`=技能加载器；`round50`=Operit 端点接入；`round52`=授权/未授权自动分辨；`round53`=未授权扫前识别（37 断言）；`round54`=授权文案对齐 + Setup.exe 二次双击自愈；`round55`=`tools/scope_sync.py` 离线同步（46 断言）；`round56`=交付物单点化；`round57`=域名 NXDOMAIN 自动接管可解析形态（37 断言）；**`round58`=开放 API 注册端点未鉴权 + 下发会话凭据检测器（54 断言，本会话）**。**下一轮编 round59。**

### 6.3 本轮备份文件（回滚用）

`core/dicts.py.bak_r58`、`modules/vulnchecks.py.bak_r58`、`core/engine.py.bak_r58`、`core/config.py.bak_r58`、`lab/regall.sh.bak_r58`、`dist/CardinalSRCHunter/_internal/config/config.json.bak_r58`。
��
