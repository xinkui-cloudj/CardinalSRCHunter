# 交接文档 round90 —— FIX-16 / FIX-17（全检测器同族误报扩面排查）

> 本文件不写死任何行数与 md5（避免「文档变 → EXE 变 → md5 变 → 文档失效」的自指循环）。
> 一切校验值以 `dist-win/MD5SUMS.txt` 为唯一权威。

---

## 一、用户原话与本轮任务定义

| # | 用户原话 | 落地含义 |
|---|---|---|
| 1 | 「现在好了吗？」 | round89 交付确认 |
| 2 | 「就是扫别的不管什么域名什么漏洞类型那些基本都不会再出现重复了是吧？快速回答我」 | 要求对「跨域名 / 跨漏洞类型」的重复问题给**准确**答案，不许打包票 |
| 3 | 「行，先列任务清单再去做」 | 先出清单，授权后才动手 |
| 4 | 「这个第四点如果不重新设计检测框架有什么影响吗？」 | 追问最小闸门方案的代价 |
| 5 | 「行吧4点全按你的建议来」 | 4 个决策点全部采纳 AI 建议，正式开工 |
| 6 | 「继续」 | 自主执行（发现即修、不逐项请示） |
| 7 | 「等一下弄完到最后收尾的时候先别重打包，到时候还要别的让你做」 | **重打包链路挂起**，等后续指令 |

### 答案口径（必须延续，不得放宽）
- **去重层面对所有类型都有效**：`_dedup_key` 五元组 `(类型, 主机, 路径, 方法, 参数)`，同一处漏洞重复扫只保留一条，与域名、漏洞类型无关。这一层没有坏。
- **误报层面**：round89 只清理了账号枚举一条链（FIX-14 / FIX-15 / FIX-15b）。本轮把其余 14 个检测器全部过了一遍，**又找到 2 处确凿误报并修掉**（FIX-16 / FIX-17）。
- 现在可以说：**已知的 5 类基础设施噪声（兜底 200、WAF 403、跳登 302、后端 500、padding 抖动）在全类型上都不会再批量产假重复**。未知噪声形态（如 200 + JS 跳转、200 + 空正文）仍属现状既有风险，不是本轮引入，也不要对外承诺已覆盖。

---

## 二、证据硬事实（探针 8 场景实测）

探针 `lab/_tmp_probe_family.py` 自建假响应对象，构造场景后直接调产品函数，跑完即删（**不在代码库、不在包内**）。

| 场景 | 构造 | 改前实测 | 改后实测 |
|---|---|---|---|
| A | 兜底站点：任意路径 200 + 同一 9KB 首页（基线 200/8881） | **备份文件 6 条**；其余 6 类 0 | 全部 0 |
| B | padding 抖动（长度差 100~400B，基线 200/9146） | `is_soft404(抖动)=True`；目录爆破 0；敏感路径 0（FIX-15b 已生效） | 不变（无退化） |
| C | 任意响应统一带 `ACAO: *` | **CORS 1 条**；无该头时 0 | 全部 0 |
| D | 全站 403 + 2.7KB WAF 页（基线 403/2687） | 8 类全 0 | 不变 |
| E | 全站 302 → /login（基线 302/37） | 5 类全 0 | 不变 |
| F | 真 CORS 反射（回显 evil.com + ACAC:true） | 1（**真漏洞**，探针 `<<< 误报` 标记是探针自身粗糙判定） | 1（未误伤） |
| G | 兜底页回显请求路径（基线 200/928） | XSS 0 / SQLi 报错 0 / 开放重定向 0 | 不变 |
| H | 全站 500（基线 500/647） | 5 类全 0 | 不变 |

**关键澄清**：场景 D/E/H 的「全站 403 / 全站 302 / 全站 500」三类 **不需要新闸门**——此前已被 FIX-6 / FIX-12 的拦截墙通道与各检测器自带基线守卫覆盖。不要把这三类误读成「还有三类没修」。

---

## 三、15 个检测器审读结论

`modules/vulnchecks.py` 的检测函数全清单与判定口径：

| 函数 | 判定口径 | 本轮结论 |
|---|---|---|
| `check_sqli` | 报错关键字 + 基线对比 | 已有守卫，无需改 |
| `check_xss` | 反射特征 + 基线对比 | 已有守卫，无需改 |
| `check_open_redirect` | Location 归属判定 | 已有守卫，无需改 |
| `check_jwt_weak_key` | 弱密钥字典命中 | 已有守卫，无需改 |
| `check_ssrf` | 带外/回显通道 | 已有守卫，无需改 |
| `check_unauthorized` | 只认 200 + `baseline_ok` | 已有守卫，无需改 |
| `check_weak_password` | 负证据优先 + 强证据门槛 | 已有守卫，无需改 |
| **`check_cors`** | 原：`acao` 含 evil.com **或等于 `*`** 就报 | **缺口 → FIX-17** |
| **`check_backup_files`** | 原：仅 `HEAD status==200 and length>1000` | **缺口 → FIX-16** |
| `check_cn_components` | `status not in (200,302)` + `is_soft404` + marker 非空 | 已有守卫，无需改 |
| `check_directory_listing` | `status != 200` + `is_soft404` + 索引标记 + ≥2 条目 | 已有守卫，无需改 |
| `check_open_api_auth` | `status not in (200,201)` + 基线守卫 | 已有守卫，无需改 |
| `check_user_enum` | 三门槛 + `baseline_usable` + `is_soft404`（round89 已加固） | 已修（FIX-14/15/15b） |
| `check_hardcoded_key` | `status != 200` + 基线守卫 | 已有守卫，无需改 |
| `check_token_reuse` | 基线守卫 | 已有守卫，无需改 |

静态审读结论与探针实测**完全吻合**，互相印证，不存在「纸面已修、实测还漏」的错位。

---

## 四、FIX-16：备份文件泄露（双闸）

**立论证据**：兜底站点（nginx `try_files` 兜底 / SPA history 模式）下 `/www.zip`、`/backup.zip`、`/web.zip`、`/site.tar.gz`、`/db.sql`、`/dump.sql` **六条全部命中**。每台这类站点稳定产 6 条假备份泄露——这正是「换哪个域名都一堆重复」的构成之一。

| 闸 | 位置 | 逻辑 |
|---|---|---|
| 闸 1 | 函数入口 | `base = probe.soft404_baseline(...)`；`if not probe.baseline_usable(base): return []`。基线不可耗时 `is_soft404` 恒 False，必然把兜底首页当备份 |
| 闸 2 | HEAD 粗筛后 | `if not (r.status == 200 and r.length > 1000): continue`；GET 回正文后 `if probe.is_soft404(g, base): continue` |
| 退化分支 | GET 拿不到 | `if probe.same_length(r.length, base.get("length")): continue`（与基线同量级即兜底页） |

函数头新增 docstring 记录复现事实，防止后续review者误判这些闸是「无理由加的限制」。

---

## 五、FIX-17：CORS 配置错误（三闸 + 一条例外）

**立论证据**：`Access-Control-Allow-Origin: *` 与 `Allow-Credentials: true` 在浏览器里**互斥** —— 带 `*` 的响应根本不允许携带 Cookie，构不成「跨域窃取凭据」。而 CDN / 网关默认加 `*` 极其普遍，任意一个带参 URL 都稳定产 1 条假 CORS 漏洞。

| 闸 | 逻辑 | 目的 |
|---|---|---|
| 闸 1 | `if not acao or acao == "*": return findings` | 通配符一律不报，无论 ACAC 是什么 |
| 闸 2 | `if acao != probe_origin: return findings` | 必须回显**本次注入的 Origin**；固定白名单域不报 |
| 闸 3 | 与软 404 基线同质 → 丢弃 | 兜底页 / WAF 页统一加头，非业务响应 |
| **例外** | `if acac.lower() != "true":` 才走闸 3 | 反射任意 Origin + 允许携带凭据，本身就是可读任意已登录接口的**真实配置错误** |

**例外为何必须存在**：首版实现无条件走闸 3，复跑探针场景 F 时真漏洞 findings 从 1 变成 **0** —— 整站回同一份 JSON 的真反射站点会被误判成兜底噪声。这是典型「闸门误伤真信号」，已用断言 D1/D2 钉死。

### 首版踩坑（必记）
改动 `findings.append(_finding(...))` 多行参数时，旧字符串行 `"携带凭据时不得使用通配符。"))` 未删净，与新 `fix=` 的收尾括号冲突，触发：

```
File "<unknown>", line 820
    "携带凭据时不得使用通配符。"))
                    ^
SyntaxError: unmatched ')'
```

**教训**：改多行函数返回值/调用参数后，**先 `ast.parse` 再往下走**。本轮已把「三文件 AST OK」固化成断言 F 段（见下）。

---

## 六、断言资产：`lab/verify_round90_fix16_17.py`

**PASS=25 FAIL=0**，已登记进 `lab/regall.sh`（在 `verify_round89_ui.py` 之后）。

| 段 | 项数 | 内容 |
|---|---|---|
| A | 2 | 兜底站点基线可用（证明闸 1 真的走进去）+ 备份文件 findings=0（原 6 条） |
| B | 2 | **正向对照**：真 2MB zip 备份文件仍命中（防「一刀切死」） |
| C | 4 | `ACAO:*` 在 ACAC=none / false / true 三种下均 0；完全没有 CORS 头也 0 |
| D | 6 | **正向对照**：真反射+ACAC:true → 1 条且 high；真反射无 ACAC 且正文区别于基线 → 1 条且 medium；真反射无 ACAC 但整站回同一 JSON → 0（**有意保守取舍，显式记入断言，防止未来被当 bug 改掉**）；白名单固定域 → 0 |
| E | 4 | 国产组件 / 目录列表 / 开放API / 硬编码公钥 在兜底站点下均 0 |
| F | 3 | `modules/vulnchecks.py` / `modules/probe.py` / `core/verify.py` AST 全绿 |
| G | 4 | **结构锁**：四道关键闸门不得被后续改动删除（备份基线闸、通配符不报闸、Origin 回显闸、ACAC:true 例外） |

设计原则：**每一道「不报」的闸都必须配一条「该报还报」的正向对照**。只测「归零」会掩盖过度收紧导致的漏报。

---

## 七、验收数字

| 项 | 结果 | 说明 |
|---|---|---|
| `lab/verify_round90_fix16_17.py` | **PASS=25 FAIL=0** | 本轮新增断言 |
| `lab/regall.sh` 全量 | `REGALL TOTAL PASS=4018 FAIL=0 SCRIPTS_FAILED=1` | 4018 = round89 的 3993 + 本轮 25 |
| `lab/check_exe_r82.py` | `BAD=1 / TOTAL PASS=174 FAIL=1` | **预期红**：`modules/vulnchecks.py DIFF  ws=b70def3f6bb8 exe=c0a8b79c3d80` —— 源码已改、EXE 按用户指令暂不重打包。其余 174 项（run.bat / start.bat / scan.bat / doctor.bat / VERSION / stray）全部 OK |
| AST | 三文件全绿 | `vulnchecks.py` / `probe.py` / `verify.py` |

`check_exe_r82` 的复跑工艺（**工艺坑⑲，累计 19 条中仍必须遵守**）：
```
rm -rf /tmp/verify82 && mkdir -p /tmp/verify82
7z x -y -o/tmp/verify82 dist-win/CardinalSRCHunter.exe    # 不加 'app/*' 过滤
python3 lab/check_exe_r82.py
```
跳过全量解包会产生假红；加子集过滤会缺 `python/` 等目录，实测可造 15 条假红。

---

## 八、当前挂起项（用户明确指令）

用户原话：「等一下弄完到最后收尾的时候先别重打包，到时候还要别的让你做」。

因此以下链路**全部挂起**，等后续指令一并执行：

1. 源码 zip 重建（内含本交接文档与 `进度.md`）
2. EXE 重建
3. EXE 全量解包核验（`/tmp/verify82`）→ `check_exe_r82` 复跑至 `BAD=0`
4. zip 二次重建（因为 EXE 变了，zip 内含 EXE 时需同步）—— 按 round89 的固定顺序 `源码定稿 → zip → EXE → 解包核验 → zip 重打`
5. `dist-win/MD5SUMS.txt` 刷新
6. 同步 EXE 到 `/sdcard/AI文件/`
7. 清理残留（`/tmp/verify82`、`/tmp/regall_r90.log`、`lab/__pycache__` 等中间产物）

**现存预期红仅一项**：`check_exe_r82` 的 `vulnchecks.py DIFF`。重打包后应回到 `BAD=0 PASS=175`。

---

## 九、遗留待办（不阻塞本轮，但交付口径需保留）

| # | 事项 | 状态 |
|---|---|---|
| 1 | 用户实机验收新 EXE（Web 控制台「刷新模型」弹窗能滑到底、能点「全选当前 / 确定」） | 待用户验收 |
| 2 | 对 `lanli.cc` 重扫，账号枚举类应归零 | 待用户实测 |
| 3 | 对任意其他域名重扫，账号枚举类不得因 405 / WAF 403 / 限流 429 批量产出 | 待用户实测 |
| 4 | 本轮新增：任意域名重扫，备份文件类不得因兜底 200 批量产出 | 待用户实测 |
| 5 | 本轮新增：任意域名重扫，CORS 类不得因网关统一 `ACAO:*` 批量产出 | 待用户实测 |
| 6 | 老遗留 `www` 上 24 条 403 仍需定向确认（按设计 403 不进非业务白名单，仍走 FIX-6/FIX-12 拦截墙通道） | 待确认 |

---

## 十、FIX 清单（累计，不得回退）

| 编号 | 内容 |
|---|---|
| FIX-1b | 拦截墙快照不跟跳转 |
| FIX-2c | （round 早期修复，见历史交接文档） |
| FIX-3 | `_VERIFIERS` 15 → 21 |
| FIX-4 | （见历史交接文档） |
| FIX-6 | 拦截墙通道 |
| FIX-8 / 8b | （见历史交接文档） |
| FIX-9 | （见历史交接文档） |
| FIX-10 | （见历史交接文档） |
| FIX-11 | 两个打包器硬拦 `mcp` |
| FIX-12 / 12b | `_channel_clean()` 通道自证 + JSON 信封识别 |
| FIX-13 | （见历史交接文档） |
| FIX-14 | 非业务状态码 + 正文白化（账号枚举 padding 抖动） |
| FIX-15 | 对照名不可信状态码（403/429/5xx → inconclusive） |
| FIX-15b | `probe._white()` / `_sim_white()`，`is_soft404` 与 `blocking_wall` 白化后比对 |
| **FIX-16** | **备份文件软 404 基线双闸** |
| **FIX-17** | **CORS 三闸 + ACAC:true 例外** |

---

## 十一、接手指引

1. 先读 `进度.md` 末尾的 `round90` 章（本文的精简版），确认当前状态。
2. 确认挂起项：**重打包未做**，`check_exe_r82` 的 `BAD=1` 是预期，不是缺陷。
3. 若用户要求继续收尾，按 §8 的 7 步顺序执行，不要跳步、不要先打 zip 后改源码。
4. 若用户提新需求，先判断是否触碰 `check_backup_files` / `check_cors` —— 触碰则必须重跑 `lab/verify_round90_fix16_17.py` 的 A/B/C/D 四段（尤其是 B 段与 D 段的正向对照）。
5. 任何改动后第一件事：`python3 -c "import ast;ast.parse(open('modules/vulnchecks.py',encoding='utf-8').read())"`。
