# Cardinal-SRC-Hunter 交接文档 · round75
> 生成：2026-10-17 ｜ 代码版本 round75（round74 基线 + 19 项清单收口 + 版本戳升 r75）
> 交付物：`dist-win/CardinalSRCHunter.exe` + `dist-win/CardinalSRCHunter-src.zip`
>         （哈希见 `dist-win/MD5SUMS.txt`，以该文件为准）
> 版本戳：`ui/web.py::_APP_VER = "r75"`、`build/make_sfx_exe.py::BUILD_ID = "r75-"`

---

## §1 本轮做了什么（用户 19 项清单，逐条对账）

### A. 会话存档与续跑（原目标②，前三轮的真实空白）
| # | 项 | 结论 | 落点 |
|---|---|---|---|
| 4 | db.py 会话读写三件套 | 完成 | `core/db.py::SESSION_KEY/save_session/load_session/clear_session`（落 `progress` 表） |
| 5 | engine.run 会话追踪 | 完成 | `core/engine.py::_session_start/_session_mark/_session_pause/_session_finish/session_pending`（1536–1610 行区） |
| 6 | pause()/stop() 原子落盘 | 完成 | `stop()` = `_stop=True` + `_session_pause("stopped")`；`wait_if_paused()` 每 2s 兜底 `_session_pause("paused")` |
| 7 | 落盘时机 | 完成 | `run()` 内 1475 起档 → 1485 每目标收尾落盘 → 1529 `if not self._stop and not self._pause.is_set(): self._session_finish()` |
| 8 | gui.py 开窗提示 + 继续上次扫描 | 完成 | `ui/gui.py::_scan_session_pending`(86) / `_resume_prompt`(120) / 开窗续跑块(814–825) / `on_close()`(841 行先落盘再 pause) |
| 9 | cli.py `--resume-last` | 完成 | `ui/cli.py`（`--no-resume` 与 `eng.resume=False` 未被破坏，round7 锁仍在） |
| 10 | web.py pause/resume/stop 路由与按钮 | 完成 | `ui/web.py` GET `/api/scan/session` + POST `/api/scan/pause|resume|stop|resume-last`；页面对应三按钮 |
| 11 | web.py 退出兜底落盘 + 页面续跑提示 | 完成 | `atexit(session_pause_by_exit)`；`scan_status()` 用 `d = {k:v for k,v in _SCAN.items() if k != "eng"}` 剔除 eng 对象 |
| 12 | lab/verify_round75.py | 完成 | 690 行 / **142 断言**（A–I 九段，含真引擎 e2e）；单跑 `ROUND75 PASS=142 FAIL=0` |
| 13 | regall 登记 + 全量回归全绿 | 完成 | 清单 67 脚本 + EXE 复核段 = 68；重打包后 **`REGALL TOTAL PASS=3133 FAIL=0 SCRIPTS_FAILED=0`**（全绿） |

### B. AI 开关与红线
| # | 项 | 结论 | 落点 |
|---|---|---|---|
| 1 | gui.py AI 区块（三勾 + 端点 + 模型 + 密钥框 + 保存/清除） | 完成 | `ui/gui.py` 862 → **863 行** |
| 2 | 落点对齐 round74（ai 段 / takeover 段 / `data/ai_key.txt`） | 完成 | 密钥**绝不写进 config.json**（round50 P5 仍绿） |
| 3 | 开窗回填 + 状态行 | 完成 | `_ai_status_line()`（三闸门 + takeover 已并入 `ready`，A30 锁死） |
| 19 | AI 内置一条红线（用户附件文本） | 完成 | **新增 `core/redline.py`（261 行 / 11262 B，md5 `434bf2b9b4e31110da6d534b84daa13a`）** + 三条注入链（见 §3） |

### C. 用户追加两项 + 版本戳
| # | 项 | 结论 | 落点 |
|---|---|---|---|
| 17 | GUI 标题「补天」→「Cardinal」 | 完成 | `ui/gui.py:170` → `Cardinal-SRC-Hunter · Cardinal自动挖洞套件 v1.0` |
| 18 | 报告平台名 `butian` → 「(请填写你的平台)」 | 完成 | `core/report.py:41 PLATFORM_NAME`（524/862 两处引用共用，md/html 一并覆盖） |
| 14 | 版本戳 r73 → r75 + EXE 复核脚本换代 | 完成 | 见 §4 |

---

## §2 验证证据（可复现）

```sh
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter
python3 -B lab/verify_round75.py      # ROUND75 PASS=142 FAIL=0
python3 -B lab/verify_round67.py      # round67 PASS=36 FAIL=0（版本断言已解耦为区间）
python3 -B lab/verify_round73.py      # ROUND73 PASS=67 FAIL=0（E 组按版本区间通过）
python3 -m core.redline               # ok=True miss=[] len=2935 sha=7c28f1bb9b02
python3 -m core.redline sha           # 7c28f1bb9b027b719c93f9b61fdfd4aca6888183c53f049cdabd94f050117c76
sh lab/regall.sh                      # 全量回归（67 脚本 + EXE 复核段），最终日志 /tmp/reg75final.out
rm -rf /tmp/verify75 && mkdir -p /tmp/verify75
7z x -y -o/tmp/verify75 dist-win/CardinalSRCHunter.exe
EX75_DIR=/tmp/verify75 python3 -B lab/check_exe_r75.py   # BAD=0 / TOTAL PASS=117 FAIL=0
```

**全量回归实测（最终锁定，日志 `/tmp/reg75final.out`，重打包之后跑的）**
```
REGALL TOTAL PASS=3133 FAIL=0 SCRIPTS_FAILED=0
ALLDONE
```
- 67 个脚本**全部** `FAIL=0`；EXE 复核段 `BAD=0 / TOTAL PASS=117 FAIL=0`；
- **重打包前的中间观测**（留证）：`/tmp/reg75x.out` → `PASS=3103 FAIL=30 SCRIPTS_FAILED=1`，30 红全部来自未重打包的 `check_exe_r75`（旧 EXE 缺 `core/redline.py`，`BAD=38`），脚本侧当时即 `FAIL=0`。

**回归口径说明（给下一位）**：round74 终态是 `PASS=2968 FAIL=3 SCRIPTS_FAILED=1`（3 红为 r73 版本戳差异）；本轮 r75 基线把同一批红条压到 30 条（check_exe_r75 静态组从 68 条扩到 94 条 + FILES 14 项，差异条数随之变多）。**只认 `FAIL=0` 与 `SCRIPTS_FAILED=0`，不看 PASS 绝对值。**

---

## §3 本轮契约与红线（改代码前必读）

1. **`core/redline.py` 零依赖**：只 `import hashlib / io / os`，零网络、零落盘、**不得 import `tools.ai_client`**（AST 口径锁死，红线 docstring 里出现该字面也不算命中）。红线原文一字不改，只在两处插值：`{auth}`（实时授权标注）、`{caps}`（已登记能力清单）。
2. **三条注入链，唯一且不重复注入**：
   - `tools/agent_loop.py::run_agent()` → system 走 `_redline.with_system(_SYSTEM_PROMPT.format(...), auth=_redline.auth_note(engine, target), caps=caps)`；`_SYSTEM_PROMPT` 一字未改（`{hunt}`/`hunt_user` 均在）。
   - `tools/ai_client.py::chat()` → `"messages": _redline.with_system_first(messages)`（`ask_json()` 走 `chat()` 自动覆盖）。
   - `tools/ai_client.py::chat_step()` → **只有调用方没有 system 时**才 `msgs.insert(0, ...)`，有 system 就不动（防重复注入）。`_redline.with_system_first(` 全文件**仅出现 1 次**（H20 锁）。
3. **红线 SHA 是契约**：`redline_sha()` = `7c28f1bb9b027b719c93f9b61fdfd4aca6888183c53f049cdabd94f050117c76`。改红线原文必须同步更新 `lab/verify_round75.py` H 段。
4. **会话存档落 `data/`**（`progress` 表，WAL + `synchronous=NORMAL` + 同步 commit）。`data/` 被两个打包器排除 → 存档**天然不进包**，设计成立。
5. **`_session_mark()` 开头必须 `if self._stop: return False`**：否则 `stop()` 后 `scan_target()` 立刻返回，`run()` 循环仍会把「被跳过的目标」记成「已完成」，一停就丢续跑清单（本轮修的真实缺陷，C 段锁死）。
6. **`_SCAN` 里挂着 `eng` 对象（不可 JSON 序列化）**：`scan_status()` 必须剔除 `eng`，否则 `/api/scan/status` 直接 500（D 段锁死）。
7. **版本字面量断言一律用「区间」而非等值**：`r(?:7[3-9]|[89]\d)` 表达「≥ r73」。此后升版**不需要**再动 round67/73 的 E 组。
8. **`verify_round38.py:94` AI 段恰 11 键**、**`verify_round48.py` G5 `AI_ENV_MAP` 恰 4 项**、**`verify_round50.py` P5 项目根不得有 `ai_key.txt`**、**`verify_round47.py` D1 core/modules/ui 不得 import `tools.ai_client`**（AST 全量含延迟 import）、**`verify_round45/37/40.py` B1 为纯文本行扫描**（注释/docstring 里的字面也算命中）。以上五条继续有效，本轮全部实测通过。
9. `tools/scope_sync.py:52` 的「补天漏洞响应平台」是**检索关键词**，用户未要求改，保持原样；`core/report.py` 里其余「补天」字样属注释/文档串，同样不动。

---

## §4 版本戳 r75 换代（第 14 项）

| 文件 | 改动 |
|---|---|
| `ui/web.py:36` | `_APP_VER = "r73"` → `"r75"` |
| `build/make_sfx_exe.py:36` | `BUILD_ID = "r73-" + time.strftime(...)` → `"r75-"` |
| `lab/check_exe_r73.py` | **升级为 `lab/check_exe_r75.py`（248 行 / 14056 B），旧版删除不留双版本**（回滚副本 `lab/check_exe_r73.py.bak_r75`） |
| `lab/regall.sh` | 改调 `check_exe_r75.py`；`EX73_DIR` → `EX75_DIR`（5 处）；`/tmp/verify73` → `/tmp/verify75`（2 处） |
| `lab/verify_round67.py` | A1/A12 改版本区间正则；B2/B3 桩服务 `ver=web._APP_VER`；B9/B10 断言改「返回当前版本戳」；D 组 jsdom `/r73/` → `/r\d+/`；临时文件 `/tmp/r73_page.*` → `/tmp/r67_page.*` |
| `lab/verify_round73.py` | E1–E6 全部改版本区间或指向 `lab/check_exe_r75.py` |
| `lab/verify_round75.py` | 新增 **I 段 8 条**（版本戳 r75 一致性自锁） |

**`lab/check_exe_r75.py` 判定口径** = 静态 **94 条**（原 40 条 + round73 D/C/B/A 组 + round71/71b/72/70 全部保留 + **round75 五组锚点**：桌面 AI 开关 / 会话存档续跑 / Web 暂停继续停止 / 标题 Cardinal / AI 内置红线）
+ **14 个**文件与工作区逐字节一致（新增 `tools/ai_client.py`、`core/redline.py`）
+ `VERSION` 前缀必须 `r75-` + `run.bat` 字节级 8 项，
`TOTAL = len(checks) + len(FILES) + 1 + 8` = **117**。

**关键设计（不要改回去）**：末尾**打两行汇总** —— 先 `TOTAL PASS=n FAIL=n`（含 FILES md5 比对，供人工看），再 `PASS=n FAIL=n`（**不含** FILES）。因为 `lab/_regsum.py` 取「最后一条 `PASS=(\d+)\s+FAIL=(\d+)`」，这样重打包前后 md5 差异不会把回归总数打成一片红。

**读取兜底（本轮新增）**：`_rd()/_rdabs()` 缺文件一律返回空字节并登记 `_missing`，**绝不抛 `FileNotFoundError`**——崩了就没有汇总行，`regall.sh` 只能记 `SCRIPTS_FAILED`，红灯不可读。`run.bat` 缺失时 8 项一律记 FAIL（空串里「没有 powershell/pause」会假通过）。空目录实测：`TOTAL PASS=12 FAIL=105` + `PASS=12 FAIL=91` + `WARN 解包缺失 16 个文件…`，RC=1，可读红灯。

---

## §5 交付物重建（三连，改任何源码后必须重跑）

```sh
python3 build/make_src_zip.py        # 源码包（排除 .bak* / tmp_patch_* / __pycache__ / data / dist-win 等）
python3 build/make_sfx_exe.py pack   # EXE（用 /tmp/btsfx 缓存；只 copy_app 刷新源码）
python3 build/make_src_zip.py        # 再跑一次刷新 dist-win/MD5SUMS.txt
```
- `make_src_zip.py` 末尾两个硬自检：`BAK_LEAK bad=0`、`VERIFY bad=0`，任一非 0 即返回 1；
- `make_sfx_exe.py pack` 的 `copy_app()` 内有「包内混入备份文件」自检，返回 1 即中止；
- EXE 内层 7z 必须 `-mf=off` 且格式版本降为 0.3（否则 7-Zip 9.20 SFX 解码器报 `Unsupported Method`，用户双击无反应）；
- **重打包前必须先删 `进度_round75.md`**（round75 惯例：进度文件不随交付走）。

---

## §6 本轮新增铁律（防再犯）

1. **补丁脚本的 `sub()` 锚点计数不符会 `sys.exit(1)` 半途而废但前段已落盘**——退出前改掉的部分不会回滚。遇到 `MISS count=N want=M` 不是数据损坏，要**续写第二段补丁接着做**，并按「实际剩余出现次数」修正 `n`（本轮 `/tmp/patch75_v.py` 在第 21 步倒下，前 20 处已落盘，`/tmp/patch75_v2.py` 收尾）。
2. **升版本戳时必须同时解耦历史脚本的版本硬编码**，否则全量回归集体翻红。可复用口径：
   `re.search(r'_APP_VER = "r(?:7[3-9]|[89]\d)"', src)`、`re.search(r'BUILD_ID = "r(?:7[3-9]|[89]\d)-" \+ time\.strftime', src)`、jsdom 断言 `/r\d+/`、桩服务版本取 `web._APP_VER` 运行时值。**只动版本字面、不动语义。**
3. **测试断言的「某某不得 import 某某」一律走 AST 口径**（裸文本会被 docstring 误伤；本轮红线自测 C8 即栽在这里）。
4. **不要用 `python3 - <<'PYEOF'` heredoc 里再套三引号**（会被 shell 截断）；改文件的活一律写成 `/tmp/*.py` 再 `python3 /tmp/xxx.py`。
5. **`create_file` 必须显式 `environment=linux`**（否则含多层引号的脚本会以 `sh: syntax error: unexpected '('` 落盘失败）；且**覆盖同名文件会被直接拒绝**，必须先 `delete_file` 再重建。
6. **回归脚本数变化必须同步核对**：新增 `lab/verify_roundNN*.py` 必须登记进 `lab/regall.sh` 清单，否则该组运行时路径漏检。
7. **全量回归跑完前禁止 `pkill -f vuln_server.py`**（会杀 8081 靶机导致活体脚本 FAIL）；只可 `pkill` `bash lab/regall.sh` 与 `python3 -u lab/verify*`。
8. **禁止 `set -e` / `set -o errexit`**；**工作区重挂载会丢最新未落盘文件**，落盘后必须回读确认。
9. **文档里禁止写死「包内产物」的 md5 / 体积 / `VERSION` 戳**——`项目总结报告.md` 与 `交接文档_round75.md` **自身就在 `src.zip` 与 EXE 的 `app/` 内**，写死就构成不动点悖论：「改文档 → 必须重打包 → md5/戳再变 → 文档又过期」，永不收敛（本轮实测：先写死 `2026c38b…`/`r75-…110251`，重打后立刻变 `3de0524b…`/`r75-…114051`，再改再打成 `05789632…`/`r75-…114647`）。**正确口径：文档只写「以 `dist-win/MD5SUMS.txt` 为准」与「`VERSION = r75-<打包时间戳>`」，只保留稳定不变量（zip 恒 168 文件 / EXE 解包恒 2984 文件）；验收点 = 「`MD5SUMS.txt` 的 report 行 md5 == EXE 内 `app/项目总结报告.md` 逐字节一致」。**

---

## §7 待下一轮（本轮未动 / 仅记录）

- **`ui/web.py` 的 `__ai_status.ready` 仍不含 takeover 第三闸门**（takeover 只作独立字段返回），与 `ui/gui.py::_ai_status_line()` 口径**不一致**。若要求「GUI 与 Web 同口径」需再决策（本轮未改，避免动 round74 G 组断言）。
- **`core/engine.py` 永不输出的死日志**：该文件从未 `import os`，但 1237/1269 行在用 `os.path.basename(...)`，一直被外部 `except` 吞掉。按「只改必要文件」未触碰。
- 备份命名历史不统一（`.r62bak` / `.r63bak` / `.bak_rNN` 并存），交付前靠 `BAK_LEAK bad=0` 兜底；本轮新增 14 个 `.bak_r75*` 回滚副本（两个打包器的排除规则都按子串判 `.bak`，不会混进交付物）。
- 回归脚本数 67（+1 EXE 复核段 = 68）。**round75 最终锁定基线：`REGALL TOTAL PASS=3133 FAIL=0 SCRIPTS_FAILED=0`**（日志 `/tmp/reg75final.out`）。
- **交付物终态**（规则式，不写死，避免不动点悖论）：`CardinalSRCHunter.exe` 与 `CardinalSRCHunter-src.zip` 的具体大小 / md5 **一律以 `dist-win/MD5SUMS.txt` 为准**；`VERSION` 戳形如 `r75-<打包时间戳>`（可用 `EX75_DIR=<解包目录> python3 -B lab/check_exe_r75.py` 回读）；zip 恒为 **168 文件**；EXE 解包恒为 **2984 文件**。
- **踩坑（本轮真实发生，已固化为规则）**：本报告与 `交接文档_round75.md` **自身就在 zip 与 EXE 的 `app/` 内**，所以**文档里绝不能写死 exe/zip 的 md5 或 VERSION 戳**——写了就形成不动点悖论：「改文档 → 必须重打包 → md5/戳再变 → 文档又过期」，永不收敛（本轮实测：补丁刚写死 `2026c38b…` / `r75-…110251`，重打后立刻变成 `3de0524b…` / `r75-…114051`）。**文档只写「以 `MD5SUMS.txt` 为准」这条规则**，验收点改为「`MD5SUMS.txt` 的 report 行 md5 == EXE 内 `app/项目总结报告.md` 逐字节一致」（即「报告与代码同源」）。
- **本轮踩坑（真实发生）**：删除 `进度_round74/75.md` 时**误删了 `进度.md` 与 `任务清单_round73.md`**——`make_src_zip.py --check` 立刻报出 `SKIP(缺文件)`，因为 zip 已打过、工作区却少了两个文件。**恢复方式：直接从已打好的 `dist-win/CardinalSRCHunter-src.zip` 里原样取回**（md5 双侧一致），避免为两个文件重打一次包。**以后再删文件，删完立刻跑一次 `python3 build/make_src_zip.py --check`**。
