# 交接文档 round85 — MCP 存量配置自愈 + 启动即自检

## 一、本轮背景
r84 交付后用户 Windows 实机仍报错（截图铁证）：
src_elite_mcp 已启用 · python3 server.py 下方红字 `失败: FileNotFoundError: [WinError 2]`。
用户追问：是不是电脑问题？—— 不是，是程序 bug（第七层）。

## 二、两个真根因（都已实证）
### 根因 1：存量旧式配置永远不会被修正
r84 的 `_norm_launcher`（python3 -> sys.executable）和 `_resolve_script`（绝对化 + 推断 cwd）只在**导入时**生效。
用户在旧版导入的 `src_elite_mcp` 记录是 `command=python3`、`args=[server.py]`、无 `cwd`。
`_resolve_script` 找不到脚本时**原样返回**，于是 subprocess 以 `cwd=None` 继承程序目录启动：
Windows 上没有 `python3` 命令、程序目录也没有 `server.py` -> WinError 2。

### 根因 2：自检读配置调了不存在的函数（本轮新发现）
`tools/capability.py::selfcheck` 写的是 `_cfgmod.load()`，但 `core.config` **没有模块级 load()**，
真正的读取器是 `Config` 类（它的 `load()` 是实例方法）。
该调用 100% 抛 AttributeError，被 `except Exception` 吞掉退化成 `{"takeover": {}}`，
于是无论用户配了什么，自检永远输出「MCP 段未配置」。
这是典型的「静默失败」——比报错更危险。

## 三、本轮改动清单
| 文件 | 改动 |
|---|---|
| `tools/mcp_client.py` | 新增 `_find_by_name(name)` / `_find_any_script(fname)`；`_resolve_script(args, cwd, cmd, srv_name)` 加服务名参数，回退顺序：服务名 -> cwd basename -> 暴力搜同名；找到后改写绝对路径并钉 cwd |
| `tools/capability.py` | 新增 `selfcheck(engine,force)`（真实 spawn + initialize + tools/list，20s TTL 缓存防轮询 fork 炸弹）、`selfcheck_lines()`；**修正配置读取为 `_cfgmod.Config().data`**，失败时输出真实原因而不是静默降级 |
| `ui/web.py` | `_APP_VER="r85"`；`_mcp_probe` 2028 行 `_rs(...)` 传入服务名 `nm` |
| `ui/gui.py` | `_cap_lines()` SKILL 区后追加 MCP 服务真实连接明细（✓/✗ + 修复建议） |
| `build/make_sfx_exe.py` | `BUILD_ID = "r85-" + ...`（跟随 `_APP_VER`，round80-F2/round81-E2 断言要求） |
| `lab/verify_round85.py` | 31 项断言（M1-M6） |

## 四、验证证据
- `lab/verify_round85.py` -> PASS=31 FAIL=0（M6 为 config 读取回归，含真实 `Config().data` 携带 takeover 段）
- 端到端（旧式配置 `python3` + 裸 `server.py` + `cwd=""`）：
  - `capability.selfcheck` -> ok=True, 1 服务 / 2 工具, cmd 归一为 /usr/bin/python3, cwd 自动钉到安装目录
  - `ui.web._mcp_probe` -> ok=True, tools=[fingerprint_probe, waf_check]
- 全量回归 `lab/regall.sh` -> REGALL TOTAL PASS=3685 FAIL=0 SCRIPTS_FAILED=1（唯一失败项是 check_exe_r82 与**未打包前**源码差异，重打包后归零）
- 重打包 -> VERSION=r85-20261019-145116，`check_exe_r82` -> BAD=0 TOTAL PASS=175 FAIL=0
- 10 个关键脚本复验全绿：49/50/66/79/80/81/84/84_mcp_e2e/fixes/85 共 464 项断言 0 失败

## 五、本轮教训（已写入，后续必须遵守）
1. **存量数据必须在解析期兜底**，不能只依赖「导入时归一化」。r84 的测试脚本全建立在「导入时已归一」假设上，所以漏测。
2. **静默降级是 bug 温床**。`except Exception: cfg = {"takeover": {}}` 让错误表现为「用户没配」，
而不是「程序读不到配置」。凡降级必带可读原因。
3. **断言不得被注释误导**。M6.1 初版用 `"_cfgmod.load()" not in src` 判定，被我自己的说明注释误伤；
正确做法是按行过滤注释后再断言（已改）。
4. **check_exe_r82 不会自动解包**。它读的是 `/tmp/verify82`，必须手动 `7z x` 新包后再跑，
否则拿到的是上一版残留，BAD 数会骗人。

## 六、交付
- 位置：`dist-win/CardinalSRCHunter.exe`
- MD5：`69085b12d4cd85acf2b798ef852fbfa1`
- 版本戳：`r85-20261019-145116`
- 不覆盖 `/sdcard/AI文件/`（按用户指示）

## 七、用户实机上要预期看到的
程序一打开，桌面黑框里应直接出现：
  MCP 自检：✓ 全部连接成功（1 个服务，N 个工具）
    ✓ src_elite_mcp：N 个工具（...）
Web 控制台「测试连接」应返回 ok 并列出工具名。
若仍失败，黑框会直接给出 error 原文 + 修复建议，不再是无信息的 0 个。
