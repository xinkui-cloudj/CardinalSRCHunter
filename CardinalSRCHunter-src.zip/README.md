# Cardinal-SRC-Hunter · 补天自动挖洞套件

> 定位：面向补天 / 众测 / SRC 授权的**半自动到全自动**漏洞挖掘与报告生成工具。
> 形态：Python 源码 + 一键打包为 Windows EXE。首次运行自动安装全部前置环境（Python / Go / 工具链 / 依赖库），
> 安装失败自动诊断→修复→重试，直到环境完全可用。

---

## 一、能力总览

| 阶段 | 模块 | 说明 |
|---|---|---|
| 0 环境自愈 | `bootstrap/installer.py` `bootstrap/doctor.py` | 一键装 Python/Go/pip 库/子域工具；失败自动修复重试 |
| 1 授权范围 | `core/scope.py` | 强制 scope 守卫，越界请求直接拦截并记日志 |
| 2 被动侦察 | `modules/recon.py` | crt.sh 证书透明度、Wayback、GitHub dork、favicon hash、DNS 历史 |
| 3 资产枚举 | `modules/probe.py` | 子域爆破（内置字典）、存活探测、指纹识别、目录发现、JS 提取 |
| 4 漏洞狩猎 | `modules/vulnchecks.py` | 未授权访问 / 信息泄露 / IDOR / SQLi / XSS / SSRF / 开放重定向 / JWT / 上传 / 子域接管 / 组件 CVE |
| 5 PoC 验证 | `modules/poc.py` | 无危害验证（只证明可达性，不拖库、不写入、不 DoS） |
| 6 报告 | `core/report.py` | 补天提交格式：标题 / 复现步骤 / 请求响应原文 / CVSS 4.0 / 修复建议 |
| 7 核验闭环 | `core/verify.py` `core/confidence.py` | 独立证据通道复核漏洞真实性，输出证实/证伪/误报率 |
| 8 规则自收紧 | `core/tuning.py` | 依据历史误报率自动收紧检测阈值（tune 子命令） |

**内置资产**：国产 OA 指纹库（致远/泛微/通达/万户/用友/金蝶/蓝凌）、默认凭据表、
常见未授权路径表（Actuator / Swagger / Druid / Nacos / Redis / Jenkins / .git / .env）、
WAF 指纹与自适应降速策略。

---

## 二、快速开始

### 方式 A：Windows 一键（推荐）
```
1. 把整个 bt-src-hunter 目录拷到电脑
2. 双击  start.bat        # 首次运行自动装环境
3. 双击  build_exe.bat    # 打包成单文件 EXE（可选）
```

### 方式 B：源码直跑
```bash
python main.py doctor                 # 环境诊断 + 自愈
python main.py install                # 一键安装前置工具
python main.py scan -t example.com    # 对授权目标开扫
python main.py report -s 1            # 生成补天格式报告
python main.py verify -s 1            # 核验漏洞真实性（独立证据通道）
python main.py tune --dry-run         # 看误报率驱动的阈值收紧建议
python main.py tune                   # 依据历史误报率写入 data/tuning.json
python main.py gui                    # 图形界面
```

### 方式 C：打包后的 EXE
```
CardinalSRCHunter.exe doctor
CardinalSRCHunter.exe scan -t example.com --full
CardinalSRCHunter.exe gui
```

### 方式 D：启用 AI 辅助（可选，默认关闭）

工具默认**零联网**。需要 AI 辅助时，在**当前终端**临时导出下列变量即可，
不必修改任何配置文件；关掉终端或 `unset` 后立刻回到零网络状态。

```bash
export BTSRHUNTER_AI_ENABLED=1                 # 总开关
export BTSRHUNTER_AI_ONLINE=1                  # 联网开关（必须与上面同时开）
export BTSRHUNTER_AI_BASE=https://api.deepseek.com/v1   # OpenAI 兼容地址
export BTSRHUNTER_AI_MODEL=deepseek-chat       # 模型名
export BTSRHUNTER_AI_KEY=sk-你的密钥            # 密钥（仅内存，绝不落盘）
```

- 两个开关**必须同时为真**才生效，只开一个不会联网（防误触）。
- 密钥只从环境变量读取，不写入 `config/config.json`，不进发布包。
- AI 产物一律落为 `.draft` 文件，**人工审核改名后才生效**；扫描主流程不依赖 AI。
- 免费替代：`BTSRHUNTER_AI_BASE=https://open.bigmodel.cn/api/paas/v4` +
  `BTSRHUNTER_AI_MODEL=glm-4-flash`。

### 方式 E：同步授权范围（白名单）—— 离线半自动

`scope.yaml` 的 `in_scope` 就是「授权测试范围」。手动逐条抄写平台授权页很低效，
可用内置的 **scope-sync** 把「公开 SRC 平台的测试范围」批量抓成候选，人审后一键并入。

```bash
python3 main.py scope-sync --list                      # 看草稿状态 + 当前 in_scope
python3 main.py scope-sync                             # 预演：只打印计划，不联网
python3 main.py scope-sync --fetch                     # 联网检索，落 .draft 草稿（不生效）
python3 main.py scope-sync --fetch --ai --engine bing  # 允许模型参与抽取（需先开 AI 开关）
python3 main.py scope-sync --apply                     # 人审通过后，把草稿追加进 scope.yaml
python3 main.py scope-sync --fetch --dry-run           # 联网但不落盘（只看候选）
```

- 内置 6 个公开源：`butian` / `butian_gift` / `cnvd` / `edu_src` / `vulbox` / `hackerone`，
  只读**公开页面**，不登录、不注册、不提交任何数据。
- **产物永远先落 `.draft` 草稿**（默认 `data/scope_suggest.yaml.draft`），**不会自动生效**；
  只有你显式 `--apply` 才会写回 `config/scope.yaml`，且**只追加、不覆盖**，写前先备份原文件。
- 取数走 `tools/websearch.py`（按路径动态加载），**不进扫描热路径**：本工具不 import
  `core.engine` / `core.httpclient` / `modules.*`，也不依赖任何学习器，纯粹是离线旁路。
- 检索源难免带噪声域名（导航站、字典站），**所以最终必须人审** —— 这正是保留 `--apply` 闸门的原因。
- 白名单一旦写错等于扩大出网范围，请务必在 `--apply` 前用 `--list` / `--dry-run` 复核候选。

---

## 三、安全红线（工具内置强制）

- **只打授权目标**：`scope.yaml` 未命中的域名/IP，HTTP 层直接拒绝发送，并写审计日志。
- **无危害验证**：SQLi 只用 `sleep` 时间盲注证明，不 UNION 拖库；上传只验证扩展名解析，不落地 webshell；
  SSRF 只回连用户自有 OOB 域名。
- **限速默认 5 req/s**，单目标并发 ≤ 10，避免误伤与封 IP。
- **不碰第三方资产**：CDN / 云厂商 / 第三方统计域名自动加入排除表。
- **证据闭环**：每条 finding 必须携带原始请求 + 响应片段 + 置信度，否则不进报告。

---

## 四、目录结构

```
bt-src-hunter/
├── main.py                  入口（CLI / GUI 分发）
├── start.bat / build_exe.bat
├── requirements.txt
├── config/
│   ├── config.json          主配置
│   └── scope.yaml           授权范围（必须填！）
├── core/
│   ├── config.py            配置加载与校验
│   ├── logger.py            日志（控制台 + 轮转文件 + JSONL 审计）
│   ├── scope.py             授权范围守卫
│   ├── db.py                SQLite 结果存储
│   ├── httpclient.py        限速 / 重试 / UA 池 / WAF 识别
│   ├── verify.py            独立证据通道核验（证实/证伪）
│   ├── confidence.py        置信度评估与动态阈值
│   ├── tuning.py            误报率驱动的规则收紧
│   └── report.py            补天格式报告生成
├── modules/
│   ├── recon.py             被动侦察
│   ├── probe.py             资产枚举与指纹
│   ├── vulnchecks.py        漏洞检测器集合
│   └── poc.py               无危害 PoC 验证
├── bootstrap/
│   ├── installer.py         一键安装前置环境
│   └── doctor.py            环境诊断 + 自动修复重试
├── ui/
│   ├── cli.py               命令行
│   └── gui.py               tkinter 图形界面
└── build/
    └── build_exe.py         PyInstaller 打包脚本
```

---

## 五、输出物

- `logs/bt-YYYYMMDD.log` 运行日志
- `logs/audit.jsonl` 审计日志（每条出网请求）
- `data/findings.db` 结构化结果库（含 verifications 核验记录）
- `data/tuning.json` 误报率驱动的阈值配置（由 tune 子命令生成）
- `reports/<target>-<时间>/report.md` 补天提交正文
- `reports/<target>-<时间>/report.html` 可读版
- `reports/<target>-<时间>/verify_report.md` 核验结论与误报率汇总
- `reports/<target>-<时间>/verify.json` 核验结果机读版
- `reports/<target>-<时间>/evidence/*.txt` 每条漏洞的原始请求响应

---

## 六、免责

本工具仅用于**已获授权**的安全测试。使用者需自行确保对测试目标拥有书面授权。
工具默认拒绝一切越界请求，但最终责任在使用者。
