# Cardinal-SRC-Hunter 交接文档 · round73
> 生成：2026-10-17 ｜ 代码版本 round73（round72 基线 + 四项需求落地）
> 交付物：`dist-win/CardinalSRCHunter.exe` + `dist-win/CardinalSRCHunter-src.zip`
>         （哈希见 `dist-win/MD5SUMS.txt`，以该文件为准）
> 版本戳：`ui/web.py::_APP_VER = "r73"`、`build/make_sfx_exe.py::BUILD_ID = "r73-"`

---
## §1 本轮做了什么
| # | 需求（用户原话） | 结论 | 落点 |
|---|---|---|---|
| ① | hunt_queue 死数据回流给 AI | 已落地 + P1 结论已交拍板 | 新增 `tools/hunt_consumer.py`；`core/engine.py` AI 接管分支接线 |
| ② | 桌面加「暂停/继续」+「清空」 | 已落地（关窗软停、进度不虚标） | `core/engine.py`（闸门）+ `ui/gui.py`（按钮/关窗） |
| ③ | Web 控制台「资产」页删除失效 | 已修（端到端 `deleted=1`） | `ui/web.py::loadAssets` / `decorateTable` |
| ④ | SKILL 总开关改成与 MCP 页一致 | 已落地（真控全局生效） | `core/config.py` / `tools/skill_loader.py` / `tools/capability.py` / `ui/web.py` |
| 附 | 选项2：AI 自造 payload 通道（用户拍板加做） | 已落地（硬顶 12×12） | 新增 `modules/vc_custom.py`；`modules/vulnchecks.py`；`tools/tool_registry.py`；`tools/hunt_consumer.py` |

---
## §2 验证证据（可复现）
```sh
cd /storage/emulated/0/Audiobooks/src/bt-src-hunter
python3 -B lab/verify_round73.py     # round73 PASS=67 FAIL=0（A/C/D/E 四组 + 端到端 HTTP）
python3 -B lab/verify_round73b.py    # PASS=20 FAIL=0（B 组暂停/清空/进度不虚标）
python3 -B lab/verify_round49.py     # PASS=47 FAIL=0（skill_loader 导入面契约红线）
python3 -B lab/verify_round71c.py    # PASS=96 FAIL=0（round71c 三项检测器复跑）
rm -rf /tmp/verify73 && mkdir -p /tmp/verify73
7z x -y -o/tmp/verify73 dist-win/CardinalSRCHunter.exe
EX73_DIR=/tmp/verify73 python3 -B lab/check_exe_r73.py   # BAD=0 / PASS=83 FAIL=0
sh lab/regall.sh                     # 全量回归（67 脚本，含 EXE 复核段）
```

---
## §3 本轮契约与红线（改代码前必读）
1. **`tools/skill_loader.py` 导入面必须是纯标准库**（`os/re/sys/argparse/io/json/importlib`）。
   `verify_round49.py` N3 会 ast 扫描导入面，出现 `from core import …` 即判 FAIL。
   `global_enabled()` 的配置落点由 `_cfg_path()` 自行复刻（`BTSRHUNTER_USER_DIR` >
   EXE 态 `%LOCALAPPDATA%\CardinalSRCHunter\userdata` > 开发态源码根），**不要为了省事去 import core.config**。
2. **`hunt_consumer` 只读不写**：模块内不得出现 `record_many` / 任何写盘调用；
   指纹必须走 `core.hunt_queue.fingerprint`（单一来源），不得本地复制算法。
3. **AI 接管分支的两段提示默认空串**：AI 关闭 / `takeover.hunt_max=0` 时，
   `run_agent(hunt_system="", hunt_user="")` 行为必须与 round72 逐字一致。
4. **`takeover.skill.enabled` 默认 True**（与 `mcp.enabled` 默认 False 相反）：
   技能装了就生效，改默认值等于改变既有行为。

---
## §4 交付物重建（三连，改任何源码后必须重跑）
```sh
python3 build/make_src_zip.py        # 源码包（排除 .bak_* / tmp_patch_* / __pycache__ 等）
python3 build/make_sfx_exe.py pack   # EXE（用 /tmp/btsfx 缓存；只 copy_app 刷新源码）
python3 build/make_src_zip.py        # 再跑一次刷新 dist-win/MD5SUMS.txt
```
- `make_src_zip.py` 末尾有两个硬自检：`BAK_LEAK bad=0`、`VERIFY bad=0`，任一非 0 即返回 1；
- `make_sfx_exe.py pack` 的 `copy_app()` 内有「包内混入备份文件」自检，返回 1 即中止；
- EXE 内层 7z 必须 `-mf=off` 且格式版本降为 0.3（否则 7-Zip 9.20 的 SFX 解码器报
  `Unsupported Method`，用户双击无反应）。

---
## §5 本轮新增铁律（防再犯）
- **新增 `lab/verify_roundNN*.py` 必须同步登记进 `lab/regall.sh` 脚本清单**，否则该组仅被 AST 静态断言覆盖、运行时路径漏检（round73 的 B 组即漏检一次，已补）；
- 全量回归**跑完前禁止 `pkill -f vuln_server.py`**：`regall.sh` 自己会拉起 8081 靶机，抢跑收尾会杀掉靶机导致 round9 等活体脚本 FAIL（本轮已踩一次，重跑才拿到真结果）；
- 版本字面量断言随版本戳升级同步：round66 A1 已改为 `range(72,100)` 历史基线、round71 A11 正则已放宽为 `r(?:7[1-9]|[89]\d)`，**此后升版只需改 round67 的全文**。
- **工作区重挂载会丢最新未落盘文件**：本轮收口尾声宿主重挂载（session 变更）后 `lab/verify_round65.py` 真丢（仅剩 `lab/__pycache__/*.pyc`）。**任何改动落盘后必须回读确认存在**；一旦 `edit_file` 报 `File does not exist`，即为文件真丢信号，应立即排查而非重试。恢复源优先级：① 其它快照内副本（本轮 EXE 不含 `lab/`，无此源）② 历史 `dist-win/*.zip` ③ `lab/__pycache__/*.pyc` 反汇编重建（本轮走此路，`verify_round65.py` 10830B pyc → 1082 行反汇编 → 181 行源码，单跑 40/0 复原）；
- **打包卫生**：任何 `pip download/install -t .` 类排障动作会在项目根留下 `.whl`，打包前必须清掉（本轮 8 个 whl 一度把 src.zip 从 164 顶到 172 文件）。交付前用`python3 -c "import zipfile;print(len(zipfile.ZipFile('dist-win/CardinalSRCHunter-src.zip').namelist()))"` 核对文件数是否为 **164**；
---
## §6 待下一轮（本轮未动）
- 工作区根目录 `tmp_patch_*.py` 8 个与 `_r58_dicts.txt` 已在本轮 E5 清理时删除；`ai_key.txt` 保留不动；
- 备份命名历史不统一（`.r62bak` / `.r63bak` 与 `.bak_rNN` 并存），交付前靠 `BAK_LEAK bad=0` 兜底；
- 回归脚本数 64 → **67**（新增 `lab/verify_round73.py` 67 项 + 补登记 `lab/verify_round73b.py` 20 项；`check_exe` 段脚本换代不计入脚本数）。全量回归最终基线：`REGALL TOTAL PASS=2894 FAIL=0 SCRIPTS_FAILED=0`（最终锁定日志 `/tmp/reg73g.out`，事故恢复后重跑）；
