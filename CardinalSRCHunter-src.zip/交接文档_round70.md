# 交接文档 · round70
> 生成时间：2026-10-15 20:20
> 代码版本：round70（round68 基线 + 六项需求之 ②③⑤⑥ 落地 + 版本戳升 r70）
> 前置文档：`交接文档_round61.md`（round60/61 主体改动）、`项目总结报告.md` 第十节（round70 详情）
> 接手请先读本文档 §0/§1，再看 `项目总结报告.md` 第十节。

---
## §0 一句话结论
round68 用户定下的**六项需求 + 收尾**中，本轮完成 **②③⑤⑥ 四项**（需求① 已于 round69 闭环；需求④ 用户两张截图里没有第四条内容，留空待用户补）。
全部改动已落源码、回归全绿、交付物（EXE / src.zip / MD5SUMS）已重建。

---
## §1 本轮改了什么
| 文件 | 改动 |
|---|---|
| `tools/skill_loader.py` | `_parse()` 加 `source` 字段；新增 `install_pack()` / `uninstall_pack()` / `_reap()`；CLI `uninstall` 优先整包语义 |
| `tools/capability.py` | **新增**（93 行）：`list_capabilities()` / `build_note()`，能力清单只含已启用项 |
| `tools/agent_loop.py` | system 模板加 `{caps}`，注入能力清单（适用性由 AI 自主判断） |
| `core/engine.py` | 扫描主循环显式打印能力清单一行（异常静默） |
| `ui/web.py` | 需求② ZIP 整包安装 + `reaped`；需求③ 两个总开关合并为切换按钮；需求⑥ 报告页列表化 + 六页统一顶部「删除/全选/清空」；`_APP_VER` → `r70` |
| `build/make_sfx_exe.py` | `BUILD_ID` → `r70-`；rem 注释同步 |
| `lab/verify_round70.py` | **新增**（47 断言，三层） |
| `lab/verify_round66.py` | ZIP 断言改「整包合并 1 条目」；A1 版本戳 → r70；A8 加单切换按钮断言 |
| `lab/verify_round62.py` `verify_round64.py` | MCP 行内「删除」断言改为「已上移顶部」 |
| `lab/verify_round67.py` | 版本字面量 r67 → r70（34 处） |
| `lab/check_exe_r70.py` | **新增**（由 r67 版派生 + round70 八条新锚点） |
| `lab/regall.sh` | 收录 `verify_round70.py`（60 脚本） |
| `项目总结报告.md` | 版本行/基线更新 + 新增第十节 |

备份：`/tmp/web.py.bak_r70`、`/tmp/r66.py.bak_r70`、`/tmp/skill_loader.py.bak_r70`。

---
## §2 六项需求完成度
| # | 需求 | 状态 |
|---|---|---|
| ① | 端点与 API 配置持久化 | ✅ round69 已闭环 |
| ② | SKILL 导入/卸载交互改造（一个 ZIP=一个工具、旧条目一起收拾、删除按钮上移、单/多/全选） | ✅ 本轮 |
| ③ | 总开关合并（MCP 两按钮→单切换；SKILL 页同款） | ✅ 本轮 |
| ④ | （用户两张截图均无第四条内容） | ⏸ 待用户补 |
| ⑤ | 扫描能力自挂载（能力清单→适用性判定→调用） | ✅ 本轮 |
| ⑥ | 四页批量删除（含报告页，连磁盘产物一起删） | ✅ 本轮 |
| 收尾 | 重打 EXE + 刷 zip + MD5SUMS + 全量回归 + 自检 | ✅ 本轮 |

---
## §3 当前权威状态
| 项 | 值 |
|---|---|
| 全量回归 | `REGALL TOTAL PASS=2589 FAIL=0 SCRIPTS_FAILED=0`（60 脚本） |
| 回归日志 | `/tmp/regall_r70f.txt`（本轮权威） |
| `ui/web.py` | 1590 行，`ast.parse` 通过，`node --check` 通过 |
| `tools/skill_loader.py` | 449 行 |
| `tools/capability.py` | 93 行（新增） |
| EXE 解包复核 | `lab/check_exe_r70.py` **BAD=0**；三文件与源码 md5 一致（SAME） |
| 靶场进程 | 已 `kill`，零残留 |

---
## §4 交付物（`dist-win/MD5SUMS.txt` 为权威）
| 文件 | size | md5 |
|---|---|---|
| `CardinalSRCHunter.exe` | 21541418 | b83cd69533987e3cdd7527f05b459180 |
| `CardinalSRCHunter-src.zip` | 680703（149 files） | 5d78b5742fa9d9e366988368dc9abe07 |
| `项目总结报告.md` | 78583 | c93485b9f3cbbdd46f86ffb2af7eb11e |

重建顺序（**必须按此顺序**）：
```sh
python3 build/make_src_zip.py        # 出 PACK + BAK_LEAK bad=0 + VERIFY bad=0
python3 build/make_sfx_exe.py pack   # 出 [verify] MZ=True PE=True
python3 build/make_src_zip.py        # 再跑一次刷新 MD5SUMS.txt
```

---
## §5 下一轮方向
1. **需求④**：用户两张截图里没有第四条，需用户补内容后开工；
2. 收尾自检可加 `check_exe_r70.py` 进 `regall.sh`（当前需手工解包到 `/tmp/verify70` 再跑）；
3. 上一轮遗留：`core/engine.py:1060 scan_target` 的 `as_completed` 无 `timeout`（worker 可能永不返回），
   本轮未动，仍是「完整回归偶发卡住」的候选根因；
4. round60 交接文档 §6.1 的三项检测器扩展仍可做。

---
## §6 环境硬约束（继续有效）
- `read_file` 直读 `/storage/emulated/0/...` 会报 `File does not exist`，走 terminal 或 `repo:Audiobooks`；
- 禁止 `set -e`（会卡死终端会话）；
- **含中文 + 复杂引号的批量替换，一律写成 `.py` 落 `/tmp/` 再执行**，不要 heredoc 内联（PTY 会改写中文引号致 `SyntaxError`）；
- `_PAGE` 内联 JS 里拼 `onclick="fn(\'x\',true)"` 需**四重**反斜杠；改完必须 `node --check` 抽 `<script>` 校验；
- jsdom 子进程要 `cwd=/tmp/jsdomtest`；脚本末尾必须 `process.exit(0)`；
- 长命令必须拆短 + 显式传 `timeoutMs`；全量回归 > 5 分钟，用 `setsid nohup ... &` 后台跑再轮询 `grep -c '^===== '`；
- 跑完回归必查 `vuln_server.py` 残留（`pkill -9 -f vuln_server.py`）；
- 备份一律后缀式（`foo.py.bak_rNN`），不要目录式（`os.walk` 会扫到）。

---
*本文档随 round70 交付生成，与 `dist-win/CardinalSRCHunter-src.zip` 内源码一致。*
