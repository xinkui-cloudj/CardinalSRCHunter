# -*- coding: utf-8 -*-
"""Cardinal-SRC-Hunter 入口。

- 保证以脚本所在目录为工作根（兼容 PyInstaller 单文件 exe）；
- 初始化目录与日志，打印 banner；
- 无参数时：若在 Windows 且有图形环境 → 进 GUI；否则打印帮助；
- 有参数 → 交给 ui.cli 处理。

首次使用：运行期依赖已内置，直接 `scan -t 目标` 即可；如需自检可运行 `doctor`（离线校验，不联网）。
"""
import os
import sys

# r88: 禁用 .pyc 字节码缓存。
# 原因：源码树可写，执行器一旦留下 __pycache__，升级源码后仍可能复用旧字节码；
# 实测导致 r88 复扫跑的是 p1 补丁前的 template_engine（Laravel 误报又打回 16 条，
# 新增日志一条不出现）。不写字节码，源码就是唯一事实来源。
sys.dont_write_bytecode = True


def _safe_stdio():
    """pythonw.exe 无控制台，sys.stdout/stderr 为 None。

    此时任何 print()/sys.stderr.write() 都会抛 AttributeError 把进程打挂，
    表现为"双击后毫无反应"。这里给它们接上可写的兜底对象。
    """
    class _Null(object):
        encoding = "utf-8"
        errors = "replace"

        def write(self, *_a):
            return 0

        def flush(self):
            pass

        def isatty(self):
            return False

    for name in ("stdout", "stderr"):
        s = getattr(sys, name, None)
        if s is None:
            setattr(sys, name, _Null())
            continue
        # 有对象但写不了（GUI 模式常见的无效句柄）也换掉
        try:
            s.write("")
            s.flush()
        except Exception:
            setattr(sys, name, _Null())


def _bootstrap_path():
    """把项目根加入 sys.path，保证 core/ modules/ 可导入。"""
    here = os.path.dirname(os.path.abspath(__file__))
    if getattr(sys, "frozen", False):
        here = os.path.dirname(sys.executable)
    if here not in sys.path:
        sys.path.insert(0, here)
    return here


def main(argv=None):
    _safe_stdio()
    root = _bootstrap_path()
    try:
        os.chdir(root)
    except Exception:
        pass

    argv = list(sys.argv[1:] if argv is None else argv)

    from core import config as cfg
    from core import logger
    cfg.ensure_assets()   # 打包后先把随包 config/ 释放到 exe 同级
    cfg.ensure_libs_path()  # 把 libs/（--target 装依赖的落点）挂进 sys.path
    cfg.ensure_dirs()

    # 全局 DNS 增强：把 socket.getaddrinfo 换成「dnsx 多源解析优先、系统兜底」，
    # 让 requests / urllib3 / dnspython 全部无感获得多源并发解析能力。
    # 必须在任何出网请求之前装（放在这里最早，且失败不影响启动）。
    try:
        from core import dnsx
        dnsx.install_hook()
    except Exception:
        pass

    # 无参数：尝试 GUI，失败则打印帮助
    if not argv:
        try:
            from ui import gui
            return gui.main()
        except Exception:
            # round77 实机事故教训：GUI 崩在这里会被静默吞掉 —— pythonw 无控制台，
            # 用户只看到「黑框闪一下就没反应」，logs/crash.log（只由顶层未捕获
            # 异常写）也留不下证据。因此先单独落一份 gui_crash.log 再回退 CLI。
            import traceback
            _gui_crash_log(traceback.format_exc())
            from ui import cli
            logger.init()
            print(logger.banner())
            cli.build_parser().print_help()
            return 0

    from ui import cli
    return cli.main(argv)

def _gui_crash_log(exc_text):
    """把 GUI 启动失败单独写到 logs/gui_crash.log。

    与 _crash_log 的区别：这里只捞「无参数 → 进 GUI → 炸了」这一种情况，
    因为该异常会被 `except Exception` 吞掉并回落 CLI，顶层兜底永远看不到它。
    round77 实机事故（`_pref` 先用后绑）就是死在这个黑洞里，
    用户侧只剩「黑框闪一下就没反应」这一条线索。落点优先用户目录
    （安装态为 %LOCALAPPDATA%\\CardinalSRCHunter\\logs），失败再退回程序目录。
    """
    try:
        from core import config as cfg
        d = getattr(cfg, "LOG_DIR", None) or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "logs")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "gui_crash.log"), "a", encoding="utf-8") as f:
            f.write("==== %s ====\n%s\n" % (
                __import__("datetime").datetime.now().isoformat(timespec="seconds"),
                exc_text))
    except Exception:
        pass
    """把致命异常写到 logs/crash.log（pythonw 无控制台，只能落盘）。

    round77 事故后修正落点：优先用户目录 `<用户数据根>/logs`（安装态为
    `%LOCALAPPDATA%\\CardinalSRCHunter\\userdata\\logs`），失败再退回程序目录
    （旧行为；程序目录可能是只读的 Program Files，留不下证据）。
    """
    try:
        from core import config as cfg
        d = getattr(cfg, "LOG_DIR", None) or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "logs")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "crash.log"), "a", encoding="utf-8") as f:
            f.write("==== %s ====\n%s\n" % (
                __import__("datetime").datetime.now().isoformat(timespec="seconds"),
                exc_text))
    except Exception:
        pass


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except BaseException:
        import traceback
        _crash_log(traceback.format_exc())
        # 有控制台时也打出来，方便 doctor.bat 直接看到
        try:
            print(traceback.format_exc())
        except Exception:
            pass
        sys.exit(1)