# -*- coding: utf-8 -*-
"""环境诊断 + 自愈。

对应用户需求 5：安装失败时自动检查错误并修正，直到安装成功、程序能完美运行。

闭环模型：
    diagnose() → 发现缺失/异常 → heal() 分类错误 → 施加修复动作 → 复测
    → 仍失败则换策略重试，最多 bootstrap.max_repair_rounds（默认 6）轮
    → 6 轮仍失败：把"可运行的最小降级方案"落地（可选依赖跳过），保证主流程能跑。

判定原则：核心依赖必须全绿；可选依赖（lxml/bs4/Jinja2）缺失只降级不阻塞。
"""
import importlib
import os
import shutil
import socket
import sys
import time

from core import config as cfg
from core import logger as log
from . import installer as ins

# 核心依赖：缺一个主流程就跑不起来
CORE_DEPS = {"requests": "requests", "yaml": "PyYAML", "dns": "dnspython",
             "urllib3": "urllib3", "tqdm": "tqdm", "colorama": "colorama"}
# 可选依赖：缺失只降级（当前内核为纯字符串实现，不依赖它们）
OPTIONAL_DEPS = {"bs4": "beautifulsoup4", "lxml": "lxml", "jinja2": "Jinja2"}

PROBE_HOSTS = [("pypi.tuna.tsinghua.edu.cn", 443), ("mirrors.aliyun.com", 443),
               ("pypi.org", 443)]


# ---------------------------------------------------------------- 检查项

def check_python_version():
    try:
        v = ins.check_python()
        return True, "Python %s" % v
    except ins.InstallError as ex:
        return False, ex.message


def check_modules(mods):
    # 依赖可能刚被 --target 装进 libs/，此处先把它挂进 sys.path 再探测，
    # 否则"装好了却检测不到"，自愈会误判为缺失并反复重装。
    cfg.ensure_libs_path()
    importlib.invalidate_caches()
    missing = []
    for mod in mods:
        try:
            importlib.import_module(mod)
        except Exception:
            missing.append(mod)
    return missing


def check_pip():
    try:
        ins.ensure_pip()
        return True, "pip 可用"
    except ins.InstallError as ex:
        return False, ex.message


def check_network():
    for host, port in PROBE_HOSTS:
        try:
            s = socket.create_connection((host, port), timeout=4)
            s.close()
            return True, "可达 %s" % host
        except Exception:
            continue
    return False, "无法连接任何 PyPI 镜像（可能离线/被代理拦截）"


def check_writable():
    bad = []
    for d in (cfg.DATA_DIR, cfg.LOG_DIR, cfg.REPORT_DIR, cfg.TOOLS_DIR):
        try:
            os.makedirs(d, exist_ok=True)
            t = os.path.join(d, ".wtest")
            with open(t, "w") as f:
                f.write("ok")
            os.remove(t)
        except Exception as e:
            bad.append("%s(%s)" % (d, e))
    return (not bad), ("目录可写" if not bad else "不可写: %s" % "; ".join(bad))


def check_disk(min_mb=200):
    try:
        total, used, free = shutil.disk_usage(cfg.ROOT)
        free_mb = free // (1024 * 1024)
        return (free_mb >= min_mb), "剩余 %d MB" % free_mb
    except Exception as e:
        return True, "无法检测磁盘(%s)" % e


def check_go():
    go = ins.find_go()
    if not go:
        return False, "未安装（可选，不影响 Python 内核）"
    try:
        return True, ins.run([go, "version"], "go", timeout=60).strip()
    except ins.InstallError as ex:
        return False, ex.message


def diagnose(verbose=False, check_net=True):
    """返回 {"ok": bool, "items": [...], "missing_core": [...], "missing_opt": [...]}

    check_net=False 时跳过联网探测（纯离线校验，秒出结果）。
    联网能力不是必需项，因此跳过它不影响 ok 判定。
    """
    items = []
    py_ok, py_msg = check_python_version()
    items.append(("python", py_ok, py_msg, True))

    pip_ok, pip_msg = check_pip()
    items.append(("pip", pip_ok, pip_msg, True))

    if check_net:
        net_ok, net_msg = check_network()
    else:
        net_ok, net_msg = True, "已跳过（离线模式）"
    items.append(("network", net_ok, net_msg, False))

    missing_core = check_modules(list(CORE_DEPS.keys()))
    items.append(("core_deps", not missing_core,
                  "齐全" if not missing_core else "缺失: %s" % ",".join(missing_core), True))

    missing_opt = check_modules(list(OPTIONAL_DEPS.keys()))
    items.append(("optional_deps", not missing_opt,
                  "齐全" if not missing_opt else "缺失: %s" % ",".join(missing_opt), False))

    wr_ok, wr_msg = check_writable()
    items.append(("writable", wr_ok, wr_msg, True))

    disk_ok, disk_msg = check_disk()
    items.append(("disk", disk_ok, disk_msg, True))

    go_ok, go_msg = check_go()
    items.append(("go", go_ok, go_msg, False))

    ok = all(ok for _, ok, _, required in items if required)
    if verbose:
        for name, good, msg, required in items:
            log.get().info("  [%s] %-14s %s", "OK" if good else "--", name, msg)
    return {"ok": ok, "items": items, "missing_core": missing_core,
            "missing_opt": missing_opt}


# ---------------------------------------------------------------- 错误分类修复

def classify(err):
    """从 InstallError 里识别错误类型，返回修复策略名。"""
    blob = ("%s %s %s" % (err.message, err.output, err.hint)).lower()
    table = [
        ("no_pip", ["no module named pip", "ensurepip"]),
        ("ssl", ["ssl", "certificate verify failed", "certifi", "certificate"]),
        ("timeout", ["timed out", "timeout", "read timed out", "connection reset",
                     "connection aborted", "temporary failure", "network is unreachable"]),
        ("dns", ["name or service not known", "nodename nor servname",
                 "getaddrinfo", "failed to resolve"]),
        ("permission", ["permission denied", "access is denied", "winerror 5",
                        "errno 13"]),
        ("build", ["microsoft visual c++", "building wheel", "metadata-generation",
                   "failed building wheel", "error: can't find rust", "rustc",
                   "gcc", "cc1plus", "fatal error"]),
        ("version", ["no matching distribution", "could not find a version",
                     "requires-python", "is not a supported wheel"]),
        ("diskfull", ["no space left", "disk full", "errno 28"]),
        ("proxy", ["proxy", "tunnel connection failed", "407"]),
    ]
    for name, keys in table:
        if any(k in blob for k in keys):
            return name
    return "generic"


def _pip_extra(args, stage="repair"):
    """以「真实 Python 解释器 + frozen 目标目录」执行 pip。

    缺陷 F 修复：frozen（PyInstaller）下 sys.executable 是本 exe，直接
    `exe -m pip` 只会重启自己；必须走 ins.python_exe() 找到外部真 Python，
    再用 --target 把包装进 exe 同级 libs/（否则系统 site-packages 不在
    应用的 sys.path 里，装了也 import 不到）。
    """
    py = ins.python_exe()
    if not py:
        raise ins.InstallError(
            "pip", "未找到可用的 Python 解释器",
            hint="安装 Python 3.9+（勾选 Add to PATH），或设置环境变量 "
                 "BTSRC_PYTHON 指向 python.exe")
    tgt = ins._pip_target_args()
    args = list(args)
    # --target 与 --user 互斥，target 模式下剔除 --user
    if tgt and "--user" in args:
        args = [a for a in args if a != "--user"]
    ins.run(py + ["-m", "pip"] + args + tgt, stage, timeout=1800)


def apply_fix(kind, requirements=None):
    """按错误类型施加修复动作。返回 (是否可能已修复, 说明)。"""
    requirements = requirements or os.path.join(cfg.ROOT, "requirements.txt")

    if kind == "no_pip":
        py = ins.python_exe()
        if py:
            try:
                ins.run(py + ["-m", "ensurepip", "--upgrade"], "repair", 600)
                return True, "已用 ensurepip 重建 pip"
            except ins.InstallError:
                pass
        if ins._bootstrap_getpip():
            return True, "已用 get-pip.py 兜底重建 pip"
        return False, "ensurepip 与 get-pip.py 均失败，需手动安装 pip"

    if kind == "ssl":
        try:
            _pip_extra(["install", "--upgrade", "certifi", "--trusted-host",
                        "pypi.tuna.tsinghua.edu.cn", "-i",
                        "https://pypi.tuna.tsinghua.edu.cn/simple"])
        except ins.InstallError:
            pass
        try:
            _pip_extra(["install", "-r", requirements, "--trusted-host",
                        "pypi.tuna.tsinghua.edu.cn", "-i",
                        "https://pypi.tuna.tsinghua.edu.cn/simple"])
            return True, "已加 --trusted-host 并更新 certifi 后重装"
        except ins.InstallError as ex:
            return False, "SSL 修复重装失败: %s" % ex.message

    if kind in ("timeout", "dns", "generic"):
        # 换镜像重试由 installer 内部轮转完成，这里显式再跑一轮
        try:
            ins.install_pip_deps(requirements, mirror="auto")
            return True, "已轮转镜像重装"
        except ins.InstallError as ex:
            return False, ex.message

    if kind == "proxy":
        return False, ("检测到代理问题：请设置环境变量 HTTP_PROXY/HTTPS_PROXY，"
                       "或清空 http.proxy 后重试")

    if kind == "permission":
        try:
            _pip_extra(["install", "-r", requirements, "--user"])
            return True, "已改用 --user 安装到用户目录"
        except ins.InstallError as ex:
            return False, "用户目录安装失败: %s" % ex.message

    if kind == "build":
        # 优先用预编译 wheel，避免本地编译；lxml 等失败即降级为可选跳过
        try:
            _pip_extra(["install", "-r", requirements, "--only-binary", ":all:",
                        "--prefer-binary"])
            return True, "已强制使用预编译 wheel"
        except ins.InstallError:
            try:
                _pip_extra(["install", "requests", "urllib3", "dnspython", "PyYAML",
                            "tqdm", "colorama", "--only-binary", ":all:"])
                return True, "已安装核心依赖（可选编译型依赖跳过）"
            except ins.InstallError as ex:
                return False, "预编译安装失败: %s" % ex.message

    if kind == "version":
        try:
            _pip_extra(["install", "--upgrade", "pip", "setuptools", "wheel"])
            _pip_extra(["install", "-r", requirements])
            return True, "已升级 pip/setuptools/wheel 后重装"
        except ins.InstallError as ex:
            return False, ex.message

    if kind == "diskfull":
        return False, "磁盘空间不足：请清理后重试（至少预留 200MB）"

    return False, "无匹配修复策略，将换镜像重试"


# ---------------------------------------------------------------- 自愈主循环

def heal(requirements=None, max_rounds=None, with_go=True):
    """自愈主循环：装 → 测 → 修 → 再装，直到全绿或轮次耗尽。"""
    max_rounds = max_rounds or cfg.Config().get("bootstrap.max_repair_rounds", 6)
    cfg.ensure_dirs()
    history = []

    # ---- 快路径：依赖已内置时，离线校验通过即返回 ----
    # 便携包已把全部运行期依赖内置进 python/Lib/site-packages，
    # 此时联网 pip 纯属多余（弱网会白等很久）。先做一次不联网的校验，
    # 全绿就直接结束；只有真的缺东西才进入下面的联网修复循环。
    pre = diagnose(verbose=True, check_net=False)
    if pre["ok"]:
        log.get().info("环境自检通过 ✅（离线校验，无需联网安装）")
        log.audit("heal_ok", rounds=0, offline=True)
        return {"ok": True, "rounds": 0, "history": history, "report": pre}

    log.get().warning("离线校验未通过（核心缺失 %s），进入联网修复流程",
                      ",".join(pre["missing_core"]) or "-")

    for rnd in range(1, int(max_rounds) + 1):
        log.get().info("═══ 自愈第 %d/%d 轮 ═══", rnd, max_rounds)
        try:
            ins.install_all(requirements, with_go=with_go)
        except ins.InstallError as ex:
            kind = classify(ex)
            log.get().warning("第 %d 轮安装失败 [%s]: %s", rnd, kind, ex.message)
            if ex.output:
                log.get().debug("输出尾部: %s", ex.output[-800:])
            fixed, note = apply_fix(kind, requirements)
            history.append({"round": rnd, "kind": kind, "msg": ex.message,
                            "fixed": fixed, "note": note})
            log.audit("heal_round", round=rnd, kind=kind, fixed=fixed, note=note)
            if not fixed and kind in ("diskfull", "proxy"):
                # 这两类无法程序化修复，提前给出明确人工指引
                return {"ok": False, "history": history,
                        "reason": "需要人工处理: %s" % note}
            time.sleep(min(2 * rnd, 6))
            continue

        rep = diagnose(verbose=True)
        if rep["ok"]:
            # 可选依赖仍缺：尝试补一次，补不上就降级继续
            if rep["missing_opt"]:
                try:
                    ins.install_pip_deps(requirements, mirror="auto")
                except ins.InstallError:
                    log.get().warning("可选依赖未装齐（%s），主流程不受影响，继续",
                                      ",".join(rep["missing_opt"]))
            log.get().info("环境自检通过 ✅")
            log.audit("heal_ok", rounds=rnd)
            return {"ok": True, "rounds": rnd, "history": history, "report": rep}
        log.get().warning("第 %d 轮复测未通过: 核心缺失 %s",
                          rnd, ",".join(rep["missing_core"]) or "-")
        # 复测失败也走一次修复
        fixed, note = apply_fix("generic", requirements)
        history.append({"round": rnd, "kind": "recheck", "msg": "复测未通过",
                        "fixed": fixed, "note": note})
        time.sleep(1)

    rep = diagnose(verbose=True)
    log.get().error("自愈 %s 轮仍未全绿；已尽力修复，给出最小可用降级方案", max_rounds)
    return {"ok": rep["ok"], "rounds": int(max_rounds), "history": history,
            "report": rep,
            "reason": "核心依赖仍缺失: %s" % ",".join(rep["missing_core"])}


def ensure_ready(requirements=None):
    """主程序启动前的守卫：环境不 OK 就自愈，仍不 OK 才抛错。

    这里用离线校验（check_net=False）：联网能力不是运行必需项，
    依赖已内置时不该因为探测网络而多等数秒。
    """
    rep = diagnose(check_net=False)
    if rep["ok"]:
        return True
    log.get().warning("启动自检未通过，进入自动修复流程")
    res = heal(requirements)
    if not res["ok"]:
        raise RuntimeError("环境自动修复失败：%s\n请查看 logs/audit.jsonl 与上述提示。"
                           % res.get("reason", ""))
    return True


def print_report(check_net=True):
    rep = diagnose(verbose=True, check_net=check_net)
    print("\n环境总评: %s" % ("✅ 通过" if rep["ok"] else "❌ 未通过"))
    if rep["missing_core"]:
        print("核心依赖缺失: %s" % ", ".join(rep["missing_core"]))
    if rep["missing_opt"]:
        print("可选依赖缺失(不影响运行): %s" % ", ".join(rep["missing_opt"]))
    return rep