# -*- coding: utf-8 -*-
"""一键安装器：Python 依赖 + Go 工具链。

设计目标（对应用户需求 4）：
- 第一次运行自动装齐所有前置：pip 依赖、可选 Go 工具。
- 任一环节失败不静默：抛出 InstallError，携带 stage / cmd / output / hint，
  交给 doctor 做"检查错误 → 修正 → 重试"的闭环。
- 镜像自动切换：默认官方源失败即按 pip 镜像列表轮转。

所有安装产物与状态写入 data/install_state.json，便于断点续装。
"""
import importlib
import json
import os
import shutil
import subprocess
import sys
import time

from core import config as cfg
from core import logger as log

# ---------------------------------------------------------------- 镜像源

PIP_MIRRORS = [
    ("official", "https://pypi.org/simple"),
    ("tuna", "https://pypi.tuna.tsinghua.edu.cn/simple"),
    ("aliyun", "https://mirrors.aliyun.com/pypi/simple"),
    ("ustc", "https://mirrors.ustc.edu.cn/pypi/simple"),
    ("tencent", "https://mirrors.cloud.tencent.com/pypi/simple"),
]

GO_MIRRORS = [
    ("official", "https://proxy.golang.org,direct"),
    ("goproxy.cn", "https://goproxy.cn,direct"),
    ("aliyun", "https://mirrors.aliyun.com/goproxy/,direct"),
]

# 需要随 Go 一起安装的工具（与 config.json tools 段对应）
GO_TOOLS = {
    "subfinder": "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
    "httpx": "github.com/projectdiscovery/httpx/cmd/httpx@latest",
    "dnsx": "github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
    "nuclei": "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
}

STATE_FILE = os.path.join(cfg.DATA_DIR, "install_state.json")

# 打包后第三方依赖的落地目录（frozen 应用 import 得到的地方）
TARGET_DIR = cfg.LIBS_DIR


def _looks_like_python(path):
    """确认某个可执行文件确实是 Python（而不是本 exe 自己）。"""
    if not path:
        return False
    try:
        out = run([path, "-c", "import sys;print(sys.version_info[0])"], "probe",
                  timeout=60)
        return "3" in out
    except InstallError:
        return False


def find_python():
    """定位一个"真正的" Python 解释器。

    frozen（PyInstaller）后 sys.executable 是本 exe，不是 Python ——
    直接拿它执行 `-m pip` 只会无限重启自己。因此必须主动去找系统 Python。
    查找顺序：环境变量 → py 启动器 → python3/python → 常见安装路径。
    """
    env = os.environ.get("BTSRC_PYTHON")
    cands = []
    if env:
        cands.append(env)
    if os.name == "nt":
        py = shutil.which("py")
        if py:
            # Windows 的 py 启动器：py -3 -c ... 才等价于 python
            cands.append(py + "|-3")
        for n in ("python.exe", "python3.exe"):
            p = shutil.which(n)
            if p:
                cands.append(p)
        for guess in (os.path.expandvars(r"%LOCALAPPDATA%\Programs\Python"),
                      r"C:\Python312", r"C:\Python311", r"C:\Python310"):
            if os.path.isdir(guess):
                for sub in sorted(os.listdir(guess), reverse=True):
                    exe = os.path.join(guess, sub, "python.exe")
                    if os.path.isfile(exe):
                        cands.append(exe)
    else:
        for n in ("python3", "python"):
            p = shutil.which(n)
            if p:
                cands.append(p)
        for guess in ("/usr/bin/python3", "/usr/local/bin/python3"):
            if os.path.isfile(guess):
                cands.append(guess)

    for c in cands:
        if not c:
            continue
        if "|" in c:  # py 启动器：拆分参数
            head, arg = c.split("|", 1)
            try:
                out = run([head, arg, "-c", "import sys;print(sys.version_info[0])"],
                          "probe", timeout=60)
                if "3" in out:
                    return [head, arg]
            except InstallError:
                continue
        else:
            if _looks_like_python(c):
                return [c]
    return None


_PY_CACHE = {}


def python_exe():
    """返回执行 pip 用的 Python 命令前缀（list）。

    - 非 frozen（直接跑源码）：就是当前解释器，最稳。
    - frozen：必须找到外部真 Python；找不到则返回 None，由调用方给出明确指引。
    """
    if not cfg.is_frozen():
        return [sys.executable]
    if "exe" not in _PY_CACHE:
        _PY_CACHE["exe"] = find_python()
    return _PY_CACHE["exe"]


def _pip_target_args():
    """frozen 下把依赖装进 exe 同级的 libs/，否则装进系统环境也 import 不到。"""
    if cfg.is_frozen():
        return ["--target", TARGET_DIR]
    return []


class InstallError(Exception):
    """安装失败。stage 标识环节，hint 给出可执行的修复方向。"""

    def __init__(self, stage, message, cmd=None, output="", hint=""):
        super(InstallError, self).__init__("[%s] %s" % (stage, message))
        self.stage = stage
        self.message = message
        self.cmd = cmd or ""
        self.output = output or ""
        self.hint = hint


# ---------------------------------------------------------------- 状态

def load_state():
    if os.path.isfile(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"pip_done": False, "go_done": False, "tools_done": [], "mirror": None}


def save_state(state):
    cfg.ensure_dirs()
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------- 执行封装

def run(cmd, stage, timeout=1800, env=None, cwd=None):
    """执行外部命令；失败抛 InstallError（带完整输出，便于诊断）。"""
    log.get().info("执行: %s", " ".join(cmd) if isinstance(cmd, list) else cmd)
    e = dict(os.environ)
    e.setdefault("PYTHONIOENCODING", "utf-8")
    e.setdefault("PYTHONUTF8", "1")
    if env:
        e.update(env)
    try:
        p = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=e, cwd=cwd, universal_newlines=True,
            encoding="utf-8", errors="replace",
        )
        out, _ = p.communicate(timeout=timeout)
    except FileNotFoundError as ex:
        raise InstallError(stage, "命令不存在: %s" % cmd[0], cmd=cmd, output=str(ex),
                           hint="检查该可执行文件是否在 PATH 中，或安装对应运行时。")
    except subprocess.TimeoutExpired:
        p.kill()
        raise InstallError(stage, "命令超时(%ss)" % timeout, cmd=cmd,
                           hint="网络过慢或镜像不可达，尝试切换镜像或延长超时。")
    except Exception as ex:
        raise InstallError(stage, "命令执行异常: %s" % ex, cmd=cmd)
    if p.returncode != 0:
        raise InstallError(stage, "命令返回码 %d" % p.returncode, cmd=cmd,
                           output=(out or "")[-4000:])
    return out or ""


# ---------------------------------------------------------------- 阶段一：Python

def check_python(min_version=None):
    min_version = min_version or cfg.Config().get("bootstrap.python_min", "3.9")
    need = tuple(int(x) for x in min_version.split("."))
    cur = sys.version_info[:2]
    if cur < need:
        raise InstallError(
            "python", "Python %s 低于最低要求 %s" % ("%d.%d" % cur, min_version),
            hint="请安装 Python %s+（https://www.python.org/downloads/），"
                 "安装时勾选 Add Python to PATH。" % min_version)
    return "%d.%d.%d" % sys.version_info[:3]


def _bootstrap_getpip(timeout=300):
    """ensurepip 不可用时的兜底：下载官方 get-pip.py 并用真 Python 执行。

    兼容 Debian/Ubuntu 的 PEP 668 externally-managed 限制：
    依次尝试 默认 → --user → --break-system-packages。
    """
    import tempfile
    import urllib.request
    py = python_exe()
    if not py:
        log.get().warning("找不到可用的 Python 解释器，无法执行 get-pip.py")
        return False
    urls = ["https://bootstrap.pypa.io/get-pip.py",
            "https://bootstrap.pypa.io/pip/get-pip.py"]
    dst = os.path.join(tempfile.gettempdir(), "get-pip.py")
    got = False
    for u in urls:
        try:
            log.get().info("尝试下载 pip 引导脚本: %s", u)
            with urllib.request.urlopen(u, timeout=30) as r, open(dst, "wb") as f:
                f.write(r.read())
            got = True
            break
        except Exception as ex:  # noqa
            log.get().warning("下载 %s 失败: %s", u, ex)
    if not got:
        log.get().warning("get-pip.py 下载失败（网络不可达）")
        return False

    for extra in ([], ["--user"], ["--break-system-packages"]):
        try:
            run(py + [dst, "--no-warn-script-location"] + extra,
                "pip", timeout=timeout)
            return True
        except InstallError as ex:
            log.get().debug("get-pip.py %s 失败: %s", extra or "默认", ex.message)
            continue
    log.get().warning("get-pip.py 三种安装模式均失败（可能系统目录只读）")
    return False


def ensure_pip():
    """确保 pip 可用；缺失则用 ensurepip 引导，再退化到 get-pip.py。"""
    py = python_exe()
    if not py:
        raise InstallError(
            "pip", "未找到可用的 Python 解释器",
            hint="打包版需要本机已安装 Python 3.9+（勾选 Add to PATH），"
                 "或设置环境变量 BTSRC_PYTHON 指向 python.exe。"
                 "也可手动执行：pip install --target libs -r requirements.txt")
    try:
        run(py + ["-m", "pip", "--version"], "pip", timeout=120)
        return True
    except InstallError:
        log.get().warning("pip 不可用，尝试 ensurepip 引导")
    try:
        run(py + ["-m", "ensurepip", "--upgrade"], "pip", timeout=300)
        run(py + ["-m", "pip", "--version"], "pip", timeout=120)
        return True
    except InstallError:
        log.get().warning("ensurepip 不可用，尝试 get-pip.py 兜底")
    if _bootstrap_getpip():
        try:
            run(py + ["-m", "pip", "--version"], "pip", timeout=120)
            return True
        except InstallError as ex:
            raise InstallError("pip", "get-pip.py 已执行但 pip 仍不可用", cmd=ex.cmd,
                               output=ex.output,
                               hint="尝试手动执行 get-pip.py，或重装 Python 并勾选 pip 组件。")
    raise InstallError("pip", "pip 不可用（ensurepip 与 get-pip.py 均失败）",
                       hint="请安装官方 Python（含 pip），或手动执行 get-pip.py；"
                            "Debian/Ubuntu 可执行 apt install python3-pip。")


def install_pip_deps(requirements=None, mirror="auto", upgrade_pip=True):
    """安装 requirements.txt 中的依赖，镜像失败自动轮转。

    frozen 打包版会把依赖装进 exe 同级的 libs/（--target），
    这样主程序通过 cfg.ensure_libs_path() 才能 import 到。
    """
    requirements = requirements or os.path.join(cfg.ROOT, "requirements.txt")
    if not os.path.isfile(requirements):
        raise InstallError("pip_deps", "找不到依赖清单: %s" % requirements,
                           hint="确认 requirements.txt 与主程序在同一目录。")
    py = python_exe()
    if not py:
        raise InstallError("pip_deps", "未找到可用的 Python 解释器",
                           hint="安装 Python 3.9+ 并加入 PATH，或设置 BTSRC_PYTHON。")
    ensure_pip()
    tgt = _pip_target_args()
    if tgt:
        os.makedirs(TARGET_DIR, exist_ok=True)

    if upgrade_pip and not tgt:
        # --target 模式下升级系统 pip 无意义，跳过
        _try_pip(py + ["-m", "pip", "install", "--upgrade",
                       "pip", "setuptools", "wheel"], mirror, stage="pip_upgrade")

    base = py + ["-m", "pip", "install", "-r", requirements,
                 "--disable-pip-version-check"] + tgt
    _try_pip(base, mirror, stage="pip_deps")
    return True


def _mirror_candidates(mirror):
    if mirror and mirror not in ("auto", None):
        for name, url in PIP_MIRRORS:
            if name == mirror:
                return [(name, url)]
        return [(mirror, mirror)]
    return PIP_MIRRORS


def _try_pip(base_cmd, mirror, stage):
    last = None
    # --target 模式（frozen 打包版）下追加 --user / --break-system-packages
    # 会与 --target 冲突（pip 直接报错），因此只保留纯净命令。
    target_mode = "--target" in base_cmd
    extras = [[]] if target_mode else ([], ["--break-system-packages"], ["--user"])
    for name, url in _mirror_candidates(mirror):
        cmd = base_cmd + ["-i", url, "--trusted-host", _host_of(url),
                          "--timeout", "30", "--retries", "2"]
        for extra in extras:
            try:
                log.get().info("pip 使用镜像: %s%s", name,
                               (" " + " ".join(extra)) if extra else "")
                run(cmd + extra, stage, timeout=1800)
                st = load_state()
                st["mirror"] = name
                save_state(st)
                return True
            except InstallError as ex:
                last = ex
                blob = ("%s %s" % (ex.message, ex.output)).lower()
                # 仅在遇到 PEP 668 externally-managed 时才升级参数重试
                if extra == [] and "externally-managed" in blob:
                    log.get().warning("检测到 PEP 668 限制，改用 --break-system-packages 重试")
                    continue
                if extra == ["--break-system-packages"] and "externally-managed" in blob:
                    continue
                log.get().warning("镜像 %s 失败: %s", name, ex.message)
                break
    raise InstallError(stage, "所有 pip 镜像均失败", cmd=last.cmd if last else "",
                       output=last.output if last else "",
                       hint="检查网络/代理；或离线下载 wheel 后 pip install --no-index "
                            "--find-links=<dir>。若为 SSL 错误，尝试 pip install "
                            "--trusted-host 并更新 certifi。Debian/Ubuntu 的 PEP 668 "
                            "限制可加 --break-system-packages 或使用虚拟环境。")


def _host_of(url):
    return url.split("//")[-1].split("/")[0]


def verify_imports():
    """逐个 import 关键依赖，返回缺失清单。"""
    cfg.ensure_libs_path()   # frozen 下依赖装在 libs/，先挂路径再验证
    importlib.invalidate_caches()
    mods = ["requests", "urllib3", "dns", "yaml", "tqdm", "colorama", "bs4", "lxml"]
    missing = []
    for m in mods:
        try:
            __import__(m)
        except Exception:
            missing.append(m)
    return missing


# ---------------------------------------------------------------- 阶段二：Go

def find_go():
    for exe in ("go", "go.exe"):
        p = shutil.which(exe)
        if p:
            return p
    for guess in (r"C:\Go\bin\go.exe", "/usr/local/go/bin/go",
                  os.path.expanduser("~/go/bin/go")):
        if os.path.isfile(guess):
            return guess
    return None


def ensure_go():
    """Go 工具链为可选项：存在即用，不存在则给出安装指引但不阻塞主流程。"""
    go = find_go()
    if go:
        out = run([go, "version"], "go", timeout=60)
        return go, out.strip()
    log.get().warning("未检测到 Go，跳过 Go 工具链（Python 内核仍可独立完成扫描）")
    return None, ""


def install_go_tools(go_bin, tools=None, mirror="auto"):
    """安装 Go 工具；单个工具失败不影响其他，返回成功/失败清单。"""
    if not go_bin:
        return [], []
    tools = tools or GO_TOOLS
    ok, failed = [], []
    for name, pkg in tools.items():
        if shutil.which(name):
            log.get().info("%s 已存在，跳过", name)
            ok.append(name)
            continue
        done = False
        for mname, murl in _go_mirror_candidates(mirror):
            try:
                run([go_bin, "install", pkg], "go_tools", timeout=1800,
                    env={"GOPROXY": murl, "GO111MODULE": "on",
                         "GOSUMDB": "off", "CGO_ENABLED": "0"})
                ok.append(name)
                st = load_state()
                if name not in st.get("tools_done", []):
                    st.setdefault("tools_done", []).append(name)
                save_state(st)
                done = True
                break
            except InstallError as ex:
                log.get().warning("%s 经 %s 安装失败: %s", name, mname, ex.message)
        if not done:
            failed.append(name)
    return ok, failed


def _go_mirror_candidates(mirror):
    if mirror and mirror not in ("auto", None):
        for name, url in GO_MIRRORS:
            if name == mirror:
                return [(name, url)]
    return GO_MIRRORS


# ---------------------------------------------------------------- 总入口

def install_all(requirements=None, mirror="auto", with_go=True):
    """完整安装流程；返回结构化结果，失败抛 InstallError 由上层重试。"""
    cfg.ensure_dirs()
    state = load_state()
    result = {"python": "", "pip": False, "missing": [], "go": "", "go_ok": [],
              "go_failed": [], "mirror": mirror, "elapsed": 0}

    t0 = time.time()
    result["python"] = check_python()

    if not state.get("pip_done"):
        install_pip_deps(requirements, mirror)
        state["pip_done"] = True
        save_state(state)
    else:
        log.get().info("pip 依赖此前已安装，跳过（doctor 会复核）")

    missing = verify_imports()
    if missing:
        log.get().warning("依赖复核仍缺失: %s，重新安装", ", ".join(missing))
        install_pip_deps(requirements, mirror)
        missing = verify_imports()
    result["missing"] = missing
    result["pip"] = not missing

    if with_go:
        go_bin, ver = ensure_go()
        result["go"] = ver
        if go_bin:
            ok, failed = install_go_tools(go_bin, mirror=mirror)
            result["go_ok"], result["go_failed"] = ok, failed

    result["elapsed"] = round(time.time() - t0, 1)
    log.audit("install_done", python=result["python"], pip_ok=result["pip"],
              go=result["go"], go_ok=result["go_ok"], go_failed=result["go_failed"],
              elapsed=result["elapsed"])
    return result
