# 交接文档 round91 —— A / B / C / D 四段（AI 日志 / 写配置装包 / 真实实扫 / 清理回归）

## 一、本轮任务定义（用户原口）
> 做完这些，就直接重打包就行了。

四段一次交付：

| 段 | 内容 | 状态 |
|---|---|---|
| A | AI 输出日志与报告放同一个文件夹 | 已闭环 |
| B | 写配置、装 SKILL 工具、装 MCP 插件 | 7/7 完成 |
| C | 真打实扫一个目标，验证 AI 真跑通 | 代码已修，二次实扫被 401 阻断 |
| D | 清理垃圾 + 回归归零 + 文档 | 归零完成 |

## 二、A 段：AI 日志进报告目录
- 实现：`core/report.py:export_ai_log(report_dir, target, since_ts, until_ts, log_dir)`，落 `reports/<target>-<ts>/ai_log.txt`。
- 筛选口径：**只看 logger 名前缀**（`bt.agent` / `bt.ai` / `bt.skill` / `bt.mcp`），绝不做正文关键词匹配 —— 目标域名含 `ai` 三字母会误伤；续行（traceback / 多行响应）跟随上一行判定。
- 时间边界：**扫描启动 `t0` 到 `scan_ended_at`**，不是 `new_report_dir()` —— 目录建立往往晚于 t0，以目录为起点会漏掉启动到建目录之间的 AI 行。
- **空则不建文件**：没有任何 AI 行时返回 None。空文件会被误当成「AI 没跑」的证据，比没有文件更容易误导。
- 验收：`lab/verify_round91_ailog.py` **PASS=46 FAIL=0**；真机 `reports/mendunerhr.com-20261021-114513-15423-1/ai_log.txt` **22010 字节 / 152 行**。

## 三、B 段：写配置 / 装 SKILL / 装 MCP
- `config/config.json` 的 `ai` 段写入真实端点与模型；**密钥绝不进 config.json**（round74 G4 断言仍绿），只落 `data/ai_key.txt`（`chmod 600`）。
- `api_key_env` 仍为 `BTSRHUNTER_AI_KEY`，**环境变量优先于文件**；当前环境变量为空（`ENV_LEN=0`），因此走文件通道。
- `mcp/` 现只余 `src_elite_mcp`；`skills/` 现为 `mega-offensive-suite-v5_6` + `字典工程师增强.md` + `验证工程师增强.md`。

## 四、C 段：真打实扫 mendunerhr.com
### 4.1 首轮数据（修复前）
`EXIT=0`、2 存活 / 2 主机 / 2 条漏洞 / **1598 请求** / **633.2s**；AI 跑 7 轮、23 次工具调用、0 漏洞结论。

### 4.2 第 7 轮 33 秒后中止的真因（已定调）
- 取证：用 grep 搜扫扫描日志中 `401` / `Invalid token` / `timeout` / `timed out` / `502` / `503` —— **零命中**，证明扫描当时端点**正常**。
- 日志原文：`[11:41:14] 第 7/8 轮` → `[AI] 第 7 轮：模型请求 153 个工具调用` → `调用 mcp_verify_poc 参数：{}` → `失败：missing_arg` → 连续 3 条 `bad_arguments` → `[11:41:47] [中止] 模型未返回可用响应`。
- 33 秒 = 一次请求超时量级；结论：**149 个空名 / null 调用作为非法 `assistant.tool_calls` 回喂后被服务端拒绝或挂起**。
- **重要**：扫描之后才出现的 401 是**独立事件**，不能用来解释当时那 33 秒。

### 4.3 FIX-21（`tools/ai_client.py:_sse_collect`）
- 旧写法：`idx = tc.get("index"); if idx is None: idx = len(calls)` —— **一次响应能造出 149 个 `{"name":"","arguments":""}` 空壳**。
- 新写法：**index 优先** —— `if idx is not None: key = ("idx", idx)`；无 index 时依次：按 `id` 反查已有槽 → `len(calls) == 1` 时直接复用唯一槽 → 再按 `tid` 建槽 → 最后才落最后一个槽或 `("idx", 0)`。
- 返回前统一过滤：`function.name` 为空的槽直接 `continue`。
- **为什么不按 id 优先**：SSE 协议里 index 是稳定槽号，同一条调用的后续分片**通常只带 index 不带 id**；按 id 优先会把后续分片拆到新槽、参数拼不起来。这条是断言 A5 抓出来的**真回归**，注释已写明。

### 4.4 FIX-22（`tools/agent_loop.py:run_agent`）
- 在 `messages.append` 之前插入：`per_cap = max(1, per_round)` → 遍历 `calls` 丢弃空名 → `exec_batch = _valid[:per_cap]` → 累加 `_drop` → `if _drop:` 打两行留痕。
- `messages.append({... "tool_calls": exec_batch})` 与 `for call in exec_batch:` 两处同步切到 `exec_batch`，保证 `assistant.tool_calls`、实际执行、后续 `role=tool` 三者**一一对应**。
- **语义不变**：`max_calls_per_round` 仍是硬上限，`bad_arguments` / `missing_arg` 仍如实留痕，只是不再把未执行的调用塞回上下文。
- 验收：`lab/verify_round91_fix21_22.py`（170 行 / **22 条断言**）→ **PASS=22 FAIL=0**。

### 4.5 外部环境阻断（非代码问题）
- 端点 旧端点（开发期自建，已作废） 现返回 `HTTP 401` + `Invalid token (request id: ...)`，`/v1/chat/completions` 与 `/v1/models` **同时 401**。
- 已排除可能：密钥文件在、**51 字节**、值正确、权限 `600`、环境变量为空；`A.chat_step()` 返回 `None`；`curl` 直打同样 401。
- 结论：**服务端令牌被吊销或过期**。二次实扫与任何联网 AI 断言因此不可执行，需**重新签发 token**。
- **round92 更新**：AI 端点改为用户自建端点（端点地址与模型名由开发者本地配置，不进包；key 存 `data/ai_key.txt`、`chmod 600`），`/v1/models` 实测可用。**交付包不携带任何端点、模型名与 key**。

### 4.6 AI 越权写出 6 条假洞（round92 事故与修复，最重要）
**现象**：`reports/mendunerhr.com-20261021-163032-7012-1/` 共有 7 条，其中 6 条 URL 全是 `http://127.0.0.1:8081/proxy`、`/proxy-post`、`/search`、`/redirect`、`/search-post`、`/redirect-post`，只有第 7 条 `https://www.mendunerhr.com/index.6cavyuxF.js` 属真实目标。**即：报告里的「漏洞」绝大部分是本机靶场的洞，被记到了客户域名名下。**

**AI 当时的思考原文**（有存档）：「The user wants me to scan the target mendunerhr.com, plus rescan 4 local interfaces (127.0.0.1:8081, 8126).」—— 说明 AI 不是幻觉，是**照着一份污染的任务队列在干活**。

**因果链四环（缺一不成立）**：
1. `data/hunt_queue.jsonl` 残留 4 条历史扫本机靶场的行（`127.0.0.1:8081/?q=bt` 等），是上一轮调靶场时写进去的；
2. `hunt_consumer.pick()` 只按 target 做指纹去重、**不校验 URL 归属**，把这 4 条当「难例回流」交给 AI；
3. `mcp/src_elite_mcp/server.py:381 tool_scope_check` 在 `in_scope` 为空时按「空 scope：放行（本地靶场模式）」返回 `allowed: True`；
4. AI 照单打本机靶场（靶场**确实有洞**），`engine._persist` 原样落库，报告生成器也不校验归属。

**修法（两道门禁 + 一个原则）**：
- **FIX-30**（进 AI 之前）：`hunt_consumer.pick()` 逐条校验归属，目标外一律 `_dropped.append(url); continue`，返回前 warning 留痕「丢弃 n 条目标外 URL」。辅以 `_host_only` / `_is_local` / `in_target_scope` 三个小工具函数。
- **FIX-31**（落库之前）：`engine._persist` 前新增模块级 `_in_scope_for_persist(url, target)`，与 FIX-30 同口径但**独立实现**（不 import hunt_consumer，避免循环依赖）；`_hp()` 给裸域名补 `//`，修掉 `_host_of` 对无 scheme 目标一律判「不在范围内」的误判。AI 回写循环改 `_n_out` 计数 + 拦截 + 告警「丢弃 n 条目标外漏洞项」。
- **原则**：**宁可丢、不可污**。两道门禁分别堵「进」和「出」，任一道单独也能拦住本次事故的 6 条假洞。

**修后复验**：`reports/mendunerhr.com-20261021-164354-758-1/`，存活 2/2、漏洞 2 条、用时 456.44s、累计请求 845；`findings.json` 里 `127.0.0.1` 出现 **0 次**、`难例回流` **0 次**。

**留给人接手的一句判断**：AI 确实是能出洞的（这也是要它的理由），所以真正的风险不是「AI 不出洞」，而是「**AI 出了不属于本次目标的洞**」。今后任何绕过 `hunt_consumer` / `engine._persist` 的新落库路径，都必须自己再过一遍 `_in_scope_for_persist`。


## 五、D 段：清理 + 回归 + 文档
### 5.1 清理
- 删除 `mcp/r66mcp2` / `mcp/r66mcp3`（各 20K，内容 `one.json` / `server.py`(8B) / `skip.txt` / `two.json`，`takeover.mcp.servers` 零引用）。
- 复验：grep 扫 `r6[0-9]|test|demo|z[0-9]` 返回 `NO_TEST_RESIDUE`。

### 5.2 【严重事故，已抢救，必须记成红线】回归脚本删掉生产密钥
- `lab/verify_round74.py` 有 **9 处** `cfg.write_ai_key_file(...)`，其中 `_cleanup()` 与文末各一处 `write_ai_key_file("")`。
- 注释还写着「回归期间 `data/ai_key.txt` 若残留，B4 与 round50 P5 都会翻红」 —— 它**知道**自己在写真实文件，却选了「用完清掉」而不是「隔离起来」。
- 在密钥长期为空的历史阶段这条清理无害；本轮 B 段一写入真 key，它就变成 **回归脚本删除生产密钥**。
- 发现方式：`wc -c data/ai_key.txt` 返回 `No such file or directory`。
- 恢复：`printf '%s' '<原值>' > data/ai_key.txt && chmod 600 data/ai_key.txt`，回读 `key_len 51 head sk-MyRKv` 通过。
- **定性**：历史遗留的越界写入缺陷，**不是本轮 FIX 引入的**。
- **处置**：6 个涉写用例全部改为 `/tmp` 沙箱 —— 在模块 docstring 之后注入 `BTSRHUNTER_USER_DIR=/tmp/btsr91_<脚本名>`（`core/config.py:_user_root()` 第 142–144 行的**官方入口**，优先于 frozen 判断）。
- **复验（硬证据）**：round74 跑完后 `data/ai_key.txt` 仍是 **51 字节**、`md5sum -c` **OK**；`/tmp/btsr91_verify_round74/` 已生成，证明沙箱真的生效、真实目录零触碰。
- **红线升级（永久）**：回归脚本**永久禁止**对 `USER_ROOT/data`、`USER_ROOT/config` 做写或删；测试数据一律走 `/tmp`；回归结束必须检查这几处有无残留。

### 5.3 回归归零（8 个红脚本，三类根因）
首轮 `bash lab/regall.sh`：`REGALL TOTAL PASS=3989 FAIL=30 SCRIPTS_FAILED=8`（基线 `PASS=4018 FAIL=0 SCRIPTS_FAILED=1`）。

**类一：测试桩签名过时（round59 / 75 / 79）**
- 现象：所有失败项都是「计数为 0」，即 `run_agent` 根本没进到 `chat_step`。
- 真因：**FIX-19** 给 `chat_step` 加了 `max_tokens` 参数，mock 还是旧签名，`TypeError` 被 `except Exception: break` 吞掉。
- 定论方式：`/tmp/r91/probe_r59.py` 做 A/B 对照 → `[旧签名(无max_tokens)] chat_step_calls=0` / `[新签名(有max_tokens)] chat_step_calls=2`。
- 修法：桩签名改为 `(messages, tools=None, timeout=None, max_tokens=None, **kw)`。结果：round59 `63/63`、round75 `150/150`、round79 `70/70`。

**类二：断言本身过时（round50 的「仅四键」）**
- 因 FIX-19 加 `max_tokens`、双通道又加 `stream`，「仅四键」已不成立。
- 改为语义断言：「不含 `tools` / `tool_choice` 且至少含 `messages` / `model` / `temperature`」。

**类三：「出厂默认配置」类断言与 B 段写入真实端点冲突（round38/47/48/49/50/74）**
- 旧写法读的是**本机 `config/config.json`**，B 段一写入真实端点就必红。
- 关键判断：这些断言的**原意是「产品出厂默认不带 AI 与端点」**，**不是「这台机器上的配置有没有被用户填过」** —— 前者是产品红线，后者是用户态，不能当回归红。
- 修法：改读 `core.config.DEFAULT_CONFIG`（源码硬编码出厂值），并加一条「磁盘即使贴了端点也不影响出厂模板」的隔离断言。
- 结果：round38 `50`、round47 `45`、round48 `21`、round49 `48`、round50 `28`、round74 `77`，**全部 FAIL=0**。

**预期红（不是缺陷）**：`lab/check_exe_r82.py` 报 `TOTAL PASS=171 FAIL=4 / BAD=4`。因本轮四处改动尚未重打包，EXE 内文件与源码不一致。重打包后应回 `BAD=0`。

## 六、当前状态与挂起项
- **代码层**：全部闭环（A/B/D 验收完成，C 代码已修 + 22 条断言全绿）。
- **二次实扫**：阻断在端点 401（外部），需重签 token。本轮再次复现：`curl /v1/models` 返回 `HTTP=401 Invalid token`。
- **重打包 7 步（已全部完成）**：①源码 zip 重建 → ②EXE 重建 → ③EXE 全量解包核验 `/tmp/verify82` 并复跑 `check_exe_r82` 至 `BAD=0` → ④zip 二次重建 → ⑤刷新 `dist-win/MD5SUMS.txt` → ⑥同步 EXE 到 `/sdcard/AI文件/` → ⑦清理 `/tmp/verify82`、`lab/__pycache__`。
- **打包结果（round92 最终交付）**：`CardinalSRCHunter.exe` 约 20.9MB 量级，**字节数 / md5 / 文件数一律以 `dist-win/MD5SUMS.txt` 为准，本文件不写死任何数字**；`check_exe_r82` **BAD=0 / TOTAL PASS=175 FAIL=0**（打包后实测）；`/sdcard/AI文件/CardinalSRCHunter.exe` 与 `dist-win/` 同名文件 md5 双向比对一致。核验方式：`cat dist-win/MD5SUMS.txt` + `md5sum dist-win/CardinalSRCHunter.exe /sdcard/AI文件/CardinalSRCHunter.exe`。
- **AI 端点现状（round92 变更）**：旧端点 旧端点（开发期自建，已作废） + 旧 key（`401 Invalid token`）已作废；现用自建端点 + 自签 key（`chmod 600`，`data/ai_key.txt`），`/v1/models` 实测可用。**不要再回滚旧端点**。注意：**key 字节数会随签发的 token 长度变化，不要写死**，用 `wc -c data/ai_key.txt` 现场取。
- **打包器口径（两个打包器已对齐）**：`build/make_src_zip.py` 用 `EXC_SKILL_SUB`，`build/make_sfx_exe.py` 用 FIX-29 单独分支；两边都只发 `skills/` 根下 `*.md`，子目录（自装技能包 `mega-offensive-suite-v5_6`，1220 文件 / 约 92MB）不进包。
- **`lab/check_exe_r82.py` 基线**：源码改完未重打包前必然红（`BAD=n`，且只能是 `FILES` 清单里改过的那几个文件 DIFF），重打包后回 `BAD=0`。

## 七、FIX 清单追加（round91）
| 编号 | 内容 |
|---|---|
| **FIX-21** | **`_sse_collect` index 优先归并 + 空名槽位过滤** |
| **FIX-22** | **`run_agent` 只回喂 `exec_batch` + 丢弃留痕** |
| **FIX-23** | **回归脚本 `USER_ROOT` 沙箱化（`BTSRHUNTER_USER_DIR=/tmp/...`）+ 出厂值断言改查 `DEFAULT_CONFIG`** |
| **FIX-24** | **`make_src_zip.py` 加 `EXC_SKILL_SUB` 排除 `skills/` 子目录，`round49` 加 O10b 源码守卫** |
| **FIX-25** | **MCP 卸载连物理目录一起删**（`ui/web.py` remove 分支 + `rmtree`，防“删了又长”）；`round66` 加 **B20b** 断言 + `round49` 加 **O10c** 守卫 |
| **FIX-26** | **`skills/` 沙箱化**：`tools/skill_loader.py` 加 `BTSRHUNTER_SKILLS_DIR` 环境变量；`verify_round66/70` 改为「`USER_DIR` + `SKILLS_DIR` 双重重定向」且只复制顶层 `*.md`，`restore()` 不再 `rmtree` 真实 `skills/`；`round49` 加 **O10d** 守卫 |
| **FIX-27** | **`/api/skill/list` 性能**：`_iter_skill_files` 直接跳过 `references/`、`assets/` 等资料目录（顺带修正 `references/INDEX.md` 被当成技能入口）；`_known_tool_names()` 加以注册表对象为键的缓存（不影响 round80 B5 不误报）；`round49` 加 **O10e** 守卫 |
| **FIX-28** | **`verify_round75.py` 重建沙箱**：该脚本第 303 行有 `cfg.write_ai_key_file(chr(39)+chr(39))`，`ai_key_path()` 落在 `DATA_DIR`，不隔离就会直接清空真实 `data/ai_key.txt`（本轮已真实发生，已用原值恢复）；现已补 `BTSRHUNTER_USER_DIR` 前置块 |
| **FIX-29** | **EXE 打包器也只发技能根下手册**：`build/make_sfx_exe.py:copy_app()` 重建 payload 时把 `skills/mega-offensive-suite-v5_6`（1220 文件 / 约 92MB）整个拷进包，EXE 从 21.9MB 胀到 **39.9MB**；现与 `EXC_SKILL_SUB` 口径对齐，只拷 `skills/` 根下 `*.md`，体积回到 **20.9MB**；`round49` 加 **O10f** 守卫 |
| **FIX-30** | **`hunt_consumer.pick()` 加回流作用域门禁**：队列里残留历史扫本机靶场的旧行（`127.0.0.1:8081/?q=bt` 等 4 条）会被「难例回流」当成本次目标交给 AI；新增 `_host_only` / `_is_local` / `in_target_scope`，`pick()` 逐条校验归属，目标外一律 `_dropped.append(url); continue`，返回前 warning 留痕「丢弃 n 条目标外 URL」 |
| **FIX-31** | **`engine._persist` 前加最后一道作用域门禁**：新增模块级 `_in_scope_for_persist(url, target)`（与 FIX-30 同口径但**独立实现**避免循环依赖，`_hp()` 给裸域名补 `//` 以修复 `_host_of` 对无 scheme 目标一律误判为不放行），AI 回写循环改为 `_n_out` 计数 + 拦截 + 告警「丢弃 n 条目标外漏洞项」。**宁可丢、不可污** |
| **FIX-32** | **round42 强制离线**：E4/E6 断言的是确定性特征表首项/余项，但 `tools/hunt_assist._ai_trigger()` 在 `ai_ready()` 为真时会用模型结果覆盖 payload/alternatives；旧 key 失效时该路径不触发故一直绿，换签后暴露。修法由 `lab/_offline_guard.py` 统一承担（见 FIX-34），`_r42_offline.py` 已删除 |
| **FIX-33** | **`knowledge_learn.py` 的 `_meta.ai` 溯源块排序化**：`:598` 把模型返回的原始顺序直接写进 `subdomain_words` / `dir_words` / `creds`，而模型每次输出顺序不同，导致 round40 D1「同输入两次跑逐字节一致」随机变红（`DIFF_AT 57`，`creds` 顺序 `redis2024,redis2025,…` vs `redis2024,redis@123,…`）。修法：三词表统一 `sorted({str(x) for x in (v or []) if str(x).strip()})` 后再写；`_merge_ai_dicts` 的正文顺序契约不动 |
| **FIX-34** | **回归离线护栏统一到 `lab/_offline_guard.py`**：① `force_offline()` 把 `Config.ai_ready` 钉成恒 False（进程内）；② `env_offline(env)` 给 `subprocess` 拉起的独立解释器写 `BTSRHUNTER_AI_ENABLED=0` / `BTSRHUNTER_AI_ONLINE=0`（只有进程内钉死不够，`tools/*_learn.py` 是被 subprocess 起的）；③ `spy_fail_on_network()` 作 socket 兜底。已接 round37 / round40 / round42，新增 `lab/verify_round92_fix34.py`（**PASS=21**）锁住三入口与「两次跑逐字节一致」行为实证 |
| **FIX-34c** | **`regall.sh` 跑批前自清环境**：`unset BTSRHUNTER_USER_DIR / BTSRHUNTER_SKILLS_DIR / BTSRHUNTER_KEYFILE` —— 本轮真实踩坑：手工 `export BTSRHUNTER_SKILLS_DIR=/tmp/...` 残留进终端会话后跑全量，技能目录指到空 sandbox，round49/88/36/37 集体变红（技能列表 n=0）。**注意不得在此全局设 `AI_ENABLED=0`**：round38 R3/I3 恰恰要验证「双开 -> ai_ready True」。另：**跑批期间不得编辑 `regall.sh` 本身**（bash 逐行读脚本，改到一半会 `unexpected EOF` 中断，本轮 `regall6` 即此原因） |
| **FIX-35** | **AI 接管通道污染回归脚本（round92 根因）**：`Config.__init__` 必调 `load()`，本机 `config/config.json` 的 `takeover.enabled=true`，于是任何直接 `Config()` + `Engine.run()` 的 `verify_*.py` 都会真的联网跑 AI 接管，断言变非确定性。事故表现：`regall8` 唯一红是 `verify_round9.py` 的 `C body_keys 不含 submit 字段 go`——AI 把靶机表单的 submit 按钮 （`<input type="submit" name="go" value="search">`）当业务字段抄进 `check_xss` 的 body，`_persist` 记成 `body_keys=['go','q']`。**不是产品缺陷**（浏览器真会提交 `go`），缺陷是「测试耦合了真实端点」。`lab/_offline_guard.py` 新增 `force_no_takeover(cfg)`（关单副本，内存）与 `force_no_takeover_all()`（钉 `Config.takeover`，全局幂等）；`verify_round9.py` 接入后 `PASS=68 FAIL=0` 由 `67/1` 转绿；另 13 个 Engine 级脚本批量接入后全部复跑绿（新增 519 条确定性断言回离线）；`verify_round75.py` 另补 `force_offline() + force_no_takeover_all()` |
| **FIX-36** | **AI 装配三开关从「认知正确」落到「实际生效」**：`config.py` 中 `takeover.allow_active` / `takeover.allow_poc` / `scan.mode` 档位原先是「OR 兜底」口径（任一路为真即放行），与用户拍板的 **AND** 语义相反，导致 `scan.mode=1`（保守档）时 `allow_poc` 仍能单独放行 PoC 执行分支。修法：`takeover_allow_active()` / `takeover_allow_poc()` 统一改为 **AND**（`takeover.enabled` ∧ `allow_active/allow_poc` ∧ `scan.mode` 档位三者同时为真），默认值统一 `True`；GUI 侧 `_tk_allow` 的读取顺序固定为 `engine.config.takeover()` → `engine.config.get("takeover")` → `True`，**任何异常一律吞成 `True`**——红线原文「本模块绝不因自身异常而阻断 AI，真正的安全边界在 scope 授权与档位闸门」。验证：新增 `lab/verify_round93_fix36.py`；本机 `config/config.json` 两键按用户选定的 B 方案置为 `true` |
| **FIX-37** | **桌面「调参」从「形式按钮」升级为可用功能（合并写入 + 无样本不落盘）**：`core/tuning.py` 原 `apply_from_stats()` 是无调用者的死代码，唯一实现路径 `cli()` 用**覆盖写入**，且 `stats_empty` 时也照样落盘——在 `verifications` 为空的本机真实库上点一次就 `tuning.json` 从 `{dirlist:4, ssrf:3}` 被清成 `{}`（**丢数据**）。修法三件：① 新增 `_load_raw()` + `merge_tuning(prev, target, detail, min_samples)`，规则四条 —— 样本不足的 kind **保持**已有值 / 样本足够且目标 > `BASE_THRESHOLD` 则覆盖（`tighten`）/ 样本足够且目标 == base 则**删除**回到默认（`reset`，保留原自愈语义）/ 本次统计里没出现的 kind **原样保留**（绝不因「没提到」而清掉）；② `apply_from_stats()` 加 `if report["stats_empty"]: return report` 守卫，**无样本一个字节都不动盘**，并返回结构化 report（`thresholds/detail/decisions/changed/written/dry_run/samples/stats_empty/unmapped/path` 等）；③ 新增 `format_report()` 把人话结论打出来，`cli()` 全程走 `apply_from_stats + format_report`，返回码按「有写入 / 无样本或 dry-run / 写失败」区分。`compute_tuning(stats, min_samples)` 另加 `unmapped` / `sample_enough` 字段，让「无法映射到 kind 的 vuln_type」单独可见而不再无声消失。GUI 侧新增独立「调参」控件区（勾选「只试算不写盘」/「只统计目标框里的目标」+ 「立即调参」/「恢复默认阈值」两按钮 + 生效阈值只读回显行），`do_tune(reset=False)` 重写并新增 `_refresh_tune_stat()` / `_tune_target()`，开窗即回显。验证：新增 `lab/verify_round93_tuning.py`（280 行 / **PASS=41 FAIL=0**，A–H 八组），并在真实工程路径复验——`verifications=0` 情况下 `tuning.json` 的 md5 前后一致 `2c8a82a46ff9cadb525d632dbf2080be`、`{dirlist:2, ssrf:2, unauth:2}` 三阈值全部保住；两脚本均已挂进 `lab/regall.sh` |
| **FIX-38** | **删掉顶部重复的「调参」按钮（round94，界面精简）**：`ui/gui.py` 原顶部 bar 上的 `ttk.Button(bar, text="调参", command=do_tune)` 与后加的「调参」控件区重复，且能力是它的**真子集** （无法 dry-run、不能限目标、没有恢复默认、不回显生效阈值），旧点击等价于「下方什么都不勾直接点立即调参」。已删除该按钮并改写上方注释说明「唯一入口是 tune_box 的立即调参 / 恢复默认阈值」。删除后 `do_tune` 仅存 3 处：定义 1 处 + `command=lambda: do_tune()` + `command=lambda: do_tune(reset=True)`。为避免回潮，新增 G9（`'text="调参", command=do_tune' not in 源码`）与 G9b（`do_tune` 计数恒为 3）两条断言锁死；另用 `ast.walk` 做结构级自检：12 个 `ttk.Button` 文本无重名、11 个 `command` 全部可解析（无悬空引用）。验证：改名后的 `lab/verify_round94_tuning.py` 单跑全绿，`regall` 全量回归无 `FAIL` 行，重打包后解包复核 EXE 内 `app/ui/gui.py` 与工作区逐字节一致、旧按钮串计数为 0 |

| **FIX-39** | **交付包里不得夹带测试数据 / 测试工具（round95，交付红线级）**：用户实测装上 EXE 后看到两处不该出现的东西 —— Web 控制台「端点/API」页预填了开发用端点与模型名，MCP 页直接显示 `src_elite_mcp` 已启用·待探活（并附截图）。根因：`build/make_src_zip.py` 与 `build/make_sfx_exe.py` 只做**目录/文件名级**排除（`mcp/` 整个目录、`skills/` 子目录），但 `config/config.json` 是**整文件原样拷进包**的，而那是开发机真实在用的配置，里面带着开发端点、模型名与开发期 MCP 插件声明，于是随包发给了用户。修法：新增 `build/sanitize.py` 作为**唯一净化口径**（以 `core/config.py` 的 `DEFAULT_CONFIG` 为基准，不再另写一份默认值），提供 `factory_config()` / `factory_config_text()` / `assert_clean()`；两个打包器写包前都用 `factory_config_text()` 覆盖包内 `config/config.json`（zip 侧走 `writestr` 替换、EXE 侧在 `copytree` 之后覆写），并各自加入打包期硬自检：zip 侧输出 `CFG_DIRTY bad=0`、EXE 侧输出 `[chk] config/config.json 出厂净化版校验通过`，不满足即 `return 1/2` 失败退出。净化口径：`ai.enabled=False` / `ai.online=False` / `ai.api_base=""` / `ai.model=""` / `takeover.mcp.servers=[]` / `target.domains|ips|cidrs=[]` / `ui.targets=""`，并剔除 `api_key` 字段。同时新增 `lab/verify_round95_fix39.py`（43 断言，已接入 `lab/regall.sh`）锁住四件事：出厂版本身干净、`assert_clean` 能检出脏配置（负向对照，防「永远返回干净」）、净化器不落盘不改工作区真实配置、两个打包器确实接入了净化（含 `import io` 这类运行时才会炸的前置检查）。同轮还堵了两个同类缺口（都属于「夹带测试工具」）：(a) 源码 zip 原先**整目录带上 `lab/`**（126 文件 / 1.16MB，全是 `verify_` / `t_` / `check_` 回归脚本）与 `build/`（打包器自身），而 EXE 侧 `skip_dirs` 早已排除这两个目录 —— 两侧口径分叉，用户解包就看到一堆测试脚本与靶场域名案例。现统一为同一集合：`EXC_DIRS` 增加 `lab` 与 `build`，zip 文件数由 225 降到 93。(b) `nohup.out`（后台跑扫描时 nohup 生成的空文件）四条旧规则全拦不到，实测进了包；zip 侧新增 `EXC_FILES`、EXE 侧并入 `skip_files`，两侧口径一致。另外 `项目总结报告.md` 里写着开发用端点与模型名以及本机密钥路径，已改写为「可配置的自建端点，不随包发布」，报告内两类开发期特征串命中数均为 0。**纪律**：净化只作用于包内副本，工作区 `config/config.json` 一律不动，用户本机配置不受影响 |
| **FIX-40** | **源码包内不得残留开发期端点 / 模型名 / 插件名（round95 同轮补强）**：FIX-39 只堵了 `config/config.json` 与 `lab/`、`build/`，但整包特征串扫描发现**文档与产品注释**里仍明文写着开发期自建端点、旧开发端点、开发模型名与开发期 MCP 插件名（开发端点域名、旧开发端点域名、开发模型名、开发期 MCP 插件名各一类）。修法：统一改写为抽象描述——“可配置的自建端点”“开发期模型”“旧开发端点已作废”，涉及 `交接文档_round91.md` 3 处、`进度.md` 3 处、`tools/agent_loop.py:346` 1 处、`tools/ai_client.py:136` 1 处；同时新增 `lab/verify_round95_fix39.py` H 组 8 条断言锁住：H1–H3 三类开发期特征串在包内所有 `.json/.py/.md/.sh/.bat/.txt` 中出现次数必须为 0，H4–H7 包内无 `lab/`、`build/`、`nohup*`、`.bak/.corrupt`，H8 包内 `skills/` 下无靶场字典。断言总数 43 → 59，全绿（`ROUND95_FIX39 PASS=59 FAIL=0`）。**产品代码体（`main.py`/`core`/`modules`/`ui`/`templates`/`bootstrap`/`tools`）三类开发期特征串命中数实测均为 0**；保留的靶场域名仅存于注释里的历史因果说明（`core/engine.py:77`、`core/verify.py:1189`、`modules/vulnchecks.py:1311`、`modules/template_engine.py:444`）与 `skills/` 字典，不属于端点泄露。|
| **FIX-41** | **round96 全量改名：旧名 -> Cardinal（从里到外）**：① 桌面标题改为 `Cardinal-SRC-Hunter · 自动挖洞套件 v1.0`（删尾部 Cardinal、前缀 BT 换 Cardinal）；② 产品/产物名由旧 exe 名（BT 前缀 + Setup 后缀）-> `CardinalSRCHunter`，覆盖打包器（`make_sfx_exe.py` 的 NAME 与 BAT 模板 DEST）、`make_src_zip.py`、`build_exe.py`/`build_exe.bat`/`start.bat`、`ui/cli.py` 的 prog、`ui/web.py` 的 title/h1/server_version/app 协议常量（**成对同步**，否则同实例探测失效）、`main.py` 与 `README.md`，以及全部交接文档/进度/总结/MD5SUMS；③ **内部无横杠名连带改名**（`core/config.py` 的 `install_dir` 与 `_user_root` 落点、`tools/skill_loader.py`、`tools/skill_exec.py` 复刻的落点、注释）；④ **新增 `_migrate_legacy_root()`**：首次以新名启动时，若新目录不存在且旧目录存在，整体 `rename`（失败则 `copytree`）承接旧安装的用户数据（config.json / ai_key.txt / findings.db / skills），**避免改名=升级即丢配置**；迁移失败一律静默放行，绝不阻断启动；⑤ 同步修正被改名打断的 6 处脚本锚点：`verify_round75` A22/A23、`check_exe_r82` gui 标题两项、`verify_round77` A7、`verify_round95` 相关、`verify_fixes` 的 dist 比对改为读解包目录 `/tmp/verify82/app`；⑥ 清掉 `dist-win/` 里手工改名残留（尾部多一连字符的文件），交付三件恢复整洁。|
## 八、接手指引
1. 先读本文与 `进度.md` 末尾的 round91 章。
2. 先确认密钥与端点状态：`wc -c data/ai_key.txt`（非 0 即可，不写死长度）+ `curl` 打 `/v1/models`。若 401，先找用户重签 token，**不要改代码**。
3. 回归：`bash lab/regall.sh`，目标 `FAIL=0 SCRIPTS_FAILED=0`（源码与 EXE 一致时）。若源码已改但未重打包，`check_exe_r82` 会红且**只允许它红**，重打包后必须归零。
4. 改任何 `lab/` 下的脚本前，先确认它没有向 `USER_ROOT` 写真实数据的动作；有则先沙箱化（`BTSRHUNTER_USER_DIR=/tmp/...`）。
5. 重打包不许跳步：先改源码 → 再打 zip → 再打 EXE → 最后刷 MD5。
6. 文档红线：**绝不写死行数 / md5**，统一写「与源码逐字节一致（`diff -q` + md5 双证）」。
7. 测试沙箱名单（`BTSRHUNTER_USER_DIR` 前置块）：`verify_round38/47/48/49/50/66/74/75.py`；其中 `verify_round66/70.py` 还需**额外**设 `BTSRHUNTER_SKILLS_DIR`（它们旧版会 `rmtree` 真实 `skills/` 再从快照复制，快照落在空档就永久丢技能）。「只要 `grep -l 'write_ai_key_file' lab/*.py` 命中，必须逐个核对是否已有沙箱前置块，不能靠「上次补过一批」推断」。新增脚本一律照此处理，**不允许再出现向真实 `USER_ROOT​/config`、`USER_ROOT/data`、`cwd/skills`、`cwd/mcp` 写入的用例**。
