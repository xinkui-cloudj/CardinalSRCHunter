# -*- coding: utf-8 -*-
"""tools/dict_gen.py —— 离线字典生成器（阶段 3-4 产字典 / 阶段 3-5 扩解析候选）。

定位
----
读**已抓到的资产特征**（指纹 / 标题 / server / URL 路径），离线归纳出
「针对性」子域词、目录词、口令候选；并读「解析没命中的主机名」，离线推理
常见变形候选。两者都只落盘为草稿（DRAFT_SUFFIX 结尾），**人审改名后**才可被
``load_dicts()`` / ``load_hosts()`` 读到。

数据流（单向，永不回流）
------------------------
  data/findings.db[assets]  --只读-->  dict_gen  --写-->  data/dicts_ai.json[SUF]
                                                   --写-->  data/hosts_ai.json[SUF]
                                                            |
                          人工审核（去掉草稿后缀）           v
                             core.dicts 契约（is_draft / loadable / live_path）

红线遵守
--------
1. 本工具**永不进扫描热路径**：不 import engine / report / verify / modules。
2. 产物一律以 DRAFT_SUFFIX 结尾（硬护栏 ensure_draft_path），未审不加载。
3. 只依赖标准库 + core.config + core.dicts；不联网、不随机、可重入。

用法
----
  python3 tools/dict_gen.py dict  --mock --json --dry-run
  python3 tools/dict_gen.py dict  --from data/findings.db --out data/dicts_ai.json[SUF]
  python3 tools/dict_gen.py hosts --hosts a.com,b.com --json --dry-run
  python3 tools/dict_gen.py hosts --hosts-file /tmp/hosts.txt
  python3 tools/dict_gen.py both  --mock
  python3 tools/dict_gen.py show  --path data/dicts_ai.json
"""
import json
import os
import re
import sqlite3
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
from core import config as cfg          # noqa: E402
from core import dicts as _dicts        # noqa: E402
# 草稿后缀：直接引用契约单一来源，本文件不写字面量（round39 D5 判据）。
DRAFT_SUFFIX = _dicts.DRAFT_SUFFIX
# 正式位：人审改名后即生效（与阶段 3-4 的加载位对齐）。
DICT_LIVE_NAME = "dicts_ai.json"
HOSTS_LIVE_NAME = "hosts_ai.json"
DEFAULT_DICT_DRAFT = os.path.join(cfg.DATA_DIR, DICT_LIVE_NAME) + DRAFT_SUFFIX
DEFAULT_HOSTS_DRAFT = os.path.join(cfg.DATA_DIR, HOSTS_LIVE_NAME) + DRAFT_SUFFIX
DEFAULT_DB = os.path.join(cfg.DATA_DIR, "findings.db")
_USAGE = ("用法: python3 tools/dict_gen.py <dict|hosts|both|show> [选项]\n"
          "  dict  : 读资产指纹产针对性字典草稿\n"
          "  hosts : 读未命中主机名产解析变形候选草稿\n"
          "  both  : 依次执行 dict 与 hosts\n"
          "  show  : 读回并打印已人审的正式文件\n"
          "选项: [--from DB] [--mock] [--limit N] [--min-count N]\n"
          "      [--out PATH] [--hosts a.com,b.com] [--hosts-file F]\n"
          "      [--hosts-out PATH] [--path FILE] [--dry-run] [--json]")

# ------------------------------------------------------------ 参数
def _parse_args(argv):
    """极简手写解析（与 tools/knowledge_learn.py 同风格，便于单测）。"""
    opt = {"cmd": "", "from": DEFAULT_DB, "mock": False, "limit": 500,
           "min_count": 1, "out": "", "hosts": "", "hosts_file": "",
           "hosts_out": "",
           "path": "", "dry_run": False, "json": False, "online": False,
           "help": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opt["help"] = True
            i += 1
        elif a in ("dict", "hosts", "both", "show"):
            opt["cmd"] = a
            i += 1
        elif a == "--mock":
            opt["mock"] = True
            i += 1
        elif a == "--dry-run":
            opt["dry_run"] = True
            i += 1
        elif a == "--json":
            opt["json"] = True
            i += 1
        elif a == "--online":
            opt["online"] = True
            i += 1
        elif a in ("--from", "--limit", "--min-count", "--out", "--hosts",
                   "--hosts-file", "--hosts-out", "--path") and i + 1 < len(argv):
            k = {"--from": "from", "--limit": "limit", "--min-count": "min_count",
                 "--out": "out", "--hosts": "hosts", "--hosts-file": "hosts_file",
                 "--hosts-out": "hosts_out", "--path": "path"}[a]
            v = argv[i + 1]
            if k in ("limit", "min_count"):
                try:
                    v = int(v)
                except Exception:
                    v = opt[k]
            opt[k] = v
            i += 2
        else:
            i += 1
    if not opt["cmd"]:
        opt["cmd"] = "both"
    return opt

# ------------------------------------------------------------ 素材（只读）
def load_assets(path=None, limit=500):
    """读 ``findings.db`` 的 assets 表（**只读**，从不写回）。
    库不存在 / 表缺失 / 打开失败一律返回空列表——素材缺失不该让工具崩。
    """
    p = path or DEFAULT_DB
    if not os.path.isfile(p):
        return []
    out = []
    conn = None
    try:
        try:
            conn = sqlite3.connect("file:%s?mode=ro" % p, uri=True)
        except Exception:
            conn = sqlite3.connect(p)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT host,url,title,tech,server,status FROM assets ORDER BY id"
        ).fetchall()
        for r in rows:
            out.append({k: str(r[k] or "") for k in
                        ("host", "url", "title", "tech", "server", "status")})
    except Exception:
        return []
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    if limit and len(out) > int(limit):
        out = out[-int(limit):]
    return out

# 内置 mock 素材：覆盖 6 类组件，供离线自测（不读 DB、不联网）。
_MOCK_ASSETS = (
    {"host": "10.0.0.11", "url": "http://10.0.0.11:6379/", "title": "",
     "tech": "Redis", "server": "", "status": "200"},
    {"host": "10.0.0.12", "url": "http://10.0.0.12/jenkins/", "title": "Jenkins",
     "tech": "Jenkins", "server": "Jetty", "status": "200"},
    {"host": "10.0.0.13", "url": "http://10.0.0.13/nacos/index.html", "title": "Nacos",
     "tech": "Nacos", "server": "nginx", "status": "200"},
    {"host": "10.0.0.14", "url": "http://10.0.0.14/login", "title": "Grafana",
     "tech": "Grafana", "server": "nginx", "status": "200"},
    {"host": "10.0.0.15", "url": "http://10.0.0.15/actuator/health", "title": "",
     "tech": "Spring Boot", "server": "", "status": "200"},
    {"host": "10.0.0.16", "url": "http://10.0.0.16/phpmyadmin/", "title": "phpMyAdmin",
     "tech": "PHP", "server": "Apache/2.4", "status": "200"},
)
def mock_assets():
    """返回内置 mock 素材的**副本**（调用方改动不污染常量）。"""
    return [dict(a) for a in _MOCK_ASSETS]

# ------------------------------------------------------------ 提取
_STOPWORDS = frozenset((
    "http", "https", "www", "com", "cn", "net", "org", "html", "htm",
    "php", "jsp", "aspx", "index", "login", "logout", "static", "assets",
    "images", "img", "css", "js", "the", "and", "for", "you", "are",
    "with", "server", "apache", "nginx", "jetty", "unknown", "boot",
))
def _first_seg(url):
    """从 url 取首个路径段（目录词候选）。取不到返回空串。"""
    m = re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://[^/]+/([^/?#]+)", str(url or ""))
    if not m:
        return ""
    seg = m.group(1).strip().lower()
    if not seg or len(seg) > 24:
        return ""
    return re.sub(r"[^a-z0-9_\-.]", "", seg)
def _roots_of(a):
    """从一条素材抽词根（小写、去噪、保序去重，最多 6 个）。"""
    out = []

    def _push(w):
        w = str(w or "").strip().lower()
        if len(w) < 3 or w in _STOPWORDS or w.isdigit():
            return
        if w not in out:
            out.append(w)

    h = str(a.get("host") or "").lower()
    m = re.match(r"^([a-z0-9][a-z0-9\-]*)\.", h)
    if m:
        _push(m.group(1))
    for f in ("tech", "title", "server"):
        for w in re.split(r"[^a-z0-9]+", str(a.get(f) or "").lower()):
            _push(w)
    return out[:6]

# ------------------------------------------------------------ 组件关键词（3-4 归纳用）
# 顺序即优先级；(关键词, 名称)。只保留"能从资产特征里认出组件"的最少信息，
# 不涉及模板 / 路径 / severity —— 那些属模板产物，与本工具无关。
_COMPONENT_KEYWORDS = (
    ("redis", "Redis"),
    ("jenkins", "Jenkins"),
    ("gitlab", "GitLab"),
    ("nacos", "Nacos"),
    ("druid", "Druid"),
    ("grafana", "Grafana"),
    ("kibana", "Kibana"),
    ("prometheus", "Prometheus"),
    ("zabbix", "Zabbix"),
    ("elasticsearch", "Elasticsearch"),
    ("tomcat", "Tomcat"),
    ("phpmyadmin", "phpMyAdmin"),
    ("spring", "Spring Boot"),
    ("thinkphp", "ThinkPHP"),
    ("shiro", "Shiro"),
    ("weblogic", "WebLogic"),
    ("consul", "Consul"),
    ("zookeeper", "Zookeeper"),
)

def _hay(a):
    """把一条素材的可检索字段拼成小写 haystack。"""
    return " ".join([str(a.get("title") or ""), str(a.get("tech") or ""),
                     str(a.get("server") or ""), str(a.get("url") or ""),
                     str(a.get("host") or "")]).lower()

def component_hits(assets, min_count=1):
    """统计素材里命中的组件关键词（确定性：计数降序 + 名称升序）。"""
    counts = {}
    for a in assets or []:
        if not isinstance(a, dict):
            continue
        h = _hay(a)
        for kw, _name in _COMPONENT_KEYWORDS:
            if kw in h:
                counts[kw] = counts.get(kw, 0) + 1
    items = [(k, v) for k, v in counts.items() if v >= int(min_count)]
    items.sort(key=lambda kv: (-kv[1], kv[0]))
    return items

def _name_of(kw):
    """组件关键词 -> 展示名（未知则原样返回）。"""
    for k, n in _COMPONENT_KEYWORDS:
        if k == kw:
            return n
    return kw

# ------------------------------------------------------------ 字典草稿（3-4）
def build_dicts(assets, min_count=1, limit=500, source="findings.db"):
    """把素材归纳成 ``{"subdomain_words": [...], "dir_words": [...], "creds": [...]}``。

    子域词来自组件命中（``kw`` / ``kw+"admin"`` / ``kw+"-test"``）并叠加从素材抽出的
    词根；口令来自组件命中（``kw`` / ``kw+"123"`` / ``kw+"@123"``）；目录词来自 URL 首段。
    全部保序去重、排序确定 —— 同输入必同输出（``_meta.generated_at`` 除外）。
    """
    subs, creds, dirs = [], [], []
    for kw, _n in component_hits(assets, min_count=min_count):
        for w in (kw, kw + "admin", kw + "-test"):
            if w not in subs:
                subs.append(w)
        for c in (kw, kw + "123", kw + "@123"):
            if c not in creds:
                creds.append(c)
    for a in assets or []:
        if not isinstance(a, dict):
            continue
        for r in _roots_of(a):
            for w in (r, r + "-test"):
                if w not in subs:
                    subs.append(w)
        d = _first_seg(a.get("url"))
        if d and d not in dirs:
            dirs.append(d)
    dirs.sort()
    hits = component_hits(assets, min_count=min_count)
    draft = {"subdomain_words": subs, "dir_words": dirs, "creds": creds}
    draft["_meta"] = {
        "generator": "tools/dict_gen.py",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": str(source or ""),
        "sample_count": len([a for a in (assets or []) if isinstance(a, dict)]),
        "component_count": len(hits),
        "rule_count": len(subs),
        "items": [{"component": k, "name": _name_of(k), "count": n}
                  for k, n in hits],
        "note": ("草稿。人工审核后改名为 %s 才会被加载（阶段 3-4 并入）。"
                 % DICT_LIVE_NAME),
    }
    return draft

def validate_dicts(d):
    """结构合法性自校验，返回 (ok, reason)。"""
    if not isinstance(d, dict):
        return False, "顶层不是映射"
    for k in ("subdomain_words", "dir_words", "creds"):
        v = d.get(k)
        if not isinstance(v, list):
            return False, "%s 不是列表" % k
        for it in v:
            if not isinstance(it, str) or not it.strip():
                return False, "%s 含非法项 %r" % (k, it)
    if not isinstance(d.get("_meta"), dict):
        return False, "_meta 缺失"
    return True, ""

# ------------------------------------------------------------ 解析变形候选（3-5）
# 与 core/dnsx.py::_VARIANT_PREFIXES 保持同源同序；此处**本地副本**，
# 因为 import core.dnsx 会间接拉起 socket，而本工具必须无网络 SDK（round40 A4）。
_VARIANT_PREFIXES = ("www", "m", "wap", "oa", "erp", "crm", "mail",
                     "portal", "home", "app", "admin", "web", "shop",
                     "mall", "bbs", "blog", "api", "sso", "hr", "test",
                     "dev", "vpn", "git", "jenkins")

def _norm_host(h):
    """归一主机名：去空白、转小写、去尾点；空 / 含非法字符 / 非域名形态返回空串。"""
    s = str(h or "").strip().lower().rstrip(".")
    if not s or len(s) > 253:
        return ""
    if ":" in s or "/" in s or " " in s:
        return ""
    if not re.match(r"^[a-z0-9][a-z0-9.\-]*\.[a-z0-9\-]+$", s):
        return ""
    return s

def hosts_variants(host):
    """单个主机名 -> 变形候选列表（保序去重，与 dnsx.suggest_variants 同口径）。
    先处理 www 去/加，再依次拼 _VARIANT_PREFIXES；IP 字面量原样返回空。
    """
    h = _norm_host(host)
    if not h:
        return []
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", h):
        return []
    labels = h.split(".")
    out = []
    if h.startswith("www.") and len(labels) > 2:
        out.append(h[4:])
        base = h[4:]
    else:
        out.append("www." + h)
        base = h
    for p in _VARIANT_PREFIXES:
        cand = "%s.%s" % (p, base)
        if cand != h and cand not in out:
            out.append(cand)
    return out

def build_hosts(hosts, limit=500, source="findings.db"):
    """把主机名列表归纳成解析候选：``{"candidates": {host: [...]}, "variant_words": [...]}``。
    ``variant_words`` 是全部候选里去重后的「词根集合」（供人工挑选扩字典）。
    同输入必同输出（``_meta.generated_at`` 除外）。
    """
    cands = {}
    words = []
    n = 0
    for h in hosts or []:
        nh = _norm_host(h)
        if not nh or nh in cands:
            continue
        vs = hosts_variants(nh)
        if not vs:
            continue
        cands[nh] = vs
        n += 1
        for v in vs:
            head = v.split(".")[0]
            if head and head not in words:
                words.append(head)
        if limit and n >= int(limit):
            break
    words.sort()
    draft = {"candidates": cands, "variant_words": words}
    draft["_meta"] = {
        "generator": "tools/dict_gen.py",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": str(source or ""),
        "sample_count": len([x for x in (hosts or []) if _norm_host(x)]),
        "host_count": len(cands),
        "candidate_count": sum(len(v) for v in cands.values()),
        "prefix_count": len(_VARIANT_PREFIXES),
        "note": ("草稿。人工审核后改名为 %s 才会被加载（阶段 3-5 并入）。"
                 % HOSTS_LIVE_NAME),
    }
    return draft

def validate_hosts(obj):
    """结构合法性自校验，返回 (ok, reason)。"""
    if not isinstance(obj, dict):
        return False, "顶层不是映射"
    c = obj.get("candidates")
    if not isinstance(c, dict):
        return False, "candidates 不是映射"
    for k, v in c.items():
        if not isinstance(k, str) or not k.strip():
            return False, "candidates 含非法键 %r" % (k,)
        if not isinstance(v, list) or not v:
            return False, "%s 候选不是非空列表" % k
        for it in v:
            if not isinstance(it, str) or not it.strip():
                return False, "%s 含非法候选 %r" % (k, it)
    w = obj.get("variant_words")
    if not isinstance(w, list):
        return False, "variant_words 不是列表"
    for it in w:
        if not isinstance(it, str) or not it.strip():
            return False, "variant_words 含非法项 %r" % (it,)
    if not isinstance(obj.get("_meta"), dict):
        return False, "_meta 缺失"
    return True, ""

# ------------------------------------------------------------ 写盘（硬护栏 + 原子写）
def ensure_draft_path(path, default=None):
    """硬护栏：写盘路径必须以草稿后缀结尾，防止误写正式文件。"""
    p = str(path or default or DEFAULT_DICT_DRAFT)
    if not p.endswith(DRAFT_SUFFIX):
        p = p + DRAFT_SUFFIX
    return p

def write_draft(obj, path=None, default=None):
    """原子写草稿（tmp + replace）。返回实际写入路径。"""
    p = ensure_draft_path(path, default)
    d = os.path.dirname(p)
    if d:
        os.makedirs(d, exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return p

# ------------------------------------------------------------ 读回人审件（show）
def load_live(path):
    """读回已人审的正式文件（仅读，不写）。草稿后缀一律拒绝，返回 (obj, err)。"""
    p = str(path or "")
    if not p:
        return None, "未指定 --path"
    if p.endswith(DRAFT_SUFFIX):
        return None, "拒绝读取未审草稿：%s" % p
    if not os.path.isfile(p):
        return None, "文件不存在：%s" % p
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f), ""
    except Exception as e:
        return None, "解析失败：%s" % e

# ------------------------------------------------------------ 联网参考（可选，仅入 _meta）
def research(queries, engine="auto", max_results=5):
    """用 tools/websearch.py 取参考资料（只进 ``_meta``，不参与生成）。
    动态加载是**唯一取数出口**（round40 A5 同款约束），失败静默返回空。
    """
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "websearch.py")
        spec = importlib.util.spec_from_file_location("bt_websearch", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    except Exception:
        return {}
    out = {}
    for q in queries:
        try:
            res = mod.search(q, engine=engine, max_results=max_results)
        except Exception:
            res = []
        out[q] = [{"title": r.get("title"), "url": r.get("url")}
                  for r in (res or [])]
    return out

def _hosts_from_opt(opt):
    """从 --hosts / --hosts-file 收集主机名（无则回退读库里的 host 列）。"""
    raw = []
    if opt.get("hosts"):
        raw.extend(str(opt["hosts"]).replace(";", ",").split(","))
    hf = str(opt.get("hosts_file") or "")
    if hf and os.path.isfile(hf):
        try:
            with open(hf, "r", encoding="utf-8") as f:
                raw.extend(f.read().splitlines())
        except Exception:
            pass
    return [_norm_host(x) for x in raw if _norm_host(x)]

# ------------------------------------------------------------ 入口
# ------------------------------------------------------------ AI 增强（可选层）
def _ai_ready():
    """双开关就绪（与 Config.ai_ready 同源）；任何异常一律视为未就绪。"""
    try:
        return bool(cfg.Config().ai_ready())
    except Exception:
        return False


def _ai_enhance():
    """动态加载 tools/ai_enhance.py（与 research() 加载 websearch 同款，不改导入面）。"""
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "ai_enhance.py")
        if not os.path.isfile(p):
            return None
        spec = importlib.util.spec_from_file_location("bt_ai_enhance", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _ai_ctx(assets):
    """给模型的资产特征摘要（确定性、截断）。"""
    out = []
    for a in (assets or [])[:30]:
        if not isinstance(a, dict):
            continue
        out.append({"title": str(a.get("title") or "")[:80],
                    "tech": str(a.get("tech") or "")[:80],
                    "url": str(a.get("url") or "")[:120]})
    return out


def _merge_ai_dicts(d, aw):
    """把 AI 词表候选并入字典草稿（保序去重 + dir_words 重排，守确定性）。"""
    for key in ("subdomain_words", "creds"):
        cur = d.get(key)
        if not isinstance(cur, list):
            continue
        for w in aw.get(key) or []:
            if isinstance(w, str) and w and w not in cur:
                cur.append(w)
    dirs = d.get("dir_words")
    if isinstance(dirs, list):
        for w in aw.get("dir_words") or []:
            if isinstance(w, str) and w and w not in dirs:
                dirs.append(w)
        d["dir_words"] = sorted(set(dirs))
    md = d.get("_meta")
    if isinstance(md, dict):
        md["rule_count"] = len(d.get("subdomain_words") or [])


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    opt = _parse_args(argv)
    if opt.get("help"):
        print(_USAGE)
        return 0
    cmd = opt["cmd"]

    if cmd == "show":
        obj, err = load_live(opt["path"])
        if err:
            print("[dict] %s" % err)
            return 1
        print(json.dumps(obj, ensure_ascii=False, indent=2))
        return 0

    if opt["mock"]:
        assets, src = mock_assets(), "mock://built-in"
    else:
        assets, src = load_assets(opt["from"], limit=opt["limit"]), opt["from"]

    res = None
    if opt["online"]:
        qs = ["%s 默认口令 未授权" % kw
              for kw, _n in component_hits(assets, min_count=opt["min_count"])[:5]]
        res = research(qs, max_results=5)

    ai_words = None
    if cmd in ("dict", "both") and assets:
        try:
            if _ai_ready():
                _enh = _ai_enhance()
                if _enh is not None and _enh.available():
                    ai_words = _enh.suggest_words(_ai_ctx(assets), limit=30)
        except Exception:
            ai_words = None

    want_d = cmd in ("dict", "both")
    want_h = cmd in ("hosts", "both")
    d = h = None

    if want_d:
        if not assets:
            print("[dict] 没有可用的资产素材（%s 为空或不存在）" % src)
        else:
            d = build_dicts(assets, min_count=opt["min_count"], limit=opt["limit"],
                            source=src)
            if res:
                d["_meta"]["research"] = res
            if ai_words:
                _merge_ai_dicts(d, ai_words)
                d["_meta"]["ai"] = _enh.meta_block(
                    subdomain_words=ai_words.get("subdomain_words") or [],
                    dir_words=ai_words.get("dir_words") or [],
                    creds=ai_words.get("creds") or [])
            okd, why_d = validate_dicts(d)
            if not okd:
                print("[dict] 字典自校验失败：%s" % why_d)
                return 2

    if want_h:
        hosts = _hosts_from_opt(opt)
        if not hosts and assets:
            hosts = [_norm_host(a.get("host"))
                     for a in assets if isinstance(a, dict)]
            hosts = [x for x in hosts if x]
        if not hosts:
            print("[dict] 没有可用的主机名（--hosts/--hosts-file 为空且库无 host）")
        else:
            h = build_hosts(hosts, limit=opt["limit"], source=src)
            okh, why_h = validate_hosts(h)
            if not okh:
                print("[dict] 候选自校验失败：%s" % why_h)
                return 2

    if d is None and h is None:
        return 0

    if opt["json"]:
        print(json.dumps({"dicts": d, "hosts": h}, ensure_ascii=False, indent=2))
    else:
        if d is not None:
            md = d["_meta"]
            print("[dict] 素材=%d 组件=%d 子域词=%d 目录词=%d 口令=%d"
                  % (md["sample_count"], md["component_count"], md["rule_count"],
                     len(d["dir_words"]), len(d["creds"])))
        if h is not None:
            mh = h["_meta"]
            print("[dict] 主机=%d 候选=%d 前缀=%d"
                  % (mh["host_count"], mh["candidate_count"], mh["prefix_count"]))

    if opt["dry_run"]:
        print("[dict] dry-run：未写盘")
        return 0

    wrote = []
    if d is not None:
        wrote.append(write_draft(d, opt["out"] or None, DEFAULT_DICT_DRAFT))
    if h is not None:
        wrote.append(write_draft(h, opt["hosts_out"] or None,
                                 DEFAULT_HOSTS_DRAFT))
    print("[dict] 草稿已写入 %s（人工审核改名后才会生效）" % " / ".join(wrote))
    return 0

if __name__ == "__main__":
    sys.exit(main())
