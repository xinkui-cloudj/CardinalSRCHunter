# -*- coding: utf-8 -*-
"""tools/ai_enhance.py —— AI 增强层（模型能力 → 离线工具可用的候选生成器）。

层级
----
    四个离线工具  --动态加载-->  ai_enhance  --动态加载-->  ai_client  --HTTPS--> 模型

本模块是「AI 能力」与「业务工具」之间的**唯一适配层**：四个工具不直接碰
网络协议，只调这里的 ``suggest_words`` / ``suggest_trigger`` / ``suggest_actions``。

红线
----
1. 本模块**不 import** ``urllib`` / ``requests`` / ``socket``（网络动作全部封在
   ``tools/ai_client.py`` 里）；四个工具仍以 ``spec_from_file_location`` 方式
   动态加载本模块，与 ``tools/websearch.py`` 同款，保持导入面不变。
2. 任何异常一律静默返回 ``None``，调用方必须能原地回落到确定性规则表。
3. 产出全部是**候选**，由调用方并入草稿并写 ``_meta.ai`` 溯源；本模块不落盘。

用法
----
  python3 tools/ai_enhance.py status
"""
import json
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# 词表候选的合法形状：小写字母数字开头，可含 . _ @ -，最长 64。
WORD_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._@\-]{0,63}$")
# 学习器产出的 code 形状（与 core.selfheal 的 learned- 前缀一致）。
CODE_RE = re.compile(r"^learned-[a-z0-9\-]{1,60}$")
MAX_WORDS = 30
MAX_ALTS = 8
MAX_CONDS = 6
MAX_STR = 512


def _dyn(name, filename):
    """动态加载 tools/ 下的模块（与各工具加载 websearch.py 同款，不改导入面）。"""
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", filename)
        spec = importlib.util.spec_from_file_location(name, p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _skills():
    """Dynamically load tools/skill_loader.py; None when unavailable."""
    return _dyn("bt_skill_loader", "skill_loader.py")


def _sys_with_skill(base, kind):
    """Append the skill text of this kind to the system prompt."""
    try:
        sl = _skills()
        if sl is None:
            return base
        return sl.apply(base, kind)
    except Exception:
        return base


def client():
    """返回已加载的 ai_client 模块；不可用返回 None。"""
    return _dyn("bt_ai_client", "ai_client.py")


def available():
    """模型是否真的可调用（双开关 + base/model/key 三件齐备）。"""
    c = client()
    if c is None:
        return False
    try:
        return bool(c.available())
    except Exception:
        return False


def model_name():
    """当前模型名（诊断用；不可用返回空串）。"""
    c = client()
    if c is None:
        return ""
    try:
        return str(c.settings().get("model") or "")
    except Exception:
        return ""


def meta_block(**kw):
    """统一的 ``_meta.ai`` 溯源块。"""
    b = {"enabled": True, "generator": "tools/ai_enhance.py",
         "model": model_name()}
    b.update(kw)
    return b


# ------------------------------------------------------------ 清洗
def _clean_words(v, limit=MAX_WORDS):
    """把模型返回的词表清洗成合法候选：形状校验 + 去重 + 保序 + 截断。"""
    out = []
    if not isinstance(v, list):
        return out
    for it in v:
        if not isinstance(it, str):
            continue
        w = it.strip().lower()
        if not w or not WORD_RE.match(w) or w in out:
            continue
        out.append(w)
        if len(out) >= int(limit):
            break
    return out


def _clean_strs(v, limit, cap=MAX_STR):
    """清洗字符串列表（payload 候选 / 触发条件）。"""
    out = []
    if isinstance(v, str):
        v = [v]
    if not isinstance(v, list):
        return out
    for it in v:
        if not isinstance(it, str):
            continue
        s = it.strip()
        if not s or s in out:
            continue
        out.append(s[:cap])
        if len(out) >= int(limit):
            break
    return out


# ------------------------------------------------------------ 三类候选生成
def suggest_words(ctx, limit=MAX_WORDS):
    """读资产特征 -> ``{subdomain_words, dir_words, creds}``；失败返回 None。"""
    c = client()
    if c is None:
        return None
    system = _sys_with_skill("你是渗透测试的字典工程师，只输出 JSON，不写任何解释。", "words")
    prompt = (
        "根据下列目标资产特征（组件/标题/URL），产出**针对性**的爆破字典候选。\n"
        "规则：\n"
        "  1) subdomain_words：子域名词（不含点、不含域名后缀，如 redisadmin）\n"
        "  2) dir_words：目录/路径词（不含斜杠，如 actuator）\n"
        "  3) creds：口令候选（如 redis123）\n"
        "全部小写、无空格、每类最多 %d 条，优先该组件真实常见命名。\n"
        "只输出 JSON：{\"subdomain_words\":[],\"dir_words\":[],\"creds\":[]}\n\n"
        "资产特征：\n%s"
        % (int(limit), json.dumps(ctx, ensure_ascii=False)[:4000]))
    obj = c.ask_json(prompt, system=system, max_tokens=800)
    if not isinstance(obj, dict):
        return None
    out = {}
    for k in ("subdomain_words", "dir_words", "creds"):
        out[k] = _clean_words(obj.get(k), limit)
    if not any(out.values()):
        return None
    return out


def suggest_trigger(ctx, base_payload=None):
    """读难例上下文 -> ``{payload, alternatives, conditions, why}``；失败返回 None。"""
    c = client()
    if c is None:
        return None
    system = _sys_with_skill("你是 Web 漏洞验证工程师，只输出 JSON，不写任何解释。", "trigger")
    prompt = (
        "下面是一条扫描器未命中任何已知规则的难例（响应片段 + 组件推断）。\n"
        "请给出最可能触发该组件的**候选 payload** 与**触发条件**。\n"
        "参考基线 payload：%s\n"
        "只输出 JSON：{\"payload\":\"...\",\"alternatives\":[...],\"conditions\":[...],\"why\":\"...\"}\n"
        "alternatives 最多 %d 条，conditions 最多 %d 条（每条一句可验证的话）。\n\n"
        "难例上下文：\n%s"
        % (json.dumps(base_payload or "", ensure_ascii=False), MAX_ALTS, MAX_CONDS,
           json.dumps(ctx, ensure_ascii=False)[:4000]))
    obj = c.ask_json(prompt, system=system, max_tokens=800)
    if not isinstance(obj, dict):
        return None
    out = {}
    p = obj.get("payload")
    if isinstance(p, str) and p.strip():
        out["payload"] = p.strip()[:MAX_STR]
    alts = _clean_strs(obj.get("alternatives"), MAX_ALTS)
    if alts:
        out["alternatives"] = alts
    conds = _clean_strs(obj.get("conditions"), MAX_CONDS, 300)
    if conds:
        out["conditions"] = conds
    why = obj.get("why")
    if isinstance(why, str) and why.strip():
        out["why"] = why.strip()[:500]
    return out or None


def suggest_actions(ctx, known):
    """读失败聚类 -> ``{code: [[action, why, {}], ...]}``；失败返回 None。

    ``action`` 必须在 ``known``（扫描器真正认识的动作词表）内，否则丢弃。
    """
    c = client()
    if c is None:
        return None
    ks = set(known or [])
    system = _sys_with_skill("你是网络爬虫稳定性工程师，只输出 JSON，不写任何解释。", "actions")
    prompt = (
        "下面是扫描器遇到的未知失败聚类。请为每个聚类给出补救动作。\n"
        "动作**只能**从下列白名单中选：%s\n"
        "每个 code 最多 2 个动作。code 必须形如 learned-xxx。\n"
        "只输出 JSON：{\"learned-xxx\":[[\"动作\",\"理由\"], ...]}\n\n"
        "失败聚类：\n%s"
        % (json.dumps(sorted(ks), ensure_ascii=False),
           json.dumps(ctx, ensure_ascii=False)[:4000]))
    obj = c.ask_json(prompt, system=system, max_tokens=800)
    if not isinstance(obj, dict):
        return None
    out = {}
    for code, rows in obj.items():
        if not isinstance(code, str) or not CODE_RE.match(code.strip()):
            continue
        if not isinstance(rows, list):
            continue
        clean = []
        for r in rows[:2]:
            act = why = None
            if isinstance(r, list) and r:
                act, why = r[0], (r[1] if len(r) > 1 else "")
            elif isinstance(r, dict):
                act, why = r.get("action"), r.get("why")
            if isinstance(act, str) and act.strip() in ks:
                clean.append([act.strip(), str(why or "")[:200], {}])
        if clean:
            out[code.strip()] = clean
    return out or None


_USAGE = ("用法: python3 tools/ai_enhance.py status\n"
          "  status : 打印 AI 增强层可用性与模型名\n")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd = argv[0] if argv else "status"
    if cmd in ("-h", "--help", "help"):
        print(_USAGE)
        return 0
    if cmd == "status":
        c = client()
        st = c.status() if c is not None else {"client": "missing"}
        st["enhance_available"] = available()
        st["model_name"] = model_name()
        print(json.dumps(st, ensure_ascii=False, indent=2))
        return 0
    print(_USAGE)
    return 2


if __name__ == "__main__":
    sys.exit(main())
