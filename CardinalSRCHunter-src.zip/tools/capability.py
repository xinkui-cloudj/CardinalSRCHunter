# -*- coding: utf-8 -*-
"""扫描能力自挂载（round70 需求⑤）。

目标：扫描主循环里显式多出一步——
    能力清单 -> 适用性判定 -> 调用
- **清单来源**：已启用项。SKILL 走 ``skill_loader.list_skills()`` 过滤 enabled；
  MCP 走配置 ``takeover.mcp.servers`` 过滤 enabled（与 ui/web.py 的 _mcp_list 同源）。
- **适用性判定**：由 AI 自主判断。本模块只负责把清单整理成一段可读文本，
  注入 ``tools/agent_loop.py`` 的 system 提示；具体"哪个能力适用于当前目标"
  由模型在 tool_calls 里自己决定。
- **调用**：MCP 能力已由 ``engine._load_mcp_tools()`` 注册进 tool_registry，
  AI 通过 ``run_tool`` 调用；SKILL 是提示词（无副作用），随清单一起注入即可。

红线（与 round38 H1 一致）：本模块位于 ``tools/``，**不被** core/modules/ui 的
热路径直接引用任何 ai 符号；``core/engine.py`` 只做 ``from tools import capability``
这种惰性引用。任何异常一律静默返回空清单，绝不影响扫描主流程。
"""
import os

# round86 M1b: selfcheck() cache globals (referenced by the body below).
# Missing definitions made the first selfcheck() call raise NameError,
# which callers swallowed into a fake "not configured" verdict.
_SELFCHECK_TTL = 20.0
_SELFCHECK_CACHE = {"ts": 0.0, "data": None}


def _skills():
    out = []
    try:
        from tools import skill_loader as sl
        # round73 D 组：SKILL 总开关关闭时，能力清单里也不列技能——
        # 否则会出现"清单说有技能、实际却不注入"的撒谎态。
        if not sl.global_enabled():
            return out
        for it in sl.list_skills():
            if not it.get("enabled"):
                continue
            txt = (it.get("text") or "").strip()
            first = ""
            for ln in txt.splitlines():
                ln = ln.strip()
                if ln:
                    first = ln[:120]
                    break
            out.append({"name": it.get("name") or it.get("file") or "?",
                        "kind": it.get("kind") or "all",
                        "desc": first})
    except Exception:
        pass
    return out

def _mcp(engine):
    """已启用 MCP 服务名 + 工具名 + 未生效原因。

    round86 N1: the old body counted ``tool_registry`` external tools only.
    But scan_target() prints this list BEFORE engine._load_mcp_tools() runs,
    so freshly started program reported "MCP tools 0 / MCP not effective"
    while the AI box (which loads them) reported 12. Two numbers for one
    machine. Now the truth comes from selfcheck(): real spawn + initialize
    + tools/list, cached 20s. Falls back to registry count only when
    selfcheck cannot run.
    """
    servers, tools = [], []
    # round86 N1b: engine may be None (CLI self-test, early startup).
    # The old body only read engine.config, so the same machine
    # reported 'MCP 段未发级' here while selfcheck() found live
    # servers -- exactly the contradictory counts the user saw.
    cfg_obj = None
    try:
        cfg_obj = engine.config if engine is not None else None
    except Exception:
        cfg_obj = None
    if cfg_obj is None:
        try:
            from core import config as _cfgmod
            cfg_obj = getattr(_cfgmod.Config(), "data", None) or {}
        except Exception:
            cfg_obj = {}
    try:
        raw = cfg_obj.get("takeover") if hasattr(cfg_obj, "get") else None
    except Exception:
        raw = None
    m = (raw or {}).get("mcp") if isinstance(raw, dict) else None
    if not isinstance(m, dict):
        return servers, tools, "MCP 段未配置"
    if not m.get("enabled"):
        return servers, tools, "总开关未开"
    for s in (m.get("servers") or []):
        if isinstance(s, dict) and s.get("enabled") is not False:
            nm = str(s.get("name") or "").strip()
            if nm:
                servers.append(nm)
    if not servers:
        return servers, tools, "总开关已开，但未配置任何 MCP 服务"
    _sc_ok = False
    try:
        _sc = selfcheck(engine)
        for _r in (_sc.get("servers") or []):
            if _r.get("ok"):
                for _t in (_r.get("tools") or []):
                    if _t and _t not in tools:
                        tools.append(str(_t))
        _sc_ok = bool(_sc.get("ok"))
    except Exception:
        pass
    if not tools:
        try:
            from tools import tool_registry
            for n, sp in (tool_registry.all_specs() or {}).items():
                if isinstance(sp, dict) and sp.get("external"):
                    tools.append(n)
        except Exception:
            pass
    if tools:
        return servers, tools, ""
    if not _sc_ok:
        return servers, tools, "服务已配置，但未注册出任何工具（连接或握手失败）"
    return servers, tools, ""
def selfcheck(engine=None, force=False):
    """round85 M2: real startup probe of every enabled MCP server.

    Why this exists: ``_mcp()`` only counts config entries + registry hits, so
    a server that never handshakes still shows up as "configured". The user
    then sees "MCP 服务 1 个" but zero tools, with no reason. This function
    actually spawns each server once (initialize + tools/list), closes it, and
    reports per-server truth: ok / error / hint / tools.

    Read-only: no tool is invoked, no scan request is sent. Cached for
    ``_SELFCHECK_TTL`` seconds so the UI polling loop cannot fork bombs.
    """
    import time as _t
    now = _t.time()
    if (not force) and _SELFCHECK_CACHE["data"] is not None             and (now - _SELFCHECK_CACHE["ts"]) < _SELFCHECK_TTL:
        return _SELFCHECK_CACHE["data"]
    out = {"ok": False, "servers": [], "n_servers": 0, "n_tools": 0,
           "reason": "", "ts": now}
    try:
        cfg = engine.config if engine is not None else None
        if cfg is None:
            from core import config as _cfgmod
            # round85 M2b: ``core.config`` has no module-level ``load()`` --
            # the reader is the ``Config`` class (its ``load()`` is an
            # *instance* method). Calling ``_cfgmod.load()`` always raised
            # AttributeError, got swallowed here, and degraded to
            # ``{"takeover": {}}`` so every server reported
            # "MCP 段未配置" no matter what the user configured.
            try:
                _inst = _cfgmod.Config()
                cfg = getattr(_inst, "data", None) or {}
            except Exception as e:
                out["reason"] = "读取配置失败：%s" % e
                _SELFCHECK_CACHE.update({"ts": now, "data": out})
                return out
        raw = cfg.get("takeover") if hasattr(cfg, "get") else None
        m = (raw or {}).get("mcp") if isinstance(raw, dict) else None
        if not isinstance(m, dict):
            out["reason"] = "MCP 段未配置"
            _SELFCHECK_CACHE.update({"ts": now, "data": out})
            return out
        if not m.get("enabled"):
            out["reason"] = "总开关未开（Web 控制台里打开 MCP 总开关）"
            _SELFCHECK_CACHE.update({"ts": now, "data": out})
            return out
        srv_list = [x for x in (m.get("servers") or [])
                    if isinstance(x, dict) and x.get("enabled") is not False]
        out["n_servers"] = len(srv_list)
        if not srv_list:
            out["reason"] = "总开关已开，但未配置任何 MCP 服务"
            _SELFCHECK_CACHE.update({"ts": now, "data": out})
            return out
        try:
            from tools.mcp_client import MCPClient, _norm_launcher, _resolve_script
        except Exception as e:
            out["reason"] = "MCP 客户端模块加载失败：%s" % e
            _SELFCHECK_CACHE.update({"ts": now, "data": out})
            return out
        all_tools = []
        for srv in srv_list:
            nm = str(srv.get("name") or "").strip()
            row = {"name": nm, "ok": False, "tools": [], "n_tools": 0,
                   "error": "", "hint": "", "command": "", "cwd": ""}
            cmd0 = str(srv.get("command") or "").strip()
            if not cmd0:
                row["error"] = "未配置启动命令"
                row["hint"] = "在 Web 控制台重新导入 MCP 插件 ZIP"
                out["servers"].append(row)
                continue
            cli = None
            try:
                cmd = _norm_launcher(cmd0)
                args, cwd = _resolve_script(srv.get("args"), srv.get("cwd"),
                                            cmd, nm)
                row["command"] = cmd
                row["cwd"] = cwd or ""
                cli = MCPClient(cmd, args=args, env=srv.get("env"), cwd=cwd,
                                timeout=srv.get("timeout") or 15)
                if not cli.initialize():
                    fr = ""
                    try:
                        fr = cli.failure_reason() or ""
                    except Exception:
                        fr = ""
                    row["error"] = fr or "握手失败（未返回原因）"
                    low = fr.lower()
                    if ("filenotfound" in low or "找不到" in fr
                            or "no such file" in low or "cannot find" in low
                            or "不是内部或外部命令" in fr):
                        row["hint"] = ("启动器不存在或脚本没落地："
                                       "请在 Web 控制台重新导入该插件 ZIP")
                    elif fr:
                        row["hint"] = "子进程起来了但没回 JSON-RPC，看 error 原文"
                    else:
                        row["hint"] = "进程未能启动，检查 command 是否绝对路径"
                else:
                    ts = cli.list_tools() or []
                    names = [str(x.get("name")) for x in ts
                             if isinstance(x, dict) and x.get("name")]
                    row["tools"] = names
                    row["n_tools"] = len(names)
                    row["ok"] = True
                    all_tools.extend(names)
            except Exception as e:
                row["error"] = "%s: %s" % (type(e).__name__, e)
                row["hint"] = "探活异常，把这条 error 原文发出来"
            finally:
                if cli is not None:
                    try:
                        cli.close()
                    except Exception:
                        pass
            out["servers"].append(row)
        out["n_tools"] = len(all_tools)
        n_ok = len([r for r in out["servers"] if r["ok"]])
        out["ok"] = n_ok == len(out["servers"]) and n_ok > 0
        if n_ok == 0:
            out["reason"] = "%d 个服务全部连接失败" % len(out["servers"])
        elif n_ok < len(out["servers"]):
            out["reason"] = "%d 个服务中 %d 个连接失败" % (len(out["servers"]),
                                                         len(out["servers"]) - n_ok)
    except Exception as e:
        out["reason"] = "自检异常：%s" % e
    _SELFCHECK_CACHE.update({"ts": now, "data": out})
    return out

def selfcheck_lines(engine=None, force=False):
    """Human-readable lines for the desktop black box / web console."""
    d = selfcheck(engine, force=force)
    lines = []
    if d.get("ok"):
        lines.append("MCP 自检：✓ 全部连接成功（%d 个服务，%d 个工具）"
                     % (d.get("n_servers") or 0, d.get("n_tools") or 0))
    elif d.get("n_servers"):
        lines.append("MCP 自检：✗ %s" % (d.get("reason") or "连接失败"))
    else:
        lines.append("MCP 自检：✗ %s" % (d.get("reason") or "未配置"))
    for r in (d.get("servers") or []):
        if r.get("ok"):
            lines.append("  ✓ %s：%d 个工具（%s）"
                         % (r["name"], r["n_tools"],
                            ", ".join(r["tools"][:8]) or "无"))
        else:
            lines.append("  ✗ %s：%s" % (r["name"], r.get("error") or "?"))
            if r.get("hint"):
                lines.append("      修复：%s" % r["hint"])
    return lines

def list_capabilities(engine):
    """返回当前"可用能力清单"（只含已启用项）。任何异常都退化成空清单。"""
    sk = _skills()
    sv, mt, why = _mcp(engine)
    return {"skills": sk, "mcp_servers": sv, "mcp_tools": mt,
            "mcp_reason": why}


def summary_lines(engine):
    """能力清单的可读行列表（供 UI 黑框/左框直接渲染）。

    与 build_note 的区别：build_note 是喂给模型的提示词，这里返回给人看的中文行。
    第 0 行为汇总，后续为明细（SKILL / MCP 服务 / MCP 工具）。
    任何异常退化成单行「读取失败」，不会抛出。
    """
    try:
        c = list_capabilities(engine)
        sk = c.get("skills") or []
        sv = c.get("mcp_servers") or []
        mt = c.get("mcp_tools") or []
        why = (c.get("mcp_reason") or "").strip()
        out = []
        head = ("能力清单：SKILL %d 个｜MCP 服务 %d 个｜MCP 工具 %d 个"
                % (len(sk), len(sv), len(mt)))
        if why:
            head += "（MCP 未生效：%s）" % why
        out.append(head)
        if sk:
            out.append("  SKILL（作业规范，不产生调用）：")
            for it in sk:
                nm = it.get("name") or "?"
                kd = it.get("kind") or "?"
                ds = it.get("desc") or ""
                out.append("    * %s [%s]%s" % (nm, kd, (" — " + ds) if ds else ""))
        else:
            out.append("  SKILL：未安装（需在 Web 控制台安装 SKILL 工具）")
        if sv:
            out.append("  MCP 服务：%s" % ", ".join(sv))
        else:
            out.append("  MCP 服务：0 个（" + (why or "未安装 MCP 插件") + "）")
        if mt:
            out.append("  MCP 工具（%d）：%s" % (len(mt), ", ".join(sorted(mt))))
        return out
    except Exception as e:
        return ["能力清单读取失败：%s" % e]


def build_note(engine):
    """把能力清单整理成一段注入 system 提示的文本；无能力时返回空串。"""
    c = list_capabilities(engine)
    sk, sv, mt = c["skills"], c["mcp_servers"], c["mcp_tools"]
    if not sk and not sv:
        return ""
    lines = ["可用能力清单（由程序自挂载，仅列已启用项；请自行判断哪些适用于当前目标，"
             "适用才用、不适用就跳过）："]
    if sk:
        lines.append("- 技能（作业规范，直接遵守即可，不产生调用）：")
        for it in sk:
            lines.append("  * %s [%s]%s" % (it["name"], it["kind"],
                                          (" — " + it["desc"]) if it["desc"] else ""))
    if sv:
        lines.append("- MCP 服务（可调工具）：%s" % ", ".join(sv))
    if mt:
        lines.append("- MCP 已注册工具（括号内为必填参数，参数名照抄，不要自创 target/url）：")
        for _sig in _tool_signatures(sorted(mt)):
            lines.append("  * " + _sig)
    lines.append("若清单为空或与目标无关，按常规确定性流程继续，不要强行调用。")
    return "\n".join(lines)


def _tool_signatures(names):
    """round87 D1: render name(req, opt) from the real JSON schema.

    The model used to see bare tool names only, then invented argument
    names (target/url) that the CLI rejected with "required: --domain".
    Printing declared parameter names up front removes the guesswork.
    """
    out = []
    try:
        from tools import tool_registry as _tr
        specs = _tr.all_specs()
    except Exception:
        return out
    for n in names:
        sp = specs.get(n)
        if not isinstance(sp, dict):
            out.append(n)
            continue
        fn = (sp.get("schema") or {}).get("function") or {}
        prm = fn.get("parameters") or {}
        props = list((prm.get("properties") or {}).keys())
        req = list(prm.get("required") or [])
        if not props:
            out.append(n + "()")
            continue
        parts = []
        for k in props:
            parts.append(k if k in req else k + "?")
        out.append("%s(%s)" % (n, ", ".join(parts)))
    return out


def scan_note(engine):
    """B 方案（round71）：启动横幅上的「AI 增强可用性」提示文本。

    条件：AI 未就绪（ai.enabled/online 未同时开）**或** SKILL/MCP 清单全空
    时，返回两行提示；两者都满足（有 AI 且有可用能力）时返回空串。
    任何异常一律退化成空串，绝不阻断启动或扫描。
    """
    try:
        try:
            ai_ok = bool(engine.config.ai_ready())
        except Exception:
            ai_ok = False
        c = list_capabilities(engine)
        has_cap = bool(c.get("skills") or c.get("mcp_servers"))
        if ai_ok and has_cap:
            return ""
        return ("  当前仅确定性扫描，漏洞环节无 AI 产出\n"
                "  如需漏洞检测请启用 AI 并安装 SKILL/MCP")
    except Exception:
        return ""
