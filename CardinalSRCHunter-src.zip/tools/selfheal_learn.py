# -*- coding: utf-8 -*-
"""离线自愈规则学习器（阶段 1-3）。

定位
----
把扫描时落盘的"未知失败样本"（``data/unknowns.jsonl``，见 ``core/unknowns.py``）
离线归纳成**候选自愈规则草稿**，供人工审核后改名生效。

数据流（单向，永不回流）
------------------------
::

    扫描热路径 --写--> data/unknowns.jsonl
                              |
                  tools/selfheal_learn.py   （本文件，离线 CLI）
                              |
                              v
                 data/selfheal_extra.json.draft
                              |
                         人工审核改名
                              v
                  data/selfheal_extra.json  <--读-- 扫描热路径（core/selfheal.py）

红线遵守（三条）
----------------
1. **AI 永不进扫描热路径做决策**：本文件是离线 CLI，不被任何扫描代码 import
   （见 lab/verify_round37 A5/B1 断言）；其产物只是静态数据，由
   ``core/selfheal.py::_apply_extra`` 只读加载。
2. **产物必须人审后生效**：本文件**只写 ``.draft``**，绝不写
   ``selfheal_extra.json``。``_apply_extra`` 只认后者，故草稿永远不生效
   （``ensure_draft_path`` 是硬护栏，见 lab/verify_round37 E1）。
3. **本文件自身不做"决策"**：关键词 -> 候选动作的映射是确定性表（``_HINTS``），
   联网检索只取"参考资料"写进 ``_meta.research``，不参与规则生成；无
   ``random``，同输入必同输出。

用法
----
::

    python3 tools/selfheal_learn.py --dry-run                 # 只看归纳结果
    python3 tools/selfheal_learn.py --online --limit 200      # 带联网参考线索
    python3 tools/selfheal_learn.py --out data/my.json        # 自动补 .draft 后缀
"""
import json
import os
import re
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core import config as cfg          # noqa: E402
from core import selfheal               # noqa: E402
from core import unknowns               # noqa: E402

# 草稿后缀（硬护栏）：写盘路径一律以它结尾，避免误写正式文件。
DRAFT_SUFFIX = ".draft"
# 正式文件名：扫描器只读这个，草稿不会生效。
LIVE_NAME = "selfheal_extra.json"
DEFAULT_DRAFT = os.path.join(cfg.DATA_DIR, LIVE_NAME + DRAFT_SUFFIX)

_USAGE = ("用法: python3 tools/selfheal_learn.py "
          "[--from data/unknowns.jsonl] [--out data/selfheal_extra.json.draft] "
          "[--limit N] [--min-count N] [--online] [--engine auto|bing|baidu] "
          "[--dry-run] [--json]")


# ------------------------------------------------------------ 参数
def _parse_args(argv):
    """极简手写解析（与 tools/websearch.py 风格一致，便于单测）。"""
    opt = {"from": unknowns.UNKNOWNS_PATH, "out": DEFAULT_DRAFT, "online": False,
           "limit": 200, "min_count": 1, "dry_run": False, "json": False,
           "engine": "auto", "help": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opt["help"] = True
            i += 1
        elif a == "--online":
            opt["online"] = True
            i += 1
        elif a == "--dry-run":
            opt["dry_run"] = True
            i += 1
        elif a == "--json":
            opt["json"] = True
            i += 1
        elif a in ("--from", "--out", "--limit", "--min-count", "--engine") and i + 1 < len(argv):
            k = {"--from": "from", "--out": "out", "--limit": "limit",
                 "--min-count": "min_count", "--engine": "engine"}[a]
            v = argv[i + 1]
            if k in ("limit", "min_count"):
                try:
                    v = int(v)
                except Exception:
                    v = opt[k]
            opt[k] = v
            i += 2
        else:
            i += 1
    return opt


# ------------------------------------------------------------ 读样本（只读）
def load_samples(path=None, limit=200):
    """读 ``unknowns.jsonl``（**只读**，从不写回）。坏行静默跳过。"""
    p = path or unknowns.UNKNOWNS_PATH
    out = []
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                if isinstance(obj, dict):
                    out.append(obj)
    except Exception:
        return []
    if limit and len(out) > int(limit):
        out = out[-int(limit):]
    return out


# ------------------------------------------------------------ 归一化 / 聚类
_RE_UUID = re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b")
_RE_IPV4 = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
_RE_HEX = re.compile(r"\b0x[0-9a-fA-F]+\b")
_RE_PORT = re.compile(r":\d{2,5}\b")
_RE_NUM = re.compile(r"\b\d+\b")
_RE_WS = re.compile(r"\s+")


def norm_err(err):
    """把错误文本归一化成模板：IP / 端口 / 数字 / uuid / hex 全部占位化。

    这样"同一类失败、只是地址不同"的样本会落进同一个聚类。
    """
    s = str(err or "").strip().lower()
    s = _RE_UUID.sub("<uuid>", s)
    s = _RE_IPV4.sub("<ip>", s)
    s = _RE_HEX.sub("<hex>", s)
    s = _RE_PORT.sub(":<port>", s)
    s = _RE_NUM.sub("<n>", s)
    s = _RE_WS.sub(" ", s)
    return s[:240]


def cluster(samples, min_count=1):
    """按归一化错误模板聚类，返回按样本数降序的分组列表。"""
    groups = {}
    for s in samples or []:
        if not isinstance(s, dict):
            continue
        key = (norm_err(s.get("err")) or norm_err(s.get("reason"))
               or norm_err(s.get("code")) or "<empty>")
        g = groups.get(key)
        if g is None:
            g = {"key": key, "count": 0, "hosts": [], "codes": {}, "err_samples": []}
            groups[key] = g
        g["count"] += 1
        h = str(s.get("host") or "")
        if h and h not in g["hosts"] and len(g["hosts"]) < 5:
            g["hosts"].append(h)
        c = str(s.get("code") or "unknown")
        g["codes"][c] = g["codes"].get(c, 0) + 1
        e = str(s.get("err") or "")
        if e and len(g["err_samples"]) < 3 and e not in g["err_samples"]:
            g["err_samples"].append(e[:200])
    out = [g for g in groups.values() if g["count"] >= int(min_count)]
    out.sort(key=lambda g: (-g["count"], g["key"]))
    return out


# ------------------------------------------------------------ 确定性映射
# 顺序即优先级；(正则, 候选动作, 理由)。动作名会被 known_actions() 过滤，
# 保证草稿里只出现 core/selfheal.py 真正认识的动作。
_HINTS = (
    (r"certificate|ssl|tls|handshake|wrong version|self signed",
     ("scheme_retry", "proxy_hint"),
     "握手 / 证书类失败：优先换 scheme 重试，必要时走代理出口"),
    (r"timed out|timeout|timedout",
     ("port_retry", "slow_down", "stop_if_exhausted"),
     "超时：换端口重试 + 降速，连续失败则确定性放弃"),
    (r"refused|econnrefused|connection refused",
     ("port_retry", "stop_if_exhausted"),
     "连接被拒：换端口重试，全部被拒则放弃该主机"),
    (r"reset|econnreset|connection reset|broken pipe",
     ("slow_down", "proxy_hint"),
     "连接被重置：降速规避中间设备限流，仍失败则换出口"),
    (r"name or service not known|getaddrinfo|nxdomain|no address associated|servfail",
     ("dns_rotate", "stop_if_exhausted"),
     "解析类失败：换 DNS 解析器重试，仍无结果则放弃"),
    (r"network is unreachable|no route|ehostunreach|enetunreach",
     ("proxy_hint", "stop"),
     "网络不可达：本机路由无出口，只能换代理或确定性放弃"),
    (r"address family|af_|ipv6|eafnosupport|protocol not available",
     ("family_v4_only", "socket_fallback"),
     "地址族不支持：强制 IPv4 优先，必要时回退裸 socket"),
    (r"too many redirects|redirect|301|302|loop",
     ("scheme_retry", "slow_down"),
     "重定向异常：换 scheme 重试并降速"),
    (r"403|429|503|too many requests|rate limit|forbidden",
     ("slow_down", "rotate_ua"),
     "被限流 / 拦截：降速并轮换 UA"),
    (r"bad status line|malformed|invalid http|connection aborted",
     ("socket_fallback", "slow_down"),
     "响应非 HTTP：回退裸 socket 探测 + 降速"),
    (r"temporarily unavailable|eagain|resource temporarily",
     ("port_retry", "slow_down"),
     "资源暂不可用：换端口重试 + 降速"),
)
_DEFAULT_ACTIONS = ("dns_rotate", "slow_down")


def _slug(text):
    t = re.sub(r"[^a-z0-9]+", "-", str(text or "").lower()).strip("-")
    t = re.sub(r"-{2,}", "-", t)
    return (t[:36].strip("-")) or "unknown"


def code_for(key):
    """由归一化模板生成稳定 code（同输入必同输出，无随机）。"""
    return "learned-" + _slug(key)


def known_actions():
    """从内置 + 外置动作表收集合法动作名（含外置层）。"""
    ks = set()
    try:
        for rows in selfheal.ACTIONS.values():
            for r in rows or ():
                if r:
                    ks.add(str(r[0]))
    except Exception:
        pass
    return ks


def candidate_actions(key, err_samples=()):
    """关键词 -> 候选动作（确定性）。无命中时保守回落，绝不激进重试。"""
    hay = " ".join([str(key or "")] + [str(x or "") for x in (err_samples or [])]).lower()
    acts, whys = [], []
    for pat, alist, why in _HINTS:
        if re.search(pat, hay):
            for a in alist:
                if a not in acts:
                    acts.append(a)
                    whys.append(why)
            if len(acts) >= 3:
                break
    if not acts:
        for a in _DEFAULT_ACTIONS:
            acts.append(a)
            whys.append("未知失败模式：保守采用解析轮换 + 降速，避免激进重试")
    return list(zip(acts, whys))


# ------------------------------------------------------------ 草稿构建
def build_draft(samples, min_count=1, limit=200, research=None):
    """把样本归纳成 ``{"actions": {...}, "budget": {...}, "_meta": {...}}``。

    顶层两键严格符合 ``core/selfheal.py::_apply_extra`` 的契约；
    ``_meta`` 只是给人看的说明，加载器不读它。
    """
    groups = cluster(samples, min_count=min_count)
    known = known_actions()
    actions, budget, items = {}, {}, []
    for g in groups:
        code = code_for(g["key"])
        if code in selfheal.ACTIONS or code in actions:
            continue                      # 只补不覆盖：内置/已有 code 一律跳过
        rows = []
        for a, why in candidate_actions(g["key"], g["err_samples"]):
            if known and a not in known:
                continue                  # 草稿里只放扫描器真正认识的动作
            rows.append([a, why, {}])
        if not rows:
            continue
        actions[code] = rows
        budget[code] = min(2, len(rows))  # 预算不超动作条数（与 _apply_extra 一致）
        items.append({"code": code, "count": g["count"], "key": g["key"],
                      "hosts": list(g["hosts"]), "actions": [r[0] for r in rows]})
    draft = {"actions": actions, "budget": budget}
    draft["_meta"] = {
        "generator": "tools/selfheal_learn.py",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": "data/unknowns.jsonl",
        "sample_count": len([s for s in (samples or []) if isinstance(s, dict)]),
        "cluster_count": len(groups),
        "rule_count": len(actions),
        "items": items,
        "research": research or {},
        "note": ("草稿（.draft）。人工审核后改名为 %s 才会被扫描器加载；"
                 "加载时只补不覆盖内置表。" % LIVE_NAME),
    }
    _ai_actions(draft, groups, known)
    return draft


# ------------------------------------------------------------ AI 增强（可选层）
def _ai_ready():
    """双开关就绪（与 Config.ai_ready 同源）；任何异常一律视为未就绪。"""
    try:
        return bool(cfg.Config().ai_ready())
    except Exception:
        return False


def _ai_enhance():
    """动态加载 tools/ai_enhance.py（与 research() 加载 websearch 同款，不改导入面）。"""
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "ai_enhance.py")
        if not os.path.isfile(p):
            return None
        spec = importlib.util.spec_from_file_location("bt_ai_enhance", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _ai_actions(draft, groups, known):
    """用 AI 增强层补 actions（code 必须 learned-xxx、动作必须在 known 内、只补不覆盖）。"""
    try:
        if not _ai_ready():
            return
        _enh = _ai_enhance()
        if _enh is None or not _enh.available():
            return
        ctx = [{"key": g.get("key"), "count": g.get("count"),
                "err": list(g.get("err_samples") or [])[:3]}
               for g in (groups or [])[:10]]
        sug = _enh.suggest_actions(ctx, known)
        if not isinstance(sug, dict):
            return
        acts = draft.get("actions")
        budget = draft.get("budget")
        if not isinstance(acts, dict) or not isinstance(budget, dict):
            return
        added = []
        for code, rows in sug.items():
            if code in selfheal.ACTIONS or code in acts:
                continue
            clean = [r for r in rows if r and r[0] in known]
            if not clean:
                continue
            acts[code] = clean
            budget[code] = min(2, len(clean))
            added.append(code)
        md = draft.get("_meta")
        if added and isinstance(md, dict):
            md["ai"] = _enh.meta_block(actions=sorted(added))
            md["rule_count"] = len(acts)
    except Exception:
        return


def ensure_draft_path(path):
    """硬护栏：写盘路径必须以 ``.draft`` 结尾，防止误写正式文件。"""
    p = str(path or DEFAULT_DRAFT)
    if not p.endswith(DRAFT_SUFFIX):
        p = p + DRAFT_SUFFIX
    return p


def write_draft(draft, path=None):
    """原子写草稿（tmp + replace）。返回实际写入路径。"""
    p = ensure_draft_path(path)
    d = os.path.dirname(p)
    if d:
        os.makedirs(d, exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(draft, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return p


# ------------------------------------------------------------ 联网参考（可选）
def research(queries, engine="auto", max_results=5):
    """用 tools/websearch.py 取参考资料（只进 ``_meta``，不参与规则生成）。"""
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "websearch.py")
        spec = importlib.util.spec_from_file_location("bt_websearch", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    except Exception:
        return {}
    out = {}
    for q in queries:
        try:
            res = mod.search(q, engine=engine, max_results=max_results)
        except Exception:
            res = []
        out[q] = [{"title": r.get("title"), "url": r.get("url")} for r in (res or [])]
    return out


# ------------------------------------------------------------ 入口
def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    opt = _parse_args(argv)
    if opt.get("help"):
        print(_USAGE)
        return 0
    samples = load_samples(opt["from"], limit=opt["limit"])
    if not samples:
        print("[learn] 没有可用的未知样本（%s 为空或不存在）" % opt["from"])
        return 0
    groups = cluster(samples, min_count=opt["min_count"])
    res = None
    if opt["online"]:
        qs = []
        for g in groups[:5]:
            q = " ".join(g["key"].replace("<", " ").replace(">", " ").split()[:8])
            if q:
                qs.append(q)
        res = research(qs, engine=opt["engine"], max_results=5)
    draft = build_draft(samples, min_count=opt["min_count"],
                        limit=opt["limit"], research=res)
    if opt["json"]:
        print(json.dumps(draft, ensure_ascii=False, indent=2))
    else:
        m = draft["_meta"]
        print("[learn] 样本=%d 聚类=%d 候选规则=%d"
              % (m["sample_count"], m["cluster_count"], m["rule_count"]))
        for it in m["items"]:
            print("  %-34s x%-3d %s" % (it["code"], it["count"], " -> ".join(it["actions"])))
    if opt["dry_run"]:
        print("[learn] dry-run：未写盘")
        return 0
    if not draft["actions"]:
        print("[learn] 无新增规则，跳过写盘")
        return 0
    p = write_draft(draft, opt["out"])
    print("[learn] 草稿已写入 %s（人工审核后改名为 %s 才会生效）" % (p, LIVE_NAME))
    return 0


if __name__ == "__main__":
    sys.exit(main())
