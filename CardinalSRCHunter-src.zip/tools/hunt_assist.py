# -*- coding: utf-8 -*-
"""难例旁路分析器（阶段 5-2）。

定位
----
扫描器扫完一轮后，把"响应不匹配任何已知规则"的接口落进
``data/hunt_queue.jsonl``（阶段 5-1）。本工具**离线**读这份难例队列，
按确定性特征表把每条难例映射成"候选 payload + 触发条件"草稿，写到
``data/templates_ai/<id>.tpl.draft``，供人工审核后改名生效（阶段 5-3）。

数据流（单向，永不回流）
------------------------
::

    data/hunt_queue.jsonl --只读--> tools/hunt_assist.py（本文件，离线 CLI）
                                      |
                                      v
                    data/templates_ai/<id>.tpl.draft
                                      |
                                 人工审核改名
                                      v
                   扫描器读模板实测（阶段 5-3，未复现不写 findings）

红线遵守（三条）
----------------
1. **AI 永不进扫描热路径做决策**：本文件是离线 CLI，不被任何扫描代码
   import；它只读难例、只写草稿，从不参与扫描判定。
2. **产物必须人审后生效**：本文件**只写草稿后缀**（复用
   ``core.dicts.DRAFT_SUFFIX`` 这一契约单一来源），``ensure_tpl_draft_path``
   是硬护栏，任何输出路径都会被强制补成 ``*.tpl.draft``。
3. **本文件自身不做"决策"**：特征串 -> 候选 payload 的映射是确定性表
   （``_HUNT_PLAYBOOKS``），联网检索只写 ``_meta.research``；无 ``random``，
   同输入必同输出（可重入）。

遗留口径（阶段 5-3 已处理）
--------------------------
1. YAML/JSON：``templates/`` 下是 YAML，模板引擎只遍历 ``.yaml/.yml``；本工具
   产 JSON 草稿。已由 ``tools/hunt_promote.py``（5-3）补上正式化通道 —— 人审
   + ``--apply`` 后转 YAML 落 ``templates/``，详见 ``_meta.note``。
2. 指纹口径：``_fp_of`` 曾本地复制 sha1（method 缺省 "" vs "GET"、encode 严格
   vs replace、kind 缺省 "" vs "no_match" 三处与 ``core.hunt_queue`` 漂移），
   同一样本会算出不同指纹、tpl_id 与落盘 fp 对不上。5-3 起改为委托
   ``core.hunt_queue.fingerprint``，契约单一来源。

用法
----
::

    python3 tools/hunt_assist.py --mock --dry-run        # 离线自测
    python3 tools/hunt_assist.py --limit 50              # 读难例队列
    python3 tools/hunt_assist.py --online --engine bing  # 带联网参考
    python3 tools/hunt_assist.py --out-dir data/templates_ai
"""
import json
import os
import re
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core import config as cfg              # noqa: E402
from core import dicts as _dicts            # noqa: E402
from core import hunt_queue as _hunt_queue  # noqa: E402

# 草稿后缀：直接引用契约单一来源，本文件不写字面量（round39 D5 判据）。
DRAFT_SUFFIX = _dicts.DRAFT_SUFFIX
# 阶段 5-2 产物：一难例一文件，落 data/templates_ai/<id>.tpl.draft
TPL_DIR_NAME = "templates_ai"
HUNT_TPL_SUFFIX = ".tpl" + DRAFT_SUFFIX
DEFAULT_OUT_DIR = os.path.join(cfg.DATA_DIR, TPL_DIR_NAME)
# 难例队列：以 hunt_queue 模块常量为准（不重复写字面量）。
DEFAULT_QUEUE = _hunt_queue.HUNT_PATH

_USAGE = ("用法: python3 tools/hunt_assist.py "
          "[--from data/hunt_queue.jsonl] [--mock] [--limit N] "
          "[--out-dir data/templates_ai] [--online] [--engine auto|bing|baidu] "
          "[--dry-run] [--json]")


# ------------------------------------------------------------ 参数
def _parse_args(argv):
    """极简手写解析（与 tools/knowledge_learn.py / selfheal_learn.py 风格一致，便于单测）。"""
    opt = {"from": DEFAULT_QUEUE, "mock": False, "limit": 50,
           "out_dir": DEFAULT_OUT_DIR, "online": False, "engine": "auto",
           "dry_run": False, "json": False, "help": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opt["help"] = True
            i += 1
        elif a == "--mock":
            opt["mock"] = True
            i += 1
        elif a == "--online":
            opt["online"] = True
            i += 1
        elif a == "--dry-run":
            opt["dry_run"] = True
            i += 1
        elif a == "--json":
            opt["json"] = True
            i += 1
        elif a in ("--from", "--limit", "--out-dir", "--engine") and i + 1 < len(argv):
            k = {"--from": "from", "--limit": "limit",
                 "--out-dir": "out_dir", "--engine": "engine"}[a]
            v = argv[i + 1]
            if k == "limit":
                try:
                    v = int(v)
                except Exception:
                    v = opt[k]
            opt[k] = v
            i += 2
        else:
            i += 1
    return opt


# ------------------------------------------------------------ 难例素材（只读）
def load_queue(path=None, limit=50):
    """读难例队列 JSONL（**只读**，从不写回）。

    文件不存在 / 打开失败 / 单行坏 JSON 一律跳过——素材缺失不该让工具崩。
    只取最近 limit 条（队列是追加式，最近的样本最有价值）。
    """
    p = str(path or DEFAULT_QUEUE)
    if not os.path.isfile(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]
    except Exception:
        return []
    if limit:
        lines = lines[-int(limit):]
    out = []
    for line in lines:
        try:
            d = json.loads(line)
        except Exception:
            continue
        if isinstance(d, dict):
            out.append(d)
    return out


# 内置 mock 难例：覆盖 5 类特征 + 1 条无特征兜底，供离线自测（不读盘、不联网）。
_MOCK_SAMPLES = (
    {"fp": "1111111111111111111111111111111111111111",
     "at": "2026-10-09 00:00:01", "target": "10.0.0.11",
     "url": "http://10.0.0.11/item.php?id=1", "method": "GET", "param": "id",
     "kind": "no_match",
     "snippet": "You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version"},
    {"fp": "2222222222222222222222222222222222222222",
     "at": "2026-10-09 00:00:02", "target": "10.0.0.12",
     "url": "http://10.0.0.12/query.jsp?name=x", "method": "GET", "param": "name",
     "kind": "no_match",
     "snippet": "ORA-01756: quoted string not properly terminated"},
    {"fp": "3333333333333333333333333333333333333333",
     "at": "2026-10-09 00:00:03", "target": "10.0.0.13",
     "url": "http://10.0.0.13/api/v1/detail", "method": "POST", "param": "orderId",
     "kind": "no_match",
     "snippet": "Whitelabel Error Page This application has no explicit mapping for /error"},
    {"fp": "4444444444444444444444444444444444444444",
     "at": "2026-10-09 00:00:04", "target": "10.0.0.14",
     "url": "http://10.0.0.14/view?file=index.html", "method": "GET", "param": "file",
     "kind": "no_match",
     "snippet": "Traceback (most recent call last): File \"/app/main.py\", line 42, in view"},
    {"fp": "5555555555555555555555555555555555555555",
     "at": "2026-10-09 00:00:05", "target": "10.0.0.15",
     "url": "http://10.0.0.15/dl?path=a.txt", "method": "GET", "param": "path",
     "kind": "no_match",
     "snippet": "root:x:0:0:root:/root:/bin/bash daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin"},
    {"fp": "6666666666666666666666666666666666666666",
     "at": "2026-10-09 00:00:06", "target": "10.0.0.16",
     "url": "http://10.0.0.16/svc/echo?msg=hi", "method": "GET", "param": "msg",
     "kind": "no_match",
     "snippet": "{\"code\":0,\"msg\":\"ok\",\"data\":{\"echo\":\"hi\"}}"},
)


def mock_samples():
    """返回内置 mock 难例的**副本**（调用方改动不污染常量）。"""
    return [dict(s) for s in _MOCK_SAMPLES]


# ------------------------------------------------------------ 确定性映射表
# 顺序即优先级。元组：
#   (特征串, 组件, 类别, severity, 候选 payload 列表, 触发条件列表, 匹配词)
# 特征串全部小写，在 url+param+snippet+method 的小写 haystack 里做子串匹配。
# payload 是"候选假设"，**不是**结论 —— 人审后才可能进模板实测（5-3）。
_HUNT_PLAYBOOKS = (
    ("you have an error in your sql syntax", "mysql", "sqli", "high",
     ["'", "\"", "' OR '1'='1", "1' AND '1'='2"],
     ["响应体回显 MySQL 语法错误", "参数未做类型/转义校验", "报错随参数值变化"],
     ["SQL syntax", "mysql_fetch", "check the manual"]),
    ("microsoft ole db provider for sql server", "mssql", "sqli", "high",
     ["'", "';--", "1' AND 1=1--"],
     ["响应体回显 MSSQL OLE DB 错误", "参数直达数据库查询"],
     ["OLE DB", "SQL Server", "Unclosed quotation mark"]),
    ("ora-0", "oracle", "sqli", "high",
     ["'", "' OR 1=1--", "' UNION SELECT NULL--"],
     ["响应体回显 Oracle 错误码（ORA-）", "参数直达数据库查询"],
     ["ORA-", "Oracle", "quoted string"]),
    ("whitelabel error page", "spring", "error-disclosure", "medium",
     ["'", "{{7*7}}", "${7*7}"],
     ["Spring Boot 默认错误页暴露", "参数进入模板/表达式渲染"],
     ["Whitelabel Error Page", "no explicit mapping"]),
    ("traceback (most recent call last)", "python", "debug-disclosure", "medium",
     ["'", "{{7*7}}", "1/0"],
     ["Python 异常栈回显", "调试模式未关闭", "参数进入未捕获异常路径"],
     ["Traceback", "most recent call last"]),
    ("java.lang.nullpointerexception", "java", "debug-disclosure", "medium",
     ["'", "{{7*7}}", "%{7*7}"],
     ["Java 异常栈回显", "参数触发空指针路径"],
     ["NullPointerException", "java.lang"]),
    ("thinkphp", "thinkphp", "rce", "critical",
     ["?s=index/\\think\\app/invokefunction&function=call_user_func_array&vars[0]=phpinfo&vars[1][]=1"],
     ["响应含 ThinkPHP 特征", "框架版本存在已知远程调用面", "参数可影响路由解析"],
     ["ThinkPHP", "thinkphp"]),
    ("root:x:0:0", "linux", "lfi", "high",
     ["../../../../etc/passwd", "....//....//etc/passwd", "/etc/passwd%00"],
     ["响应体出现 /etc/passwd 内容", "参数被当作文件路径拼接"],
     ["root:x:0:0", "bin/bash"]),
    ("index of /", "apache", "dir-listing", "low",
     ["/", "../"],
     ["目录列表开启", "响应体出现 Apache 目录索引"],
     ["Index of /", "Parent Directory"]),
    ("{{", "template", "ssti", "high",
     ["{{7*7}}", "${7*7}", "<%= 7*7 %>"],
     ["参数进入模板渲染", "响应体回显模板语法特征"],
     ["{{", "}}"]),
)

# 无特征命中时的兜底：只给"注入面基础探测"候选，不猜组件。
# 结构与 _HUNT_PLAYBOOKS 的 7 元组**完全同构**（首位是"命中特征串"，兜底为空串），
# 这样 build_template 可以统一按 7 解包 —— round42 首跑曾因此处 6 元组崩溃。
_FALLBACK = ("", "unknown", "generic-probe", "info",
             ["'", "\"", "{{7*7}}", "../../../../etc/passwd"],
             ["响应未匹配任何已知规则（难例）", "参数类型与用途未知",
              "需人工确认参数是否进入可控上下文"],
             ["error", "exception", "stack"])


def _hay(sample):
    """把一条难例的可检索字段拼成小写 haystack。"""
    return " ".join([str(sample.get("url") or ""),
                     str(sample.get("param") or ""),
                     str(sample.get("snippet") or ""),
                     str(sample.get("method") or "")]).lower()


def classify(sample):
    """确定性分类：返回 (playbook, 命中特征串)。未命中返回 (兜底, "")。"""
    h = _hay(sample)
    for pb in _HUNT_PLAYBOOKS:
        if pb[0] in h:
            return pb, pb[0]
    return _FALLBACK, ""


def _fp_of(sample):
    """取样本指纹；缺失时委托 ``hunt_queue.fingerprint`` 现算（同输入同输出）。

    阶段 5-3 统一口径：本文件不再本地复制 sha1 逻辑。此前三处漂移（method
    缺省 "" vs "GET"、encode 严格 vs replace、kind 缺省 "" vs "no_match"）
    会导致同一样本在难例队列与本工具算出不同指纹、tpl_id 与落盘 fp 对不上。
    现在契约单一来源 = ``core.hunt_queue.fingerprint``。
    """
    fp = str(sample.get("fp") or "").strip()
    if fp:
        return fp
    return _hunt_queue.fingerprint(sample)


def _tpl_id(sample):
    """模板 id：``hunt-<fp 前 12 位>``（满足 ^[a-z0-9][a-z0-9_\\-]{1,63}$）。"""
    return "hunt-" + _fp_of(sample)[:12].lower()


def _path_for(sample, payload):
    """由难例 url + param 构造候选探测路径（保留原 payload 原文，便于人审）。"""
    url = str(sample.get("url") or "")
    param = str(sample.get("param") or "").strip()
    m = re.match(r"^([a-zA-Z][a-zA-Z0-9+.\-]*://[^/?#]+)([^?#]*)(?:\?([^#]*))?", url)
    if not m:
        return "{{BaseURL}}/"
    path = m.group(2) or "/"
    query = m.group(3) or ""
    if param:
        keep = [p for p in query.split("&") if p and p.split("=")[0] != param]
        q = "&".join(keep)
        q = (q + "&" if q else "") + "%s=%s" % (param, payload)
    else:
        q = query
    return "{{BaseURL}}%s%s" % (path, ("?" + q) if q else "")


# ------------------------------------------------------------ 模板结构校验
# 复刻 template_engine.validate_template 的关键分支（与 knowledge_learn._tpl_ok
# 同口径）。本工具**不 import modules.template_engine**，守住"离线工具不依赖
# 执行链"的隔离原则；round42 用真 validate_template 做交叉验证。
_ALLOWED_SEV = ("critical", "high", "medium", "low", "info")
_ALLOWED_MT = ("status", "word", "regex", "dsl")
_ALLOWED_PART = ("body", "header", "all")
_ALLOWED_METHODS = ("GET", "HEAD", "POST")
_MAX_PATHS = 6
_TPL_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_\-]{1,63}$")


def _tpl_ok(t):
    """内联最小校验，返回 (ok, reason)。"""
    if not isinstance(t, dict):
        return False, "模板不是映射"
    if not _TPL_ID_RE.match(str(t.get("id") or "").strip()):
        return False, "id 非法"
    info = t.get("info")
    if not isinstance(info, dict) or not str(info.get("name") or "").strip():
        return False, "info.name 缺失"
    if str(info.get("severity") or "").strip().lower() not in _ALLOWED_SEV:
        return False, "info.severity 非法"
    reqs = t.get("http")
    if not isinstance(reqs, list) or not reqs:
        return False, "缺少 http 段"
    for req in reqs:
        if not isinstance(req, dict):
            return False, "http 项不是映射"
        if str(req.get("method") or "GET").strip().upper() not in _ALLOWED_METHODS:
            return False, "method 非法"
        paths = req.get("path")
        if not isinstance(paths, list) or not paths or len(paths) > _MAX_PATHS:
            return False, "path 缺失或超限"
        mats = req.get("matchers")
        if not isinstance(mats, list) or not mats:
            return False, "matchers 缺失"
        for m in mats:
            if not isinstance(m, dict):
                return False, "matcher 不是映射"
            mt = str(m.get("type") or "").strip().lower()
            if mt not in _ALLOWED_MT:
                return False, "matcher 类型非法"
            if mt in ("word", "regex") and str(m.get("part") or "body").strip().lower() not in _ALLOWED_PART:
                return False, "matcher part 非法"
            if mt == "status" and not m.get("status"):
                return False, "status matcher 缺 status"
            if mt == "word" and not m.get("words"):
                return False, "word matcher 缺 words"
    return True, ""


# ------------------------------------------------------------ 生成
# ------------------------------------------------------------ AI 增强（可选层）
def _ai_ready():
    """双开关就绪（与 Config.ai_ready 同源）；任何异常一律视为未就绪。"""
    try:
        return bool(cfg.Config().ai_ready())
    except Exception:
        return False


def _ai_enhance():
    """动态加载 tools/ai_enhance.py（与 research() 加载 websearch 同款，不改导入面）。"""
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "ai_enhance.py")
        if not os.path.isfile(p):
            return None
        spec = importlib.util.spec_from_file_location("bt_ai_enhance", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _ai_trigger(t, sample):
    """用 AI 增强层补 trigger 的 payload/alternatives/conditions/why。

    有则覆盖、无则保留确定性原值 —— 只动这四个语义字段，键集不增删。
    """
    trg = t.get("trigger")
    if not isinstance(trg, dict):
        return
    try:
        if not _ai_ready():
            return
        _enh = _ai_enhance()
        if _enh is None or not _enh.available():
            return
        pb, kw = classify(sample)
        ctx = {"url": str(sample.get("url") or ""),
               "component": pb[1], "category": pb[2], "feature": kw,
               "snippet": str(sample.get("snippet") or "")[:300]}
        sug = _enh.suggest_trigger(ctx, base_payload=trg.get("payload"))
        if not isinstance(sug, dict):
            return
        for k in ("payload", "alternatives", "conditions", "why"):
            if k in sug:
                trg[k] = sug[k]
    except Exception:
        return


def build_template(sample, research=None):
    """由一条难例生成一条候选模板（**草稿**，含触发条件）。"""
    pb, kw = classify(sample)
    _kw, component, category, sev, payloads, conds, words = pb
    payload = payloads[0]
    tid = _tpl_id(sample)
    method = str(sample.get("method") or "GET").strip().upper() or "GET"
    if method not in _ALLOWED_METHODS:
        method = "GET"
    param = str(sample.get("param") or "")
    t = {
        "id": tid,
        "info": {
            "name": "%s 难例候选探测（%s）" % (component, category),
            "severity": sev,
            "description": ("由难例队列离线归纳（特征 %s）。候选草稿，"
                            "须人工复核触发条件与 payload 后再启用。" % (kw or "无")),
            "tags": ["ai-draft", "hunt", component, category],
            "fix": ("确认该参数是否进入可控上下文；如是，对输入做类型约束与"
                    "转义，并在网关层统一拦截异常回显。"),
        },
        "http": [{
            "method": method,
            "path": [_path_for(sample, payload)],
            "matchers-condition": "and",
            "matchers": [
                {"type": "status", "status": [200, 500]},
                {"type": "word", "part": "body", "words": list(words),
                 "condition": "or"},
            ],
        }],
        "trigger": {
            "kind": str(sample.get("kind") or "no_match"),
            "source_fp": _fp_of(sample),
            "source_url": str(sample.get("url") or ""),
            "target": str(sample.get("target") or ""),
            "method": method,
            "param": param,
            "component": component,
            "category": category,
            "matched_feature": kw,
            "payload": payload,
            "alternatives": list(payloads[1:]),
            "conditions": list(conds),
            "why": ("扫描器对 %s 的五类检测全部未命中，且响应未匹配任何已知规则；"
                    "按特征串 '%s' 归入 %s/%s 候选面。"
                    % (str(sample.get("url") or ""), kw or "(无)", component, category)),
            "evidence": str(sample.get("snippet") or "")[:300],
            "research": (research or {}).get(kw or component, []),
        },
    }
    _ai_trigger(t, sample)
    return t


def build_assist(samples, research=None, source="hunt_queue.jsonl"):
    """把难例列表归纳成 ``{"templates": [...], "_meta": {...}}``。

    每条先过 ``_tpl_ok``；不过的直接丢弃（结构合法的硬保证）。
    同 id 只出一条，顺序按 (component, category, id) —— 确定性无随机。
    """
    tpls, seen, dropped = [], set(), []
    for s in samples or []:
        if not isinstance(s, dict):
            continue
        t = build_template(s, research=research)
        ok, why = _tpl_ok(t)
        if not ok:
            dropped.append("%s:%s" % (t.get("id"), why))
            continue
        if t["id"] in seen:
            continue
        seen.add(t["id"])
        tpls.append(t)
    tpls.sort(key=lambda x: (x["trigger"]["component"],
                             x["trigger"]["category"], x["id"]))
    batch = {"templates": tpls}
    batch["_meta"] = {
        "generator": "tools/hunt_assist.py",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": str(source or ""),
        "sample_count": len([s for s in (samples or []) if isinstance(s, dict)]),
        "rule_count": len(tpls),
        "dropped": dropped,
        "items": [{"template_id": t["id"],
                   "component": t["trigger"]["component"],
                   "category": t["trigger"]["category"],
                   "payload": t["trigger"]["payload"]} for t in tpls],
        "research": research or {},
        "note": ("草稿。人工审核后改名为 <id>.tpl 才进入实测（阶段 5-3）；"
                 "未复现不写 findings。注意 templates/ 目前只吃 YAML，"
                 "JSON 草稿需人工转写或补读取路径。"),
    }
    return batch


def validate_assist(obj):
    """结构合法性自校验：逐条走 _tpl_ok，并强制"含触发条件"。"""
    if not isinstance(obj, dict):
        return False, "顶层不是映射"
    tpls = obj.get("templates")
    if not isinstance(tpls, list):
        return False, "templates 不是列表"
    seen = set()
    for t in tpls:
        ok, why = _tpl_ok(t)
        if not ok:
            return False, "模板 %r 非法: %s" % (
                (t or {}).get("id") if isinstance(t, dict) else t, why)
        if t["id"] in seen:
            return False, "模板 id 重复: %s" % t["id"]
        seen.add(t["id"])
        trg = t.get("trigger")
        if not isinstance(trg, dict):
            return False, "模板 %s 缺 trigger（触发条件）" % t["id"]
        if not str(trg.get("payload") or "").strip():
            return False, "模板 %s trigger.payload 为空" % t["id"]
        if not isinstance(trg.get("conditions"), list) or not trg["conditions"]:
            return False, "模板 %s trigger.conditions 为空" % t["id"]
    if not isinstance(obj.get("_meta"), dict):
        return False, "_meta 缺失"
    return True, ""


# ------------------------------------------------------------ 写盘（硬护栏 + 原子写）
def ensure_tpl_draft_path(path, default=None):
    """硬护栏：写盘路径必须以草稿后缀结尾，防止误写正式文件。

    非 ``.draft`` 结尾一律补 ``.tpl.draft``（保留调用方给的主干名）。
    """
    p = str(path or default or "")
    if not p:
        p = os.path.join(DEFAULT_OUT_DIR, "hunt.tpl" + DRAFT_SUFFIX)
    if not p.endswith(DRAFT_SUFFIX):
        p = p + HUNT_TPL_SUFFIX
    return p


def write_one(obj, path=None, default=None):
    """原子写单条草稿（tmp + replace）。返回实际写入路径。"""
    p = ensure_tpl_draft_path(path, default)
    d = os.path.dirname(p)
    if d:
        os.makedirs(d, exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return p


def write_batch(batch, out_dir=None):
    """把批次写成一难例一文件 + 一个 ``_index.json.draft``。返回写入路径列表。"""
    d = str(out_dir or DEFAULT_OUT_DIR)
    os.makedirs(d, exist_ok=True)
    written = []
    for t in batch.get("templates", []):
        p = ensure_tpl_draft_path(os.path.join(d, "%s.tpl%s" % (t["id"], DRAFT_SUFFIX)))
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(t, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        written.append(p)
    idx = ensure_tpl_draft_path(os.path.join(d, "_index.json" + DRAFT_SUFFIX))
    tmp = idx + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(batch.get("_meta", {}), f, ensure_ascii=False, indent=2)
    os.replace(tmp, idx)
    written.append(idx)
    return written


# ------------------------------------------------------------ 联网参考（可选）
def research(queries, engine="auto", max_results=5):
    """用 tools/websearch.py 取参考资料（只进 ``_meta.research``，不参与生成）。

    动态加载是**唯一取数出口**（round37 A5 同款约束），失败静默返回空。
    """
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "websearch.py")
        spec = importlib.util.spec_from_file_location("bt_websearch", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    except Exception:
        return {}
    out = {}
    for q in queries:
        try:
            res = mod.search(q, engine=engine, max_results=max_results)
        except Exception:
            res = []
        out[q] = [{"title": r.get("title"), "url": r.get("url")}
                  for r in (res or [])]
    return out


# ------------------------------------------------------------ 入口
def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    opt = _parse_args(argv)
    if opt.get("help"):
        print(_USAGE)
        return 0
    if opt["mock"]:
        samples, src = mock_samples(), "mock://built-in"
    else:
        samples, src = load_queue(opt["from"], limit=opt["limit"]), opt["from"]
    if not samples:
        print("[hunt] 没有可用的难例样本（%s 为空或不存在）" % src)
        return 0
    res = None
    if opt["online"]:
        seen_q = []
        for s in samples[:5]:
            pb, kw = classify(s)
            q = "%s %s payload 触发条件" % (pb[1], pb[2])
            if q not in seen_q:
                seen_q.append(q)
        res = research(seen_q, engine=opt["engine"], max_results=5)
    batch = build_assist(samples, research=res, source=src)
    ok, why = validate_assist(batch)
    if not ok:
        print("[hunt] 自校验失败：%s" % why)
        return 2
    if opt["json"]:
        print(json.dumps(batch, ensure_ascii=False, indent=2))
    else:
        m = batch["_meta"]
        print("[hunt] 样本=%d 产出=%d 丢弃=%d 目录=%s"
              % (m["sample_count"], m["rule_count"], len(m["dropped"]),
                 opt["out_dir"]))
        for it in m["items"]:
            print("  %-28s %-16s %-8s %s"
                  % (it["template_id"], it["component"], it["category"],
                     it["payload"]))
    if opt["dry_run"]:
        print("[hunt] dry-run：未写盘")
        return 0
    written = write_batch(batch, opt["out_dir"])
    print("[hunt] 草稿已写入 %d 个文件到 %s（人工审核改名后才会生效）"
          % (len(written), opt["out_dir"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
