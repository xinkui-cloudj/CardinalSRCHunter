# -*- coding: utf-8 -*-
"""难例回流（round73 P0）：把 data/hunt_queue.jsonl 只写不读的死数据接给 AI。

背景
----
阶段 5-1 把"有可测参数、五类检测全不命中"的接口原样落进
``data/hunt_queue.jsonl``；阶段 5-2/5-3 只做**离线**草稿与人审，扫描热路径
从不读它 —— 于是这份名单越攒越多、没有任何一侧消费（死数据）。

本模块做一件很小的事：**在 AI 接管分支里读一次这份名单**，转成两条
"AI 任务清单"文本（系统提示尾巴 + 用户提示尾巴），交给已有的
``tools/agent_loop.run_agent`` 多跑一轮。

红线（三条，与阶段 5-1/5-2/5-3 同口径）
---------------------------------------
1. **不改规则主流程**：本模块只被 engine 的 AI 接管分支（可选钩子）调用；
   AI 关闭时整段不执行，扫描行为与 round72 完全一致。
2. **不新开旁路**：AI 使用的仍是 ``tool_registry`` 里已注册的工具，因此
   出网天然走 ``engine.client`` 的同一限速器，且同样受 ``enable_active`` /
   ``enable_poc`` 闸门、scope 授权、预算与 ``_stop`` 约束。
3. **只读不写**：本模块不写 hunt_queue（落盘仍只由阶段 5-1 的
   ``record_many`` 负责），也不做任何判定。

去重与限流
----------
- 指纹去重沿用 ``core.hunt_queue.fingerprint``（契约单一来源）；
- 同一目标跨轮次重复扫描时，同一接口**只回流一次**（``_LAST_SEEN``）；
- 单轮条数上限走 ``takeover.hunt_max``（默认 8，配 0 即关闭回流）。
"""
import json

from core import hunt_queue

# 单轮回流的条数上限（可被 takeover.hunt_max 覆盖）
DEFAULT_MAX = 8

# 每条清单里 url / snippet 的最大字符数
_MAX_FIELD = 300

_LAST_SEEN = {}          # {target: set(fp)} 已回流过的指纹（进程内）

# 最近一次 build_notes 实际取到的清单（给 engine 记日志用，只读快照）
LAST_PICKED = []

_SYSTEM_HEAD = (
    "\n\n【难例回流】以下接口是确定性规则跑完五类检测后**零命中**的盲区，"
    "它们有可测参数但现有字典没打通。请针对它们重扫：先看 URL/参数名判断语义"
    "（如 id=数字、q=搜索、url=/redirect=跳转、file=文件名、page=页码、token=令牌），"
    "再自行决定调哪个检测工具、带哪些参数；不得编造工具未返回的结果。\n"
    "若内置字典打不通，可自造 payload 并通过 check_sqli / check_xss 的可选 payloads 数组参数传入（工具只负责发出去与判响应，单次上限 12 条）。\n"
)

_USER_HEAD = (
    "\n\n补充任务：以下 {n} 个接口确定性规则零命中，请重扫并给出结论。\n"
)


def _clip(s, n=_MAX_FIELD):
    """安全截断：落盘数据可能很长或含换行，塞进提示词前必须归一。"""
    s = str(s or "").replace("\r", " ").replace("\n", " ").strip()
    return s if len(s) <= n else s[:n] + "..."


def limit_of(engine):
    """读 ``takeover.hunt_max``（带默认与钳制，只读不写）。

    0 表示关闭回流；非法值回落默认。
    """
    raw = None
    try:
        cfg = engine.config.get("takeover") if hasattr(engine.config, "get") else None
        if isinstance(cfg, dict):
            raw = cfg.get("hunt_max")
    except Exception:
        raw = None
    if raw is None:
        return DEFAULT_MAX
    try:
        v = int(raw)
    except Exception:
        return DEFAULT_MAX
    return max(0, min(50, v))


def _fp_of(row):
    """指纹算不到就退化成整行 json（保证一定有条可用键）。"""
    try:
        return hunt_queue.fingerprint(row)
    except Exception:
        return json.dumps(row, ensure_ascii=False, sort_keys=True)


def _host_only(s):
    """从 url / host[:port] / scheme://host 中提取纯主机名（小写）。"""
    t = str(s or '').strip()
    if not t:
        return ''
    if '://' not in t:
        t = '//' + t.lstrip('/')
    try:
        from urllib.parse import urlparse as _up
        return (_up(t).hostname or '').lower()
    except Exception:
        return ''
def _is_local(host):
    """本机/内网地址判定：这类地址只在目标自身也是本机时才允许回流。"""
    h = (host or '').lower()
    if not h:
        return False
    if h in ('localhost', '::1', '0.0.0.0'):
        return True
    try:
        import ipaddress as _ip
        a = _ip.ip_address(h)
        return bool(a.is_loopback or a.is_private or a.is_link_local)
    except ValueError:
        return h.endswith('.local')
def in_target_scope(url, target):
    """FIX-30：回流项的 URL 必须属于本次授权目标，否则一律丢弃。

    背景：data/hunt_queue.jsonl 里可能残留历史上扫描本机靶场（127.0.0.1:8081
    这类）的旧行；旧实现只按 target 去重、不校验 URL 归属，于是旧行被当成
    "难例" 回灌给 AI，AI 真去打自己的手机，fake 洞落进客户报告（实测 6 条）。
    规则：
      1. target 为空 -> 不放行（回流是给目标补扫，目标不明就不该开枪）；
      2. 本机/内网 URL 仅当 target 本身也是本机/内网时才放行（保留本地靶场）；
      3. 其余要求 host 等于 target 主机或为其子域。
    """
    th = _host_only(target)
    if not th:
        return False
    uh = _host_only(url)
    if not uh:
        return False
    if _is_local(uh) or _is_local(th):
        return uh == th
    return uh == th or uh.endswith('.' + th)

def pick(engine, target="", limit=None):
    """读难例队列 -> 去重后待重扫清单（最新优先）。

    返回 ``[{"fp","url","method","param","kind","snippet"}, ...]``。
    任何异常都吞掉并返回已得结果——回流是旁路，绝不影响扫描。
    """
    n_lim = limit_of(engine) if limit is None else max(0, int(limit))
    if n_lim <= 0:
        return []
    rows = []
    try:
        rows = hunt_queue.tail(200)      # 只读、不写、不裁文件
    except Exception:
        rows = []
    key = str(target or "")
    seen = _LAST_SEEN.get(key)
    if seen is None:
        seen = set()
        _LAST_SEEN[key] = seen
    out = []
    _dropped = []
    for row in reversed(rows or []):      # 最新优先
        if not isinstance(row, dict):
            continue
        url = str(row.get("url") or "").strip()
        if not url:
            continue
        fp = str(row.get("fp") or "") or _fp_of(row)
        if fp in seen:
            continue
        # FIX-30 作用域门禁：队列里可能残留历史扫描本机靶场的旧行，
        # 不校验归属就会把 127.0.0.1 这类地址当成本次目标的难例交给 AI。
        if not in_target_scope(url, target):
            _dropped.append(url)
            continue
        seen.add(fp)
        out.append({
            "fp": fp,
            "url": url,
            "method": str(row.get("method") or "GET").upper(),
            "param": str(row.get("param") or ""),
            "kind": str(row.get("kind") or "no_match"),
            "snippet": str(row.get("snippet") or ""),
        })
        if len(out) >= n_lim:
            break
    if _dropped:
        try:
            from core import logger as _lgx
            _lgx.get("bt.hunt").warning(
                "[难例回流] 丢弃 %d 条目标外 URL（不属于 %s）：%s",
                len(_dropped), target, _dropped[:3])
        except Exception:
            pass
    return out


def render(items):
    """清单 -> 提示词片段（``(system_tail, user_tail)``）。

    snippet 只描述"参数形状"，不塞原始响应体，避免无谓撑大 token。
    """
    if not items:
        return ("", "")
    lines = []
    for i, it in enumerate(items, 1):
        seg = "%d. %s %s\n   参数: %s\n   形状: %s" % (
            i, it["method"], _clip(it["url"], 240),
            _clip(it["param"], 60) or "(未命名)",
            _clip(it["snippet"], 160))
        lines.append(seg)
    block = "\n".join(lines)
    return (_SYSTEM_HEAD + block, _USER_HEAD.format(n=len(items)) + block)


def build_notes(engine, target=""):
    """一步到位：取清单 + 渲染提示词，并记一行日志。

    返回 ``(system_tail, user_tail)``；无难例时返回 ``("", "")``。
    """
    try:
        items = pick(engine, target=target)
    except Exception:
        items = []
    if not items:
        return ("", "")
    notes = render(items)
    global LAST_PICKED
    LAST_PICKED = list(items)
    tl = len(items)
    try:
        from core import logger as _lg
        _lg.get("bt.engine").info(
            "[难例回流] 取 %d 条零命中接口交给 AI 重扫（目标 %s）", tl, target)
    except Exception:
        pass
    return notes


def reset(target=None):
    """测试用：清空"已回流"缓存（不传则全清）。"""
    if target is None:
        _LAST_SEEN.clear()
    else:
        _LAST_SEEN.pop(str(target), None)
