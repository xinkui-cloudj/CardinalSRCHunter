# -*- coding: utf-8 -*-
"""联网批处理知识学习器（阶段 2-2）。

定位
----
把"已抓到的资产指纹 / 标题 / 技术栈"（``data/findings.db`` 的 assets 表）
离线归纳成**字典草稿 + 模板草稿**，供人工审核后改名生效。
可选联网检索（Google / SO / GitHub issues / 厂商文档）只取参考资料写入
``_meta.research``，**不参与生成**——生成完全由确定性表决定。

数据流（单向，永不回流）
------------------------
::

    data/findings.db --只读--> tools/knowledge_learn.py（本文件，离线 CLI）
                                     |
               +---------------------+---------------------+
               v                                           v
    data/dicts_ai.json[SUF]                data/templates_ai.json[SUF]
               |                                           |
          人工审核改名                                 人工审核改名
               v                                           v
    data/dicts_ai.json                     data/templates_ai.json
      （阶段 3-4 并入字典加载）               （模板引擎校验后启用）

红线遵守（三条）
----------------
1. **AI 永不进扫描热路径做决策**：本文件是离线 CLI，不被任何扫描代码
   import；其产物只是静态数据，由人审后由加载侧只读读取。
2. **产物必须人审后生效**：本文件**只写草稿后缀**（复用
   ``core.dicts.DRAFT_SUFFIX`` 这一契约单一来源），绝不写正式文件；
   ``ensure_draft_path`` 是硬护栏。
3. **本文件自身不做"决策"**：关键词 -> 词条 / 模板骨架的映射是确定性表
   （``_COMPONENT_PROBES``），联网检索只写 ``_meta.research``；
   无 ``random``，同输入必同输出（可重入）。

用法
----
::

    python3 tools/knowledge_learn.py --mock --dry-run        # 离线自测
    python3 tools/knowledge_learn.py --limit 500             # 读 DB 归纳
    python3 tools/knowledge_learn.py --online --engine bing  # 带联网参考
    python3 tools/knowledge_learn.py --dict-out data/my.json # 自动补草稿后缀
"""
import json
import os
import re
import sqlite3
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core import config as cfg          # noqa: E402
from core import dicts as _dicts        # noqa: E402

# 草稿后缀：直接引用契约单一来源，本文件不写字面量（round39 D5 判据）。
DRAFT_SUFFIX = _dicts.DRAFT_SUFFIX
# 正式位：人审改名后即生效（与阶段 3-4 的加载位对齐）。
DICT_LIVE_NAME = "dicts_ai.json"
TPL_LIVE_NAME = "templates_ai.json"
DEFAULT_DICT_DRAFT = os.path.join(cfg.DATA_DIR, DICT_LIVE_NAME) + DRAFT_SUFFIX
DEFAULT_TPL_DRAFT = os.path.join(cfg.DATA_DIR, TPL_LIVE_NAME) + DRAFT_SUFFIX
DEFAULT_DB = os.path.join(cfg.DATA_DIR, "findings.db")

_USAGE = ("用法: python3 tools/knowledge_learn.py "
          "[--from data/findings.db] [--mock] [--limit N] [--min-count N] "
          "[--dict-out PATH] [--tpl-out PATH] [--online] [--engine auto|bing|baidu] "
          "[--dry-run] [--json]")


# ------------------------------------------------------------ 参数
def _parse_args(argv):
    """极简手写解析（与 tools/selfheal_learn.py / websearch.py 风格一致，便于单测）。"""
    opt = {"from": DEFAULT_DB, "mock": False, "limit": 500, "min_count": 1,
           "dict_out": DEFAULT_DICT_DRAFT, "tpl_out": DEFAULT_TPL_DRAFT,
           "online": False, "engine": "auto", "dry_run": False, "json": False,
           "help": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opt["help"] = True
            i += 1
        elif a == "--mock":
            opt["mock"] = True
            i += 1
        elif a == "--online":
            opt["online"] = True
            i += 1
        elif a == "--dry-run":
            opt["dry_run"] = True
            i += 1
        elif a == "--json":
            opt["json"] = True
            i += 1
        elif a in ("--from", "--limit", "--min-count", "--dict-out", "--tpl-out",
                   "--engine") and i + 1 < len(argv):
            k = {"--from": "from", "--limit": "limit", "--min-count": "min_count",
                 "--dict-out": "dict_out", "--tpl-out": "tpl_out",
                 "--engine": "engine"}[a]
            v = argv[i + 1]
            if k in ("limit", "min_count"):
                try:
                    v = int(v)
                except Exception:
                    v = opt[k]
            opt[k] = v
            i += 2
        else:
            i += 1
    return opt


# ------------------------------------------------------------ 素材（只读）
def load_assets(path=None, limit=500):
    """读 ``findings.db`` 的 assets 表（**只读**，从不写回）。

    库不存在 / 表缺失 / 打开失败一律返回空列表——素材缺失不该让工具崩。
    只取归纳需要的五列，不碰 request/response 等大字段。
    """
    p = path or DEFAULT_DB
    if not os.path.isfile(p):
        return []
    out = []
    conn = None
    try:
        try:
            conn = sqlite3.connect("file:%s?mode=ro" % p, uri=True)
        except Exception:
            conn = sqlite3.connect(p)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT host,url,title,tech,server,status FROM assets ORDER BY id"
        ).fetchall()
        for r in rows:
            out.append({k: str(r[k] or "") for k in
                        ("host", "url", "title", "tech", "server", "status")})
    except Exception:
        return []
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    if limit and len(out) > int(limit):
        out = out[-int(limit):]
    return out


# 内置 mock 素材：覆盖 6 类组件，供离线自测（不读 DB、不联网）。
_MOCK_ASSETS = (
    {"host": "10.0.0.11", "url": "http://10.0.0.11:6379/", "title": "",
     "tech": "Redis", "server": "", "status": "200"},
    {"host": "10.0.0.12", "url": "http://10.0.0.12/jenkins/", "title": "Jenkins",
     "tech": "Jenkins", "server": "Jetty", "status": "200"},
    {"host": "10.0.0.13", "url": "http://10.0.0.13/nacos/index.html", "title": "Nacos",
     "tech": "Nacos", "server": "nginx", "status": "200"},
    {"host": "10.0.0.14", "url": "http://10.0.0.14/login", "title": "Grafana",
     "tech": "Grafana", "server": "nginx", "status": "200"},
    {"host": "10.0.0.15", "url": "http://10.0.0.15/actuator/health", "title": "",
     "tech": "Spring Boot", "server": "", "status": "200"},
    {"host": "10.0.0.16", "url": "http://10.0.0.16/phpmyadmin/", "title": "phpMyAdmin",
     "tech": "PHP", "server": "Apache/2.4", "status": "200"},
)


def mock_assets():
    """返回内置 mock 素材的**副本**（调用方改动不污染常量）。"""
    return [dict(a) for a in _MOCK_ASSETS]


# ------------------------------------------------------------ 提取
def _hay(a):
    """把一条素材的可检索字段拼成小写 haystack。"""
    return " ".join([str(a.get("title") or ""), str(a.get("tech") or ""),
                     str(a.get("server") or ""), str(a.get("url") or ""),
                     str(a.get("host") or "")]).lower()


def _first_seg(url):
    """从 url 取首个路径段（目录词候选）。取不到返回空串。"""
    m = re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://[^/]+/([^/?#]+)", str(url or ""))
    if not m:
        return ""
    seg = m.group(1).strip().lower()
    if not seg or len(seg) > 24:
        return ""
    return re.sub(r"[^a-z0-9_\-.]", "", seg)


# ------------------------------------------------------------ 确定性映射
# 顺序即优先级；(关键词, 模板 id, 名称, severity, 路径列表, 特征词)。
# 特征词须是"内容特征串"，不靠状态码猜存在性（与 templates/*.yaml 同原则）。
# 模板 id 须匹配 ^[a-z0-9][a-z0-9_\-]{1,63}$（与 template_engine 白名单一致）。
_COMPONENT_PROBES = (
    ("redis", "redis-info-probe", "Redis 未授权信息泄露探测", "high",
     ["/"], ["redis_version", "redis_mode"]),
    ("jenkins", "jenkins-panel-probe", "Jenkins 控制台暴露探测", "medium",
     ["/login", "/"], ["Jenkins", "jenkins"]),
    ("gitlab", "gitlab-panel-probe", "GitLab 面板暴露探测", "medium",
     ["/users/sign_in", "/"], ["GitLab", "gitlab"]),
    ("nacos", "nacos-panel-probe", "Nacos 控制台暴露探测", "high",
     ["/nacos/", "/nacos/index.html"], ["Nacos", "nacos"]),
    ("druid", "druid-panel-probe", "Druid 监控台暴露探测", "high",
     ["/druid/index.html", "/druid/websession.html"], ["Druid", "druid"]),
    ("grafana", "grafana-panel-probe", "Grafana 面板暴露探测", "medium",
     ["/login", "/api/health"], ["Grafana", "grafana"]),
    ("kibana", "kibana-panel-probe", "Kibana 面板暴露探测", "medium",
     ["/app/kibana", "/api/status"], ["kibana", "Kibana"]),
    ("prometheus", "prometheus-metrics-probe", "Prometheus 指标接口暴露探测", "medium",
     ["/metrics", "/graph"], ["prometheus", "Prometheus"]),
    ("zabbix", "zabbix-panel-probe", "Zabbix 面板暴露探测", "medium",
     ["/zabbix/", "/index.php"], ["Zabbix", "zabbix"]),
    ("elasticsearch", "elasticsearch-info-probe", "Elasticsearch 信息泄露探测", "high",
     ["/"], ["you know, for search", "cluster_name"]),
    ("tomcat", "tomcat-manager-probe", "Tomcat 管理台暴露探测", "medium",
     ["/manager/html", "/host-manager/html"], ["Tomcat", "Apache-Coyote"]),
    ("phpmyadmin", "phpmyadmin-panel-probe", "phpMyAdmin 面板暴露探测", "medium",
     ["/phpmyadmin/", "/phpMyAdmin/"], ["phpMyAdmin", "pma_password"]),
    ("spring", "spring-actuator-probe", "Spring Boot Actuator 暴露探测", "high",
     ["/actuator", "/actuator/health"], ["_links", "actuator"]),
    ("thinkphp", "thinkphp-version-probe", "ThinkPHP 版本信息探测", "medium",
     ["/index.php", "/?s=index/index"], ["ThinkPHP", "thinkphp"]),
    ("shiro", "shiro-rememberme-probe", "Shiro rememberMe 特征探测", "medium",
     ["/"], ["rememberMe=", "shiro"]),
    ("weblogic", "weblogic-console-probe", "Weblogic 控制台暴露探测", "high",
     ["/console/login/LoginForm.jsp", "/console/"], ["WebLogic", "weblogic"]),
    ("consul", "consul-ui-probe", "Consul 控制台暴露探测", "high",
     ["/ui/", "/v1/status/leader"], ["Consul", "consul"]),
    ("zookeeper", "zookeeper-stat-probe", "Zookeeper 状态接口暴露探测", "high",
     ["/"], ["Zookeeper", "zookeeper"]),
)


def component_hits(assets, min_count=1):
    """统计素材里命中的组件关键词（确定性：按计数降序 + 名称升序）。"""
    counts = {}
    for a in assets or []:
        if not isinstance(a, dict):
            continue
        h = _hay(a)
        for probe in _COMPONENT_PROBES:
            kw = probe[0]
            if kw in h:
                counts[kw] = counts.get(kw, 0) + 1
    items = [(k, v) for k, v in counts.items() if v >= int(min_count)]
    items.sort(key=lambda kv: (-kv[1], kv[0]))
    return items


# ------------------------------------------------------------ 字典草稿
def build_dicts(assets, min_count=1, limit=500, research=None, source="findings.db"):
    """把素材归纳成 ``{"subdomain_words": [...], "dir_words": [...], "creds": [...]}``。

    顶层三键与阶段 3-4 的加载契约对齐；``_meta`` 只给人看，加载器不读。
    去重保序、排序确定 —— 同输入必同输出（``_meta.generated_at`` 除外）。
    """
    subs, creds, dirs = [], [], []
    for kw, _n in component_hits(assets, min_count=min_count):
        for w in (kw, kw + "admin", kw + "-test"):
            if w not in subs:
                subs.append(w)
        for c in (kw, kw + "123", kw + "@123"):
            if c not in creds:
                creds.append(c)
    for a in assets or []:
        if not isinstance(a, dict):
            continue
        d = _first_seg(a.get("url"))
        if d and d not in dirs:
            dirs.append(d)
    dirs.sort()
    draft = {"subdomain_words": subs, "dir_words": dirs, "creds": creds}
    draft["_meta"] = {
        "generator": "tools/knowledge_learn.py",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": str(source or ""),
        "sample_count": len([a for a in (assets or []) if isinstance(a, dict)]),
        "component_count": len(component_hits(assets, min_count=min_count)),
        "rule_count": len(subs),
        "items": [{"component": k, "count": n}
                  for k, n in component_hits(assets, min_count=min_count)],
        "research": research or {},
        "note": ("草稿。人工审核后改名为 %s 才会被扫描器加载（阶段 3-4 并入）。"
                 % DICT_LIVE_NAME),
    }
    return draft


# ------------------------------------------------------------ 模板草稿
_ALLOWED_SEV = ("critical", "high", "medium", "low", "info")
_ALLOWED_MT = ("status", "word", "regex", "dsl")
_ALLOWED_PART = ("body", "header", "all")
_ALLOWED_METHODS = ("GET", "HEAD", "POST")
_MAX_PATHS = 6
_TPL_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_\-]{1,63}$")


def _tpl_from_probe(probe):
    """由确定性骨架产一条模板（**候选草稿**，需人审后启用）。"""
    kw, tid, name, sev, paths, words = probe
    return {
        "id": tid,
        "info": {
            "name": name,
            "severity": sev,
            "description": ("由已抓到的资产技术栈归纳（关键词 %s）。"
                            "候选草稿，须人工复核特征串后再启用。" % kw),
            "tags": ["ai-draft", "exposure", kw],
            "fix": ("确认该管理/监控接口是否需要对外暴露；不需要则在网关层"
                    "限制来源并启用认证。"),
        },
        "http": [{
            "method": "GET",
            "path": ["{{BaseURL}}%s" % p for p in paths[:_MAX_PATHS]],
            "matchers-condition": "and",
            "matchers": [
                {"type": "status", "status": [200]},
                {"type": "word", "part": "body", "words": list(words),
                 "condition": "or"},
            ],
        }],
    }


def _tpl_ok(t):
    """内联最小校验（复刻 template_engine.validate_template 的关键分支）。

    本工具**不 import modules.template_engine**（守住"离线工具不依赖执行链"
    的隔离原则）；round40 用真 validate_template 对产物做交叉验证。
    """
    if not isinstance(t, dict):
        return False, "模板不是映射"
    if not _TPL_ID_RE.match(str(t.get("id") or "").strip()):
        return False, "id 非法"
    info = t.get("info")
    if not isinstance(info, dict) or not str(info.get("name") or "").strip():
        return False, "info.name 缺失"
    if str(info.get("severity") or "").strip().lower() not in _ALLOWED_SEV:
        return False, "info.severity 非法"
    reqs = t.get("http")
    if not isinstance(reqs, list) or not reqs:
        return False, "缺少 http 段"
    for req in reqs:
        if not isinstance(req, dict):
            return False, "http 项不是映射"
        if str(req.get("method") or "GET").strip().upper() not in _ALLOWED_METHODS:
            return False, "method 非法"
        paths = req.get("path")
        if not isinstance(paths, list) or not paths or len(paths) > _MAX_PATHS:
            return False, "path 缺失或超限"
        mats = req.get("matchers")
        if not isinstance(mats, list) or not mats:
            return False, "matchers 缺失"
        for m in mats:
            if not isinstance(m, dict):
                return False, "matcher 不是映射"
            mt = str(m.get("type") or "").strip().lower()
            if mt not in _ALLOWED_MT:
                return False, "matcher 类型非法"
            if mt in ("word", "regex") and str(m.get("part") or "body").strip().lower() not in _ALLOWED_PART:
                return False, "matcher part 非法"
            if mt == "status" and not m.get("status"):
                return False, "status matcher 缺 status"
            if mt == "word" and not m.get("words"):
                return False, "word matcher 缺 words"
            if mt == "regex":
                pats = m.get("regex")
                if not pats:
                    return False, "regex matcher 缺 regex"
                for pat in (pats if isinstance(pats, list) else [pats]):
                    try:
                        re.compile(str(pat))
                    except re.error:
                        return False, "正则编译失败"
    return True, ""


def build_templates(assets, min_count=1, limit=500, research=None, source="findings.db"):
    """把命中组件归纳成 ``{"templates": [...], "_meta": {...}}``。

    每条模板先过 ``_tpl_ok``；不过的直接丢弃（结构合法的硬保证）。
    同 id 只出一条，顺序按组件计数降序 —— 确定性无随机。
    """
    hits = component_hits(assets, min_count=min_count)
    probes = {p[0]: p for p in _COMPONENT_PROBES}
    tpls, seen, dropped = [], set(), []
    for kw, _n in hits:
        p = probes.get(kw)
        if p is None:
            continue
        t = _tpl_from_probe(p)
        ok, why = _tpl_ok(t)
        if not ok:
            dropped.append("%s:%s" % (kw, why))
            continue
        if t["id"] in seen:
            continue
        seen.add(t["id"])
        tpls.append(t)
    draft = {"templates": tpls}
    draft["_meta"] = {
        "generator": "tools/knowledge_learn.py",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": str(source or ""),
        "sample_count": len([a for a in (assets or []) if isinstance(a, dict)]),
        "component_count": len(hits),
        "rule_count": len(tpls),
        "dropped": dropped,
        "items": [{"template_id": t["id"], "severity": t["info"]["severity"]}
                  for t in tpls],
        "research": research or {},
        "note": ("草稿。人工审核后改名为 %s 才会被模板引擎加载。"
                 % TPL_LIVE_NAME),
    }
    return draft


# ------------------------------------------------------------ 结构自校验
def validate_dicts(d):
    """结构合法性自校验，返回 (ok, reason)。"""
    if not isinstance(d, dict):
        return False, "顶层不是映射"
    for k in ("subdomain_words", "dir_words", "creds"):
        v = d.get(k)
        if not isinstance(v, list):
            return False, "%s 不是列表" % k
        for it in v:
            if not isinstance(it, str) or not it.strip():
                return False, "%s 含非法项 %r" % (k, it)
    if not isinstance(d.get("_meta"), dict):
        return False, "_meta 缺失"
    return True, ""


def validate_templates(obj):
    """结构合法性自校验，返回 (ok, reason)。逐条走 _tpl_ok。"""
    if not isinstance(obj, dict):
        return False, "顶层不是映射"
    tpls = obj.get("templates")
    if not isinstance(tpls, list):
        return False, "templates 不是列表"
    seen = set()
    for t in tpls:
        ok, why = _tpl_ok(t)
        if not ok:
            return False, "模板 %r 非法: %s" % (
                (t or {}).get("id") if isinstance(t, dict) else t, why)
        if t["id"] in seen:
            return False, "模板 id 重复: %s" % t["id"]
        seen.add(t["id"])
    if not isinstance(obj.get("_meta"), dict):
        return False, "_meta 缺失"
    return True, ""


# ------------------------------------------------------------ 写盘（硬护栏 + 原子写）
def ensure_draft_path(path, default=None):
    """硬护栏：写盘路径必须以草稿后缀结尾，防止误写正式文件。"""
    p = str(path or default or DEFAULT_DICT_DRAFT)
    if not p.endswith(DRAFT_SUFFIX):
        p = p + DRAFT_SUFFIX
    return p


def write_draft(obj, path=None, default=None):
    """原子写草稿（tmp + replace）。返回实际写入路径。"""
    p = ensure_draft_path(path, default)
    d = os.path.dirname(p)
    if d:
        os.makedirs(d, exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return p


# ------------------------------------------------------------ 联网参考（可选）
def research(queries, engine="auto", max_results=5):
    """用 tools/websearch.py 取参考资料（只进 ``_meta``，不参与生成）。

    动态加载是**唯一取数出口**（round37 A5 同款约束），失败静默返回空。
    """
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "websearch.py")
        spec = importlib.util.spec_from_file_location("bt_websearch", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    except Exception:
        return {}
    out = {}
    for q in queries:
        try:
            res = mod.search(q, engine=engine, max_results=max_results)
        except Exception:
            res = []
        out[q] = [{"title": r.get("title"), "url": r.get("url")}
                  for r in (res or [])]
    return out


# ------------------------------------------------------------ 入口
# ------------------------------------------------------------ AI 增强（可选层）
def _ai_ready():
    """双开关就绪（与 Config.ai_ready 同源）；任何异常一律视为未就绪。"""
    try:
        return bool(cfg.Config().ai_ready())
    except Exception:
        return False


def _ai_enhance():
    """动态加载 tools/ai_enhance.py（与 research() 加载 websearch 同款，不改导入面）。"""
    try:
        import importlib.util
        p = os.path.join(_ROOT, "tools", "ai_enhance.py")
        if not os.path.isfile(p):
            return None
        spec = importlib.util.spec_from_file_location("bt_ai_enhance", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _ai_ctx(assets):
    """给模型的资产特征摘要（确定性、截断）。"""
    out = []
    for a in (assets or [])[:30]:
        if not isinstance(a, dict):
            continue
        out.append({"title": str(a.get("title") or "")[:80],
                    "tech": str(a.get("tech") or "")[:80],
                    "url": str(a.get("url") or "")[:120]})
    return out


def _merge_ai_dicts(d, aw):
    """把 AI 词表候选并入字典草稿（保序去重 + dir_words 重排，守确定性）。"""
    for key in ("subdomain_words", "creds"):
        cur = d.get(key)
        if not isinstance(cur, list):
            continue
        for w in aw.get(key) or []:
            if isinstance(w, str) and w and w not in cur:
                cur.append(w)
    dirs = d.get("dir_words")
    if isinstance(dirs, list):
        for w in aw.get("dir_words") or []:
            if isinstance(w, str) and w and w not in dirs:
                dirs.append(w)
        d["dir_words"] = sorted(set(dirs))
    md = d.get("_meta")
    if isinstance(md, dict):
        md["rule_count"] = len(d.get("subdomain_words") or [])


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    opt = _parse_args(argv)
    if opt.get("help"):
        print(_USAGE)
        return 0
    if opt["mock"]:
        assets, src = mock_assets(), "mock://built-in"
    else:
        assets, src = load_assets(opt["from"], limit=opt["limit"]), opt["from"]
    if not assets:
        print("[know] 没有可用的资产素材（%s 为空或不存在）" % src)
        return 0
    res = None
    if opt["online"]:
        qs = ["%s 默认管理路径 未授权" % kw
              for kw, _n in component_hits(assets, min_count=opt["min_count"])[:5]]
        res = research(qs, engine=opt["engine"], max_results=5)
    ai_words = None
    if assets:
        try:
            if _ai_ready():
                _enh = _ai_enhance()
                if _enh is not None and _enh.available():
                    ai_words = _enh.suggest_words(_ai_ctx(assets), limit=30)
        except Exception:
            ai_words = None
    d = build_dicts(assets, min_count=opt["min_count"], limit=opt["limit"],
                    research=res, source=src)
    if ai_words:
        _merge_ai_dicts(d, ai_words)
        # FIX-33：溯源块参与“同输入同输出”比对，
        # 而模型返回的候选顺序每次不同；必须排序后再写。
        def _det(v):
            return sorted({str(x) for x in (v or []) if str(x).strip()})
        d["_meta"]["ai"] = _enh.meta_block(
            subdomain_words=_det(ai_words.get("subdomain_words")),
            dir_words=_det(ai_words.get("dir_words")),
            creds=_det(ai_words.get("creds")))
    t = build_templates(assets, min_count=opt["min_count"], limit=opt["limit"],
                        research=res, source=src)
    okd, why_d = validate_dicts(d)
    okt, why_t = validate_templates(t)
    if not (okd and okt):
        print("[know] 自校验失败：dicts=%s templates=%s" % (why_d, why_t))
        return 2
    if opt["json"]:
        print(json.dumps({"dicts": d, "templates": t}, ensure_ascii=False, indent=2))
    else:
        md, mt = d["_meta"], t["_meta"]
        print("[know] 素材=%d 组件=%d 字典词=%d 模板=%d"
              % (md["sample_count"], md["component_count"], md["rule_count"],
                 mt["rule_count"]))
        for it in mt["items"]:
            print("  %-30s %s" % (it["template_id"], it["severity"]))
    if opt["dry_run"]:
        print("[know] dry-run：未写盘")
        return 0
    pd = write_draft(d, opt["dict_out"], DEFAULT_DICT_DRAFT)
    pt = write_draft(t, opt["tpl_out"], DEFAULT_TPL_DRAFT)
    print("[know] 草稿已写入 %s / %s（人工审核改名后才会生效）" % (pd, pt))
    return 0


if __name__ == "__main__":
    sys.exit(main())
