# -*- coding: utf-8 -*-
"""难例草稿正式化通道（阶段 5-3）。

定位
----
5-2 的 ``tools/hunt_assist.py`` 把难例归纳成 **JSON 草稿** 写进
``data/templates_ai/*.tpl.draft``；而执行链的模板引擎
（``modules/template_engine.py``）只遍历 ``templates/*.yaml``。
两者之间此前**没有通道** —— 链条最后一环是断的。

本工具就是那条通道：**人工审核通过后**，把某条草稿从 JSON 转成
引擎可加载的 YAML，落进 ``templates/<id>.yaml``，并当场回读校验。

三条红线（本工具必须遵守）
--------------------------
1. **AI 永不进扫描热路径做决策** —— 本工具是**离线人工工具**，
   不 import ``core.engine``，不被任何扫描路径调用；
   正式化动作必须由人显式执行（``--apply``），默认只打印计划。
2. **AI 产物必须人工审核后才生效** —— 只接受 ``.draft`` 结尾的输入；
   正式化 = 人去审核 + 主动执行，不做任何自动/定时提升。
3. **扫描热路径永不 import 学习器模块** —— 本文件不被
   ``core/engine.py`` 引用（round43 A 段断言）。

数据流
------
    data/templates_ai/<id>.tpl.draft   （JSON，AI 产，含 trigger 人审依据）
              │  人工审核：确认触发条件与 payload 后
              ▼
    templates/<id>.yaml                （YAML，引擎可加载）
              │  template_engine.load_templates()
              ▼
    扫描时执行（GET/HEAD/POST 白名单 + scope 闸 + 限速）

用法
----
    python3 tools/hunt_promote.py --list                 # 列出草稿与状态
    python3 tools/hunt_promote.py --id hunt-abc123       # 预演（dry-run）
    python3 tools/hunt_promote.py --id hunt-abc123 --apply
    python3 tools/hunt_promote.py --all --apply
    python3 tools/hunt_promote.py --id hunt-abc123 --target /tmp/tpl --apply

退出码：0 = 全部成功；1 = 有拒绝/失败项。
"""
import argparse
import json
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core import config as cfg          # noqa: E402
from core import dicts as _dicts        # noqa: E402

# 草稿来源目录（与 tools/hunt_assist.py 的 DEFAULT_OUT_DIR 同口径，不写字面量重复值）
TPL_DIR_NAME = "templates_ai"
DRAFT_SUFFIX = _dicts.DRAFT_SUFFIX
HUNT_TPL_SUFFIX = ".tpl" + DRAFT_SUFFIX
DEFAULT_IN_DIR = os.path.join(cfg.DATA_DIR, TPL_DIR_NAME)
DEFAULT_OUT_DIR = os.path.join(cfg.ROOT, "templates")

_USAGE = ("用法: python3 tools/hunt_promote.py "
          "[--list] [--id ID] [--all] [--apply] [--target DIR] [--in-dir DIR]")


def _parse_args(argv):
    """手写参数解析（与 tools/ 下其它离线工具同风格，不依赖 argparse 之外的东西）。"""
    ap = argparse.ArgumentParser(add_help=False, usage=_USAGE)
    ap.add_argument("-h", "--help", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--id", default="")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--target", default="")
    ap.add_argument("--in-dir", default="")
    try:
        return ap.parse_args(argv)
    except SystemExit:
        print(_USAGE)
        return None


# ------------------------------------------------------------ YAML 生成
# 只用 JSON 风格的双引号标量 —— JSON 字符串是合法 YAML 标量，
# 因此 json.dumps 产出的就是安全转义（含单引号/反斜杠/中文都无需自己写转义）。
def _scalar(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return repr(v)
    return json.dumps(str(v), ensure_ascii=False)


def _is_empty(v):
    return isinstance(v, (dict, list)) and not v


def _emit(obj, indent=0):
    """把 dict/list 递归渲染成 YAML 行（确定性：保持插入序）。"""
    pad = " " * indent
    lines = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = str(k)
            if _is_empty(v):
                lines.append("%s%s: %s" % (pad, key, "[]" if isinstance(v, list) else "{}"))
            elif isinstance(v, (dict, list)):
                lines.append("%s%s:" % (pad, key))
                lines.extend(_emit(v, indent + 2))
            else:
                lines.append("%s%s: %s" % (pad, key, _scalar(v)))
    elif isinstance(obj, list):
        for it in obj:
            if _is_empty(it):
                lines.append("%s- %s" % (pad, "[]" if isinstance(it, list) else "{}"))
            elif isinstance(it, (dict, list)):
                sub = _emit(it, indent + 2)
                lines.append("%s- %s" % (pad, sub[0].strip()))
                lines.extend(sub[1:])
            else:
                lines.append("%s- %s" % (pad, _scalar(it)))
    return lines


def tpl_from_draft(t):
    """剥掉 ``trigger``（人审依据，非引擎字段），返回引擎可加载的模板映射。"""
    if not isinstance(t, dict):
        return {}
    return dict((k, v) for k, v in t.items() if k != "trigger")


def _header(t, src_name):
    """正式化溯源注释：人审时看这一段就能确认"这条模板从哪来、凭什么"。"""
    trg = t.get("trigger") or {}
    out = [
        "# 由 tools/hunt_promote.py 正式化（阶段 5-3）—— 来源草稿：%s" % src_name,
        "# 来源难例：%s %s" % (trg.get("method") or "GET", trg.get("source_url") or "-"),
        "# 参数：%s   组件/类别：%s/%s   命中特征：%s"
        % (trg.get("param") or "-", trg.get("component") or "-",
           trg.get("category") or "-", trg.get("matched_feature") or "(无)"),
        "# 触发条件（人审依据，非引擎字段）：",
    ]
    for c in (trg.get("conditions") or []):
        out.append("#   - %s" % c)
    alts = trg.get("alternatives") or []
    if alts:
        out.append("# 备选 payload：%s" % ", ".join(str(a) for a in alts))
    return out


def render_yaml(t, src_name):
    """渲染完整 YAML 文本（注释头 + 模板体）。"""
    lines = _header(t, src_name)
    lines.append("")
    lines.extend(_emit(tpl_from_draft(t), 0))
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------ 读写
def list_drafts(in_dir=None):
    """列出草稿：[(id, 文件名, 绝对路径)]，按 id 排序。"""
    in_dir = in_dir or DEFAULT_IN_DIR
    out = []
    if not os.path.isdir(in_dir):
        return out
    for fn in sorted(os.listdir(in_dir)):
        if not fn.endswith(HUNT_TPL_SUFFIX):
            continue
        out.append((fn[:-len(HUNT_TPL_SUFFIX)], fn, os.path.join(in_dir, fn)))
    return out


def read_draft(path):
    """读一条草稿。非 ``.draft`` 结尾一律拒绝（安全侧默认）。"""
    if not _dicts.is_draft(path):
        raise ValueError("拒绝非草稿输入：%s（安全侧默认）" % path)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def existing_ids(out_dir=None):
    """扫描目标目录已有 id（用于撞名检查）。只读文本，不 import 执行链。"""
    out_dir = out_dir or DEFAULT_OUT_DIR
    ids = set()
    if not os.path.isdir(out_dir):
        return ids
    for fn in sorted(os.listdir(out_dir)):
        if not fn.lower().endswith((".yaml", ".yml")):
            continue
        try:
            with open(os.path.join(out_dir, fn), "r", encoding="utf-8") as f:
                for line in f:
                    m = re.match(r"^id:\s*['\"]?([A-Za-z0-9_\-]+)['\"]?\s*$", line)
                    if m:
                        ids.add(m.group(1))
                        break
        except OSError:
            continue
    return ids


def validate_draft(t):
    """结构校验：优先用执行链的真 validate_template（单一事实来源）。

    执行链不可用（PyYAML 缺失等）时回落到内联最小校验，保证离线可跑。
    """
    try:
        from modules import template_engine as te
        return te.validate_template(t)
    except Exception as e:                       # noqa: BLE001
        return _tpl_ok_inline(t), "inline（执行链不可用：%s）" % e


_ALLOWED_SEV = ("critical", "high", "medium", "low", "info")
_ALLOWED_MT = ("status", "word", "regex", "dsl")
_ALLOWED_PART = ("body", "header", "all")
_ALLOWED_METHODS = ("GET", "HEAD", "POST")
_MAX_PATHS = 6
_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_\-]{1,63}$")


def _tpl_ok_inline(t):
    """内联最小校验（与 tools/hunt_assist.py::_tpl_ok 同口径）。"""
    if not isinstance(t, dict):
        return False
    if not _ID_RE.match(str(t.get("id") or "")):
        return False
    info = t.get("info")
    if not isinstance(info, dict) or not str(info.get("name") or "").strip():
        return False
    if str(info.get("severity") or "").lower() not in _ALLOWED_SEV:
        return False
    reqs = t.get("http")
    if not isinstance(reqs, list) or not reqs:
        return False
    for req in reqs:
        if not isinstance(req, dict):
            return False
        if str(req.get("method") or "GET").upper() not in _ALLOWED_METHODS:
            return False
        paths = req.get("path")
        paths = paths if isinstance(paths, list) else ([paths] if paths else [])
        if not paths or len(paths) > _MAX_PATHS:
            return False
        mats = req.get("matchers")
        if not isinstance(mats, list) or not mats:
            return False
        for m in mats:
            if not isinstance(m, dict):
                return False
            mt = str(m.get("type") or "").lower()
            if mt not in _ALLOWED_MT:
                return False
            if mt in ("word", "regex") \
                    and str(m.get("part") or "body").lower() not in _ALLOWED_PART:
                return False
    return True


def write_yaml(text, path):
    """原子写：同目录 tmp + os.replace，避免半截文件被引擎读到。"""
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)
    return path


def roundtrip_ok(path, tid):
    """回读校验：目标目录能被引擎加载，且该 id 在列（真链路闭环）。"""
    try:
        from modules import template_engine as te
    except Exception:                            # noqa: BLE001
        return True, "引擎不可用，跳过回读"
    items = te.load_templates(tpl_dir=os.path.dirname(os.path.abspath(path)),
                              force=True)
    ids = [str(t.get("id")) for t in items]
    return (tid in ids), "loaded=%s" % ids


# ------------------------------------------------------------ 主流程
def promote_one(tid, in_dir=None, out_dir=None, apply=False):
    """正式化一条草稿，返回 (ok, msg)。apply=False 时只预演不落盘。"""
    in_dir = in_dir or DEFAULT_IN_DIR
    out_dir = out_dir or DEFAULT_OUT_DIR
    src = os.path.join(in_dir, tid + HUNT_TPL_SUFFIX)
    if not os.path.isfile(src):
        return False, "草稿不存在：%s" % src
    try:
        t = read_draft(src)
    except Exception as e:                       # noqa: BLE001
        return False, "读取失败：%s" % e
    if str(t.get("id") or "") != tid:
        return False, "草稿 id 与文件名不一致：%s != %s" % (t.get("id"), tid)
    ok, reason = validate_draft(t)
    if not ok:
        return False, "结构校验不通过：%s" % reason
    if tid in existing_ids(out_dir):
        return False, "目标目录已存在同 id 模板（拒绝覆盖）：%s" % tid
    text = render_yaml(t, os.path.basename(src))
    dst = os.path.join(out_dir, tid + ".yaml")
    if not apply:
        return True, "预演 OK -> %s（%d 字节，加 --apply 落盘）" % (dst, len(text))
    try:
        write_yaml(text, dst)
    except Exception as e:                       # noqa: BLE001
        return False, "写入失败：%s" % e
    rt_ok, rt_msg = roundtrip_ok(dst, tid)
    if not rt_ok:
        return False, "回读校验失败（已写入 %s）：%s" % (dst, rt_msg)
    return True, "已正式化 -> %s（%d 字节，回读 OK）" % (dst, len(text))


def main(argv=None):
    args = _parse_args(sys.argv[1:] if argv is None else argv)
    if args is None:
        return 1
    if args.help:
        print(_USAGE)
        print(__doc__)
        return 0
    in_dir = args.in_dir or DEFAULT_IN_DIR
    out_dir = args.target or DEFAULT_OUT_DIR
    if args.list:
        drafts = list_drafts(in_dir)
        print("[hunt_promote] 草稿目录=%s（%d 条）" % (in_dir, len(drafts)))
        have = existing_ids(out_dir)
        for tid, fn, _p in drafts:
            print("  %-24s %s  %s" % (tid, fn, "已正式化" if tid in have else "待审"))
        return 0
    if not args.id and not args.all:
        print(_USAGE)
        return 1
    targets = ([t for t, _f, _p in list_drafts(in_dir)] if args.all else [args.id])
    bad = 0
    for tid in targets:
        ok, msg = promote_one(tid, in_dir=in_dir, out_dir=out_dir,
                              apply=args.apply)
        print("  [%s] %s" % ("OK" if ok else "FAIL", msg))
        if not ok:
            bad += 1
    print("[hunt_promote] 共 %d 条，失败 %d 条（%s）"
          % (len(targets), bad, "已落盘" if args.apply else "预演"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
