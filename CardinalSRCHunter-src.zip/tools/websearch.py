# -*- coding: utf-8 -*-
"""多引擎联网搜索（零依赖 stdlib 实现）。

设计原则
--------
1. 不引入第三方依赖：proot 环境 pip 被 PEP668 锁死，且项目要求自包含，
   故全部用 urllib + re + json 手写。
2. 引擎按"实测可达性"分层，主引擎失败自动降级到备用引擎，
   绝不因为某一家不通就让整个学习器停摆。
3. 只做"取数"，不做决策：返回结构化 [{title,url,snippet,engine}]，
   落盘与审核由调用方负责；扫描热路径永不 import 本模块。

实测可达性（2026-10-08，本机 proot 网络出口）
--------------------------------------------
  bing   cn.bing.com        rc=0  0.27s   ✅ 主力
  baidu  www.baidu.com      rc=0  0.59s   ✅ 备用
  github api.github.com     rc=0           ✅ 代码/仓库
  osv    osv.dev            rc=0           ✅ 漏洞库
  nvd    nvd.nist.gov       rc=0           ✅ CVE
  google www.google.com     rc=11 4.2s     ❌ 链路不通
  ddg    duckduckgo.com     rc=11 4.0s     ❌ 链路不通

用法
----
  python3 tools/websearch.py "nuclei yaml template" --engine bing --max 8
  python3 tools/websearch.py "log4j" --engine auto --json
"""
import json
import re
import ssl
import sys
import urllib.parse
import urllib.request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

# 实测可用引擎（顺序即 auto 模式的优先级）
ENGINES = ("bing", "baidu", "github", "osv", "nvd")


def _get(url, timeout=12, headers=None, data=None):
    """统一 GET/POST：静音 TLS 校验，带浏览器 UA 与中文语言偏好。"""
    h = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h, data=data)
    with urllib.request.urlopen(req, timeout=timeout, context=_CTX) as r:
        return r.read().decode("utf-8", "ignore")


def _clean(s):
    """去标签、压空白。"""
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", s or "")).strip()


# ------------------------------------------------------------
# 引擎实现
# ------------------------------------------------------------
def bing_search(query, max_results=10, timeout=12):
    """Bing 网页搜索。cn.bing.com 实测 0.27s 可达，是当前唯一稳定的通用搜索源。"""
    url = ("https://cn.bing.com/search?q=" + urllib.parse.quote(query)
           + "&count=%d&ensearch=0" % max_results)
    html = _get(url, timeout=timeout)
    out = []
    # 结果块：<h2><a href="...">标题</a></h2> 后面跟着摘要 <p>
    pat = re.compile(r'<h2[^>]*>\s*<a[^>]*href="(https?://[^"]+)"[^>]*>(.*?)</a>(.*?)(?=<h2|\Z)', re.S)
    for m in pat.finditer(html):
        u, t, tail = m.group(1), _clean(m.group(2)), m.group(3)
        if not t or "bing.com" in u:
            continue
        sn = ""
        ms = re.search(r"<p[^>]*>(.*?)</p>", tail, re.S)
        if ms:
            sn = _clean(ms.group(1))
        out.append({"title": t, "url": u, "snippet": sn[:300], "engine": "bing"})
        if len(out) >= max_results:
            break
    return out


def baidu_search(query, max_results=10, timeout=12):
    """百度网页搜索。命中"安全验证"页时返回空列表（由上层降级处理）。"""
    url = "https://www.baidu.com/s?wd=" + urllib.parse.quote(query)
    html = _get(url, timeout=timeout)
    if "安全验证" in html or "wappass.baidu.com" in html:
        return []
    out = []
    pat = re.compile(r'<h3[^>]*class="[^"]*t[^"]*"[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<h3|\Z)', re.S)
    for m in pat.finditer(html):
        u, t, tail = m.group(1), _clean(m.group(2)), m.group(3)
        if not t:
            continue
        sn = _clean(re.sub(r"<[^>]+>", " ", tail))[:300]
        out.append({"title": t, "url": u, "snippet": sn, "engine": "baidu"})
        if len(out) >= max_results:
            break
    return out


def github_search(query, max_results=10, timeout=12):
    """GitHub 仓库搜索（REST API，无需 token 时限额 10 req/min）。"""
    url = ("https://api.github.com/search/repositories?q="
           + urllib.parse.quote(query) + "&sort=stars&order=desc&per_page=%d" % max_results)
    j = json.loads(_get(url, timeout=timeout, headers={"Accept": "application/vnd.github+json"}))
    out = []
    for it in j.get("items", [])[:max_results]:
        out.append({"title": it.get("full_name", ""),
                    "url": it.get("html_url", ""),
                    "snippet": (it.get("description") or "")[:300],
                    "stars": it.get("stargazers_count", 0),
                    "engine": "github"})
    return out


def github_code_search(query, max_results=10, timeout=12):
    """GitHub 代码搜索（需 token，无 token 会 401；失败返回空列表）。"""
    url = ("https://api.github.com/search/code?q="
           + urllib.parse.quote(query) + "&per_page=%d" % max_results)
    try:
        j = json.loads(_get(url, timeout=timeout,
                            headers={"Accept": "application/vnd.github+json"}))
    except Exception:
        return []
    return [{"title": it.get("path", ""), "url": it.get("html_url", ""),
             "snippet": (it.get("repository", {}) or {}).get("full_name", ""),
             "engine": "github_code"} for it in j.get("items", [])[:max_results]]


def osv_search(query, max_results=10, timeout=12):
    """OSV 漏洞库查询（按包名/关键字）。"""
    body = json.dumps({"package": {"name": query}}).encode("utf-8")
    try:
        j = json.loads(_get("https://api.osv.dev/v1/query", timeout=timeout,
                            headers={"Content-Type": "application/json"}, data=body))
    except Exception:
        return []
    out = []
    for v in j.get("vulns", [])[:max_results]:
        out.append({"title": v.get("id", ""),
                    "url": "https://osv.dev/vulnerability/" + v.get("id", ""),
                    "snippet": (v.get("summary") or "")[:300],
                    "engine": "osv"})
    return out


def nvd_search(keyword, max_results=10, timeout=15):
    """NVD CVE 查询（keywordSearch）。"""
    url = ("https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch="
           + urllib.parse.quote(keyword) + "&resultsPerPage=%d" % max_results)
    try:
        j = json.loads(_get(url, timeout=timeout))
    except Exception:
        return []
    out = []
    for it in j.get("vulnerabilities", [])[:max_results]:
        c = it.get("cve", {})
        desc = ""
        for d in c.get("descriptions", []):
            if d.get("lang") == "en":
                desc = d.get("value", "")
                break
        out.append({"title": c.get("id", ""), "url":
                    "https://nvd.nist.gov/vuln/detail/" + c.get("id", ""),
                    "snippet": desc[:300], "engine": "nvd"})
    return out


_DISPATCH = {
    "bing": bing_search,
    "baidu": baidu_search,
    "github": github_search,
    "osv": osv_search,
    "nvd": nvd_search,
}


def search(query, engine="auto", max_results=10, timeout=12):
    """统一入口。

    engine="auto" 时按 ENGINES 顺序依次尝试，返回第一个非空结果；
    单引擎模式下失败会抛异常（便于调用方区分"不通"与"无结果"）。
    """
    if engine and engine != "auto":
        fn = _DISPATCH.get(engine)
        if fn is None:
            raise ValueError("未知引擎: %s（可选 %s）" % (engine, ", ".join(ENGINES)))
        return fn(query, max_results=max_results, timeout=timeout)

    last_err = None
    for name in ENGINES:
        try:
            res = _DISPATCH[name](query, max_results=max_results, timeout=timeout)
            if res:
                return res
        except Exception as e:
            last_err = e
            continue
    if last_err:
        raise last_err
    return []


def main(argv=None):
    argv = list(argv if argv is not None else sys.argv[1:])
    as_json = "--json" in argv
    if as_json:
        argv.remove("--json")
    engine = "auto"
    if "--engine" in argv:
        i = argv.index("--engine")
        engine = argv[i + 1]
        del argv[i:i + 2]
    mx = 10
    if "--max" in argv:
        i = argv.index("--max")
        mx = int(argv[i + 1])
        del argv[i:i + 2]
    if not argv:
        print("用法: python3 tools/websearch.py \"查询词\" [--engine bing|baidu|github|osv|nvd|auto] [--max N] [--json]")
        return 2
    query = " ".join(argv)
    try:
        res = search(query, engine=engine, max_results=mx)
    except Exception as e:
        print("[search] 全部引擎失败: %s: %s" % (type(e).__name__, e))
        return 1
    if as_json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    if not res:
        print("[search] 无结果")
        return 0
    for i, r in enumerate(res, 1):
        print("[%d] %s" % (i, r["title"]))
        print("    %s" % r["url"])
        if r.get("snippet"):
            print("    %s" % r["snippet"][:160])
    return 0


if __name__ == "__main__":
    sys.exit(main())
