# -*- coding: utf-8 -*-
"""MCP 客户端（round59 阶段③，JSON-RPC over stdio）。

把 MCP server 暴露的工具接进 ``tool_registry``：拉取 ``tools/list``，
按需注册到外部工具表，调用走 ``tools/call``。注册进来的工具**必须**经过
``tool_registry.run_tool`` 的四道校验，因此不存在绕过授权/强度闸门的路径。

三件事（MCP 规范最小集）：
1. ``initialize`` —— 握手，声明协议版本与客户端信息；
2. ``tools/list`` —— 拉工具清单，转成 OpenAI function schema；
3. ``tools/call`` —— 执行工具，取回结果。

进程纪律：子进程随 :meth:`MCPClient.close` 统一 terminate，幂等；
``engine.close()`` 里已挂同一收口。任何失败都吞成 ``None`` / ``[]``，
**绝不向上抛**——MCP 是可选增强，拔掉它主流程照跑。
"""
import json
import os
import subprocess
import threading
import time

PROTOCOL_VERSION = "2024-11-05"
DEFAULT_TIMEOUT = 20
CLIENT_NAME = "bt-src-hunter"
CLIENT_VERSION = "round59"


class MCPError(Exception):
    """MCP 通信层异常（内部使用，不外抛给引擎）。"""


class MCPClient(object):
    """一个 MCP server 的 stdio 客户端。

    线程安全：``_lock`` 保护请求/响应配对，避免多线程下读写交错。
    """

    def __init__(self, command, args=None, env=None, timeout=DEFAULT_TIMEOUT,
                 cwd=None):
        self.command = command
        self.args = list(args or [])
        self.env = dict(env or {})
        self.timeout = int(timeout or DEFAULT_TIMEOUT)
        # round84 M1: server.py is usually a RELATIVE path in mcp.config.json
        # ("args": ["server.py"]). Without cwd the child process searches the
        # program's own working dir, so an extracted plugin can never be found
        # and dies immediately (returncode=2) -- shown as "4ms handshake fail".
        self.cwd = cwd or None
        self.proc = None
        self._lock = threading.Lock()
        self._id = 0
        self._tools = []
        self.server_info = {}
        # round84 M2: keep the failure reason so probe/UI can show it.
        self.last_error = ""
        self._stderr_tail = ""

    # -------------------------------------------------- 生命周期
    def start(self):
        """拉起子进程。失败返回 False（不抛）。"""
        if self.proc is not None and self.proc.poll() is None:
            return True
        try:
            env = dict(os.environ)
            env.update(self.env)
            self.proc = subprocess.Popen(
                [self.command] + self.args,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, env=env,
                cwd=(self.cwd or None),
                universal_newlines=True, bufsize=1)
            return True
        except Exception as e:
            # round84 M2: previously swallowed; now recorded for the UI.
            self.last_error = "%s: %s" % (type(e).__name__, e)
            self.proc = None
            return False

    def close(self):
        """终止子进程。幂等，任何异常都吞掉。"""
        p = self.proc
        self.proc = None
        if p is None:
            return
        for fn in (p.terminate, p.kill):
            try:
                fn()
            except Exception:
                pass
            try:
                if p.poll() is not None:
                    break
            except Exception:
                break

    def alive(self):
        try:
            return self.proc is not None and self.proc.poll() is None
        except Exception:
            return False

    # -------------------------------------------------- JSON-RPC
    def _rpc(self, method, params=None, notify=False):
        """发一条 JSON-RPC 请求并读回对应响应。失败返回 None。"""
        if not self.alive():
            return None
        with self._lock:
            try:
                self._id += 1
                rid = self._id
                msg = {"jsonrpc": "2.0", "method": method}
                if params is not None:
                    msg["params"] = params
                if not notify:
                    msg["id"] = rid
                self.proc.stdin.write(json.dumps(msg, ensure_ascii=False) + "\n")
                self.proc.stdin.flush()
            except Exception:
                return None
            if notify:
                return {}
            deadline = time.time() + self.timeout
            while time.time() < deadline:
                try:
                    line = self.proc.stdout.readline()
                except Exception:
                    return None
                if not line:
                    return None
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                # 跳过通知与不匹配的 id
                if isinstance(obj, dict) and obj.get("id") == rid:
                    return obj
            return None

    # -------------------------------------------------- 三件事
    def _drain_stderr(self):
        """round84 M2: pull whatever the child wrote to stderr, non-blocking.

        This is the ONLY place the real failure reason lives. It used to go
        to DEVNULL, so every failure looked identical to the user.
        """
        p = self.proc
        if p is None or p.stderr is None:
            return self._stderr_tail
        import select
        chunk = ""
        try:
            while True:
                rl, _, _ = select.select([p.stderr], [], [], 0)
                if not rl:
                    break
                ln = p.stderr.readline()
                if not ln:
                    break
                chunk += ln
        except Exception:
            pass
        if chunk:
            self._stderr_tail = (self._stderr_tail + chunk)[-800:]
        return self._stderr_tail

    def failure_reason(self):
        """round84 M2: human-readable one-liner for probe / Web UI."""
        bits = []
        if self.last_error:
            bits.append(self.last_error)
        rc = None
        try:
            rc = self.proc.poll() if self.proc is not None else None
        except Exception:
            rc = None
        if rc is not None:
            bits.append("exit=%s" % rc)
        tail = (self._stderr_tail or "").strip()
        if tail:
            bits.append(tail.splitlines()[-1][:200])
        return "｜".join(bits) or "no-detail"

    def initialize(self):
        """握手。成功返回 True。"""
        if not self.start():
            return False
        r = self._rpc("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
        })
        if not isinstance(r, dict) or "result" not in r:
            self._drain_stderr()
            return False
        res = r.get("result") or {}
        self.server_info = res.get("serverInfo") or {}
        # 规范要求：initialize 后补一条 initialized 通知
        self._rpc("notifications/initialized", {}, notify=True)
        return True

    def list_tools(self):
        """拉工具清单，返回原始列表（失败返回 []）。"""
        r = self._rpc("tools/list", {})
        if not isinstance(r, dict):
            return []
        res = r.get("result") or {}
        tools = res.get("tools") if isinstance(res, dict) else None
        self._tools = list(tools or [])
        return self._tools

    def call_tool(self, name, arguments=None):
        """执行一个 MCP 工具，返回其 result（失败返回 None）。"""
        r = self._rpc("tools/call", {"name": name,
                                     "arguments": arguments or {}})
        if not isinstance(r, dict):
            return None
        if r.get("error"):
            return {"error": "mcp_error", "detail": r.get("error")}
        return r.get("result")


# ------------------------------------------------------------ 与注册表对接
def _to_openai_schema(name, desc, input_schema):
    """把 MCP 工具描述转成 OpenAI function schema。"""
    params = input_schema if isinstance(input_schema, dict) else {}
    if params.get("type") != "object":
        params = {"type": "object", "properties": {}}
    return {
        "type": "function",
        "function": {
            "name": str(name),
            "description": str(desc or name),
            "parameters": params,
        },
    }


def _result_text(result):
    """把 MCP 的 result 压成可读对象（content 数组 -> 文本）。"""
    if not isinstance(result, dict):
        return result
    content = result.get("content")
    if isinstance(content, list):
        texts = []
        for it in content:
            if isinstance(it, dict) and it.get("type") == "text":
                texts.append(str(it.get("text") or ""))
            elif isinstance(it, dict):
                texts.append(json.dumps(it, ensure_ascii=False, default=str))
        joined = "\n".join(t for t in texts if t)
        return {"text": joined, "isError": bool(result.get("isError"))}
    return result


_TARGET_HINTS = ("url", "uri", "host", "hostname", "domain", "target",
                 "endpoint", "address", "addr")


def _guess_target_key(input_schema):
    """从 inputSchema 里猜出"出网目标参数名"。认不出返回空串。"""
    if not isinstance(input_schema, dict):
        return ""
    props = input_schema.get("properties") or {}
    if not isinstance(props, dict):
        return ""
    low = {str(k).lower(): k for k in props}
    for hint in _TARGET_HINTS:
        for lk, orig in low.items():
            if hint == lk:
                return str(orig)
    for hint in _TARGET_HINTS:
        for lk, orig in low.items():
            if hint in lk:
                return str(orig)
    return ""


def register_server(client, registry, gate="", risk="medium", net=True,
                    prefix=""):
    """把一个已 initialize 的 MCP client 的工具注册进 registry。

    返回成功注册的工具名列表。所有工具都带 ``prefix``（默认 ``mcp_``），
    避免与内建工具撞名——同名时内建优先，外部注册不生效。
    """
    names = []
    try:
        tools = client.list_tools()
    except Exception:
        return names
    for t in tools or []:
        if not isinstance(t, dict):
            continue
        raw_name = str(t.get("name") or "")
        if not raw_name:
            continue
        full = "%s%s" % (prefix, raw_name)
        schema = _to_openai_schema(full, t.get("description"),
                                   t.get("inputSchema"))

        def _call(engine, args, _c=client, _n=raw_name):
            res = _c.call_tool(_n, args)
            if res is None:
                return {"error": "mcp_no_response", "tool": _n}
            return _result_text(res)

        tk = _guess_target_key(t.get("inputSchema"))
        if registry.register_external(full, schema, _call, gate=gate,
                                      risk=risk, net=net, target_key=tk):
            names.append(full)
    return names


# ------------------------------------------------------------ launcher fixup
_PY_NAMES = {"python", "python3", "python.exe", "python3.exe", "py"}


def _norm_launcher(cmd):
    """round84 M5: map *NIX python names onto the running interpreter.

    Plugin bundles are authored on Linux/macOS and declare "command":
    "python3". On Windows that executable usually does not exist, so Popen
    raises FileNotFoundError and the user only sees a generic failure.
    Reusing sys.executable also guarantees the child runs on the same
    interpreter that already has our dependencies.
    """
    import sys
    c = str(cmd or "").strip()
    if not c:
        return c
    base = os.path.basename(c).lower()
    if base in _PY_NAMES:
        exe = sys.executable
        if exe:
            return exe
        return "python" if os.name == "nt" else "python3"
    return c


def _looks_like_script(a):
    a = str(a or "").strip().lower()
    return a.endswith(".py") or a.endswith(".js") or a.endswith(".mjs")


def _find_by_name(name, extra=None):
    """round85 M1: last-resort lookup for an installed MCP bundle.

    Old config records (written before r84) store the bare file name
    ``server.py`` and no cwd, so nothing can resolve it. Search the managed
    install root ``USER_ROOT/mcp/<name>/`` plus any cwd hints.
    """
    name = str(name or "").strip()
    if not name:
        return ""
    roots = []
    try:
        from core import config as _cfg
        roots.append(os.path.join(_cfg.USER_ROOT, "mcp"))
    except Exception:
        pass
    try:
        roots.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  os.pardir, "mcp"))
    except Exception:
        pass
    for r in roots:
        cand = os.path.join(os.path.abspath(r), name, "server.py")
        if os.path.isfile(cand):
            return cand
    for r in roots:
        r = os.path.abspath(r)
        if not os.path.isdir(r):
            continue
        try:
            subs = sorted(os.listdir(r))
        except Exception:
            continue
        for sub in subs:
            cand = os.path.join(r, sub, "server.py")
            if os.path.isfile(cand) and name.lower() in sub.lower():
                return cand
    return ""

def _find_any_script(fname):
    """round85 M1b: brute force -- look for fname under every bundle.

    Used only when the server name is unknown or the bundle folder was named
    differently (e.g. user re-imported with a suffixed name).
    """
    fname = str(fname or "").strip()
    if not fname:
        return ""
    roots = []
    try:
        from core import config as _cfg
        roots.append(os.path.join(_cfg.USER_ROOT, "mcp"))
    except Exception:
        pass
    for r in roots:
        r = os.path.abspath(r)
        if not os.path.isdir(r):
            continue
        try:
            subs = sorted(os.listdir(r))
        except Exception:
            continue
        for sub in subs:
            cand = os.path.join(r, sub, fname)
            if os.path.isfile(cand):
                return cand
    return ""

def _resolve_script(args, cwd=None, cmd=None, srv_name=None):
    """round84 M1: make a relative script path absolute and infer cwd.

    "args": ["server.py"] plus no cwd means the child looks for server.py in
    the program's own directory -- never where the plugin actually lives.
    If the absolute script exists (installed by _mcp_import into
    userdata/mcp/<name>/), we pin cwd to its folder so that sibling imports
    (vectorstore/, etc.) also resolve.
    """
    args = list(args or [])
    cwd = cwd or None
    if not args:
        return args, cwd
    for i, a in enumerate(args):
        if not _looks_like_script(a):
            continue
        p = str(a).strip()
        if os.path.isabs(p):
            if os.path.isfile(p):
                args[i] = p
                cwd = cwd or os.path.dirname(p)
            return args, cwd
        if cwd:
            cand = os.path.join(cwd, p)
            if os.path.isfile(cand):
                args[i] = os.path.abspath(cand)
                return args, os.path.abspath(cwd)
        # round85 M1: old records have bare name and no cwd. Search the managed
        # install root by SERVER NAME first (mcp/<name>/server.py), then by a
        # cwd basename, then as a last resort any bundle that ships a script
        # with the same file name.
        _found = _find_by_name(srv_name) if srv_name else ""
        if not _found and cwd:
            _found = _find_by_name(os.path.basename(os.path.normpath(cwd)))
        if not _found:
            _found = _find_any_script(os.path.basename(p))
        if _found:
            args[i] = _found
            return args, os.path.dirname(_found)
        if cwd:
            return args, os.path.abspath(cwd)
        return args, cwd
    return args, cwd


def load_from_config(config, registry, prefix="mcp_"):
    """按配置里的 ``takeover.mcp.servers`` 批量拉起并注册。

    配置形如 ``[{"command": "...", "args": [...], "env": {...}, "gate": ""}]``。
    返回 ``(clients, names)``；任一 server 失败只跳过它，不影响其它。
    """
    clients = []
    names = []
    try:
        raw = config.get("takeover") if hasattr(config, "get") else None
    except Exception:
        raw = None
    if not isinstance(raw, dict):
        return clients, names
    mcp = raw.get("mcp") or {}
    if not isinstance(mcp, dict) or not mcp.get("enabled"):
        return clients, names
    for srv in (mcp.get("servers") or []):
        if not isinstance(srv, dict):
            continue
        cmd = str(srv.get("command") or "")
        if not cmd:
            continue
        # round84 M1/M5: normalise the launcher and the working directory.
        # mcp.config.json in most plugin bundles says "python3" (a *NIX name)
        # and a relative script path. On Windows "python3" usually does not
        # exist and the relative path resolves against the program's cwd, so
        # the child dies instantly. Fix both here, in one place.
        cmd = _norm_launcher(cmd)
        _args = list(srv.get("args") or [])
        _cwd = str(srv.get("cwd") or "").strip() or None
        _args, _cwd = _resolve_script(_args, _cwd, cmd, str(srv.get("name") or ""))
        c = MCPClient(cmd, args=_args, env=srv.get("env"),
                      timeout=srv.get("timeout"), cwd=_cwd)
        if not c.initialize():
            c.close()
            continue
        clients.append(c)
        try:
            names.extend(register_server(
                c, registry, gate=str(srv.get("gate") or ""),
                risk=str(srv.get("risk") or "medium"),
                net=bool(srv.get("net", True)), prefix=prefix))
        except Exception:
            continue
    return clients, names