# -*- coding: utf-8 -*-
"""tools/skill_loader.py —— 技能加载器（给 AI 增强层挂“说明书”）。

作用
----
把 ``skills/`` 目录下的静态技能文件（Markdown + 极简 front matter）读出来，
拼成一段提示词前缀，注入到 ``tools/ai_enhance.py`` 发给模型的 system 消息里。
这样就可以在不改代码的前提下，给模型“安装 / 卸载”技能。

技能文件格式（``skills/<名字>.md``）::

    ---
    name: 字典工程师增强
    kind: words          # words / trigger / actions / all
    enabled: true
    priority: 10         # 数字越大越靠前
    ---
    正文（纯提示词，给模型看的额外指令）

红线
----
1. 本模块**不 import** ``urllib`` / ``requests`` / ``socket``（纯文件读取，零网络）。
2. 任何异常一律静默：读技能失败就当没装技能，返回原样。
3. 技能是**静态文本**，人工审核后才生效；本模块不执行技能里的任何代码。
4. 技能目录 ``skills/`` 随源码包发布，但技能只是提示词，不改变扫描主流程。

用法
----
  python3 tools/skill_loader.py list          # 列出已装技能
  python3 tools/skill_loader.py show <名字>   # 看某个技能正文
  python3 tools/skill_loader.py on  <名字>    # 启用
  python3 tools/skill_loader.py off <名字>    # 停用
  python3 tools/skill_loader.py new <名字>    # 生成空白技能模板
  python3 tools/skill_loader.py text words    # 打印注入 words 类的提示词
"""
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
# round91 FIX-26: 技能目录允许环境变量重定向。
# 之前 SKILLS_DIR 硬编码到源码根，BTSRHUNTER_USER_DIR 沙箱对 skills/ 完全不生效，
# 而 verify_round66/70 会 rmtree 真实 skills/ 再从备份复制，
# 一旦快照恰好落在空档，技能 .md 就永久丢失（round91 已真实发生）。
# BTSRHUNTER_SKILLS_DIR 优先，仅供测试/便携，生产路径不变。
_ENV_SK = os.environ.get("BTSRHUNTER_SKILLS_DIR")
if _ENV_SK and str(_ENV_SK).strip():
    SKILLS_DIR = os.path.abspath(os.path.expanduser(str(_ENV_SK).strip()))
else:
    SKILLS_DIR = os.path.join(_ROOT, "skills")
KINDS = ("words", "trigger", "actions", "all")
MAX_SKILL_CHARS = 4000
MAX_TOTAL_CHARS = 12000

_FM_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", re.S)


def _skill_dir():
    return SKILLS_DIR


def _parse(path):
    """读一个技能文件 -> dict；失败返回 None。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()
    except Exception:
        return None
    meta = {}
    body = raw
    m = _FM_RE.match(raw)
    if m:
        head, body = m.group(1), m.group(2)
        for line in head.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or ":" not in line:
                continue
            k, v = line.split(":", 1)
            meta[k.strip().lower()] = v.strip()
    name = str(meta.get("name") or os.path.splitext(os.path.basename(path))[0]).strip()
    kind = str(meta.get("kind") or "all").strip().lower()
    if kind not in KINDS:
        kind = "all"
    enabled = str(meta.get("enabled", "true")).strip().lower() not in ("0", "false", "no", "off")
    try:
        priority = int(str(meta.get("priority", "0")).strip() or "0")
    except Exception:
        priority = 0
    # round79 ①：front-matter 里写 tools: a, b 即声明「本技能要求使用这些工具」。
    # 不写 = 不声明，行为与 round78 完全一致（纯提示词，零工具要求）。
    tools = []
    for _tk in re.split(r"[,;\s]+", str(meta.get("tools") or "")):
        _tk = _tk.strip()
        if _tk and _tk not in tools:
            tools.append(_tk)
    text = (body or "").strip()
    if len(text) > MAX_SKILL_CHARS:
        text = text[:MAX_SKILL_CHARS]
    return {
        "file": os.path.basename(path),
        "path": path,
        "name": name,
        "kind": kind,
        "enabled": enabled,
        "priority": priority,
        "source": str(meta.get("source") or "").strip(),
        "tools": tools,
        "text": text,
    }


# round87b：参考资料目录名（这些目录里的 md 是手册/资料，不是技能入口）
_REF_DIRS = ("references", "reference", "assets", "asset", "docs", "doc",
             "examples", "example", "templates", "template", "wordlists",
             "wordlist", "payloads", "payload-dicts", "nuclei-templates",
             "knowledge-base", "knowledgebase", "archive", "changelog",
             "scripts", "script", "src", "third_party", "thirdparty",
             "vendor", "lib", "libs", "deps", ".", "bin", "tools_lib")
MAX_SKILL_FILES = 300

def _iter_skill_files(base):
    """round87b: 递归找出真正的技能文件。

    round87 B1 只做了「递归 + 上限60」，实测 mega-offensive-suite 有 1871 个 md，
    结果 60 个全是 references/ 里的参考手册，没一个是技能 —— 等于白扫。
    本轮改为**按入口特征优先**：
      1. 名为 SKILL.md / skill.md / README_SKILL.md 的文件 = 包入口，最高优先；
      2. 其余 md：跳过 references/assets/wordlists 等资料目录；
      3. 顶层 md 视为单文件技能；
      4. 上限提升到 300（入口优先保证核心技能不丢）。
    """
    res, entries = [], []
    base = os.path.abspath(base)
    skip = (".git", ".github", "__pycache__", "node_modules", ".venv", "venv", "dist", ".idea")
    refset = set(_REF_DIRS)
    for root, dirs, files in os.walk(base):
        # round91 FIX-27: 资料目录直接不进。mega 包里 references/ 有 900+ 个 md、assets/ 有 290+，走完要 2.7s（Android FUSE），而这些文件本来就不当技能；另外 references/INDEX.md 曾因名字命中 index.md 而被当成技能入口。
        dirs[:] = sorted(d for d in dirs
                         if d not in skip and d.lower() not in refset)
        rel = os.path.relpath(root, base)
        depth = 0 if rel == "." else rel.count(os.sep)
        if depth > 6:
            dirs[:] = []
            continue
        parts_low = [p.lower() for p in rel.split(os.sep) if p != "."]
        in_ref = any(p in refset for p in parts_low)
        for fn in sorted(files):
            low = fn.lower()
            if not (low.endswith(".md") or low.endswith(".markdown")):
                continue
            full = os.path.join(root, fn)
            is_entry = low in ("skill.md", "readme_skill.md", "index.md") or (
                depth == 0 and len(parts_low) == 0)
            if low == "readme.md" and not in_ref:
                continue          # 纯说明文件，不当技能（round49 K10）
            if is_entry:
                entries.append(full)
            elif in_ref:
                continue          # 资料目录里的普通 md：不当作技能
            else:
                res.append(full)
    allp = entries + res
    return allp[:MAX_SKILL_FILES]


def _pack_of(path, base):
    """round87 B2: which skill package a file belongs to."""
    try:
        rel = os.path.relpath(os.path.abspath(path), os.path.abspath(base))
        parts = rel.split(os.sep)
        if len(parts) > 1:
            return parts[0]
    except Exception:
        pass
    return ""


def list_skills():
    """列出 skills/ 下全部技能（含停用的，递归扫描子目录）。"""
    out = []
    d = _skill_dir()
    try:
        paths = _iter_skill_files(d)
    except Exception:
        return out
    for _p in paths:
        item = _parse(_p)
        if not item:
            continue
        item["file"] = os.path.relpath(_p, d).replace(os.sep, "/")
        item["pack"] = _pack_of(_p, d)
        out.append(item)
    out.sort(key=lambda x: (x["pack"] or "", -x["priority"], x["name"]))
    _kn = _known_tool_names()
    for _it in out:
        _it["unknown"] = _unknown_of(_it.get("tools") or [], _kn)
    return out


def find(name):
    """按名字或文件名找技能；找不到返回 None。"""
    want = str(name or "").strip().lower()
    for it in list_skills():
        if want in (it["name"].lower(), it["file"].lower(),
                    os.path.splitext(it["file"])[0].lower()):
            return it
    return None


def _cfg_path():
    """定位 config.json（与 core.config 同源，但不 import 它）。

    round49 N3 把本模块的导入面锁死为纯标准库（os/re/sys/argparse/io/json/
    importlib），故这里**只**用 os/sys 复刻 core.config._user_root 的落点规则：
    环境变量 BTSRHUNTER_USER_DIR > EXE 态 %LOCALAPPDATA%\\CardinalSRCHunter\\userdata
    > 开发态源码根。
    """
    env = os.environ.get("BTSRHUNTER_USER_DIR")
    if env and str(env).strip():
        base = os.path.abspath(os.path.expanduser(str(env).strip()))
    elif getattr(sys, "frozen", False):
        base = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
                            "CardinalSRCHunter", "userdata")
    else:
        base = _ROOT
    return os.path.join(base, "config", "config.json")


def global_enabled():
    """SKILL 总开关（``takeover.skill.enabled``，round73 D 组）。

    读不到配置 / 配置里没这一位时返回 True——即**不改变既有行为**（技能装了
    就生效）。只有用户显式关掉总开关，才返回 False 并让注入整体停摆。
    本函数只读本地 JSON，零网络（与模块红线一致）。
    """
    try:
        import json
        p = _cfg_path()
        if not os.path.isfile(p):
            return True
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        sk = ((d.get("takeover") or {}).get("skill") or {})
        v = sk.get("enabled", True)
        return str(v).strip().lower() not in ("0", "false", "no", "off")
    except Exception:
        return True


_KNOWN_CACHE = []


def _known_tool_names():
    """round80 ①：工具注册表已知工具名；取不到返回 None（不误报）。"""
    # round91 FIX-27: 缓存。注册表静态，首次导入要 3.6s，
    # 不缓存会把 /api/skill/list 的 6s 超时窗口吃满。
    # 键取「包属性 tools.tool_registry」：round80 B5 会把它换成假对象，
    # 对象一变就重算，不会拿旧缓存蒙混。
    try:
        from tools import tool_registry as _tr
    except Exception:
        return None
    if _KNOWN_CACHE[:1] == [_tr]:
        return _KNOWN_CACHE[1]
    try:
        _v = set(_tr.all_specs().keys())
    except Exception:
        return None
    _KNOWN_CACHE[:] = [_tr, _v]
    return _v


def _unknown_of(names, known):
    """声明名里不在注册表中的那些（known 为 None 时一律返回空）。"""
    return [n for n in names if n not in known] if known else []


def skill_tools(kind=None):
    """round79 ①：「技能 -> 声明的工具」映射（只读、纯标准库、零网络）。

    front-matter 里写 ``tools: probe_host, check_sqli`` 即声明本技能要求使用的
    工具；不写则该技能不产生任何工具要求（默认行为与 round78 逐字一致）。
    返回 ``[{"name","file","kind","enabled","tools":[..]}]``，只含**已启用且已声明**项。
    总开关关闭时返回 []（与 text_for 同口径：不撒谎）。
    """
    out = []
    if not global_enabled():
        return out
    # round80 ①：把「技能声明了但工具注册表里没有」的名字单独标出来，
    # 否则写错名字只会静默不生效，用户永远不知道技能为何没动作。
    known = _known_tool_names()
    try:
        want = str(kind or "").strip().lower()
        for it in list_skills():
            if not it.get("enabled"):
                continue
            if want and want != "all" and it.get("kind") not in ("all", want):
                continue
            names = list(it.get("tools") or [])
            if not names:
                continue
            unknown = ([n for n in names if n not in known]
                       if known else [])
            out.append({"name": it.get("name") or "",
                        "file": it.get("file") or "",
                        "kind": it.get("kind") or "all",
                        "enabled": True,
                        "tools": names,
                        "unknown": unknown})
    except Exception:
        pass
    return out


def text_for(kind):
    """返回注入给 ``kind`` 类调用的技能提示词；无技能返回空串。

    round73 D 组：先看 SKILL 总开关。总开关关闭时恒返回空串（技能文件
    保持原样，随时可再开），于是所有技能提示词都不再注入模型。
    """
    if not global_enabled():
        return ""
    try:
        kind = str(kind or "all").strip().lower()
        chunks = []
        total = 0
        for it in list_skills():
            if not it["enabled"] or not it["text"]:
                continue
            if it["kind"] not in ("all", kind):
                continue
            block = "【技能：%s】\n%s" % (it["name"], it["text"])
            if total + len(block) > MAX_TOTAL_CHARS:
                break
            chunks.append(block)
            total += len(block)
        return "\n\n".join(chunks)
    except Exception:
        return ""


def apply(system, kind):
    """把技能提示词拼到 system 后面；无技能时原样返回。"""
    base = str(system or "")
    try:
        extra = text_for(kind)
    except Exception:
        extra = ""
    if not extra:
        return base
    return base + "\n\n以下是本项目预置的作业技能，请在本次输出中遵守：\n" + extra


def set_enabled(name, on):
    """就地改写技能文件的 enabled 字段；成功返回 True。"""
    it = find(name)
    if not it:
        return False
    try:
        with open(it["path"], "r", encoding="utf-8") as f:
            raw = f.read()
    except Exception:
        return False
    val = "true" if on else "false"
    if re.search(r"(?mi)^enabled\s*:", raw):
        new = re.sub(r"(?mi)^enabled\s*:.*$", "enabled: " + val, raw, count=1)
    elif raw.startswith("---"):
        new = raw.replace("---\n", "---\nenabled: %s\n" % val, 1)
    else:
        new = "---\nname: %s\nenabled: %s\n---\n%s" % (it["name"], val, raw)
    try:
        with open(it["path"], "w", encoding="utf-8") as f:
            f.write(new)
        return True
    except Exception:
        return False


_TEMPLATE = """---
name: {name}
kind: all
enabled: true
priority: 0
# 可选：声明本技能要求使用的工具（逗号分隔）。不写则本技能只是提示词。
# tools: probe_host, check_sqli
---
在这里写给模型的额外指令。例如：
- 输出必须严格是 JSON，不要任何解释文字。
- 候选词优先使用目标组件的官方默认命名。
- 不要输出任何形式的攻击性说明，只给候选数据。
"""


def create(name):
    """新建一个技能模板；成功返回路径。"""
    nm = str(name or "").strip()
    if not nm:
        return None
    safe = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]", "_", nm)
    if not safe:
        return None
    d = _skill_dir()
    try:
        if not os.path.isdir(d):
            os.makedirs(d)
        p = os.path.join(d, safe + ".md")
        if os.path.exists(p):
            return None
        with open(p, "w", encoding="utf-8") as f:
            f.write(_TEMPLATE.format(name=nm))
        return p
    except Exception:
        return None


def _read_text(path):
    """读文本；失败返回 None。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return None


def install(src_path, name=None):
    """把外部技能文件（.md）装进 skills/；成功返回落盘路径。

    源文件没有 front matter 时补一个最小头（name/kind/enabled/priority），
    保证装进来的技能立刻可被 _parse 识别。同名已存在则拒绝覆盖（返回 None）。
    红线：只做本地文本复制，不 import 网络模块、不执行任何技能正文。
    """
    src = str(src_path or "").strip()
    if not src or not os.path.isfile(src):
        return None
    raw = _read_text(src)
    if raw is None:
        return None
    nm = str(name or "").strip()
    if not nm:
        nm = os.path.splitext(os.path.basename(src))[0]
    safe = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]", "_", nm)
    if not safe:
        return None
    if not _FM_RE.match(raw):
        raw = ("---\nname: %s\nkind: all\nenabled: true\npriority: 0\n---\n%s"
               % (nm, raw))
    d = _skill_dir()
    try:
        if not os.path.isdir(d):
            os.makedirs(d)
        p = os.path.join(d, safe + ".md")
        if os.path.exists(p):
            return None
        with open(p, "w", encoding="utf-8") as f:
            f.write(raw)
        return p
    except Exception:
        return None


def _reap(d, source, names):
    """收拾遗留条目：删掉同 source 的旧条目，以及文件名命中包内片段名的历史拆开条目。
    只在 ZIP 整包安装时调用；返回被删除的文件名列表（供调用方报告）。
    """
    gone = []
    try:
        entries = list(os.listdir(d))
    except Exception:
        return gone
    want = set()
    for x in (names or []):
        b = os.path.basename(str(x or "").strip())
        if b:
            want.add(os.path.splitext(b)[0].lower())
    for fn in entries:
        if not fn.lower().endswith(".md") or fn.lower() == "readme.md":
            continue
        it = _parse(os.path.join(d, fn))
        if not it:
            continue
        base = os.path.splitext(fn)[0].lower()
        if (it.get("source") or "") == source or base in want:
            try:
                os.remove(it["path"])
                gone.append(fn)
            except Exception:
                pass
    return gone


def install_pack(pack_name, docs, source=None, kind="all", priority=0):
    """把一整个 ZIP 包装成**一个**技能条目（round70 需求②：一个 ZIP = 一个工具）。

    ``docs`` 为 ``[(name, text), ...]``，按包内路径顺序排好；合并落成单个 .md。
    - 同名已存在 -> 整包重装（先删旧文件），保证"重装即覆盖"；
    - 装前先收拾该 source 的旧条目 + 历史拆开条目（早期版本会拆成多条）。
    红线不变：只做本地文本拼接与落盘，不执行技能正文、不联网。
    """
    nm = str(pack_name or "").strip()
    if not nm:
        return None
    safe = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]", "_", nm)
    if not safe:
        return None
    src = str(source or nm).strip() or nm
    parts = []
    for n, t in (docs or []):
        t = str(t or "").strip()
        if not t:
            continue
        parts.append("## %s\n%s" % (n, t))
    if not parts:
        return None
    d = _skill_dir()
    try:
        if not os.path.isdir(d):
            os.makedirs(d)
    except Exception:
        return None
    _reap(d, src, [n for n, _t in (docs or [])])
    p = os.path.join(d, safe + ".md")
    body = ("---\nname: %s\nkind: %s\nenabled: true\npriority: %d\nsource: %s\n---\n%s"
            % (nm, kind, priority, src, "\n\n".join(parts)))
    try:
        with open(p, "w", encoding="utf-8") as f:
            f.write(body)
        return p
    except Exception:
        return None


def uninstall_pack(name):
    """卸载一个"包"：删掉文件名为 name.md 的条目，以及 source == name 的全部条目。
    返回被删文件名列表（可能为空）。
    """
    want = str(name or "").strip()
    if not want:
        return []
    d = _skill_dir()
    gone = []
    try:
        entries = list(os.listdir(d))
    except Exception:
        return gone
    for fn in entries:
        if not fn.lower().endswith(".md"):
            continue
        it = _parse(os.path.join(d, fn))
        if not it:
            continue
        if (os.path.splitext(fn)[0].lower() == want.lower()
                or (it.get("source") or "") == want):
            try:
                os.remove(it["path"])
                gone.append(fn)
            except Exception:
                pass
    return gone


def uninstall(name):
    """从 skills/ 删除一个技能文件；成功返回 True。"""
    it = find(name)
    if not it:
        return False
    try:
        os.remove(it["path"])
        return True
    except Exception:
        return False


_USAGE = ("用法: python3 tools/skill_loader.py <list|show|on|off|new|text|install|uninstall> [参数]\n"
          "  list          列出已装技能\n"
          "  show <名字>   查看技能正文\n"
          "  on  <名字>    启用技能\n"
          "  off <名字>    停用技能\n"
          "  new <名字>    新建空白技能\n"
          "  text <类别>   打印注入某类别的提示词（words/trigger/actions/all）\n"
          "  install <文件> [名字>] 把外部 .md 装进 skills/（重名可选）\n"
          "  uninstall <名字>  从 skills/ 卸载（删除文件）\n")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd = argv[0] if argv else "list"
    if cmd in ("-h", "--help", "help"):
        print(_USAGE)
        return 0
    if cmd == "list":
        rows = list_skills()
        if not rows:
            print("(skills/ 下暂无技能)")
            return 0
        for it in rows:
            print("%-3s %-10s %-8s p=%-3d %s" % (
                "ON" if it["enabled"] else "off", it["kind"], it["file"],
                it["priority"], it["name"]))
        return 0
    if cmd == "show":
        it = find(argv[1] if len(argv) > 1 else "")
        if not it:
            print("[x] 找不到技能")
            return 1
        print("name=%s kind=%s enabled=%s priority=%d file=%s"
              % (it["name"], it["kind"], it["enabled"], it["priority"], it["file"]))
        print("-" * 40)
        print(it["text"])
        return 0
    if cmd in ("on", "off"):
        ok = set_enabled(argv[1] if len(argv) > 1 else "", cmd == "on")
        print("[+] 已启用" if ok else "[x] 操作失败或技能不存在")
        return 0 if ok else 1
    if cmd == "new":
        p = create(argv[1] if len(argv) > 1 else "")
        if p:
            print("[+] 已创建: %s" % p)
            return 0
        print("[x] 创建失败（名字为空或已存在）")
        return 1
    if cmd == "install":
        p = install(argv[1] if len(argv) > 1 else "",
                    argv[2] if len(argv) > 2 else None)
        if p:
            print("[+] 已装: %s" % p)
            return 0
        print("[x] 装失败（源文件不存在或同名已有）")
        return 1
    if cmd == "uninstall":
        tgt = argv[1] if len(argv) > 1 else ""
        gone = uninstall_pack(tgt)
        if gone:
            print("[+] 已卸 %d 个: %s" % (len(gone), ",".join(gone)))
            return 0
        ok = uninstall(tgt)
        print("[+] 已卸" if ok else "[x] 卸载失败或技能不存在")
        return 0 if ok else 1
    if cmd == "text":
        print(text_for(argv[1] if len(argv) > 1 else "all") or "(无)")
        return 0
    print(_USAGE)
    return 2


if __name__ == "__main__":
    sys.exit(main())
