# -*- coding: utf-8 -*-
"""tools/skill_exec.py —— round84 S 组：让 SKILL 包里的脚本真的能被 AI 调用。

为什么需要这个模块
------------------
``tools/skill_loader.py`` 的 ``install_pack()`` 只把包里所有 .md 拼成一个
提示词文件（红线：不执行正文、不联网），所以旧行为下 SKILL 包里的
``tools/*.py`` 永远不会落盘、也不会出现在 AI 的工具表里。于是用户在 Web
上装了 SKILL，AI 能读到说明书，却一个可调用的工具都没有。

本模块把“装了就能用”补完，三件事：
1. **安装**：把一个 SKILL 包的 ZIP 真解压到 ``skills/<包名>/``（提示词 .md
   仍由 skill_loader 负责，这里只管可执行部分）；
2. **发现**（丙方案）：
   - 优先读包内的 ``tools.json``（显式声明 name/entry/description/params）；
   - 没有 tools.json 时，按文件名约定把 ``tools/*.py`` 逐个当工具，
     用脚本 docstring 首行作描述，参数统一为 ``args``（命令行参数数组）；
3. **执行**：子进程跑 ``<解释器> <脚本> <args...>``，超时/异常全部吃掉，
   返回结构化结果，绝不向引擎抛。

安全纪律（与 MCP 一致）
----------------------
- 注册进 ``tool_registry`` 的工具一律 ``net=True``（脚本可能出网），因此
  自动继承授权前置/强度闸门/预算闸门，不存在绕过路径；
- ``DANGER_KEYS`` 里的关键词（exploit/webshell/brute...）一律不注册，
  避免把高风险脚本直接交给模型自动调；
- 子进程只允许跑“包目录内”的脚本（路径穿越直接拒）；
- 只在 ``takeover.skill.enabled`` 为真时加载，总开关关闭就不动。
"""
import json
import os
import re
import subprocess
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)

MAX_TOOLS = 60                 # 一个包最多注册多少个工具，防工具表爆炸
DEFAULT_TIMEOUT = 90           # 单个工具默认超时（秒）
MAX_OUTPUT = 20000             # 单次输出截断
DANGER_KEYS = ("webshell", "reverse_shell", "revshell", "bruteforce",
               "brute_force", "exploit", "ransom", "ddos")


def _user_root():
    """与 core.config._user_root 同口径（只依赖 os/sys，不 import core）。"""
    env = os.environ.get("BTSRHUNTER_USER_DIR")
    if env and str(env).strip():
        return os.path.abspath(os.path.expanduser(str(env).strip()))
    if getattr(sys, "frozen", False):
        return os.path.join(os.environ.get("LOCALAPPDATA")
                            or os.path.expanduser("~"),
                            "CardinalSRCHunter", "userdata")
    return _ROOT


def skills_root():
    """SKILL 包的落地根目录（与 skill_loader 的 .md 目录同源）。"""
    return os.path.join(_user_root(), "skills")


def _safe_name(name):
    s = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]", "_", str(name or "").strip())
    return s.strip("_")


def install_zip(zp, pack_name=None):
    """把一个 SKILL 包 ZIP 解压到 ``skills/<pack>/``。

    返回 ``{"ok", "dir", "files", "error"}``；zip-slip 已在写入前拦截。
    目录已存在时直接覆盖写入（重装即覆盖，不残留旧文件）。
    """
    import shutil
    import zipfile
    nm = _safe_name(pack_name or os.path.splitext(os.path.basename(zp))[0])
    if not nm:
        return {"ok": False, "error": "包名为空", "dir": "", "files": 0}
    dest = os.path.join(skills_root(), nm)
    n = 0
    try:
        if os.path.isdir(dest):
            shutil.rmtree(dest, ignore_errors=True)
        os.makedirs(dest)
    except Exception as e:
        return {"ok": False, "error": "创建目录失败: %s" % e,
                "dir": dest, "files": 0}
    try:
        with zipfile.ZipFile(zp) as z:
            for info in z.infolist():
                name = info.filename
                if not name or name.endswith("/"):
                    continue
                if name.startswith("__MACOSX/") or "/__MACOSX/" in name:
                    continue
                # zip-slip：解析边界必须还在 dest 内
                tgt = os.path.abspath(os.path.join(dest, name))
                if not tgt.startswith(os.path.abspath(dest) + os.sep):
                    continue
                try:
                    os.makedirs(os.path.dirname(tgt), exist_ok=True)
                    with z.open(info) as src, open(tgt, "wb") as out:
                        shutil.copyfileobj(src, out)
                    n += 1
                except Exception:
                    continue
    except zipfile.BadZipFile:
        return {"ok": False, "error": "不是有效的 zip", "dir": dest, "files": 0}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200], "dir": dest, "files": n}
    return {"ok": True, "dir": dest, "files": n, "error": ""}


def _read_doc_line(path):
    """取脚本 docstring 里的第一条有效行当描述（失败返回文件名）。"""
    base = os.path.basename(path)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            head = f.read(4000)
    except Exception:
        return base
    # 先把前导的开头字节（#! / coding / 空行）剥干净，再认 docstring；
    # 否则 "#!/usr/bin/env python3" 里的 "!" 会被当成描述。
    lines = head.splitlines()
    while lines:
        _t0 = lines[0].strip()
        if _t0.startswith("#") or not _t0:
            lines.pop(0)
        else:
            break
    body = "\n".join(lines).lstrip()
    for _q in ('"""', chr(39) * 3):
        if body.startswith(_q):
            body = body[3:]
            break
    else:
        return base
    for ln in body.splitlines():
        t = ln.strip()
        if t and not t.startswith(("Author", "License", "@")):
            return t[:120]
    return base


def _scan_tools_json(pkgdir):
    """读包内 tools.json（也接受 skill.tools.json）。返回 (tools, err)。"""
    for fn in ("tools.json", "skill.tools.json"):
        p = os.path.join(pkgdir, fn)
        if not os.path.isfile(p):
            continue
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception as e:
            return [], "tools.json 解析失败: %s" % e
        raw = d.get("tools") if isinstance(d, dict) else d
        out = []
        for it in (raw or []):
            if isinstance(it, str):
                it = {"name": it, "entry": it}
            if not isinstance(it, dict):
                continue
            nm = str(it.get("name") or "").strip()
            entry = str(it.get("entry") or it.get("path") or "").strip()
            if not nm or not entry:
                continue
            out.append({"name": nm, "entry": entry,
                        "desc": str(it.get("description")
                                    or it.get("desc") or nm)[:300],
                        "params": it.get("params") or it.get("parameters"),
                        "timeout": it.get("timeout") or DEFAULT_TIMEOUT})
        return out, ""
    return None, ""


def _script_dirs(pkgdir):
    """round84 S2：可执行脚本可能落在这些子目录里（按优先序）
    。很多 SKILL 包把脚本放在 assets/*scripts/ 而不是 tools/，只认 tools/
    会让“已装包却零工具”，所以这里统一回归。"""
    cands = ["tools", "scripts", os.path.join("assets", "detect-scripts"),
             "detect-scripts", os.path.join("assets", "scripts"),
             os.path.join("src-elite", "tools")]
    out = []
    for rel in cands:
        d = os.path.join(pkgdir, rel)
        if os.path.isdir(d):
            out.append((rel.replace(os.sep, "/"), d))
    return out


def _scan_by_convention(pkgdir):
    """丙方案兜底：脚本目录下一个 .py = 一个工具。

    优先 tools/，没有就依次往下找；一旦在某个目录里找到 .py，
    就停在该目录（避免 tools/ 和 assets/ 两份副本重复注册）。
    """
    out = []
    for rel, d in _script_dirs(pkgdir):
        try:
            names = sorted(os.listdir(d))
        except Exception:
            continue
        for fn in names:
            if not fn.lower().endswith(".py"):
                continue
            if fn.startswith("_") or fn.lower() in ("__init__.py", "setup.py"):
                continue
            p = os.path.join(d, fn)
            if not os.path.isfile(p):
                continue
            base = os.path.splitext(fn)[0]
            out.append({"name": base, "entry": rel + "/" + fn,
                        "desc": _read_doc_line(p), "params": None,
                        "timeout": DEFAULT_TIMEOUT})
        if out:
            break
    return out


def discover(pkgdir):
    """丙方案入口发现：有 tools.json 用它，没有按 tools/*.py 约定。

    返回 ``{"source": "tools.json|convention|none", "tools": [...],
    "error": ""}``。tools.json 存在但解析失败时**不**回退，直接报错，
    免得用户写了清单却不生效还找不到原因。
    """
    if not os.path.isdir(pkgdir):
        return {"source": "none", "tools": [], "error": "包目录不存在"}
    js, err = _scan_tools_json(pkgdir)
    if err:
        return {"source": "tools.json", "tools": [], "error": err}
    if js:
        return {"source": "tools.json", "tools": js[:MAX_TOOLS], "error": ""}
    conv = _scan_by_convention(pkgdir)
    if conv:
        return {"source": "convention", "tools": conv[:MAX_TOOLS], "error": ""}
    return {"source": "none", "tools": [], "error": "包内既无 tools.json 也无 tools/*.py"}


def _dangerous(name):
    low = str(name or "").lower()
    return any(k in low for k in DANGER_KEYS)


def _schema(prefix, name, desc, params):
    """统一转 OpenAI function schema；无强类型时用单个 args 数组。"""
    props = {"args": {"type": "array", "items": {"type": "string"},
                      "description": "命令行参数，按顺序传给脚本"}}
    required = []
    if isinstance(params, dict) and params.get("type") == "object":
        p = params.get("properties")
        if isinstance(p, dict) and p:
            props = p
            required = [str(x) for x in (params.get("required") or [])]
    return {"type": "function",
            "function": {"name": "%s%s" % (prefix, name),
                         "description": desc or name,
                         "parameters": {"type": "object", "properties": props,
                                        "required": required}}}


def run_tool(pkgdir, entry, args=None, timeout=DEFAULT_TIMEOUT):
    """子进程执行包内脚本；任何失败都返回结构化结果，不抛。"""
    root = os.path.abspath(pkgdir)
    p = os.path.abspath(os.path.join(root, str(entry or "")))
    if not p.startswith(root + os.sep):
        return {"ok": False, "error": "entry 越界（必须在包目录内）", "output": ""}
    if not os.path.isfile(p):
        return {"ok": False, "error": "脚本不存在: %s" % entry, "output": ""}
    argv = [sys.executable, p]
    seq = args if isinstance(args, (list, tuple)) else ([] if args in (None, "") else [str(args)])
    argv.extend(str(a) for a in seq)
    try:
        r = subprocess.run(argv, cwd=os.path.dirname(p) or root,
                           capture_output=True, text=True,
                           timeout=int(timeout or DEFAULT_TIMEOUT))
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout(%ss)" % timeout, "output": ""}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e), "output": ""}
    out = (r.stdout or "").strip()
    err = (r.stderr or "").strip()
    return {"ok": r.returncode == 0, "code": r.returncode,
            "output": out[-MAX_OUTPUT:], "stderr": err[-2000:]}


def load_from_config(config, registry, prefix="sk_", verbose=None):
    """把 skills/<包>/ 里的工具注册进 tool_registry。返回注册成功的工具名。

    - 只读本地文件，不解压、不联网；
    - 总开关 ``takeover.skill.enabled`` 关闭时直接返回 []；
    - 每个脚本都可能出网，因此注册一律 net=True，交给授权闸门管。
    """
    names = []
    root = skills_root()
    rows = []
    try:
        try:
            tk = config.get("takeover") if hasattr(config, "get") else None
        except Exception:
            tk = None
        sk = ((tk or {}).get("skill") or {}) if isinstance(tk, dict) else {}
        en = sk.get("enabled", True)
        if str(en).strip().lower() in ("0", "false", "no", "off"):
            return names
        if not os.path.isdir(root):
            return names
        pkgs = sorted(os.listdir(root))
    except Exception:
        return names
    for nm in pkgs:
        pdir = os.path.join(root, nm)
        if not os.path.isdir(pdir):
            continue
        info = discover(pdir)
        rows.append({"pack": nm, "source": info["source"],
                     "n": len(info["tools"]), "error": info["error"]})
        for it in info["tools"]:
            if _dangerous(it["name"]):
                rows.append({"pack": nm, "skipped": it["name"],
                             "why": "danger"})
                continue
            schema = _schema(prefix, it["name"], it.get("desc"), it.get("params"))
            full = schema["function"]["name"]
            _entry, _to = it["entry"], it.get("timeout") or DEFAULT_TIMEOUT

            def _call(engine, args, _d=pdir, _e=_entry, _t=_to):
                return run_tool(_d, _e, (args or {}).get("args"), timeout=_t)

            try:
                if registry.register_external(full, schema, _call,
                                              gate="", risk="medium",
                                              net=True):
                    names.append(full)
            except Exception:
                continue
    if verbose is not None:
        try:
            verbose(rows, names)
        except Exception:
            pass
    return names


def catalog():
    """只读盘点：Web 侧展示“装了哪些包、每个包有哪些可调用工具”。"""
    out = []
    root = skills_root()
    try:
        names = sorted(os.listdir(root))
    except Exception:
        return out
    for nm in names:
        pdir = os.path.join(root, nm)
        if not os.path.isdir(pdir):
            continue
        info = discover(pdir)
        out.append({"pack": nm, "source": info["source"],
                    "error": info["error"],
                    "tools": [{"name": t["name"], "entry": t["entry"],
                               "desc": t["desc"]} for t in info["tools"]]})
    return out


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd = argv[0] if argv else "list"
    if cmd == "list":
        rows = catalog()
        if not rows:
            print("(skills/ 下暂无可执行 SKILL 包)")
            return 0
        for it in rows:
            print("%-28s %-12s %2d tools %s"
                  % (it["pack"], it["source"], len(it["tools"]),
                     it["error"] or ""))
            for t in it["tools"]:
                print("    - %-24s %s" % (t["name"], t["desc"]))
        return 0
    if cmd == "discover":
        pdir = argv[1] if len(argv) > 1 else ""
        print(json.dumps(discover(pdir), ensure_ascii=False, indent=2))
        return 0
    if cmd == "run":
        if len(argv) < 3:
            print("用法: python3 -m tools.skill_exec run <包目录> <entry> [参数...]")
            return 2
        r = run_tool(argv[1], argv[2], argv[3:])
        print(json.dumps(r, ensure_ascii=False, indent=2))
        return 0 if r.get("ok") else 1
    print("用法: python3 -m tools.skill_exec <list|discover|run> [参数]")
    return 2


if __name__ == "__main__":
    sys.exit(main())
