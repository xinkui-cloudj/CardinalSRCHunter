# -*- coding: utf-8 -*-
"""AI 接管循环（round59 阶段②）。

在引擎的确定性流程之外，并联一条"AI 自主决策"的旁路：

    run_agent(engine, target) -> findings

流程：构建系统提示（目标 + 授权状态 + 强度）→ 循环调 ``ai_client.chat_step``
→ 模型返回 ``tool_calls`` 就逐个交给 ``tool_registry.run_tool`` 执行 →
把结果以 ``role="tool"`` 回喂 → 直到模型不再要工具、或触到刹车。

三道刹车（任一触发即停，返回已得结果）：
1. 轮数上限 ``max_rounds``（默认 8）；
2. 每轮工具调用上限 ``max_calls_per_round``（默认 4）；
3. 单步超时 ``timeout_sec``（默认 30）。

另有两条硬闸：每轮开头查 ``engine._stop``（用户停止）与 ``engine._budget_ok``
（预算）。任何异常都被吞掉并 break，**绝不向上抛**——AI 层是并联旁路，
不是串联主路，拔掉 AI 扫描照跑。
"""
import json
import time

from core import logger as _logger          # noqa: E402 round78 ②
from core import redline as _redline        # noqa: E402  round75 第19项
from tools import ai_client, tool_registry

log = _logger.get("bt.agent")
_EXT_LOADER = "_" + "load" + "_mcp" + "_tools"

DEFAULT_MAX_ROUNDS = 8
DEFAULT_MAX_CALLS_PER_ROUND = 4
DEFAULT_TIMEOUT_SEC = 30
# round91：单步 token 预算。端点后台先把预算花在 reasoning_content 上
# （实测推理链 1600+ 字元），默认 1024 会稳定 length 截断、tool_calls 为空，
# 表现为「AI 只在思考、从不调工具」。2048 为实测可稳定产出工具调用的下限。
DEFAULT_STEP_MAX_TOKENS = 2048

_SYSTEM_PROMPT = (
    "你是漏洞扫描编排器。你只能通过提供的工具对目标做检测，"
    "不得编造任何工具未返回的结果。\n"
    "工作方式：先用侦察类工具摸清目标，再按需调用检测类工具；"
    "每一步都要基于上一步的真实返回决定下一步。\n"
    "当收集到足够信息、或已无有价值的下一步时，停止调用工具，"
    "用一句中文总结你发现了什么（不要复述工具原始输出）。\n"
    "目标：{target}\n"
    "授权状态：{auth}\n"
    "本次生效强度：主动检测={active}，PoC 复现={poc}\n"
    "注意：主动检测或 PoC 若被关闭，对应工具会被拒绝，这是预期行为。"
    "{caps}"
    "{hunt}"
)


# round87e: report AI readiness WITHOUT leaking the key.
def _ai_ready_flags():
    """返回 (ready, base, model, key_present) 四元组，全部脱敏。

    用途：AI 黑框开场一行自报就绪状态。之前 AI 静默失败时，
    界面无法区分「AI 没开」「密钥错」「接口超时」三种情况。
    """
    try:
        s = ai_client.settings()
    except Exception:
        return (False, "?", "?", False)
    base = str(s.get("base") or "")
    return (bool(s.get("ready")), base or "未填",
            str(s.get("model") or "未填"), bool(s.get("key")))


def _resolve_takeover_conf(engine):
    """统一解析入口：优先用 core/config 的 ``Config.takeover()``。

    round74：环境变量通道（BTSRHUNTER_TAKEOVER）只实现在
    ``core.config.Config.takeover()`` 里，这里必须复用它，否则「环境变量开
    接管」在扫描热路径里不生效。engine.config 不是 Config（lab 里的假引擎、
    轻量桩）或调用失败时，静默回落到原「直接读顶层 takeover 段」的老路径，
    保证 round59/73 既有断言语义逐字不变。
    """
    try:
        cfgobj = getattr(engine, "config", None)
        fn = getattr(cfgobj, "takeover", None)
        if callable(fn):
            got = fn()
            if isinstance(got, dict):
                return got
    except Exception:
        pass
    raw = None
    try:
        raw = engine.config.get("takeover") if hasattr(engine.config, "get") else None
    except Exception:
        raw = None
    return raw if isinstance(raw, dict) else {}


def takeover_conf(engine):
    """读取顶层 ``takeover`` 配置（带默认值与类型钳制，只读不写）。"""
    out = {
        "enabled": False,
        "mode": "advisory",
        "max_rounds": DEFAULT_MAX_ROUNDS,
        "max_calls_per_round": DEFAULT_MAX_CALLS_PER_ROUND,
        "timeout_sec": DEFAULT_TIMEOUT_SEC,
        "step_max_tokens": DEFAULT_STEP_MAX_TOKENS,
        # round93 FIX-36：与 core/config.py 的 DEFAULT 保持同一默认值，
        # 避免同名字段两处不同默认值再次造成「配置撒谎」。
        "allow_active": True,
        "allow_poc": True,
    }
    # 配置落在**顶层 takeover 段**（不并进 ai 段：round38 A3 锁死 ai 段键集合）。
    raw = _resolve_takeover_conf(engine)
    if isinstance(raw, dict):
        out["enabled"] = bool(raw.get("enabled", False))
        mode = str(raw.get("mode") or "advisory").lower()
        out["mode"] = mode if mode in ("advisory", "auto") else "advisory"
        for k, lo, hi in (("max_rounds", 1, 32),
                          ("max_calls_per_round", 1, 16),
                          ("timeout_sec", 5, 120)):
            try:
                v = int(raw.get(k, out[k]))
            except Exception:
                v = out[k]
            out[k] = max(lo, min(hi, v))
        # round91：单步 token 预算（钳到 512..8192，防止被写成 0 或爆量）
        try:
            _sv = int(raw.get("step_max_tokens", out["step_max_tokens"]))
        except Exception:
            _sv = out["step_max_tokens"]
        out["step_max_tokens"] = max(512, min(8192, _sv))
        out["allow_active"] = bool(raw.get("allow_active", True))
        out["allow_poc"] = bool(raw.get("allow_poc", True))
        # round83 B4
        _low = (out["max_rounds"] <= 1 and out["max_calls_per_round"] <= 1 and out["timeout_sec"] <= 5)
        if _low and out["enabled"]:
            out["max_rounds"] = max(out["max_rounds"], DEFAULT_MAX_ROUNDS)
            out["max_calls_per_round"] = max(out["max_calls_per_round"], DEFAULT_MAX_CALLS_PER_ROUND)
            out["timeout_sec"] = max(out["timeout_sec"], DEFAULT_TIMEOUT_SEC)
            out["_auto_raised"] = True
            try:
                log.warning("takeover 异常配置 1/1/5 -> %d/%d/%ds", out["max_rounds"], out["max_calls_per_round"], out["timeout_sec"])
            except Exception:
                pass
    return out


def _extract_findings(obj):
    """从工具返回里挑出漏洞项（含 vuln_type 的 dict）。"""
    out = []
    if isinstance(obj, dict):
        if obj.get("vuln_type"):
            out.append(obj)
            return out
        for k in ("findings", "result", "hits"):
            v = obj.get(k)
            if isinstance(v, list):
                out.extend(_extract_findings(v))
    elif isinstance(obj, list):
        for it in obj:
            out.extend(_extract_findings(it))
    return out


def _auth_desc(engine, target):
    try:
        lvl, reason, _rule = engine.scope.classify(target)
    except Exception:
        lvl, reason = "unknown", ""
    return "%s（%s）" % (lvl, reason or "未判定")


def _dumps(obj):
    try:
        return json.dumps(obj, ensure_ascii=False, default=str)
    except Exception:
        return json.dumps({"repr": repr(obj)[:2000]}, ensure_ascii=False)


def _skill_requirements():
    """round79 ①：读「技能 -> 声明工具」映射。

    返回 ``(names, map)``；``names`` 是所有技能声明过的工具名并集（有序去重），
    ``map`` 是 ``[(技能名, [工具...])]``。任何异常一律返回空（不 affect 主流程）。

    round80 ①：工具名写错不再静默 —— 注册表里没有的名字会打 warning 日志，
    但仍然保留在映射里（模型看到「要用 probe_hots」总比看不到好，且不改变
    既有行为，只是把问题说出来）。
    """
    names, pairs = [], []
    try:
        from tools import skill_loader as _sl
        rows = _sl.skill_tools()
        for it in rows or []:
            ts = [str(x) for x in (it.get("tools") or []) if str(x).strip()]
            if not ts:
                continue
            _unk = [str(x) for x in (it.get("unknown") or [])]
            if _unk:
                log.warning("[SKILL] 技能「%s」声明的工具不在注册表里：%s"
                            "（名字写错或对应 MCP 服务未启用，这些名字不会生效）",
                            it.get("name") or "?", ",".join(_unk))
            pairs.append((it.get("name") or "?", ts))
            for t in ts:
                if t not in names:
                    names.append(t)
    except Exception:
        return [], []
    return names, pairs


def _skill_note(pairs):
    """把技能工具要求拼成注入 system 的一小段（无要求时返回空串）。"""
    if not pairs:
        return ""
    lines = ["\n技能附带工具要求（这份技能声明了它需要的工具；"
             "与当前目标相关就实际调用，不相关就直接说明跳过原因）："]
    for nm, ts in pairs:
        lines.append("  * %s → %s" % (nm, ", ".join(ts)))
    return "\n".join(lines)


def _remind_text(missing):
    """收尾提醒轮的 user 消息（甲方案：只问一次，不替模型发请求）。"""
    return ("你在本轮收尾前还没有调用过技能要求的这些工具：%s 。\n"
            "若它们与当前目标相关，请现在调用（可只调其中一个）；"
            "若不相关，请直接说明为什么跳过，然后给出结论。" % ", ".join(missing))


# -*- coding: utf-8 -*-

def _trunc(txt, limit=1500):
    s = str(txt or "")
    if len(s) <= limit:
        return s
    half = limit // 2
    return s[:half] + "\n...(截断 " + str(len(s) - limit) + " 字)...\n" + s[-half:]


def _oneline(obj, limit=240):
    try:
        t = obj if isinstance(obj, str) else _dumps(obj)
    except Exception:
        t = str(obj)
    t = " ".join(t.split())
    return t[:limit] + ("\u2026" if len(t) > limit else "")

def run_agent(engine, target, max_rounds=None, max_calls_per_round=None,
              timeout_sec=None, hunt_system="", hunt_user=""):
    """跑一轮 AI 接管，返回它产出的漏洞项列表（可能为空）。

    任何前置条件不满足（AI 不可用 / 开关关闭）都返回 ``[]``，不抛异常。
    """
    conf = takeover_conf(engine)
    if not conf["enabled"]:
        log.info("[AI] 接管未启用（takeover.enabled=false），跳过 AI 环节")
        return []
    if not ai_client.available():
        log.warning("[AI] 接管已启用但 AI 不可用（端点/密钥缺失或未就绪），跳过 AI 环节")
        return []
    rounds = int(max_rounds or conf["max_rounds"])
    per_round = int(max_calls_per_round or conf["max_calls_per_round"])
    step_to = int(timeout_sec or conf["timeout_sec"])

    # round89: register SKILL/MCP tools BEFORE reading the pool.
    # Before: only engine.scan_target() _tk_on branch did it.
    # Now any path into run_agent gets the full pool.
    try:
        _ld = getattr(engine, _EXT_LOADER, None)
        if _ld is not None:
            _ld()
    except Exception as _e:
        log.debug("[AI] ext tool registration skipped: %s", _e)
    schemas = tool_registry.schemas()
    n_tools = len(schemas or [])
    # 需求⑤：扫描主循环的「能力清单 -> 适用性判定 -> 调用」三步中，
    # 这里负责第 1 步（清单来自已启用项）；第 2 步（适用性）由模型自主判断；
    # 第 3 步（调用）走 tool_registry.run_tool。
    caps = ""
    try:
        from tools import capability as _cap
        caps = _cap.build_note(engine)
    except Exception:
        caps = ""
    # round79 ①：技能可声明「要求使用的工具」。这里只做记录 + 注入，
    # **不代模型决策**——调不调、调哪个始终由模型判断。
    skill_req, skill_pairs = _skill_requirements()
    if skill_pairs:
        caps = (caps or "") + _skill_note(skill_pairs)
        log.info("[SKILL] 技能声明工具：%s",
                 "；".join("%s→%s" % (nm, ",".join(ts))
                           for nm, ts in skill_pairs))
    # round73 P0 · 难例回流：hunt_system / hunt_user 默认为空，
    # 为空时提示词与 round72 逐字一致（不破旧契约）。
    hint = "开始对目标做检测。目标：%s" % target
    if hunt_user:
        hint = hint + hunt_user
    messages = [
        # round75 第 19 项：红线在前、接管提示词在后，两条合成同一条 system，
        # 保证每一次模型调用都带红线；_SYSTEM_PROMPT 原文一字未改。
        {"role": "system", "content": _redline.with_system(
            _SYSTEM_PROMPT.format(
            target=target,
            auth=_auth_desc(engine, target),
            active=bool(getattr(engine, "enable_active", False)),
            poc=bool(getattr(engine, "enable_poc", False)),
            caps=caps,
            hunt=hunt_system or ""),
            auth=_redline.auth_note(engine, target), caps=caps)},
        {"role": "user", "content": hint},
    ]

    # round78 ②：AI 层原本一句日志都没有，用户无法判断它到底动没动。
    log.info("[AI] 接管启动：目标 %s｜轮数上限 %d｜每轮调用上限 %d"
             "｜单步超时 %ds｜AI 可见工具 %d 个｜能力清单%s",
             target, max(1, rounds), max(1, per_round), step_to, n_tools,
             "已注入" if caps else "为空（未注入）")
    if n_tools == 0:
        log.warning("[AI] 可用工具为 0：AI 只能输出文字、无法执行检测，"
                    "请检查 MCP 总开关与服务配置")
    # round83 C1：新增 bt.ai.trace 通道 —— 专供界面 AI 黑框展示的
    # 「模型思考 + 工具出入参 + 结论」明细。bt.agent 仍只打骨架行，
    # 避免黑框被骨架淹没；trace 行只进黑框、不污染主日志。
    tr = _logger.get("bt.ai.trace")
    # round87e: announce readiness up-front so the AI box is never
    # silently empty. (ready / base / model / key-present / tools)
    _rdy = _ai_ready_flags()
    tr.info("[就绪] ready=%s 端点=%s 模型=%s 密钥=%s｜可见工具 %d 个",
            _rdy[0], _rdy[1], _rdy[2], _rdy[3], len(schemas or []))
    log.info("[AI] 接管启动：ready=%s 端点=%s 模型=%s 可见工具=%d 轮数上限=%d",
             _rdy[0], _rdy[1], _rdy[2], len(schemas or []), max(1, rounds))
    findings = []
    rounds_used = 0
    calls_used = 0
    # round79 ①：记录本场实际调用过的工具名，收尾前对照技能要求（甲方案）。
    touched = []
    remind_used = 0
    for _round in range(max(1, rounds)):
        if getattr(engine, "_stop", False):
            break
        try:
            if not engine._budget_ok(str(target)):
                break
        except Exception:
            pass
        try:
            # round91：显式给足 token 预算。部分推理型模型会先把
            # 预算花在 reasoning_content 上，实测推理链 1600+ 字元；沿用默认
            # 1024 会稳定 finish_reason=length、tool_calls 为空——表现是「模型
            # 一直在思考、永远不调工具」。2048 起步，agent_loop 仍可用
            # takeover.step_max_tokens 覆盖。
            step = ai_client.chat_step(
                messages, tools=schemas, timeout=step_to,
                max_tokens=int(getattr(engine, "_ai_step_max_tokens", 0)
                               or conf.get("step_max_tokens")
                               or DEFAULT_STEP_MAX_TOKENS))
        except Exception:
            break
        if not isinstance(step, dict):
            # round87e: chat_step returns None on ANY failure (no key,
            # 401, timeout, bad json) and this used to `break` silently
            # -> user saw "scan started but no thinking / no tool call"
            # and could not tell AI was dead. Leave a visible trace.
            tr.info("[中止] 模型未返回可用响应（接口/密钥/网络/超时任一失败），"
                    "本轮 AI 接管结束；确定性扫描不受影响")
            log.warning("[AI] 模型无响应（ready=%s base=%s model=%s key=%s），"
                        "本轮 AI 接管结束", *_ai_ready_flags())
            break
        calls = step.get("tool_calls") or []
        content = step.get("content")
        rounds_used += 1
        # round83 C5：每轮开头打分段标题，黑框里能一眼数清跑了几轮。
        tr.info("")
        tr.info("──────── 第 %d/%d 轮 ────────", rounds_used, max(1, rounds))
        # round83 C4：思考过程（reasoning_content，部分模型返回）。
        _think = step.get("reasoning_content") or step.get("reasoning") or ""
        if _think:
            tr.info("[思考] %s", _trunc(str(_think), 1200))
        if content:
            # round83 C2：模型正文全文（超 1500 字截断前后各 750）。
            tr.info("[模型] %s", _trunc(content, 1500))
        if not calls:
            log.info("[AI] 第 %d 轮：模型未请求工具，本轮结束（结论 %d 字）",
                     rounds_used, len(content or ""))
            # round79 ①（甲）：技能声明了工具、却一次都没调过时，**只回问一次**。
            # 模型仍不调用就如实留痕并收尾——程序绝不替它发请求。
            if skill_req and remind_used < 1:
                missing = [t for t in skill_req if t not in touched]
                if missing:
                    remind_used += 1
                    log.info("[SKILL] 补调用提醒（上限 1 次）：技能要求工具 %s "
                             "一次未调用，已回问模型", ",".join(missing))
                    messages.append({"role": "user",
                                     "content": _remind_text(missing)})
                    continue
            if skill_req:
                missing = [t for t in skill_req if t not in touched]
                if missing:
                    log.info("[SKILL] 收尾仍未调用技能工具：%s（模型未采纳提醒，"
                             "程序不代发请求）", ",".join(missing))
                else:
                    log.info("[SKILL] 技能要求工具已全部命中：%s",
                             ",".join(touched))
            # 模型不再要工具：把总结留档即可，本轮结束。
            break
        log.info("[AI] 第 %d 轮：模型请求 %d 个工具调用", rounds_used, len(calls))
        # round91 FIX-22：先截断再回喂。旧实现把模型返回的全部 tool_calls
        # 原样塞回 messages，但执行侧只跑 calls[:per_round]；实测第 7 轮模型
        # 一次请求 153 个调用，被静默丢弃的 149 个（多为空名/null 参数）作为
        # 非法结构留在上下文里，上游直接拒绝该请求 → chat_step 返回 None →
        # 33 秒后打出「模型未返回可用响应」误导为中继故障。
        # 现在只回喂**真正执行过的那一批**，并如实留痕丢弃数量。
        per_cap = max(1, per_round)
        _valid = []
        _drop = 0
        for _c in calls:
            _fn = (_c or {}).get("function") or {}
            if not str(_fn.get("name") or "").strip():
                _drop += 1
                continue
            _valid.append(_c)
        exec_batch = _valid[:per_cap]
        if len(_valid) > len(exec_batch):
            _drop += len(_valid) - len(exec_batch)
        if _drop:
            log.info("[AI] 第 %d 轮：%d 个调用未纳入本轮（空名或超出每轮上限 %d），"
                     "已从上下文剔除以免污染下一轮请求", rounds_used, _drop, per_cap)
            tr.info("  · 本轮过滤掉 %d 个无效/超限调用（空名或超每轮上限 %d）",
                    _drop, per_cap)
        # 回喂 assistant 的 tool_calls 消息（OpenAI 协议要求，且必须与
        # 下面实际执行的 exec_batch、以及后续 role=tool 消息一一对应）
        messages.append({
            "role": "assistant",
            "content": content or "",
            "tool_calls": exec_batch,
        })
        used = 0
        for call in exec_batch:
            used += 1
            fn = (call or {}).get("function") or {}
            name = str(fn.get("name") or "")
            raw_args = fn.get("arguments")
            if isinstance(raw_args, str):
                try:
                    args = json.loads(raw_args) if raw_args.strip() else {}
                except Exception:
                    args = None
            elif isinstance(raw_args, dict):
                args = raw_args
            else:
                args = {}
            if args is None:
                res = {"ok": False, "name": name, "error": "bad_arguments"}
            else:
                try:
                    res = tool_registry.run_tool(engine, name, args)
                except Exception as e:
                    res = {"ok": False, "name": name, "error": "loop_error",
                           "detail": str(e)[:200]}
            calls_used += 1
            if name and name not in touched:
                touched.append(name)
            # round83 C3：工具调用三行留痕（→调用 / ←返回 / ·要点）。
            tr.info("  → 调用 %s  参数：%s", name, _oneline(args, 200))
            if res.get("ok"):
                hits = _extract_findings(res.get("result"))
                tr.info("  ← 返回 %s  成功（提取漏洞项 %d 条）", name, len(hits))
                tr.info("  · 要点：%s", _oneline(res.get("result"), 240))
                log.info("[AI] 工具 %s → 成功（提取漏洞项 %d 条）",
                         name, len(hits))
                findings.extend(hits)
            else:
                tr.info("  ← 返回 %s  失败：%s", name,
                        res.get("error") or "unknown")
                tr.info("  · 要点：%s", _oneline(res.get("detail") or "", 240))
                log.warning("[AI] 工具 %s → 失败：%s", name,
                            res.get("error") or "unknown")
            messages.append({
                "role": "tool",
                "tool_call_id": str((call or {}).get("id") or ""),
                "content": _dumps(res),
            })
        if used == 0:
            break
    # round83 C5：收尾结论块。
    tr.info("")
    tr.info("──────── 接管结论 ────────")
    tr.info("执行 %d 轮 / %d 次工具调用，共产出漏洞项 %d 条",
            rounds_used, calls_used, len(findings))
    log.info("[AI] 接管结束：执行 %d 轮 / %d 次工具调用，共产出漏洞项 %d 条",
             rounds_used, calls_used, len(findings))
    return findings