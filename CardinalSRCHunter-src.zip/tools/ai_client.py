# -*- coding: utf-8 -*-
"""tools/ai_client.py —— 统一大模型客户端（OpenAI 兼容协议）。

定位
----
本项目“模型调用”的唯一出口，与 ``tools/websearch.py``（联网取数出口）平级。
四个离线工具（``dict_gen`` / ``hunt_assist`` / ``knowledge_learn`` /
``selfheal_learn``）通过 ``spec_from_file_location`` 动态加载本模块获取
“生成能力”；本模块自身不做决策、不落盘、不进扫描热路径。

协议
----
OpenAI 兼容：``POST {api_base}/chat/completions``::

    {"model": "...", "messages": [...], "temperature": 0.2}
    -> {"choices": [{"message": {"content": "..."}}]}

DeepSeek / 通义 DashScope / 智谱 / 硅基流动 / Moonshot / OpenRouter /
本地 Ollama（``http://127.0.0.1:11434/v1``）全部适用，换厂商只改
``config.json`` 的 ``ai.api_base`` 与 ``ai.model``。

密钥
----
**只从环境变量读**，变量名由 ``ai.api_key_env`` 指定（默认
``BTSRHUNTER_AI_KEY``）。密钥不落盘、不进 ``config.json``、不进发布包。

红线
----
1. 永不进扫描热路径：不 import ``core.engine`` / ``core.report`` /
   ``modules.*``；扫描链永不 import 本模块。
2. ``ai_ready()`` 为 False（或 api_base/model/key 任一为空）时**零网络动作**，
   调用方必须能原地回落到确定性规则表。
3. 任何异常一律静默返回 ``None``/``False``，绝不向上抛。

用法
----
  python3 tools/ai_client.py status
  python3 tools/ai_client.py ping
  echo "你好" | python3 tools/ai_client.py ask
"""
import json
import os
import ssl
import sys
import urllib.request

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core import config as cfg          # noqa: E402
from core import redline as _redline     # noqa: E402  round75 第19项（零依赖纯字符串）

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

DEFAULT_KEY_ENV = "BTSRHUNTER_AI_KEY"
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_TOKENS = 1024
UA = "bt-src-hunter/ai-client (+offline-analyzer)"


def key_value(env_name=None):
    """取密钥：环境变量优先，其次读密钥文件；都没有返回空串。

    round74：原先**只认环境变量**，导致"双击 GUI / 网页控制台"这条正常
    路径永远无法启用 AI（用户看到"已保存"却零 token 消耗的根因之一）。
    现补一条文件兜底：``cfg.read_ai_key_file()``，落点由 core/config.py 的
    ``ai_key_path()`` 决定（默认 USER_ROOT/data/ai_key.txt，可被
    ``BTSRHUNTER_KEYFILE`` 覆盖）。

    红线不变：密钥**从不写进 config.json**（round69 scrubs_secrets 依旧生效），
    且文件读取失败一律当空串处理，不向上抛。
    """
    name = (env_name or DEFAULT_KEY_ENV) or DEFAULT_KEY_ENV
    try:
        v = (os.environ.get(name) or "").strip()
    except Exception:
        v = ""
    if v:
        return v
    try:
        return cfg.read_ai_key_file()
    except Exception:
        return ""


def settings():
    """返回已钳制的运行参数快照（只读）。

    ``ready`` 为双开关语义（``enabled`` 且 ``online``），与
    ``Config.ai_ready()`` 同源；``timeout`` 走 ``search_timeout``
    （已被 ``AI_LIMITS`` 钳到 3..60）。
    """
    try:
        conf = cfg.Config()
        c = conf.ai()
        ready = bool(conf.ai_ready())
    except Exception:
        return {"ready": False, "base": "", "model": "",
                "key_env": DEFAULT_KEY_ENV, "key": "",
                "timeout": DEFAULT_TIMEOUT, "max_results": 5}
    env = str(c.get("api_key_env") or DEFAULT_KEY_ENV) or DEFAULT_KEY_ENV
    return {
        "ready": ready,
        "base": str(c.get("api_base") or "").strip(),
        "model": str(c.get("model") or "").strip(),
        "key_env": env,
        "key": key_value(env),
        "timeout": int(c.get("search_timeout") or DEFAULT_TIMEOUT),
        "max_results": int(c.get("search_max_results") or 5),
    }


def available():
    """模型是否真的可调用：双开关开 + base/model/key 三件齐备。"""
    s = settings()
    return bool(s["ready"] and s["base"] and s["model"] and s["key"])


def endpoint(base):
    """把 ``api_base`` 规整成 ``.../chat/completions``。"""
    u = str(base or "").strip().rstrip("/")
    if not u:
        return ""
    if u.endswith("/chat/completions"):
        return u
    return u + "/chat/completions"


# ------------------------------------------------------------
# 传输层：非流式 + 流式（SSE）双通道
# ------------------------------------------------------------
# round91 现场实测（某自建 OpenAI 兼容端点）：同一模型、同一密钥，
# **非流式** POST 稳定回 `HTTP 502` / body `error code: 502`，
# 加 `stream:true` 则 200 正常出字。原实现只发非流式，于是 chat()
# 恒返回 None——用户侧表现是「密钥填好了、AI 却完全不参与扫描」。
# 处理：非流式不成自动用流式重试一次，成功后记进 _FORCE_STREAM，
# 后续直接走流式（省掉一次注定失败的往返）。全失败仍静默返回 None，
# 红线 3 不变：AI 不可用绝不阻断主流程。
_FORCE_STREAM = [False]


def _sse_collect(raw):
    """把 SSE 文本流汇总成与非流式同形的结构。

    累积三样东西：正文增量、推理链增量、tool_calls 增量。tool_calls 按
    ``index`` 归并（OpenAI 流式协议里 function.arguments 是分片到达的，
    拼接后才能 json.loads），缺 index 时退化为按出现顺序分槽。
    """
    parts, reason = [], []
    calls = {}
    fin = ""
    for line in (raw or "").splitlines():
        line = line.strip()
        if not line or line.startswith(":") or not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            if payload == "[DONE]":
                break
            continue
        try:
            obj = json.loads(payload)
        except Exception:
            continue
        ch = (obj.get("choices") or [{}])[0] or {}
        if ch.get("finish_reason"):
            fin = str(ch["finish_reason"])
        d = ch.get("delta") or ch.get("message") or {}
        c = d.get("content")
        if isinstance(c, str) and c:
            parts.append(c)
        r = d.get("reasoning_content") or d.get("reasoning")
        if isinstance(r, str) and r:
            reason.append(r)
        for tc in (d.get("tool_calls") or []):
            # round91 FIX-21b：按 id 优先归并，缺 id 再用 index，两者皆缺时
            # 落到最后一个槽位继续拼参数——绝不新开槽位。旧实现 `idx=None`
            # 时用 `len(calls)` 兜底，每一片无 index 的分片都会新建一个空槽，
            # 实测一次响应能造出 149 个 `{"name":"","arguments":""}` 空壳，
            # 直接导致上游把非法 tool_calls 回喂给模型后被拒。
            tid = tc.get("id")
            idx = tc.get("index")
            key = None
            # index 优先：SSE 协议里 index 是稳定槽号，同一条调用的后续分片
            # 通常只带 index 不带 id；反过来以 id 优先会把后续分片拆到新槽，
            # 参数就拼不起来（断言 A5 曾抓到此回归）。
            if idx is not None:
                key = ("idx", idx)
            else:
                key = None
                if tid:
                    for k2, s2 in calls.items():
                        if s2.get("id") == str(tid):
                            key = k2
                            break
                if key is None and len(calls) == 1:
                    key = list(calls.keys())[0]
                if key is None and tid:
                    key = ("id", str(tid))
                if key is None:
                    key = list(calls.keys())[-1] if calls else ("idx", 0)
            slot = calls.setdefault(key, {"id": "", "type": "function",
                                         "function": {"name": "",
                                                      "arguments": ""}})
            if tid:
                slot["id"] = str(tid)
            fn = tc.get("function") or {}
            if fn.get("name"):
                slot["function"]["name"] = fn["name"]
            if fn.get("arguments"):
                slot["function"]["arguments"] += fn["arguments"]
    # round91 FIX-21b：只返回真正有函数名的调用。空名槽位对上游是非法
    # 结构（OpenAI 会 400/502），对执行侧只会产出 bad_arguments 噪声。
    out_calls = []
    for k in calls:
        c = calls[k]
        if not str(((c.get("function") or {}).get("name") or "")).strip():
            continue
        out_calls.append(c)
    return {"content": "".join(parts) or None,
            "reasoning_content": "".join(reason),
            "tool_calls": out_calls,
            "finish_reason": fin}


def _post(url, headers, body, timeout, stream=False):
    """发一次请求并解析成统一结构；任何失败返回 None。"""
    try:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    except Exception:
        return None
    try:
        req = urllib.request.Request(url, data=data, headers=headers)
        with urllib.request.urlopen(req, timeout=int(timeout),
                                    context=_CTX) as r:
            raw = r.read().decode("utf-8", "ignore")
    except Exception:
        return None
    if not stream:
        try:
            obj = json.loads(raw)
            choice = obj["choices"][0]
            msg = choice.get("message") or {}
            return {"content": msg.get("content"),
                    "reasoning_content": (msg.get("reasoning_content")
                                          or msg.get("reasoning") or ""),
                    "tool_calls": list(msg.get("tool_calls") or []),
                    "finish_reason": str(choice.get("finish_reason") or "")}
        except Exception:
            return None
    out = _sse_collect(raw)
    if not out.get("content") and not out.get("tool_calls"):
        return None
    return out


def _call(body, url, headers, timeout):
    """双通道调用：按 _FORCE_STREAM 记忆的偏好排序，失败自动换另一种。"""
    order = (True, False) if _FORCE_STREAM[0] else (False, True)
    for stream in order:
        b = dict(body)
        b["stream"] = bool(stream)
        res = _post(url, headers, b, timeout, stream=stream)
        if res is not None:
            _FORCE_STREAM[0] = bool(stream)
            return res
    return None


def chat(messages, temperature=0.2, timeout=None, max_tokens=None):
    """发一次对话请求，返回文本；任何失败返回 ``None``。

    端点后端会把 token 预算先花在 reasoning_content（推理链）上，
    极端情况下 finish_reason=length 且 message 里没有 content 字段。
    遇到这种情况自动把 max_tokens 翻倍重试一次（最多两轮），
    仍拿不到 content 就按红线静默返回 ``None``，由调用方回落规则表。
    """
    s = settings()
    if not (s["ready"] and s["base"] and s["model"] and s["key"]):
        return None
    url = endpoint(s["base"])
    if not url:
        return None
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + s["key"],
        "User-Agent": UA,
    }
    try:
        budget = int(max_tokens or DEFAULT_MAX_TOKENS)
    except Exception:
        budget = DEFAULT_MAX_TOKENS
    if budget <= 0:
        budget = DEFAULT_MAX_TOKENS
    try:
        temp = float(temperature)
    except Exception:
        temp = 0.2
    for _ in range(2):
        body = {
            "model": s["model"],
            "messages": _redline.with_system_first(messages),
            "temperature": temp,
            "max_tokens": int(budget),
        }
        res = _call(body, url, headers, timeout or s["timeout"])
        if res is None:
            return None
        text = res.get("content")
        if text:
            return text
        fin = str(res.get("finish_reason") or "")
        if fin != "length":
            return None
        budget = min(budget * 2, 8192)
    return None


def chat_step(messages, tools=None, tool_choice="auto", temperature=0.2,
              timeout=None, max_tokens=None):
    """带工具声明的一次对话请求（OpenAI function calling 兼容）。

    返回 ``{"content": str|None, "tool_calls": list, "finish_reason": str}``；
    任何失败一律静默返回 ``None``（红线：AI 不可用不阻断主流程）。

    ``tools`` 为空或 ``None`` 时不往请求体塞 ``tools`` / ``tool_choice`` 键，
    此时请求体与 :func:`chat` 逐字节一致，既有离线调用方零影响。
    ``tool_calls`` 的 ``arguments`` 保持模型原始字符串，由调用方解析。
    """
    s = settings()
    if not (s["ready"] and s["base"] and s["model"] and s["key"]):
        return None
    url = endpoint(s["base"])
    if not url:
        return None
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + s["key"],
        "User-Agent": UA,
    }
    try:
        budget = int(max_tokens or DEFAULT_MAX_TOKENS)
    except Exception:
        budget = DEFAULT_MAX_TOKENS
    if budget <= 0:
        budget = DEFAULT_MAX_TOKENS
    try:
        temp = float(temperature)
    except Exception:
        temp = 0.2
    msgs = list(messages or [])
    if not any(isinstance(m, dict) and m.get("role") == "system"
               for m in msgs):
        # round75 第 19 项：调用方没给 system 就自动补红线；给了就不动
        # （agent_loop 走的是注入分支，避免同一段红线重复进上下文）。
        msgs.insert(0, {"role": "system",
                        "content": _redline.redline_text()})
    body = {
        "model": s["model"],
        "messages": msgs,
        "temperature": temp,
        "max_tokens": int(budget),
    }
    if tools:
        body["tools"] = list(tools)
        body["tool_choice"] = tool_choice or "auto"
    res = _call(body, url, headers, timeout or s["timeout"])
    if res is None:
        return None
    msg = {"content": res.get("content"),
           "tool_calls": list(res.get("tool_calls") or []),
           "reasoning_content": res.get("reasoning_content") or ""}
    content = msg.get("content")
    calls = msg.get("tool_calls") or []
    fin = str(res.get("finish_reason") or "")
    return {
        "content": content if isinstance(content, str) else None,
        "tool_calls": list(calls),
        "finish_reason": fin,
        # round83 C4：透传推理链（DeepSeek-R1 / QwQ / 硅基流动等会返回），
        # 缺省空串。agent_loop 用它把「模型在想什么」打进 AI 黑框。
        "reasoning_content": (msg.get("reasoning_content")
                              or msg.get("reasoning") or ""),
    }


def strip_fence(text):
    """剥掉 ```json ... ``` 围栏（模型爱加）。"""
    t = (text or "").strip()
    if not t.startswith("```"):
        return t
    lines = t.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip().startswith("```"):
        lines = lines[:-1]
    return "\n".join(lines).strip()


def ask_json(prompt, system=None, timeout=None, max_tokens=None):
    """要求模型输出 JSON 并解析；失败返回 ``None``。"""
    msgs = []
    if system:
        msgs.append({"role": "system", "content": str(system)})
    msgs.append({"role": "user", "content": str(prompt)})
    txt = chat(msgs, timeout=timeout, max_tokens=max_tokens)
    if not txt:
        return None
    try:
        return json.loads(strip_fence(txt))
    except Exception:
        return None


def status():
    """诊断用：不泄露密钥，只报是否存在与长度。"""
    s = settings()
    return {
        "ready": s["ready"],
        "api_base": s["base"],
        "model": s["model"],
        "key_env": s["key_env"],
        "key_present": bool(s["key"]),
        "key_len": len(s["key"]),
        "available": available(),
        "endpoint": endpoint(s["base"]),
    }


_USAGE = ("用法: python3 tools/ai_client.py <status|ping|ask>\n"
          "  status : 打印配置与密钥存在性（不回显密钥）\n"
          "  ping   : 发一次最小请求，验证通路\n"
          "  ask    : 读 stdin 当 prompt，输出模型返回\n")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd = argv[0] if argv else "status"
    if cmd in ("-h", "--help", "help"):
        print(_USAGE)
        return 0
    if cmd == "status":
        print(json.dumps(status(), ensure_ascii=False, indent=2))
        return 0
    if cmd == "ping":
        if not available():
            print("[ai] 不可用（双开关/配置/密钥未齐备）")
            return 1
        txt = chat([{"role": "user", "content": "ping，只回复 pong"}],
                   max_tokens=16)
        print("[ai] %s" % ("OK: " + str(txt).strip() if txt else "FAILED"))
        return 0 if txt else 1
    if cmd == "ask":
        prompt = sys.stdin.read()
        txt = chat([{"role": "user", "content": prompt}])
        if not txt:
            print("[ai] 无返回")
            return 1
        print(txt)
        return 0
    print(_USAGE)
    return 2


if __name__ == "__main__":
    sys.exit(main())
