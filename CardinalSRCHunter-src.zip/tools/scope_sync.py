# -*- coding: utf-8 -*-
"""scope_sync：把「授权范围（白名单）」的获取过程离线化。

定位与红线（与 tools/hunt_promote.py 同款，三条）：
  1. 本工具是**离线旁路**，永不进扫描热路径，绝不 import core.engine /
     core.httpclient / modules.*；只被 CLI 手动调用。
  2. AI 只负责「提候选」：从公开 SRC / 漏洞平台检索已公布的授权测试范围，
     抽取域名 -> 落 **.draft** 候选文件。是否生效完全由人显式 --apply 决定，
     不做任何自动 / 定时 / 后台提升。
  3. 正式化时**只追加不覆盖**：只往 config/scope.yaml 的 in_scope 追加新域名，
     原文件先备份，写入用「同目录 .tmp + os.replace」原子替换。

数据流：
  tools/websearch.py (公开 SRC 平台检索) ─┐
                                          ├─> 域名候选 -> data/scope_suggest.yaml.draft
  tools/ai_client.py (可选，模型抽域名)  ─┘                        │
                                                                  │ 人审 + --apply
                                                                  v
                                     config/scope.yaml 的 in_scope（追加去重，含备份）

用法：
  python3 main.py scope-sync                 # 只打印计划（默认预演，不联网也不落盘）
  python3 main.py scope-sync --fetch         # 联网检索 + 生成 .draft 候选
  python3 main.py scope-sync --fetch --ai    # 额外让模型从摘要里抽域名
  python3 main.py scope-sync --list          # 查看草稿状态
  python3 main.py scope-sync --apply         # 人审通过后，把候选并入 scope.yaml
"""
import io
import json
import os
import re
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from core import config as cfg          # noqa: E402
from core import dicts as _dicts        # noqa: E402

# ---- 契约：草稿后缀只从 core/dicts.py 引用，绝不写字面量 ----
DRAFT_SUFFIX = _dicts.DRAFT_SUFFIX
SUGGEST_NAME = "scope_suggest.yaml"
SUGGEST_DRAFT_NAME = SUGGEST_NAME + DRAFT_SUFFIX
DEFAULT_OUT_DIR = cfg.DATA_DIR
SCOPE_PATH = getattr(cfg, "SCOPE_PATH",
                     os.path.join(cfg.ROOT, "config", "scope.yaml"))

# ---- 公开 SRC / 漏洞平台检索模板（只取公开页面，不登录、不提交）----
SOURCES = (
    ("butian", "补天漏洞响应平台 测试范围 授权 域名"),
    ("butian_gift", "补天公益SRC 测试范围 域名列表"),
    ("cnvd", "CNVD 漏洞平台 测试范围 授权 域名"),
    ("edu_src", "教育行业SRC 测试范围 授权域名"),
    ("vulbox", "漏洞盒子 测试范围 授权"),
    ("hackerone", "hackerone program in scope domains"),
)

# 抽取域名的正则：至少一个点，末段为字母后缀
_HOST_RE = re.compile(
    r"\b((?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,24})\b",
    re.I)

# 噪声：搜索引擎自身、平台自身、公共基础设施
_NOISE = set((
    "baidu.com", "bing.com", "google.com", "gstatic.com", "googleapis.com",
    "github.com", "githubusercontent.com", "w3.org", "wikipedia.org",
    "zhihu.com", "csdn.net", "cnblogs.com", "jianshu.com", "gitee.com",
    "qq.com", "weixin.qq.com", "sohu.com", "sina.com.cn", "163.com",
    "butian.net", "butian.com", "vulbox.com", "cnvd.org.cn", "hackerone.com",
    "microsoft.com", "apple.com", "cloudflare.com", "amazonaws.com",
))


def _load_module(name, relpath):
    """按路径动态加载兄弟模块（websearch / ai_client 的唯一取用方式）。
    绝不顶层 import：这两模块有「不进热路径」约束，proot 下相对导入易踩坑。
    加载失败一律静默返回 None，由调用方回落。
    """
    import importlib.util
    p = os.path.join(ROOT, relpath)
    if not os.path.isfile(p):
        return None
    try:
        spec = importlib.util.spec_from_file_location(name, p)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m
    except Exception:
        return None


def extract_hosts(text):
    """从任意文本里抽域名（纯函数，零 IO、零网络，可离线单测）。
    去噪声 + 去重 + 小写。返回 set。
    """
    out = set()
    if not isinstance(text, str):
        return out
    for m in _HOST_RE.finditer(text):
        h = m.group(1).lower().strip(".")
        if h in _NOISE:
            continue
        if any(h.endswith("." + n) for n in _NOISE):
            continue
        if len(h) > 253:
            continue
        out.add(h)
    return out


def load_scope_hosts(scope_path=None):
    """读取 scope.yaml 当前 in_scope（用于去重与展示）。失败返回空列表。"""
    p = scope_path or SCOPE_PATH
    if not os.path.isfile(p):
        return []
    try:
        import yaml
        with io.open(p, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        lst = data.get("in_scope") or []
        return [str(x) for x in lst if str(x).strip()]
    except Exception:
        return []

def collect(sources, engine="auto", max_per_source=5, timeout=12, use_ai=False):
    """联网检索公开 SRC 平台，抽取候选域名。
    返回 (hosts, evidence, notes)：hosts 为排序后的域名列表，evidence 为
    host -> 来源 url 映射，notes 为逐源说明。任何异常都不抛出，只记 note。
    """
    notes = []
    ws = _load_module("bt_scope_websearch", os.path.join("tools", "websearch.py"))
    if ws is None:
        return [], {}, ["websearch 模块不可用，未检索"]
    ac = None
    if use_ai:
        ac = _load_module("bt_scope_aiclient", os.path.join("tools", "ai_client.py"))
    ai_ok = bool(ac and ac.available())
    if use_ai and not ai_ok:
        notes.append("AI 未就绪（需 enabled+online+base/model/key），跳过模型抽取")

    cands = {}
    for tag, query in sources:
        try:
            hits = ws.search(query, engine=engine,
                             max_results=max_per_source, timeout=timeout)
        except Exception as e:
            notes.append("%s: 检索失败 %s" % (tag, e))
            continue
        hits = hits or []
        added = 0
        blobs = []
        for h in hits:
            blob = " ".join([str(h.get("title", "")),
                             str(h.get("snippet", "")),
                             str(h.get("url", ""))])
            blobs.append(blob)
            for host in extract_hosts(blob):
                if host not in cands:
                    cands[host] = str(h.get("url", ""))
                    added += 1
        if ai_ok and blobs:
            for host in _ai_extract(ac, blobs):
                if host not in cands:
                    cands[host] = "ai:" + tag
                    added += 1
        notes.append("%s: %d 命中 / 新增 %d 域名" % (tag, len(hits), added))
    return sorted(cands), cands, notes


def _ai_extract(ac, blobs):
    """让模型从检索摘要里抽域名，只返回候选集合（不落盘、不改状态）。"""
    try:
        text = "\n".join(blobs)[:6000]
        prompt = (
            "从下列检索摘要中抽取所有出现的域名（形如 a.example.com）。\n"
            "只输出 JSON：{\"hosts\": [\"...\"]}。不要解释，不要编造。\n\n"
            "摘要：\n" + text
        )
        obj = ac.ask_json(prompt, temperature=0.0, max_tokens=1024)
        if not isinstance(obj, dict):
            return set()
        raw = obj.get("hosts")
        if not isinstance(raw, list):
            return set()
        out = set()
        for x in raw[:200]:
            for h in extract_hosts(str(x)):
                out.add(h)
        return out
    except Exception:
        return set()


def _q(s):
    """YAML 安全标量：用 json.dumps 做转义（保证确定性、无歧义）。"""
    return json.dumps(str(s), ensure_ascii=False)


def render(cands, evidence, meta, notes):
    """渲染候选草稿 YAML（确定性：保持插入序，无随机）。"""
    L = []
    L.append("# scope_sync 候选授权范围（检索/AI 生成，**尚未生效**）")
    L.append("# 人工审核后执行： python3 main.py scope-sync --apply")
    L.append("generated_at: " + _q(meta.get("generated_at", "")))
    L.append("engine: " + _q(meta.get("engine", "")))
    L.append("ai: " + _q("on" if meta.get("ai") else "off"))
    if not cands:
        L.append("candidates: []")
    else:
        L.append("candidates:")
        for h in cands:
            L.append("  - host: " + _q(h))
            L.append("    evidence: " + _q(evidence.get(h, "")))
    L.append("notes:")
    for n in (notes or []):
        L.append("  - " + _q(n))
    return "\n".join(L) + "\n"


def atomic_write(path, text):
    """原子写：同目录 .tmp + os.replace（与 hunt_promote 同款）。"""
    d = os.path.dirname(path) or "."
    if not os.path.isdir(d):
        os.makedirs(d)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def read_draft(path):
    """读取草稿。非 .draft 结尾一律拒绝（安全侧默认）。"""
    if not _dicts.is_draft(path):
        raise ValueError("拒绝非草稿输入：%s（安全侧默认）" % path)
    if not os.path.isfile(path):
        raise ValueError("草稿不存在：%s" % path)
    import yaml
    with io.open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError("草稿顶层必须是映射：%s" % path)
    return data


def draft_hosts(data):
    """从草稿数据里取候选域名列表（去重、保序）。"""
    out = []
    seen = set()
    for item in (data.get("candidates") or []):
        if isinstance(item, dict):
            h = str(item.get("host", "")).strip().lower()
        else:
            h = str(item).strip().lower()
        if h and h not in seen:
            seen.add(h)
            out.append(h)
    return out

def insert_in_scope(text, hosts):
    """文本级把新域名追加到 scope.yaml 的 in_scope 块末尾。
    只追加、不覆盖、不动其它键与注释。返回 (新文本, 实际新增列表)。
    """
    hosts = [str(h).strip() for h in (hosts or []) if str(h).strip()]
    if not hosts:
        return text, []
    if not text.endswith("\n"):
        text += "\n"
    lines = text.split("\n")
    idx = None
    for k, ln in enumerate(lines):
        if re.match(r"^in_scope\s*:", ln):
            idx = k
            break
    # 没有 in_scope 键：追加一个新块（只追加，不覆盖）
    if idx is None:
        if lines and lines[-1] != "":
            pass
        out = text.rstrip("\n") + "\nin_scope:\n"
        for h in hosts:
            out += "  - " + h + "\n"
        return out, list(hosts)

    head = lines[idx]
    key = head.split(":", 1)[0]
    rest = head.split(":", 1)[1].strip()
    existing = []
    if rest and rest not in ("[]", "null", "~"):
        # 行内写法（如 [a, b]）-> 统一重写为块状列表
        body = rest
        if body.startswith("[") and body.endswith("]"):
            body = body[1:-1]
        existing = [x.strip().strip("'\"") for x in body.split(",") if x.strip()]
        lines[idx] = key + ":"
        # 行内 -> 块状：原条目必须回写，否则丢数据（只追加不覆盖的反面教材）
        block = ["  - " + e for e in existing]
        lines[idx + 1:idx + 1] = block
        insert_at = idx + 1 + len(block)
    else:
        lines[idx] = key + ":"
        # 块状：定位 in_scope 块范围（缩进行），插入点取最后一个条目行之后
        j = idx + 1
        insert_at = idx + 1
        while j < len(lines):
            ln = lines[j]
            if ln.strip() == "":
                j += 1
                continue
            if ln[0] in (" ", "\t"):
                if re.match(r"^\s+-\s", ln):
                    insert_at = j + 1
                    m = re.match(r"^\s+-\s*(.+?)\s*$", ln)
                    if m:
                        existing.append(m.group(1).strip().strip("'\""))
                j += 1
                continue
            break

    seen = set(existing)
    new = []
    for h in hosts:
        if h not in seen:
            seen.add(h)
            new.append(h)
    for h in new:
        lines.insert(insert_at, "  - " + h)
        insert_at += 1
    return "\n".join(lines), new


USAGE = """scope_sync - 离线同步「授权范围（白名单）」

用法：
  python3 main.py scope-sync                    只打印计划（默认，不联网不落盘）
  python3 main.py scope-sync --fetch            联网检索公开 SRC，写 .draft 候选
  python3 main.py scope-sync --fetch --ai       额外让模型从摘要抽域名
  python3 main.py scope-sync --list             查看草稿 + 当前 in_scope
  python3 main.py scope-sync --apply            人审通过后并入 config/scope.yaml

可选：--engine bing|baidu|auto  --max-per-source N  --sources a,b  --out-dir DIR  --dry-run
红线：AI 只提候选落 .draft；是否生效完全由人显式 --apply 决定；只追加不覆盖。
"""


def _parse_args(argv):
    """极简参数解析（不依赖 argparse，保持离线可测）。"""
    a = {"list": False, "apply": False, "fetch": False, "ai": False,
         "dry_run": False, "engine": "auto", "max_per_source": 5,
         "out_dir": DEFAULT_OUT_DIR, "sources": None, "help": False}
    i = 0
    n = len(argv)
    while i < n:
        t = argv[i]
        if t in ("-h", "--help", "help"):
            a["help"] = True
        elif t == "--list":
            a["list"] = True
        elif t == "--apply":
            a["apply"] = True
        elif t == "--fetch":
            a["fetch"] = True
        elif t == "--ai":
            a["ai"] = True
        elif t == "--dry-run":
            a["dry_run"] = True
        elif t == "--engine":
            i += 1
            if i < n:
                a["engine"] = argv[i]
        elif t == "--max-per-source":
            i += 1
            if i < n:
                try:
                    a["max_per_source"] = max(1, int(argv[i]))
                except Exception:
                    pass
        elif t == "--out-dir":
            i += 1
            if i < n:
                a["out_dir"] = argv[i]
        elif t == "--sources":
            i += 1
            if i < n:
                a["sources"] = [s.strip() for s in argv[i].split(",") if s.strip()]
        else:
            print("[scope_sync] 未知参数：%s（--help 看用法）" % t)
        i += 1
    return a


def _draft_path(args):
    return os.path.join(args.get("out_dir") or DEFAULT_OUT_DIR, SUGGEST_DRAFT_NAME)


def do_list(args):
    draft = _draft_path(args)
    print("[scope_sync] 草稿：%s" % draft)
    if not os.path.isfile(draft):
        print("  状态：不存在（先跑 --fetch）")
    else:
        try:
            data = read_draft(draft)
            hosts = draft_hosts(data)
            live = set(load_scope_hosts())
            pend = [h for h in hosts if h not in live]
            print("  状态：存在；候选 %d 条，其中未生效 %d 条" % (len(hosts), len(pend)))
            for h in pend[:50]:
                print("    + %s" % h)
        except Exception as e:
            print("  状态：读取失败 %s" % e)
    live_all = load_scope_hosts()
    print("[scope_sync] 当前 in_scope（%s）：%d 条" % (SCOPE_PATH, len(live_all)))
    for h in live_all:
        print("  - %s" % h)
    return 0


def do_fetch(args):
    srcs = SOURCES
    if args.get("sources"):
        want = set(args["sources"])
        srcs = tuple(s for s in SOURCES if s[0] in want)
        if not srcs:
            print("[scope_sync] --sources 未命中已知源：%s" % ",".join(sorted(want)))
            return 1
    draft = _draft_path(args)
    if not args.get("fetch"):
        print("[scope_sync] 预演（未联网）。加 --fetch 才会检索并写草稿。")
        print("  计划源（%d）：%s" % (len(srcs), ", ".join(s[0] for s in srcs)))
        print("  引擎：%s  每源条数：%d" % (args.get("engine"), args.get("max_per_source")))
        print("  草稿目标：%s" % draft)
        print("  模型参与：%s" % ("是" if args.get("ai") else "否（加 --ai 开启）"))
        return 0

    hosts, evidence, notes = collect(
        srcs, engine=args.get("engine", "auto"),
        max_per_source=args.get("max_per_source", 5),
        use_ai=bool(args.get("ai")))
    live = set(load_scope_hosts())
    cands = [h for h in hosts if h not in live]
    meta = {"generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "engine": args.get("engine", "auto"),
            "ai": bool(args.get("ai"))}
    text = render(cands, evidence, meta, notes)
    if args.get("dry_run"):
        print(text)
        print("[scope_sync] 预演完成（未落盘）")
        return 0
    atomic_write(draft, text)
    print("[scope_sync] 检索完成：命中域名 %d 个，去掉已在 in_scope 的，候选 %d 个"
          % (len(hosts), len(cands)))
    for nline in notes:
        print("  - %s" % nline)
    print("[scope_sync] 草稿已写入：%s（%d 字节）" % (draft, len(text.encode("utf-8"))))
    print("[scope_sync] 下一步：人工审核后 python3 main.py scope-sync --apply")
    return 0


def do_apply(args):
    draft = _draft_path(args)
    try:
        data = read_draft(draft)
    except Exception as e:
        print("[scope_sync] %s" % e)
        return 1
    hosts = draft_hosts(data)
    if not hosts:
        print("[scope_sync] 草稿无候选，无事可做。")
        return 0
    try:
        with io.open(SCOPE_PATH, "r", encoding="utf-8") as f:
            old = f.read()
    except Exception as e:
        print("[scope_sync] 读取 %s 失败：%s" % (SCOPE_PATH, e))
        return 1
    new_text, added = insert_in_scope(old, hosts)
    if not added:
        print("[scope_sync] 候选 %d 条全部已在 in_scope，无新增。" % len(hosts))
        return 0
    if not args.get("apply"):
        print("[scope_sync] 预演 OK -> 将向 %s 追加 %d 条：" % (SCOPE_PATH, len(added)))
        for h in added:
            print("    + %s" % h)
        print("  加 --apply 才落盘（原文件会先备份）。")
        return 0
    ts = time.strftime("%Y%m%d_%H%M%S")
    bak = SCOPE_PATH + ".bak_scope_sync_" + ts
    atomic_write(bak, old)
    atomic_write(SCOPE_PATH, new_text)
    print("[scope_sync] 已并入 %d 条到 in_scope：" % len(added))
    for h in added:
        print("    + %s" % h)
    print("  备份：%s" % bak)
    print("  生效文件：%s" % SCOPE_PATH)
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    args = _parse_args(argv)
    if args.get("help"):
        print(USAGE)
        return 0
    if args.get("list"):
        return do_list(args)
    if args.get("apply"):
        return do_apply(args)
    return do_fetch(args)


if __name__ == "__main__":
    sys.exit(main())
