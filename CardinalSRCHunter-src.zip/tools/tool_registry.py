# -*- coding: utf-8 -*-
"""AI 工具注册表（round59 阶段②）。

把 modules/ 里实测存在的扫描动作包装成 OpenAI function-calling 工具，
并提供**唯一的执行入口** :func:`run_tool`。所有安全检查集中在这一层：

1. 工具名白名单 —— 不在表内直接拒绝；
2. 参数白名单 —— 只接受 schema 里声明过的键，多余键丢弃；
3. 授权前置 —— 调前跑 ``engine.scope.check(url)``，被 out_of_scope 排除的
   目标直接返回 ``{"error": "out_of_scope"}``，绝不发请求；
4. 强度闸门 —— ``gate`` 含 ``active`` 仅当 ``engine.enable_active`` 为真放行；
   含 ``poc`` 仅当 ``engine.enable_poc`` 为真放行；round93 FIX-36 起再加一道
   AI 侧授权位（``takeover.allow_active`` / ``takeover.allow_poc``，
   缺键视为 True），两层 AND 才放行；
5. 预算闸门 —— 出网类工具调前过一次 ``engine._budget_ok(host)``；
6. 结果截断 —— 任何返回值序列化后限长 ``MAX_RESULT_CHARS``。

设计红线：本模块**只读**引擎状态（enable_active / enable_poc / scope /
_budget_ok / _stop），不修改任何既有行为；任何异常都被吞成 ``{"error": ...}``，
绝不向上抛。AI 不可用时本模块不会被调用（由 agent_loop 决定）。
"""
import json
import re

from core import config as cfg
from core.scope import _norm_host

# 结果序列化上限：超过就截断并标注，防止把大响应灌进模型上下文。
MAX_RESULT_CHARS = 4000

# 闸门常量
GATE_ACTIVE = "active"
GATE_POC = "poc"


def _tk_allow(engine, key):
    """读 AI 侧授权位（``takeover.allow_active`` / ``takeover.allow_poc``）。

    round93 FIX-36：这两个键此前是**死配置**——core/config.py 与
    agent_loop.takeover_conf 都只赋值、全库没有任何消费点，于是「配置里写
    false，AI 照样发主动包」是句谎话。真正的闸门只有扫描档位
    （engine.enable_active / enable_poc），而它是**全扫描**共用的、不是
    AI 专属开关，所以用户没法单独把 AI 关成「只出候选」。

    语义定为 **AND**：档位（scan.mode）给能力上限，这里给 AI 侧授权，
    两者都为真才放行。缺键一律回落 True（老 config.json 没有这两个键时
    行为与升级前逐字一致，不因接线而突然收紧）。

    读取顺序：
      1. ``engine.config.takeover()`` —— 真 Config 时走这条，已带 env
         覆盖与钳制，不在这里重复实现；
      2. ``engine.config.get("takeover")`` —— 假引擎/桩配置的兼容路径；
      3. 都没有 -> True。
    任何异常都吞成 True：本模块的设计红线是「绝不因自身异常而阻断 AI」，
    而真正的安全边界在下一层的 scope 授权与档位闸门。
    """
    conf = getattr(engine, "config", None)
    try:
        fn = getattr(conf, "takeover", None)
        if callable(fn):
            got = fn()
            if isinstance(got, dict) and key in got:
                return bool(got[key])
    except Exception:
        pass
    try:
        raw = conf.get("takeover") if hasattr(conf, "get") else None
        if isinstance(raw, dict):
            return bool(raw.get(key, True))
    except Exception:
        pass
    return True


def _t_run_templates(engine, args):
    """r88：「用模板库跑一遍目标」——把确定性模板引擎也交给 AI 调用。

    历史缺口：AI 可见工具 20 个，能调 sqli/xss/ssrf 等单点检测，却**没有
    任何入口调用模板引擎**（templates/*.yaml，包含未授权访问、泄露、组件
    漏洞等 143 条规则）。于是 AI 只能自己造 payload，用不上项目积累的规则库。
    这里只做转发，不含任何新检测逻辑。
    """
    from modules import template_engine
    return template_engine.run_templates(
        str(args["base_url"]), engine.client,
        host=str(args.get("host") or ""),
        max_requests=int(args.get("max_requests") or 200))
def _schema(name, desc, props, required):
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": {
                "type": "object",
                "properties": props,
                "required": required,
            },
        },
    }


def _p_str(desc):
    return {"type": "string", "description": desc}


# ------------------------------------------------------------ 工具实现
# 每个实现签名统一为 fn(engine, args) -> 任意可序列化对象。
# 只调用 modules/ 里实测存在的函数，不新增任何检测逻辑。

def _t_dns_query(engine, args):
    from modules import recon
    return recon.dns_query(str(args["host"]), str(args.get("rtype") or "A"))


def _t_check_takeover(engine, args):
    from modules import recon
    return recon.check_takeover(str(args["host"]), engine.client)


def _t_enumerate_subdomains(engine, args):
    from modules import recon
    return recon.enumerate_subdomains(str(args["domain"]), engine.client,
                                       db=engine.db, config=engine.config)


def _t_probe_host(engine, args):
    from modules import probe
    return probe.probe_host(str(args["host"]), engine.client,
                            db=engine.db, diag={})


def _t_probe_sensitive_paths(engine, args):
    from modules import probe
    return probe.probe_sensitive_paths(str(args["base_url"]), engine.client,
                                       db=engine.db, host=str(args.get("host") or ""))


def _t_dir_bruteforce(engine, args):
    from modules import probe
    words = args.get("words")
    if isinstance(words, list) and words:
        words = [str(w) for w in words][:200]
    else:
        words = None
    return probe.dir_bruteforce(str(args["base_url"]), engine.client,
                                words=words, db=engine.db, workers=1)


def _t_scan_secrets(engine, args):
    from modules import probe
    url = str(args["url"])
    r = engine.client.get(url)
    if r is None:
        return {"url": url, "error": "no_response"}
    return probe.scan_secrets(url, getattr(r, "text", "") or "")


def _t_check_sqli(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_sqli(
        str(args["url"]), engine.client,
        params=args.get("params") or None,
        method=str(args.get("method") or "GET"),
        body=args.get("body") or None,
        extra_payloads=args.get("payloads") or None)


def _t_check_xss(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_xss(
        str(args["url"]), engine.client,
        params=args.get("params") or None,
        method=str(args.get("method") or "GET"),
        body=args.get("body") or None,
        extra_payloads=args.get("payloads") or None)


def _t_check_open_redirect(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_open_redirect(
        str(args["url"]), engine.client,
        params=args.get("params") or None,
        method=str(args.get("method") or "GET"),
        body=args.get("body") or None)


def _t_check_ssrf(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_ssrf(
        str(args["url"]), engine.client,
        params=args.get("params") or None,
        oob_domain=str(args.get("oob_domain") or ""),
        echo_url=str(args.get("echo_url") or ""),
        method=str(args.get("method") or "GET"),
        body=args.get("body") or None)




def _t_check_jwt_weak(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_jwt_weak_key(
        str(args["base_url"]), engine.client,
        max_tokens=int(args.get("max_tokens") or 3))

def _t_check_cors(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_cors(str(args["url"]), engine.client)


def _t_check_open_api_auth(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_open_api_auth(str(args["base_url"]), engine.client)


def _t_check_user_enum(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_user_enum(str(args["base_url"]), engine.client)


def _t_check_hardcoded_key(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_hardcoded_key(str(args["base_url"]), engine.client)


def _t_check_token_reuse(engine, args):
    from modules import vulnchecks
    return vulnchecks.check_token_reuse(str(args["base_url"]), engine.client)


def _t_check_unauthorized(engine, args):
    """先探敏感路径，再把命中转成漏洞项（与引擎 scan_host 同口径）。"""
    from modules import probe, vulnchecks
    base = str(args["base_url"])
    hits = probe.probe_sensitive_paths(base, engine.client, db=engine.db,
                                       host=str(args.get("host") or ""))
    if not hits:
        return {"base_url": base, "hits": 0, "findings": []}
    return vulnchecks.check_unauthorized(hits, engine.client, db=engine.db)


def _t_verify_sqli(engine, args):
    from modules import poc
    return poc.verify_sqli(str(args["url"]), engine.client,
                           str(args["param"]),
                           method=str(args.get("method") or "GET"),
                           body=args.get("body") or None)


def _t_verify_xss(engine, args):
    from modules import poc
    return poc.verify_xss(str(args["url"]), engine.client,
                          str(args["param"]),
                          method=str(args.get("method") or "GET"),
                          body=args.get("body") or None)


def _t_verify_open_redirect(engine, args):
    from modules import poc
    return poc.verify_open_redirect(str(args["url"]), engine.client,
                                    str(args["param"]),
                                    method=str(args.get("method") or "GET"),
                                    body=args.get("body") or None)


# ------------------------------------------------------------ 注册表
_URL_P = _p_str("目标 URL 或主机名（必须落在授权范围内）")

TOOLS = {
    # ---- 侦察（被动/半被动，不出网或仅 DNS） ----
    "dns_query": {
        "schema": _schema("dns_query", "解析主机名的 DNS 记录，返回 A/AAAA 等结果。",
                          {"host": _p_str("主机名，如 example.com"),
                           "rtype": _p_str("记录类型，默认 A")}, ["host"]),
        "call": _t_dns_query, "gate": "", "risk": "low", "net": False,
    },
    "check_takeover": {
        "schema": _schema("check_takeover", "检测子域是否存在子域接管（悬空 CNAME）。",
                          {"host": _p_str("待检测主机名")}, ["host"]),
        "call": _t_check_takeover, "gate": "", "risk": "low", "net": True,
    },
    "enumerate_subdomains": {
        "schema": _schema("enumerate_subdomains", "枚举域名的子域（证书透明 + 字典爆破）。",
                          {"domain": _p_str("根域名，如 example.com")}, ["domain"]),
        "call": _t_enumerate_subdomains, "gate": GATE_ACTIVE, "risk": "medium",
        "net": True,
    },
    # ---- 探测 ----
    "probe_host": {
        "schema": _schema("probe_host", "探测单主机是否存活，返回状态码/标题/技术栈。",
                          {"host": _p_str("主机名或 URL")}, ["host"]),
        "call": _t_probe_host, "gate": "", "risk": "low", "net": True,
    },
    "probe_sensitive_paths": {
        "schema": _schema("probe_sensitive_paths", "探测常见敏感路径（后台/配置/备份等）。",
                          {"base_url": _URL_P,
                           "host": _p_str("可选，主机名标注用")}, ["base_url"]),
        "call": _t_probe_sensitive_paths, "gate": GATE_ACTIVE, "risk": "medium",
        "net": True,
    },
    "dir_bruteforce": {
        "schema": _schema("dir_bruteforce", "目录爆破，返回命中的路径与状态码。",
                          {"base_url": _URL_P,
                           "words": {"type": "array", "items": {"type": "string"},
                                     "description": "可选，自定义字典（最多 200 条）"}},
                          ["base_url"]),
        "call": _t_dir_bruteforce, "gate": GATE_ACTIVE, "risk": "medium", "net": True,
    },
    "scan_secrets": {
        "schema": _schema("scan_secrets", "抓取 URL 响应体并扫描密钥/内网 IP/身份证等敏感信息。",
                          {"url": _URL_P}, ["url"]),
        "call": _t_scan_secrets, "gate": "", "risk": "low", "net": True,
    },
    "run_templates": {
        "schema": _schema("run_templates",
                          "用项目内置模板库（未授权访问/信息泄露/组件漏洞等 YAML 规则）扫描目标根地址，返回命中项。比逐个 check_* 覆盖更广，建议优先调用。",

                          {"base_url": _URL_P,
                           "host": _p_str("可选，主机名标注用"),
                           "max_requests": {"type": "integer",
                                            "description": "可选，本次最多发多少请求，默认 200"}},
                          ["base_url"]),
        "call": _t_run_templates, "gate": GATE_ACTIVE, "risk": "medium", "net": True,
    },
    # ---- 检测 ----
    "check_sqli": {
        "schema": _schema("check_sqli", "对 URL 参数做 SQL 注入检测。",
                          {"url": _URL_P,
                           "params": {"type": "array", "items": {"type": "string"},
                                      "description": "可选，指定参数名"},
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object", "description": "可选，POST 表单字段"},
                           "payloads": {"type": "array", "items": {"type": "string"},
                                        "description": "optional AI-supplied payloads (max 12)"},
                          },
                          ["url"]),
        "call": _t_check_sqli, "gate": GATE_ACTIVE, "risk": "high", "net": True,
    },
    "check_xss": {
        "schema": _schema("check_xss", "对 URL 参数做 XSS 检测。",
                          {"url": _URL_P,
                           "params": {"type": "array", "items": {"type": "string"}},
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object"},
                           "payloads": {"type": "array", "items": {"type": "string"},
                                        "description": "optional AI-supplied payloads (max 12)"},
                          },
                          ["url"]),
        "call": _t_check_xss, "gate": GATE_ACTIVE, "risk": "high", "net": True,
    },
    "check_open_redirect": {
        "schema": _schema("check_open_redirect", "检测 URL 跳转参数是否存在开放重定向。",
                          {"url": _URL_P,
                           "params": {"type": "array", "items": {"type": "string"}},
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object"}},
                          ["url"]),
        "call": _t_check_open_redirect, "gate": GATE_ACTIVE, "risk": "high",
        "net": True,
    },
    "check_ssrf": {
        "schema": _schema("check_ssrf", "检测 URL 参数是否存在 SSRF。",
                          {"url": _URL_P,
                           "params": {"type": "array", "items": {"type": "string"}},
                           "oob_domain": _p_str("可选，外带域名"),
                           "echo_url": _p_str("可选，回显探针地址模板，含 %s 占位；留空则不启用回显检测"),
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object"}},
                          ["url"]),
        "call": _t_check_ssrf, "gate": GATE_ACTIVE, "risk": "high", "net": True,
    },
    "check_jwt_weak": {
        "schema": _schema("check_jwt_weak", "检测 JWT 是否使用弱密钥签名（仅 HS 系列，本地离线复算签名，不发送伪造 token）。",
                          {"base_url": _URL_P,
                           "max_tokens": {"type": "integer"}},
                          ["base_url"]),
        "call": _t_check_jwt_weak, "gate": GATE_ACTIVE, "risk": "high",
        "net": True,
    },
    "check_cors": {
        "schema": _schema("check_cors", "检测目标 CORS 配置是否过宽。",
                          {"url": _URL_P}, ["url"]),
        "call": _t_check_cors, "gate": "", "risk": "low", "net": True,
    },
    "check_open_api_auth": {
        "schema": _schema("check_open_api_auth",
                          "检测开放 API 注册端点是否未鉴权且直接下发会话凭据。",
                          {"base_url": _URL_P}, ["base_url"]),
        "call": _t_check_open_api_auth, "gate": GATE_ACTIVE, "risk": "high",
        "net": True,
    },
    "check_user_enum": {
        "schema": _schema("check_user_enum",
                          "检测登录/校验接口是否泄露用户名存在性（账号枚举）。",
                          {"base_url": _URL_P}, ["base_url"]),
        "call": _t_check_user_enum, "gate": GATE_ACTIVE, "risk": "medium",
        "net": True,
    },
    "check_hardcoded_key": {
        "schema": _schema("check_hardcoded_key",
                          "检测前端可读位置是否内联硬编码公钥/证书材料。",
                          {"base_url": _URL_P}, ["base_url"]),
        "call": _t_check_hardcoded_key, "gate": GATE_ACTIVE, "risk": "medium",
        "net": True,
    },
    "check_token_reuse": {
        "schema": _schema("check_token_reuse",
                          "检测同一会话凭据是否跨多条端点复用（服务端静态下发）。",
                          {"base_url": _URL_P}, ["base_url"]),
        "call": _t_check_token_reuse, "gate": GATE_ACTIVE, "risk": "medium",
        "net": True,
    },
    "check_unauthorized": {
        "schema": _schema("check_unauthorized",
                          "探测敏感路径并把可直接访问的命中转成未授权访问漏洞项。",
                          {"base_url": _URL_P,
                           "host": _p_str("可选，主机名标注用")}, ["base_url"]),
        "call": _t_check_unauthorized, "gate": GATE_ACTIVE, "risk": "medium",
        "net": True,
    },
    # ---- 核验（PoC 复现，闸门最严） ----
    "verify_sqli": {
        "schema": _schema("verify_sqli", "对疑似 SQL 注入做 PoC 复现核验。",
                          {"url": _URL_P, "param": _p_str("参数名"),
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object"}},
                          ["url", "param"]),
        "call": _t_verify_sqli, "gate": GATE_POC, "risk": "high", "net": True,
    },
    "verify_xss": {
        "schema": _schema("verify_xss", "对疑似 XSS 做 PoC 复现核验。",
                          {"url": _URL_P, "param": _p_str("参数名"),
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object"}},
                          ["url", "param"]),
        "call": _t_verify_xss, "gate": GATE_POC, "risk": "high", "net": True,
    },
    "verify_open_redirect": {
        "schema": _schema("verify_open_redirect", "对疑似开放重定向做 PoC 复现核验。",
                          {"url": _URL_P, "param": _p_str("参数名"),
                           "method": _p_str("GET 或 POST"),
                           "body": {"type": "object"}},
                          ["url", "param"]),
        "call": _t_verify_open_redirect, "gate": GATE_POC, "risk": "high",
        "net": True,
    },
}

# 外部工具源（MCP 等）注册位：与内建工具共用同一套四道校验与执行入口。
EXTERNAL = {}

# AI 可直调的内建工具名集合（其余内部函数一律不可见）
TOOL_NAMES = tuple(TOOLS.keys())

# 出网目标参数名候选：用于授权前置检查
_URL_KEYS = ("url", "base_url", "host", "domain")


def register_external(name, schema, call, gate="", risk="medium", net=True,
                      target_key=""):
    """注册一个外部工具（MCP）。

    注册进来的工具**必须**走同一个 :func:`run_tool`，因此自动获得参数白名单、
    授权前置、强度闸门、预算闸门、结果截断五道保护，不存在绕过路径。
    ``target_key`` 用于声明该工具的"出网目标参数名"（MCP 工具命名不固定，
    声明后授权前置才能认出目标）。
    """
    if not isinstance(name, str) or not name:
        return False
    if not isinstance(schema, dict) or "function" not in schema:
        return False
    if not callable(call):
        return False
    EXTERNAL[name] = {"schema": schema, "call": call, "gate": gate,
                      "risk": risk, "net": bool(net), "external": True,
                      "target_key": str(target_key or "")}
    return True


def clear_external():
    EXTERNAL.clear()


def all_specs():
    """内建 + 外部工具全集（内建优先，同名时外部不得覆盖）。"""
    d = _with_defaults(dict(EXTERNAL))
    d.update(_with_defaults(TOOLS))
    return d


def _with_defaults(specs):
    """内建工具条目补齐 target_key 字段（保持结构一致）。"""
    for sp in specs.values():
        sp.setdefault("target_key", "")
    return specs


def schemas(include_external=True):
    """返回可直接塞进请求体 ``tools`` 键的 schema 列表。"""
    specs = all_specs() if include_external else TOOLS
    return [t["schema"] for t in specs.values()]


def _target_of(args, spec=None):
    """从参数里认出"出网目标"。

    外部工具（MCP）的参数名不固定，注册时可用 ``target_key`` 显式声明；
    声明了就以它为准，否则按常见命名依次尝试。
    """
    keys = []
    if isinstance(spec, dict):
        tk = spec.get("target_key")
        if isinstance(tk, str) and tk:
            keys.append(tk)
    keys.extend(_URL_KEYS)
    for k in keys:
        v = args.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _truncate(obj):
    try:
        s = json.dumps(obj, ensure_ascii=False, default=str)
    except Exception:
        s = json.dumps({"repr": repr(obj)[:MAX_RESULT_CHARS]}, ensure_ascii=False)
    if len(s) > MAX_RESULT_CHARS:
        return {"truncated": True, "chars": len(s),
                "preview": s[:MAX_RESULT_CHARS]}
    try:
        return json.loads(s)
    except Exception:
        return {"raw": s}


def run_tool(engine, name, args):
    """唯一执行入口。任何失败都返回 ``{"error": ...}``，不抛异常。

    返回 ``{"ok": bool, "name": str, "result": ...}``。
    """
    def err(code, **kw):
        d = {"ok": False, "name": name, "error": code}
        d.update(kw)
        return d

    specs = all_specs()
    if name not in specs:
        return err("unknown_tool")
    spec = specs[name]
    if not isinstance(args, dict):
        args = {}
    # 1) 参数白名单：只留 schema 里声明过的键
    allowed = set((spec["schema"]["function"]["parameters"]
                   .get("properties") or {}).keys())
    clean = {k: v for k, v in args.items() if k in allowed}
    # round87 D2: an argument name the schema does not know used to be
    # dropped in silence, so the CLI received nothing and printed
    # "usage: ... error: the following arguments are required: --domain".
    # The model then saw a useless stderr blob. Report the mismatch
    # together with the real parameter names so it can self-correct.
    dropped = [k for k in args.keys() if k not in allowed]
    if dropped and not clean:
        return err("bad_arg_names", dropped=dropped,
                   expects=sorted(allowed),
                   required=list((spec["schema"]["function"]["parameters"]
                                  .get("required") or [])))
    # 2) 必填校验
    for req in (spec["schema"]["function"]["parameters"].get("required") or []):
        if not str(clean.get(req) or "").strip():
            return err("missing_arg", arg=req)
    # 3) 授权前置
    target = _target_of(clean, spec)
    if spec.get("net") and target:
        try:
            ok, reason = engine.scope.check(_norm_host(target), purpose="ai:%s" % name)
        except Exception as e:
            return err("scope_error", detail=str(e))
        if not ok:
            return err("out_of_scope", target=target, reason=reason)
    # 4) 强度闸门
    gate = spec.get("gate") or ""
    # round93 FIX-36：两层都得过 —— 扫描档位（能力上限）+ AI 侧授权位。
    # 前者是全局的，后者才是「单独把 AI 关成只出候选」的开关。
    # by 字段告诉模型到底是哪个闸关闭了，避免它把「被拒」当成「没发现」
    # 而反复重试同一个工具。
    if GATE_ACTIVE in gate:
        if not getattr(engine, "enable_active", False):
            return err("gate_closed", gate="active", by="scan.mode")
        if not _tk_allow(engine, "allow_active"):
            return err("gate_closed", gate="active", by="takeover.allow_active")
    if GATE_POC in gate:
        if not getattr(engine, "enable_poc", False):
            return err("gate_closed", gate="poc", by="scan.mode")
        if not _tk_allow(engine, "allow_poc"):
            return err("gate_closed", gate="poc", by="takeover.allow_poc")
    # 5) 预算闸门 + 停止闸门
    if getattr(engine, "_stop", False):
        return err("stopped")
    if spec.get("net") and target:
        try:
            if not engine._budget_ok(_norm_host(target)):
                return err("budget_exhausted", target=target)
        except Exception:
            pass
    # 6) 执行
    try:
        out = spec["call"](engine, clean)
    except Exception as e:
        return err("exec_error", detail=str(e)[:300])
    # round87 D3: surface CLI usage errors as structured hints.
    # A child script that dies with "usage: x.py ... required: --domain"
    # returned ok=True with a stderr blob; the model treated that as
    # "no findings" and kept repeating the same wrong call.
    try:
        # round89: MCP 插件用 {"error": ...} / isError 表达调用失败。
        # 这种情形不是参数问题，必须单独报 tool_failed，否则模型会把
        # "网络不通" 当成 "扫过了没发现"，白跑一轮。
        _mcpfail = _mcp_error_result(out)
        if _mcpfail:
            return {"ok": False, "name": name, "error": "tool_failed",
                    "detail": _mcpfail.get("detail", ""),
                    "plugin": _mcpfail.get("plugin", ""),
                    "result": _truncate(out)}
        _hint = _usage_hint(out)
        if _hint:
            return {"ok": False, "name": name, "error": "bad_args",
                    "detail": _hint.get("detail", ""),
                    "expects": _hint.get("expects") or [],
                    "result": _truncate(out)}
    except Exception:
        pass
    return {"ok": True, "name": name, "result": _truncate(out)}


# MCP 工具的结构化错误标记：插件用 {"error": "..."} 表达"调用失败"，
# 不是参数问题。round89 前 _usage_hint 只认 usage:/required:，所以插件
# 返回 error 时被当成成功，模型会把"网络不通"误读成"没有发现"。
_ERR_MARKERS = ("urlerror:", "httperror:", "connection refused",
                "connection reset", "timed out", "timeout", "ssl:",
                "name or service not known", "temporary failure in name")

def _mcp_error_result(out):
    """MCP 结果里带结构化 error 或 isError 时，转成失败结果。

    只认"明确失败"信号：``isError`` 为真，或文本里出现 JSON 的
    ``"error":`` 键。纯自然语言里出现 error 字样不算，避免把正常
    输出的诊断文本误判成失败。
    返回 ``None`` 表示没发现失败信号。
    """
    if not isinstance(out, dict):
        return None
    if out.get("isError"):
        return {"detail": str(out.get("text") or "")[:300]}
    txt = str(out.get("text") or "")
    if not txt.strip():
        return None
    low = txt.lower()
    has_key = ('"error"' in low) or ("'error'" in low)
    if not has_key and not any(k in low for k in _ERR_MARKERS):
        return None
    try:
        obj = json.loads(txt)
    except Exception:
        obj = None
    if isinstance(obj, dict):
        if obj.get("error"):
            return {"detail": str(obj.get("error"))[:300],
                    "plugin": str(obj.get("engine") or "")}
        return None
    if any(k in low for k in _ERR_MARKERS):
        return {"detail": txt.strip()[:300]}
    return None

def _usage_hint(out):
    """round87 D3: pull "required: --x --y" out of a stderr blob."""
    import re as _re
    txt = ""
    if isinstance(out, dict):
        txt = str(out.get("stderr") or "") + " " + str(out.get("text") or "")
    else:
        txt = str(out or "")
    # round89: 只认 argparse 的 usage/required 形态。之前只要出现 "error:"
    # 就判定为参数错误，导致插件返回的 {"error": "URLError..."}（网络不通）
    # 被误标成 bad_args，模型得到"参数写错了"的错误指引。
    _low = txt.lower()
    _argparse = ("usage:" in _low) or ("required:" in _low)
    if _argparse:
        found = []
        m = _re.search(r'required:([^\n\r]+)', txt)
        if m:
            found = [x.strip() for x in _re.split(r'[,\s]+', m.group(1)) if x.strip()]
        expects = [x.lstrip('-') for x in found]
        return {'detail': txt.strip()[:300], 'expects': expects}
    return None
